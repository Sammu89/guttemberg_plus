/**
 * Theme Selector Component
 *
 * Dropdown for selecting themes with create/update/delete/rename operations.
 * Shows "(customized)" suffix when block has customizations.
 *
 * @see docs/UI-UX/40-EDITOR-UI-PANELS.md
 * @package
 * @since 1.0.0
 */

import { SelectControl, Button, Modal, TextControl } from '@wordpress/components';
import { useState, useEffect } from '@wordpress/element';

/**
 * Theme Selector Component
 *
 * @param {Object}   props                 Component props
 * @param {string}   props.blockType       Block type: 'accordion', 'tabs', or 'toc'
 * @param {string}   props.currentTheme    Current theme name
 * @param {boolean}  props.isCustomized    Whether block has customizations
 * @param {Object}   props.themes          All available themes
 * @param {boolean}  props.themesLoaded    Whether themes have been loaded
 * @param {Object}   props.attributes      Block attributes (optional)
 * @param {Object}   props.effectiveValues Effective values from cascade (optional)
 * @param {Function} props.onSaveNew       Callback to save as new theme (optional)
 * @param {Function} props.onUpdate        Callback to update current theme (optional)
 * @param {Function} props.onDelete        Callback to delete theme (optional)
 * @param {Function} props.onRename        Callback to rename theme (optional)
 * @param {Function} props.onReset         Callback to reset customizations (optional)
 * @param {Function} props.onThemeChange   Callback when theme changes (handles reset-and-apply) (optional)
 * @param {Object}   props.sessionCache    Session-only cache of customizations per theme (optional)
 */
export function ThemeSelector( {
	blockType,
	currentTheme,
	isCustomized,
	themes = {},
	themesLoaded = false,
	attributes = {},
	effectiveValues = {},
	onSaveNew,
	onUpdate,
	onDelete,
	onRename,
	onReset,
	onThemeChange,
	sessionCache = {},
} ) {
	const [ showCreateModal, setShowCreateModal ] = useState( false );
	const [ showRenameModal, setShowRenameModal ] = useState( false );
	const [ newThemeName, setNewThemeName ] = useState( '' );

	// Log when currentTheme prop changes (for debugging theme switching)
	useEffect( () => {}, [ currentTheme, isCustomized, themes ] );

	// Handle theme change
	const handleThemeChange = ( value ) => {
		// Parse value - might be "themeName" or "themeName::customized"
		const isCustomizedVariant = value.endsWith( '::customized' );
		const themeName = isCustomizedVariant ? value.replace( '::customized', '' ) : value;

		// If onThemeChange callback provided, use it (new architecture - session-only cache)
		if ( onThemeChange ) {
			// Pass theme name and flag indicating if user wants customized variant
			onThemeChange( themeName, isCustomizedVariant );
		}
	};

	// Prepare theme options for dropdown
	// Shows BOTH clean and customized variants when sessionCache exists
	const themeOptions = [];

	// Add Default options
	themeOptions.push( {
		label: 'Default',
		value: '',
	} );

	// If Default has customizations in session cache, add "Default (customized)"
	if ( sessionCache[ '' ] ) {
		themeOptions.push( {
			label: 'Default (customized)',
			value: '::customized', // Special marker for customized Default
		} );
	}

	// Add saved theme options
	Object.keys( themes || {} ).forEach( ( name ) => {
		// Clean theme
		themeOptions.push( {
			label: name,
			value: name,
		} );

		// Customized variant if exists in session cache
		if ( sessionCache[ name ] ) {
			themeOptions.push( {
				label: `${ name } (customized)`,
				value: `${ name }::customized`,
			} );
		}
	} );

	// Determine current dropdown value based on whether using customizations
	const dropdownValue = isCustomized
		? currentTheme === ''
			? '::customized'
			: `${ currentTheme }::customized`
		: currentTheme;

	// Debug what we're rendering

	return (
		<div className="theme-selector">
			<SelectControl
				label="Theme"
				value={ dropdownValue }
				options={ themeOptions }
				onChange={ handleThemeChange }
				__next40pxDefaultSize
			/>

			<div
				className="theme-actions"
				style={ {
					display: 'grid',
					gridTemplateColumns: '1fr 1fr',
					gap: '8px',
					marginTop: '12px',
				} }
			>
				<Button
					size="small"
					variant="secondary"
					onClick={ () => setShowCreateModal( true ) }
					disabled={ ! isCustomized }
				>
					Save as New Theme
				</Button>

				<Button
					size="small"
					variant="secondary"
					onClick={ onUpdate }
					disabled={ ! isCustomized || currentTheme === '' }
				>
					Update Theme
				</Button>

				<Button
					size="small"
					variant="secondary"
					onClick={ () => setShowRenameModal( true ) }
					disabled={ currentTheme === '' }
				>
					Rename
				</Button>

				<Button
					size="small"
					variant="secondary"
					onClick={ onDelete }
					disabled={ currentTheme === '' }
					isDestructive
				>
					Delete
				</Button>

				<Button
					size="small"
					variant="tertiary"
					onClick={ onReset }
					disabled={ ! isCustomized }
					style={ { gridColumn: '1 / -1' } }
				>
					Reset Modifications
				</Button>
			</div>

			{ showCreateModal && (
				<Modal
					title="Create New Theme"
					onRequestClose={ () => setShowCreateModal( false ) }
				>
					<TextControl
						label="Theme Name"
						value={ newThemeName }
						onChange={ setNewThemeName }
						placeholder="Enter theme name"
						__nextHasNoMarginBottom
					/>
					<Button
						variant="primary"
						onClick={ () => {
							onSaveNew( newThemeName );
							setShowCreateModal( false );
							setNewThemeName( '' );
						} }
					>
						Create Theme
					</Button>
				</Modal>
			) }

			{ showRenameModal && (
				<Modal title="Rename Theme" onRequestClose={ () => setShowRenameModal( false ) }>
					<TextControl
						label="New Theme Name"
						value={ newThemeName }
						onChange={ setNewThemeName }
						placeholder={ currentTheme }
						__nextHasNoMarginBottom
					/>
					<Button
						variant="primary"
						onClick={ () => {
							onRename( currentTheme, newThemeName );
							setShowRenameModal( false );
							setNewThemeName( '' );
						} }
					>
						Rename
					</Button>
				</Modal>
			) }
		</div>
	);
}

export default ThemeSelector;
