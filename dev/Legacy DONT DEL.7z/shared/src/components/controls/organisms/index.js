/**
 * Organisms Index
 *
 * Export all organism components from a single entry point.
 *
 * @package
 */

export { CompactBoxRow } from './CompactBoxRow';
