# Customization Core - API Reference

**Version:** v2.0 (v6.0 Architecture Alignment)
**Last Updated:** 2025-10-12

Complete API documentation for the centralized customization core system, adapted to the Accordion Block attributes as defined in BLOCK-ATTRIBUTES-SCHEMA.md.

**v6.0 Architecture:** This system now aligns with the CSS-as-single-source-of-truth architecture. All defaults are defined in `accordion.css` and parsed by PHP, then passed to JavaScript via `wp_localize_script`.

---

## Table of Contents

1. [v6.0 Architecture: CSS as Single Source of Truth](#v60-architecture-css-as-single-source-of-truth)
2. [Core Modules](#core-modules)
3. [WordPress Adapters](#wordpress-adapters)
4. [React Hooks](#react-hooks)
5. [Configuration](#configuration)
6. [Usage Examples](#usage-examples)
7. [Integration Guide](#integration-guide)
8. [Changelog](#changelog)

---

## v6.0 Architecture: CSS as Single Source of Truth

### Overview

Version 6.0 introduces a fundamental architectural change: all default values are defined in `accordion.css` as CSS custom properties, making it the single source of truth.

### How It Works

**1. CSS File (Single Source):**
```css
/* assets/css/accordion.css */
:root {
  --accordion-default-title-color: #333333;
  --accordion-default-title-bg: #f5f5f5;
  /* ... all defaults */
}
```

**2. PHP Parsing:**
```php
$defaults = get_accordion_plugin_defaults();
// Parses CSS, caches with filemtime, returns array
```

**3. JavaScript Access:**
```php
wp_localize_script('accordion-editor', 'accordionDefaults', $defaults);
```
```javascript
const DEFAULTS = window.accordionDefaults || {};
```

**4. Attribute Registration:**
```javascript
titleColor: { type: 'string', default: null } // Uses cascade
```

### Benefits

- **Single Maintenance Point**: Change CSS file, everything updates
- **Cache Invalidation**: Automatic via file modification time
- **No Duplication**: Defaults not scattered across PHP/JS files
- **CSS-First**: Defaults available on frontend without JavaScript

### Behavioral Defaults

Some defaults cannot be CSS variables (boolean logic, string identifiers):
- `showIcon`, `iconPosition`, `iconTypeClosed`, `iconTypeOpen`
- `iconRotation`, `initiallyOpen`, `headingLevel`, `useHeadingStyles`

These are hardcoded in the PHP parsing function.

### Null Inheritance

Some attributes inherit from others when null (resolved in PHP):
- `iconColor` ← `titleColor`
- `iconSize` ← `titleFontSize`
- `hoverTitleColor` ← `titleColor`
- `activeTitleColor` ← `titleColor`
- `activeTitleBackgroundColor` ← `titleBackgroundColor`

### The Cascade Resolution

The system uses a 3-tier cascade:

1. **Block Attributes** (highest priority) - Per-accordion customizations
2. **Theme** - Saved theme values
3. **Defaults** - From `window.accordionDefaults` (parsed from CSS)

The default tier values come from PHP parsing `accordion.css`, ensuring consistency across frontend and editor.

---

## Core Modules

Location: `blocks/shared/customization-core/`

### constants.js

#### `ERROR_MESSAGES`
```javascript
const ERROR_MESSAGES = {
	INVALID_ATTRIBUTE_CONFIG: 'Attribute configuration is invalid...',
	INVALID_ATTRIBUTE_NAME: 'Attribute name does not exist...',
	INVALID_ATTRIBUTE_VALUE: 'Attribute value does not match...',
	INVALID_THEME_DATA: 'Theme data structure is invalid',
	MISSING_REQUIRED_FIELD: 'Required field is missing',
	TYPE_MISMATCH: 'Value type does not match configuration',
}
```

#### `VALID_ATTRIBUTE_TYPES`
```javascript
const VALID_ATTRIBUTE_TYPES = ['string', 'number', 'boolean', 'object', 'array']
```

#### `DEFAULT_SECTION`
```javascript
const DEFAULT_SECTION = 'general'
```

#### `RESERVED_THEME_KEYS`
```javascript
const RESERVED_THEME_KEYS = ['id', 'theme_id', 'name', 'theme_name', 'updated']
```

---

### validation.js

#### `validateAttributeConfig(attributeConfig)`

Validates an attribute configuration object.

**Parameters:**
- `attributeConfig` (Object): Configuration object with attribute definitions

**Returns:**
- `Object`: `{ valid: boolean, errors: Array<string> }`

**Example:**
```javascript
import { validateAttributeConfig } from '../shared/customization-core';

const config = {
	titleBackgroundColor: {
		type: 'string',
		defaultValue: '#f5f5f5',
		section: 'titleColors',
	},
};

const result = validateAttributeConfig(config);
if (!result.valid) {
	console.error('Config errors:', result.errors);
}
```

#### `validateAttributeValue(attributeName, value, attributeConfig)`

Validates a single attribute value against its configuration.

**Parameters:**
- `attributeName` (string): Name of the attribute
- `value` (any): Value to validate
- `attributeConfig` (Object): Configuration object

**Returns:**
- `Object`: `{ valid: boolean, error: string|null }`

**Example:**
```javascript
const result = validateAttributeValue('titleBackgroundColor', '#ff0000', ACCORDION_ATTRIBUTE_CONFIG);
if (!result.valid) {
	console.error('Validation error:', result.error);
}
```

#### `sanitizeAttributeValue(attributeName, value, attributeConfig)`

Sanitizes and coerces an attribute value to match its expected type.

**Parameters:**
- `attributeName` (string): Name of the attribute
- `value` (any): Value to sanitize
- `attributeConfig` (Object): Configuration object

**Returns:**
- `any`: Sanitized value

**Example:**
```javascript
const sanitized = sanitizeAttributeValue('accordionBorderThickness', '5', ACCORDION_ATTRIBUTE_CONFIG);
// Returns: 5 (number)
```

---

### attribute-resolver.js

#### `resolveValueWithPriority(blockValue, themeValue, defaultValue)`

Resolves a single value using priority cascade: block → theme → default.

**Parameters:**
- `blockValue` (any): Value from block attributes
- `themeValue` (any): Value from theme
- `defaultValue` (any): Default value from config

**Returns:**
- `any`: The effective value

**Example:**
```javascript
import { resolveValueWithPriority } from '../shared/customization-core';

const effective = resolveValueWithPriority('#ff0000', '#00ff00', '#000000');
// Returns: '#ff0000' (block value has highest priority)

const effective2 = resolveValueWithPriority(null, '#00ff00', '#000000');
// Returns: '#00ff00' (falls back to theme)
```

#### `computeEffectiveValue(attributeName, blockAttributes, theme, attributeConfig)`

Computes the effective value for a single attribute.

**Parameters:**
- `attributeName` (string): Name of the attribute
- `blockAttributes` (Object): Block attributes object
- `theme` (Object|null): Theme object
- `attributeConfig` (Object): Configuration object

**Returns:**
- `any`: The effective value for the attribute

**Example:**
```javascript
const effectiveColor = computeEffectiveValue(
	'titleBackgroundColor',
	attributes,
	currentTheme,
	ACCORDION_ATTRIBUTE_CONFIG
);
```

#### `computeEffectiveValues(blockAttributes, theme, attributeConfig)`

Computes effective values for ALL attributes in the configuration.

**Parameters:**
- `blockAttributes` (Object): Block attributes object
- `theme` (Object|null): Theme object
- `attributeConfig` (Object): Configuration object

**Returns:**
- `Object`: Object with all effective values

**Example:**
```javascript
import { computeEffectiveValues } from '../shared/customization-core';

const effectiveValues = computeEffectiveValues(
	attributes,
	currentTheme,
	ACCORDION_ATTRIBUTE_CONFIG
);

console.log(effectiveValues.titleBackgroundColor); // '#ff0000'
console.log(effectiveValues.accordionBorderThickness); // 2
```

---

### customization-detector.js

#### `isAttributeCustomized(attributeName, blockAttributes, theme, attributeConfig)`

Checks if a single attribute is customized (differs from theme/default).

**Parameters:**
- `attributeName` (string): Name of the attribute
- `blockAttributes` (Object): Block attributes object
- `theme` (Object|null): Theme object
- `attributeConfig` (Object): Configuration object

**Returns:**
- `boolean`: True if customized

**Example:**
```javascript
import { isAttributeCustomized } from '../shared/customization-core';

const isCustom = isAttributeCustomized(
	'titleBackgroundColor',
	attributes,
	currentTheme,
	ACCORDION_ATTRIBUTE_CONFIG
);

if (isCustom) {
	console.log('User has customized the title background color');
}
```

**Special handling:**
- Respects `treatFalseAsCustomization` flag for boolean attributes
- Handles toggle attributes with `childAttributes`
- Handles `null` vs `undefined` vs explicit values

#### `detectAllCustomizations(blockAttributes, theme, attributeConfig)`

Detects all customized attributes.

**Parameters:**
- `blockAttributes` (Object): Block attributes object
- `theme` (Object|null): Theme object
- `attributeConfig` (Object): Configuration object

**Returns:**
- `Array<string>`: Array of customized attribute names

**Example:**
```javascript
const customized = detectAllCustomizations(attributes, currentTheme, ACCORDION_ATTRIBUTE_CONFIG);
console.log('Customized attributes:', customized);
// ['titleBackgroundColor', 'accordionBorderThickness']
```

#### `hasAnyCustomizations(blockAttributes, theme, attributeConfig)`

Checks if any attributes are customized.

**Parameters:**
- `blockAttributes` (Object): Block attributes object
- `theme` (Object|null): Theme object
- `attributeConfig` (Object): Configuration object

**Returns:**
- `boolean`: True if any customizations exist

**Example:**
```javascript
const hasCustom = hasAnyCustomizations(attributes, currentTheme, ACCORDION_ATTRIBUTE_CONFIG);
if (hasCustom) {
	showClearCustomizationsButton();
}
```

#### `getCustomizationsBySection(blockAttributes, theme, attributeConfig)`

Groups customized attributes by section.

**Parameters:**
- `blockAttributes` (Object): Block attributes object
- `theme` (Object|null): Theme object
- `attributeConfig` (Object): Configuration object

**Returns:**
- `Object`: Object with sections as keys, arrays of attribute names as values

**Example:**
```javascript
const bySection = getCustomizationsBySection(attributes, currentTheme, ACCORDION_ATTRIBUTE_CONFIG);
console.log(bySection);
// {
//   titleColors: ['titleBackgroundColor', 'titleColor'],
//   border: ['accordionBorderThickness', 'accordionBorderStyle']
// }
```

---

### attribute-operations.js

#### `clearAttributesByList(attributeNames, currentAttributes, attributeConfig)`

Clears specific attributes by resetting them to defaults.

**Parameters:**
- `attributeNames` (Array<string>): Array of attribute names to clear
- `currentAttributes` (Object): Current block attributes
- `attributeConfig` (Object): Configuration object

**Returns:**
- `Object`: Updates object for setAttributes

**Example:**
```javascript
import { clearAttributesByList } from '../shared/customization-core';

const updates = clearAttributesByList(
	['titleBackgroundColor', 'titleColor'],
	attributes,
	ACCORDION_ATTRIBUTE_CONFIG
);

setAttributes(updates);
```

#### `clearAttributesBySection(section, currentAttributes, attributeConfig)`

Clears all attributes in a specific section.

**Parameters:**
- `section` (string): Section name (e.g., 'titleColors', 'border')
- `currentAttributes` (Object): Current block attributes
- `attributeConfig` (Object): Configuration object

**Returns:**
- `Object`: Updates object for setAttributes

**Example:**
```javascript
const updates = clearAttributesBySection('titleColors', attributes, ACCORDION_ATTRIBUTE_CONFIG);
setAttributes(updates);
```

#### `clearAllCustomizations(currentAttributes, attributeConfig)`

Clears all customization attributes.

**Parameters:**
- `currentAttributes` (Object): Current block attributes
- `attributeConfig` (Object): Configuration object

**Returns:**
- `Object`: Updates object for setAttributes

**Example:**
```javascript
const updates = clearAllCustomizations(attributes, ACCORDION_ATTRIBUTE_CONFIG);
setAttributes(updates);
```

#### `resetAttributeToDefault(attributeName, attributeConfig)`

Gets the default value for an attribute.

**Parameters:**
- `attributeName` (string): Name of the attribute
- `attributeConfig` (Object): Configuration object

**Returns:**
- `any`: Default value

**Example:**
```javascript
const defaultColor = resetAttributeToDefault('titleBackgroundColor', ACCORDION_ATTRIBUTE_CONFIG);
// Returns: '#f5f5f5'
```

#### `getAttributeDefaultValue(attributeName, attributeConfig)`

Gets the default value for an attribute (alias for resetAttributeToDefault).

**Parameters:**
- `attributeName` (string): Name of the attribute
- `attributeConfig` (Object): Configuration object

**Returns:**
- `any`: Default value

---

### theme-manager.js

#### `normalizeThemeData(themeData, attributeConfig)`

Normalizes theme data to ensure all attributes are present.

**Parameters:**
- `themeData` (Object): Raw theme data
- `attributeConfig` (Object): Configuration object

**Returns:**
- `Object`: Normalized theme data

**Example:**
```javascript
import { normalizeThemeData } from '../shared/customization-core';

const normalized = normalizeThemeData(rawTheme, ACCORDION_ATTRIBUTE_CONFIG);
```

#### `validateThemeStructure(themeData, attributeConfig)`

Validates theme data structure.

**Parameters:**
- `themeData` (Object): Theme data to validate
- `attributeConfig` (Object): Configuration object

**Returns:**
- `Object`: `{ valid: boolean, errors: Array<string> }`

#### `mergeThemeData(existingTheme, updates, attributeConfig)`

Merges updates into existing theme.

**Parameters:**
- `existingTheme` (Object): Existing theme data
- `updates` (Object): Updates to apply
- `attributeConfig` (Object): Configuration object

**Returns:**
- `Object`: Merged theme data

**Example:**
```javascript
const updated = mergeThemeData(
	currentTheme,
	{ titleBackgroundColor: '#ff0000' },
	ACCORDION_ATTRIBUTE_CONFIG
);
```

#### `extractCustomizationAttributes(blockAttributes, attributeConfig)`

Extracts only customization attributes from block attributes.

**Parameters:**
- `blockAttributes` (Object): Block attributes object
- `attributeConfig` (Object): Configuration object

**Returns:**
- `Object`: Object with only customization attributes

**Example:**
```javascript
const customizations = extractCustomizationAttributes(attributes, ACCORDION_ATTRIBUTE_CONFIG);
// Returns: { titleBackgroundColor: '#ff0000', accordionBorderThickness: 2, ... }
```

#### `prepareThemeForStorage(themeData, attributeConfig)`

Prepares theme data for database storage.

**Parameters:**
- `themeData` (Object): Theme data to prepare
- `attributeConfig` (Object): Configuration object

**Returns:**
- `Object`: Prepared theme data

#### `generateThemeId()`

Generates a unique theme ID.

**Returns:**
- `string`: Theme ID in format 'theme_${timestamp}'

**Example:**
```javascript
import { generateThemeId } from '../shared/customization-core';

const themeId = generateThemeId();
// Returns: 'theme_1696784560123'
```

---

## WordPress Adapters

Location: `blocks/shared/utils/`

### ajax-adapter.js

#### `getAjaxConfig(blockType)`

Gets AJAX configuration for a block type.

**Parameters:**
- `blockType` (string): Block type identifier (e.g., 'accordion', 'tabs')

**Returns:**
- `Object`: `{ ajaxUrl, nonce, actions }`

**Example:**
```javascript
import { getAjaxConfig } from '../shared/utils/ajax-adapter';

const config = getAjaxConfig('accordion');
console.log(config.actions.load); // 'guten_nav_load_accordion_themes'
```

#### `sendAjaxRequest(action, data, options)`

Sends a generic AJAX request.

**Parameters:**
- `action` (string): WordPress AJAX action name
- `data` (Object): Data to send
- `options` (Object): Options `{ timeout, blockType }`

**Returns:**
- `Promise<Object>`: Response data

**Example:**
```javascript
import { sendAjaxRequest } from '../shared/utils/ajax-adapter';

try {
	const response = await sendAjaxRequest(
		'guten_nav_load_accordion_themes',
		{},
		{ blockType: 'accordion', timeout: 30000 }
	);
	console.log('Themes:', response.themes);
} catch (error) {
	console.error('AJAX error:', error.message);
}
```

#### `loadThemes(blockType, options)`

Loads all themes for a block type.

**Parameters:**
- `blockType` (string): Block type identifier
- `options` (Object): Options `{ timeout }`

**Returns:**
- `Promise<Object>`: Object with theme data `{ themes: {...} }`

**Example:**
```javascript
import { loadThemes } from '../shared/utils/ajax-adapter';

const { themes } = await loadThemes('accordion');
console.log('All themes:', themes);
```

#### `saveTheme(blockType, themeId, themeData, options)`

Saves a new theme.

**Parameters:**
- `blockType` (string): Block type identifier
- `themeId` (string): Theme ID
- `themeData` (Object): Theme data to save
- `options` (Object): Options `{ timeout }`

**Returns:**
- `Promise<Object>`: `{ success, themes }`

**Example:**
```javascript
import { saveTheme } from '../shared/utils/ajax-adapter';

const result = await saveTheme('accordion', 'theme_123', {
	name: 'My Custom Theme',
	titleBackgroundColor: '#ff0000',
	// ... other attributes
});

if (result.success) {
	console.log('Theme saved!', result.themes);
}
```

#### `updateTheme(blockType, themeId, updates, options)`

Updates an existing theme.

**Parameters:**
- `blockType` (string): Block type identifier
- `themeId` (string): Theme ID
- `updates` (Object): Updates to apply
- `options` (Object): Options `{ timeout }`

**Returns:**
- `Promise<Object>`: `{ success, themes }`

**Example:**
```javascript
import { updateTheme } from '../shared/utils/ajax-adapter';

await updateTheme('accordion', 'theme_123', {
	titleBackgroundColor: '#00ff00'
});
```

#### `deleteTheme(blockType, themeId, options)`

Deletes a theme.

**Parameters:**
- `blockType` (string): Block type identifier
- `themeId` (string): Theme ID
- `options` (Object): Options `{ timeout }`

**Returns:**
- `Promise<Object>`: `{ success, themes }`

**Example:**
```javascript
import { deleteTheme } from '../shared/utils/ajax-adapter';

await deleteTheme('accordion', 'theme_123');
```

---

### style-helpers.js

#### `getBorderRadiusValue(topLeft, topRight, bottomRight, bottomLeft)`

Generates CSS border-radius shorthand.

**Parameters:**
- `topLeft` (number): Top left radius in pixels
- `topRight` (number): Top right radius in pixels
- `bottomRight` (number): Bottom right radius in pixels
- `bottomLeft` (number): Bottom left radius in pixels

**Returns:**
- `string`: CSS border-radius value

**Example:**
```javascript
import { getBorderRadiusValue } from '../shared/utils/style-helpers';

const radius = getBorderRadiusValue(5, 5, 5, 5);
// Returns: '5px' (shorthand for equal values)

const radius2 = getBorderRadiusValue(5, 10, 15, 20);
// Returns: '5px 10px 15px 20px'
```

#### `getAlignmentMargins(horizontalAlign)`

Gets margin styles for horizontal alignment.

**Parameters:**
- `horizontalAlign` (string): Alignment value ('left', 'center', 'right')

**Returns:**
- `Object`: Margin style object

**Example:**
```javascript
import { getAlignmentMargins } from '../shared/utils/style-helpers';

const margins = getAlignmentMargins('center');
// Returns: { marginLeft: 'auto', marginRight: 'auto' }

Object.assign(inlineStyles, margins);
```

#### `hasBorderRadius(topLeft, topRight, bottomLeft, bottomRight)`

Checks if any border radius values are non-zero.

**Parameters:**
- `topLeft` (number): Top left radius
- `topRight` (number): Top right radius
- `bottomLeft` (number): Bottom left radius
- `bottomRight` (number): Bottom right radius

**Returns:**
- `boolean`: True if any value is non-zero

**Example:**
```javascript
import { hasBorderRadius } from '../shared/utils/style-helpers';

if (hasBorderRadius(0, 0, 0, 0)) {
	// Won't execute
}

if (hasBorderRadius(5, 0, 0, 0)) {
	// Will execute
}
```

#### `buildInlineStyles(effectiveValues)`

Builds inline CSS styles object from effective values.

**Parameters:**
- `effectiveValues` (Object): Object with all effective values

**Returns:**
- `Object`: Inline styles object with CSS variables

**Example:**
```javascript
import { buildInlineStyles } from '../shared/utils/style-helpers';

const effectiveValues = computeEffectiveValues(attributes, theme, config);
const inlineStyles = buildInlineStyles(effectiveValues);

console.log(inlineStyles);
// {
//   '--title-bg-color': '#ff0000',
//   '--title-color': '#ffffff',
//   '--accordion-border-thickness': '2px',
//   '--accordion-border-radius': '5px',
//   ...
// }
```

---

## React Hooks

Location: `blocks/shared/hooks/`

### useEffectiveValues

Memoized wrapper around computeEffectiveValues.

**Parameters:**
- `attributes` (Object): Block attributes object
- `theme` (Object|null): Theme object
- `attributeConfig` (Object): Configuration object

**Returns:**
- `Object`: Memoized effective values object

**Example:**
```javascript
import { useEffectiveValues } from '../shared/hooks';
import { ACCORDION_ATTRIBUTE_CONFIG } from './config';

function MyBlockEdit({ attributes }) {
	const { currentTheme } = useThemeManagement('accordion', {...});

	const effectiveValues = useEffectiveValues(
		attributes,
		currentTheme,
		ACCORDION_ATTRIBUTE_CONFIG
	);

	console.log(effectiveValues.titleBackgroundColor);
	console.log(effectiveValues.accordionBorderThickness);

	return (
		<div style={{
			backgroundColor: effectiveValues.titleBackgroundColor,
			borderWidth: `${effectiveValues.accordionBorderThickness}px`
		}}>
			...
		</div>
	);
}
```

**Performance:** Only recomputes when `attributes`, `theme`, or `attributeConfig` change.

---

### useCustomizationState

Provides customization detection and clearing operations.

**Parameters:**
- `attributes` (Object): Block attributes object
- `theme` (Object|null): Theme object
- `attributeConfig` (Object): Configuration object
- `setAttributes` (Function): WordPress setAttributes function

**Returns:**
- `Object`: Customization state and operations

**Return Object:**
```javascript
{
	hasCustomizations: boolean,
	customizedAttributes: Array<string>,
	customizationsBySection: Object,
	clearCustomizations: Function,
	clearSection: Function,
	clearAttributes: Function,
}
```

**Example:**
```javascript
import { useCustomizationState } from '../shared/hooks';
import { ACCORDION_ATTRIBUTE_CONFIG } from './config';

function MyBlockEdit({ attributes, setAttributes }) {
	const { currentTheme } = useThemeManagement('accordion', {...});

	const {
		hasCustomizations,
		customizedAttributes,
		customizationsBySection,
		clearCustomizations,
		clearSection,
		clearAttributes,
	} = useCustomizationState(
		attributes,
		currentTheme,
		ACCORDION_ATTRIBUTE_CONFIG,
		setAttributes
	);

	return (
		<>
			{hasCustomizations && (
				<button onClick={clearCustomizations}>
					Clear All Customizations
				</button>
			)}

			{customizationsBySection.titleColors && (
				<button onClick={() => clearSection('titleColors')}>
					Clear Color Customizations
				</button>
			)}

			<button onClick={() => clearAttributes(['titleBackgroundColor', 'accordionBorderThickness'])}>
				Clear Specific Attributes
			</button>
		</>
	);
}
```

---

### useThemeManagement

Complete theme CRUD with AJAX integration and cross-block sync.

**Parameters:**
- `blockType` (string): Block type identifier (e.g., 'accordion', 'tabs')
- `options` (Object): Configuration options

**Options Object:**
```javascript
{
	attributeConfig: Object,      // Required: Attribute configuration
	currentThemeId: string|null,  // Required: Current theme ID
	onThemeChange: Function,      // Optional: Callback when theme changes
}
```

**Returns:**
- `Object`: Theme state and operations

**Return Object:**
```javascript
{
	themes: Object,               // All available themes
	currentTheme: Object|null,    // Current theme object
	isLoading: boolean,           // Loading themes from server
	isSaving: boolean,            // Saving/updating theme
	isDeleting: boolean,          // Deleting theme
	error: string|null,           // Error message
	setError: Function,           // Set error state
	loadThemes: Function,         // Reload themes from server
	createTheme: Function,        // Create new theme
	updateTheme: Function,        // Update existing theme
	deleteTheme: Function,        // Delete theme
}
```

**Example:**
```javascript
import { useThemeManagement } from '../shared/hooks';
import { ACCORDION_ATTRIBUTE_CONFIG } from './config';

function MyBlockEdit({ attributes, setAttributes }) {
	const {
		themes,
		currentTheme,
		isLoading,
		isSaving,
		error,
		createTheme,
		updateTheme,
		deleteTheme,
	} = useThemeManagement('accordion', {
		attributeConfig: ACCORDION_ATTRIBUTE_CONFIG,
		currentThemeId: attributes.themeId,
		onThemeChange: (themeId) => {
			setAttributes({ themeId });
		},
	});

	const handleCreateTheme = async () => {
		try {
			await createTheme('My New Theme', attributes);
			// Theme created and synced across all blocks
		} catch (err) {
			console.error('Failed to create theme:', err);
		}
	};

	const handleUpdateTheme = async () => {
		try {
			await updateTheme(attributes.themeId, {
				titleBackgroundColor: '#ff0000'
			});
			// Theme updated and synced across all blocks
		} catch (err) {
			console.error('Failed to update theme:', err);
		}
	};

	return (
		<>
			{isLoading && <p>Loading themes...</p>}
			{error && <p>Error: {error}</p>}

			<select
				value={attributes.themeId || ''}
				onChange={(e) => setAttributes({ themeId: e.target.value })}
			>
				{Object.entries(themes).map(([id, theme]) => (
					<option key={id} value={id}>{theme.name}</option>
				))}
			</select>

			<button onClick={handleCreateTheme} disabled={isSaving}>
				Create Theme
			</button>

			<button onClick={handleUpdateTheme} disabled={isSaving}>
				Update Theme
			</button>

			<button onClick={() => deleteTheme(attributes.themeId)}>
				Delete Theme
			</button>
		</>
	);
}
```

**Cross-Block Sync:**
The hook automatically listens for CustomEvents (`${blockType}ThemeUpdated`) and updates all block instances when any theme is created, updated, or deleted.

---

## Configuration

### ATTRIBUTE_CONFIG Structure

Each block must define an ATTRIBUTE_CONFIG object:

```javascript
export const MY_BLOCK_ATTRIBUTE_CONFIG = {
	attributeName: {
		type: 'string' | 'number' | 'boolean' | 'object' | 'array',
		defaultValue: any,
		section: 'sectionName',

		// Optional flags
		isToggle?: boolean,
		childAttributes?: Array<string>,
		treatFalseAsCustomization?: boolean,
	},
	// ... more attributes
};
```

### v6.0 Architecture Note: CSS as Single Source of Truth

**IMPORTANT:** The `defaultValue` fields shown in ATTRIBUTE_CONFIG below are for **documentation reference only**.

In v6.0 architecture:
- Actual defaults are defined in `accordion.css` as `:root` CSS variables
- PHP parses the CSS file using `get_accordion_plugin_defaults()` (cached with file modification time)
- JavaScript receives defaults via `window.accordionDefaults` (passed by `wp_localize_script`)
- Block attributes for customizable properties default to `null` (not the values shown)
- The cascade resolves: Block attributes → Theme → window.accordionDefaults

The `defaultValue` fields below show what the expected values are from the CSS file, serving as documentation for developers.

**Example - Accordion:**
```javascript
export const ACCORDION_ATTRIBUTE_CONFIG = {
	// Title Colors section (including interactive states)
	titleColor: {
		type: 'string',
		defaultValue: '#333333',
		section: 'titleColors',
	},
	titleBackgroundColor: {
		type: 'string',
		defaultValue: '#f5f5f5',
		section: 'titleColors',
	},
	hoverTitleColor: {
		type: 'string',
		defaultValue: null, // inherits from titleColor
		section: 'titleColors',
	},
	hoverTitleBackgroundColor: {
		type: 'string',
		defaultValue: '#eeeeee',
		section: 'titleColors',
	},
	activeTitleColor: {
		type: 'string',
		defaultValue: null, // inherits from titleColor
		section: 'titleColors',
	},
	activeTitleBackgroundColor: {
		type: 'string',
		defaultValue: null, // inherits from titleBackgroundColor
		section: 'titleColors',
	},

	// Title Typography section
	titleFontSize: {
		type: 'number',
		defaultValue: 16,
		section: 'titleTypography',
	},
	titleFontWeight: {
		type: 'string',
		defaultValue: '600',
		section: 'titleTypography',
	},
	titleFontStyle: {
		type: 'string',
		defaultValue: 'normal',
		section: 'titleTypography',
	},
	titleTextDecoration: {
		type: 'string',
		defaultValue: 'none',
		section: 'titleTypography',
	},
	titleTextTransform: {
		type: 'string',
		defaultValue: 'none',
		section: 'titleTypography',
	},
	titleAlignment: {
		type: 'string',
		defaultValue: 'left',
		section: 'titleTypography',
	},
	titlePadding: {
		type: 'object',
		defaultValue: { top: 12, right: 12, bottom: 12, left: 12 },
		section: 'titleTypography',
	},
	headingLevel: {
		type: 'string',
		defaultValue: 'h3',
		section: 'titleTypography',
	},

	// Content Styling section
	contentBackgroundColor: {
		type: 'string',
		defaultValue: 'transparent',
		section: 'contentStyling',
	},

	// Border section
	accordionBorderThickness: {
		type: 'number',
		defaultValue: 1,
		section: 'border',
	},
	accordionBorderStyle: {
		type: 'string',
		defaultValue: 'solid',
		section: 'border',
	},
	accordionBorderColor: {
		type: 'string',
		defaultValue: '#e0e0e0',
		section: 'border',
	},
	accordionBorderRadius: {
		type: 'object',
		defaultValue: { topLeft: 4, topRight: 4, bottomLeft: 4, bottomRight: 4 },
		section: 'border',
	},
	accordionShadow: {
		type: 'string',
		defaultValue: 'none',
		section: 'border',
	},
	dividerBorderThickness: {
		type: 'number',
		defaultValue: 0,
		section: 'border',
	},
	dividerBorderStyle: {
		type: 'string',
		defaultValue: 'solid',
		section: 'border',
	},
	dividerBorderColor: {
		type: 'string',
		defaultValue: '#e0e0e0',
		section: 'border',
	},
	accordionMarginBottom: {
		type: 'number',
		defaultValue: 0,
		section: 'border',
	},

	// Icon section with toggle
	showIcon: {
		type: 'boolean',
		defaultValue: true,
		section: 'icon',
		isToggle: true,
		childAttributes: ['iconPosition', 'iconColor', 'iconSize', 'iconTypeClosed', 'iconTypeOpen', 'iconRotation'],
	},
	iconPosition: {
		type: 'string',
		defaultValue: 'right',
		section: 'icon',
	},
	iconColor: {
		type: 'string',
		defaultValue: null, // inherits from titleColor
		section: 'icon',
	},
	iconSize: {
		type: 'number',
		defaultValue: null, // inherits from titleFontSize
		section: 'icon',
	},
	iconTypeClosed: {
		type: 'string',
		defaultValue: 'plus',
		section: 'icon',
	},
	iconTypeOpen: {
		type: 'string',
		defaultValue: 'none',
		section: 'icon',
	},
	iconRotation: {
		type: 'number',
		defaultValue: 0,
		section: 'icon',
	},
};
```

**Auto-Generated Constants:**
```javascript
// Auto-generate sections
export const MY_BLOCK_CUSTOMIZATION_SECTIONS = Object.entries(MY_BLOCK_ATTRIBUTE_CONFIG)
	.reduce((sections, [attrName, config]) => {
		const section = config.section;
		if (!sections[section]) sections[section] = [];
		sections[section].push(attrName);
		return sections;
	}, {});

// Auto-generate attribute list
export const MY_BLOCK_CUSTOMIZATION_ATTRIBUTES = Object.keys(MY_BLOCK_ATTRIBUTE_CONFIG);
```

---

## Usage Examples

### Example 1: Basic Block Integration

```javascript
// config.js
export const MY_BLOCK_ATTRIBUTE_CONFIG = {
	// Define all customization attributes
};

export const MY_BLOCK_CUSTOMIZATION_SECTIONS = /* auto-generate */;
export const MY_BLOCK_CUSTOMIZATION_ATTRIBUTES = /* auto-generate */;
```

### Example 2: Save Component

```javascript
// save.js
import { buildInlineStyles, getAlignmentMargins } from '../shared/utils/style-helpers';
import { computeEffectiveValues } from '../shared/customization-core';
import { MY_BLOCK_ATTRIBUTE_CONFIG } from './config';

function Save({ attributes }) {
	// Compute effective values (no theme in save context)
	const effectiveValues = computeEffectiveValues(
		attributes,
		null,
		MY_BLOCK_ATTRIBUTE_CONFIG
	);

	// Build inline styles
	const inlineStyles = buildInlineStyles(effectiveValues);

	// Add alignment
	const margins = getAlignmentMargins(attributes.titleAlignment);
	Object.assign(inlineStyles, margins);

	return (
		<div className="my-block" style={inlineStyles}>
			<InnerBlocks.Content />
		</div>
	);
}
```

---

## Integration Guide

### Step 1: Define Configuration

Create `config.js`:
```javascript
export const MY_BLOCK_ATTRIBUTE_CONFIG = {
	// Define all customization attributes
};

export const MY_BLOCK_CUSTOMIZATION_SECTIONS = /* auto-generate */;
export const MY_BLOCK_CUSTOMIZATION_ATTRIBUTES = /* auto-generate */;
```

### Step 2: Update edit.js

```javascript
// Import shared hooks
import {
	useThemeManagement,
	useEffectiveValues,
	useCustomizationState,
} from '../shared/hooks';

// Import config
import { MY_BLOCK_ATTRIBUTE_CONFIG } from './config';

// Initialize hooks
const { themes, currentTheme, ... } = useThemeManagement('myblock', {...});
const effectiveValues = useEffectiveValues(attributes, currentTheme, config);
const { clearCustomizations, ... } = useCustomizationState(attributes, currentTheme, config, setAttributes);
```

### Step 3: Update save.js

```javascript
// Import utilities
import { buildInlineStyles } from '../shared/utils/style-helpers';
import { computeEffectiveValues } from '../shared/customization-core';

// Compute and apply styles
const effectiveValues = computeEffectiveValues(attributes, null, config);
const inlineStyles = buildInlineStyles(effectiveValues);
```

### Step 4: Update Inspector Panels

Pass `currentTheme` instead of manual theme lookups:
```javascript
<MyPanel
	currentTheme={currentTheme}
	defaultTheme={themes?.default}
	// ... other props
/>
```

### Step 5: Register AJAX Handlers (PHP)

```php
// In your plugin's main file
add_action('wp_ajax_guten_nav_load_myblock_themes', 'handle_load_myblock_themes');
add_action('wp_ajax_guten_nav_save_myblock_theme', 'handle_save_myblock_theme');
add_action('wp_ajax_guten_nav_update_myblock_theme', 'handle_update_myblock_theme');
add_action('wp_ajax_guten_nav_delete_myblock_theme', 'handle_delete_myblock_theme');
```

---

## Best Practices

1. **Always use shared hooks** - Don't reimplement theme management
2. **Use memoized hooks** - `useEffectiveValues` is already optimized
3. **Pass configs explicitly** - Make dependencies clear
4. **Handle errors gracefully** - All AJAX functions return promises
5. **Test with unit tests** - Use templates in IMPLEMENTATION-GUIDE.md
6. **Document custom flags** - If using `treatFalseAsCustomization`, document why
7. **Follow naming conventions** - Use `${blockType}ThemeUpdated` for CustomEvents

---

## Changelog

**v2.0 (2025-10-12) - v6.0 Architecture Alignment**
- Added v6.0 architecture documentation (CSS as single source of truth)
- Updated ATTRIBUTE_CONFIG with prominent note about defaults
- Added CSS parsing system explanation
- Updated naming: `title*` prefix, `accordion*` prefix, nested objects
- Documented null inheritance for attributes
- Updated cascade resolution to 3-tier (block → theme → defaults)
- Clarified behavioral defaults handling (defined in PHP parsing function)
- Added notes about `window.accordionDefaults` from `wp_localize_script`
- Aligned with FRONTEND-RENDERING.md v6.0

**v1.0 (Phase 3 Complete - 2025-10-07)**
- Initial API reference documentation
- Core modules: constants, validation, attribute-resolver, customization-detector, attribute-operations, theme-manager
- WordPress adapters: ajax-adapter, style-helpers
- React hooks: useEffectiveValues, useCustomizationState, useThemeManagement
- Configuration system with ATTRIBUTE_CONFIG structure
- Usage examples and integration guide
- Best practices documentation
