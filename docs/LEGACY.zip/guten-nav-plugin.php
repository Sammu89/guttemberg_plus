<?php
/**
 * Plugin Name: Guten Nav Plugin
 * Description: Lightweight WordPress plugin with three Gutenberg blocks: Tabs, Auto Menu, and Accordion.
 * Version: 1.0.2
 * Author: Your Name
 * Text Domain: guten-nav-plugin
 */

if (!defined('ABSPATH')) {
    exit;
}

define('GUTEN_NAV_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('GUTEN_NAV_PLUGIN_URL', plugin_dir_url(__FILE__));

class GutenNavPlugin {

    public function __construct() {
        add_action('init', array($this, 'register_blocks'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
        add_action('enqueue_block_editor_assets', array($this, 'enqueue_editor_assets'));
        add_filter('the_content', array($this, 'process_auto_menu'), 10);
        add_filter('the_content', array($this, 'process_tabs'), 11);

        // Theme management AJAX
        add_action('wp_ajax_get_accordion_themes', array($this, 'get_accordion_themes'));
        add_action('wp_ajax_save_accordion_theme', array($this, 'save_accordion_theme'));
        add_action('wp_ajax_delete_accordion_theme', array($this, 'delete_accordion_theme'));
        add_action('wp_ajax_test_accordion_ajax', array($this, 'test_ajax'));

        // Auto-deduplication system (Phase 3 - Section 6.1)
        add_action('save_post', array($this, 'auto_optimize_accordions'), 10, 3);
    }

    public function register_blocks() {
        // Register Tabs Block
        register_block_type(GUTEN_NAV_PLUGIN_PATH . 'blocks/tabs');
        register_block_type(GUTEN_NAV_PLUGIN_PATH . 'blocks/tab-panel');

        // Register Auto Menu Block
        register_block_type(GUTEN_NAV_PLUGIN_PATH . 'blocks/auto-menu');

        // Register Accordion Block
        register_block_type(GUTEN_NAV_PLUGIN_PATH . 'blocks/accordion');
    }

    public function enqueue_frontend_assets() {
        global $post;

        if (!$post) return;

        $content = $post->post_content;

        // Check if any of our blocks are present and enqueue assets accordingly
        if (has_block('sammu/tabs', $content) || has_block('sammu/tab-panel', $content)) {
            wp_enqueue_script('guten-nav-tabs', GUTEN_NAV_PLUGIN_URL . 'assets/js/tabs.js', array(), '1.0.0', true);
            wp_enqueue_style('guten-nav-tabs', GUTEN_NAV_PLUGIN_URL . 'assets/css/tabs.css', array(), '1.0.0');
        }

        if (has_block('sammu/auto-menu', $content)) {
            wp_enqueue_script('guten-nav-auto-menu', GUTEN_NAV_PLUGIN_URL . 'assets/js/auto-menu.js', array(), '1.0.0', true);
            wp_enqueue_style('guten-nav-auto-menu', GUTEN_NAV_PLUGIN_URL . 'assets/css/auto-menu.css', array(), '1.0.0');
        }

        if (has_block('sammu/accordion', $content)) {
            wp_enqueue_script('guten-nav-accordion', GUTEN_NAV_PLUGIN_URL . 'assets/js/accordion.js', array(), '1.0.0', true);
            wp_enqueue_style('guten-nav-accordion', GUTEN_NAV_PLUGIN_URL . 'assets/css/accordion.css', array(), '1.0.0');

            // Inject theme CSS variables
            $this->inject_accordion_theme_styles();

            // Inject page style CSS variables (Phase 3 - Section 8.1)
            $this->inject_accordion_page_styles();
        }
    }

    public function enqueue_editor_assets() {
        // Enqueue nonce for AJAX requests in block editor
        wp_localize_script('wp-blocks', 'accordionGlobalSettings', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('accordion_global_settings'),
            'themesNonce' => wp_create_nonce('accordion_themes')
        ));
    }

    public function process_auto_menu($content) {
        if (!has_block('sammu/auto-menu', $content)) {
            return $content;
        }

        // Process each auto-menu block individually with its settings
        $content = preg_replace_callback(
            '/<nav[^>]*class="[^"]*auto-menu[^"]*"[^>]*data-menu-title="([^"]*)"[^>]*data-show-title="([^"]*)"[^>]*data-title-level="([^"]*)"[^>]*data-included-headings="([^"]*)"[^>]*data-include-classes="([^"]*)"[^>]*data-exclude-classes="([^"]*)"[^>]*data-class-filter-mode="([^"]*)"[^>]*><\/nav>/',
            array($this, 'process_auto_menu_block'),
            $content
        );

        // Add IDs to headings
        $content = $this->add_heading_ids($content);

        return $content;
    }

    private function process_auto_menu_block($matches) {
        $menu_title = html_entity_decode($matches[1]);
        $show_title = $matches[2] === 'true';
        $title_level = $matches[3] ?: 'h3';
        $included_headings = json_decode(html_entity_decode($matches[4]), true) ?: ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'];
        $include_classes = json_decode(html_entity_decode($matches[5]), true) ?: [];
        $exclude_classes = json_decode(html_entity_decode($matches[6]), true) ?: [];
        $class_filter_mode = $matches[7] ?: 'none';

        global $post;
        $post_content = $post ? $post->post_content : '';

        // Extract headings with filters
        $headings = $this->extract_headings_with_filters($post_content, $included_headings, $include_classes, $exclude_classes, $class_filter_mode);

        if (empty($headings)) {
            $no_headings_msg = '<nav class="auto-menu"><p class="no-headings">No headings found matching the criteria.</p></nav>';

            // Add title even if no headings found
            if ($show_title && !empty($menu_title)) {
                return '<nav class="auto-menu">' .
                       '<' . $title_level . ' class="menu-title">' . esc_html($menu_title) . '</' . $title_level . '>' .
                       '<p class="no-headings">No headings found matching the criteria.</p></nav>';
            }

            return $no_headings_msg;
        }

        // Generate menu HTML with optional title
        return $this->generate_menu_html($headings, $menu_title, $show_title, $title_level);
    }

    private function extract_headings($content) {
        return $this->extract_headings_with_filters($content, ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'], [], [], 'none');
    }

    private function extract_headings_with_filters($content, $included_headings, $include_classes, $exclude_classes, $class_filter_mode) {
        preg_match_all('/<h([1-6])([^>]*)?>(.*?)<\/h[1-6]>/i', $content, $matches, PREG_SET_ORDER);

        $headings = array();
        foreach ($matches as $match) {
            $level = intval($match[1]);
            $tag = 'h' . $level;
            $attributes = $match[2] ?? '';
            $text = strip_tags($match[3]);
            $id = sanitize_title($text);

            // Check if heading level is included
            if (!in_array($tag, $included_headings)) {
                continue;
            }

            // Apply class filtering
            if ($class_filter_mode !== 'none') {
                $heading_classes = $this->extract_classes_from_attributes($attributes);

                if ($class_filter_mode === 'include') {
                    // Only include headings that have at least one of the specified classes
                    $has_include_class = false;
                    foreach ($include_classes as $class) {
                        if (in_array($class, $heading_classes)) {
                            $has_include_class = true;
                            break;
                        }
                    }
                    if (!$has_include_class && !empty($include_classes)) {
                        continue;
                    }
                } elseif ($class_filter_mode === 'exclude') {
                    // Exclude headings that have any of the specified classes
                    $has_exclude_class = false;
                    foreach ($exclude_classes as $class) {
                        if (in_array($class, $heading_classes)) {
                            $has_exclude_class = true;
                            break;
                        }
                    }
                    if ($has_exclude_class) {
                        continue;
                    }
                }
            }

            $headings[] = array(
                'level' => $level,
                'text' => $text,
                'id' => $id
            );
        }

        return $headings;
    }

    private function extract_classes_from_attributes($attributes) {
        if (preg_match('/class=["\']([^"\']*)["\']/', $attributes, $class_matches)) {
            return array_filter(explode(' ', $class_matches[1]));
        }
        return array();
    }

    private function generate_menu_html($headings, $menu_title = '', $show_title = false, $title_level = 'h3') {
        $html = '<nav class="auto-menu">';

        // Add title if specified
        if ($show_title && !empty($menu_title)) {
            $html .= '<' . $title_level . ' class="menu-title">' . esc_html($menu_title) . '</' . $title_level . '>';
        }

        $html .= '<ul>';
        $current_level = 0;
        $open_tags = array();

        foreach ($headings as $heading) {
            $level = $heading['level'];
            $text = $heading['text'];
            $id = $heading['id'];

            if ($level > $current_level) {
                // Open new nested list
                for ($i = $current_level; $i < $level - 1; $i++) {
                    $html .= '<li><ul>';
                    $open_tags[] = '</ul></li>';
                }
                if ($current_level > 0) {
                    $html .= '<ul>';
                    $open_tags[] = '</ul>';
                }
            } elseif ($level < $current_level) {
                // Close nested lists
                $diff = $current_level - $level;
                for ($i = 0; $i < $diff; $i++) {
                    if (!empty($open_tags)) {
                        $html .= array_pop($open_tags);
                    }
                }
            }

            $html .= '<li><a href="#' . $id . '">' . esc_html($text) . '</a></li>';
            $current_level = $level;
        }

        // Close remaining open tags
        while (!empty($open_tags)) {
            $html .= array_pop($open_tags);
        }

        $html .= '</ul></nav>';

        return $html;
    }

    private function add_heading_ids($content) {
        return preg_replace_callback(
            '/<h([1-6])([^>]*)>(.*?)<\/h[1-6]>/i',
            function($matches) {
                $level = $matches[1];
                $attributes = $matches[2];
                $text = $matches[3];
                $id = sanitize_title(strip_tags($text));

                // Check if ID already exists
                if (strpos($attributes, 'id=') === false) {
                    $attributes .= ' id="' . $id . '"';
                }

                return '<h' . $level . $attributes . '>' . $text . '</h' . $level . '>';
            },
            $content
        );
    }

    public function process_tabs($content) {
        if (!has_block('sammu/tabs', $content)) {
            return $content;
        }

        // Process tabs blocks to restructure the HTML
        $content = preg_replace_callback(
            '/<div class="wp-block-sammu-tabs tabs-block">(.*?)<\/div>/s',
            array($this, 'restructure_tabs_block'),
            $content
        );

        return $content;
    }

    private function restructure_tabs_block($matches) {
        $tabs_content = $matches[1];

        // Extract tab panels
        preg_match_all('/<li[^>]*data-tab="(\d+)"[^>]*>(.*?)<\/li>.*?<div[^>]*class="[^"]*tab-content[^"]*"[^>]*data-tab="\1"[^>]*>(.*?)<\/div>/s', $tabs_content, $panel_matches, PREG_SET_ORDER);

        if (empty($panel_matches)) {
            return $matches[0]; // Return original if no matches
        }

        // Build new structure
        $nav_html = '<ul class="tab-nav">';
        $content_html = '';

        foreach ($panel_matches as $i => $panel) {
            $tab_index = $panel[1];
            $tab_title = strip_tags($panel[2]);
            $tab_content = $panel[3];

            $active_class = ($i === 0) ? ' active' : '';

            $nav_html .= '<li class="' . $active_class . '" data-tab="' . $tab_index . '">' . $tab_title . '</li>';
            $content_html .= '<div class="tab-content' . $active_class . '" data-tab="' . $tab_index . '">' . $tab_content . '</div>';
        }

        $nav_html .= '</ul>';

        return '<div class="tabs-block">' . $nav_html . $content_html . '</div>';
    }

    // ===== THEME MANAGEMENT FUNCTIONS =====

    /**
     * Test AJAX endpoint
     */
    public function test_ajax() {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $log_file = plugin_dir_path(__FILE__) . 'debug-theme.log';
            file_put_contents($log_file, date('Y-m-d H:i:s') . " TEST AJAX CALLED\n", FILE_APPEND);
        }
        wp_send_json_success(array('message' => 'Test successful'));
    }

    /**
     * Get all accordion themes
     *
     * Returns complete theme snapshots:
     * - Every theme has ALL attributes with real values (no nulls)
     * - Default theme loaded from database (synced during activation)
     * - Each theme is independent and self-contained
     */
    public function get_accordion_themes() {
        // Check nonce - use false to prevent die() on failure
        $nonce_check = check_ajax_referer('accordion_themes', 'nonce', false);
        if (!$nonce_check) {
            wp_send_json_error(array('message' => 'Invalid security token'));
            return;
        }

        $themes = get_option('accordion_themes', array());

        // Ensure themes is an array
        if (!is_array($themes)) {
            $themes = array();
        }

        // If default theme is not in database, sync it now (backwards compatibility)
        if (!isset($themes['default'])) {
            $this->sync_default_theme_to_db();
            $themes = get_option('accordion_themes', array());
        }

        wp_send_json_success(array(
            'message' => 'Themes retrieved successfully',
            'themes' => $themes
        ));
    }

    /**
     * Save or create accordion theme
     *
     * COMPLETE SNAPSHOT SYSTEM:
     * - Receives ALL 33+ attributes from JavaScript (block OR theme values)
     * - Saves complete snapshot to database with NO null values
     * - Each theme is self-contained and independent
     * - No inheritance, no cascading, no defaults needed
     */
    public function save_accordion_theme() {
        // Log to custom file for debugging (only in debug mode)
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $log_file = plugin_dir_path(__FILE__) . 'debug-theme.log';
            $log_entry = "\n" . date('Y-m-d H:i:s') . " === save_accordion_theme START ===\n";
            file_put_contents($log_file, $log_entry, FILE_APPEND);
        }

        // Check nonce - use false to prevent die() on failure
        $nonce_check = check_ajax_referer('accordion_themes', 'nonce', false);

        if (!$nonce_check) {
            wp_send_json_error(array('message' => 'Invalid security token'));
            return;
        }

        // Allow any user who can edit posts to save accordion themes
        // This is appropriate since themes are site-wide settings that affect content presentation
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(array('message' => 'Unauthorized access'));
            return;
        }

        $theme_id = isset($_POST['theme_id']) ? sanitize_key($_POST['theme_id']) : '';
        $theme_name = isset($_POST['theme_name']) ? sanitize_text_field($_POST['theme_name']) : '';

        // Theme ID validation (BEFORE processing) - per section 9.1
        if (!empty($theme_id) && !preg_match('/^[a-z0-9-]{1,50}$/', $theme_id)) {
            wp_send_json_error(array('message' => 'Invalid theme ID format (alphanumeric + hyphens only)'));
            return;
        }

        // Prevent reserved IDs
        $reserved_ids = array('default', 'auto', 'page', 'inline', 'theme', 'style');
        if (in_array($theme_id, $reserved_ids)) {
            wp_send_json_error(array('message' => 'Theme ID is reserved'));
            return;
        }

        // Build settings from individual POST fields with immediate basic sanitization
        // IMPORTANT: This must match CUSTOMIZATION_SECTIONS in constants.js
        // Organized by section for maintainability
        $theme_settings = array();
        $allowed_settings = array(
            // Colors
            'headerBackgroundColor', 'headerTextColor', 'headerHoverColor', 'contentBackgroundColor',
            // Main Border
            'borderColor', 'borderWidth', 'borderStyle',
            // Divider Border
            'dividerBorderColor', 'dividerBorderWidth', 'dividerBorderStyle',
            // Border Radius
            'borderRadiusTopLeft', 'borderRadiusTopRight', 'borderRadiusBottomLeft', 'borderRadiusBottomRight',
            // Animation
            'animationSpeed',
            // Icon
            'showIcon', 'icon', 'iconType', 'iconPosition', 'animateIcon',
            // Title Formatting - Toggles
            'useHeading', 'headingLevel', 'useHeadingStyles', 'useCustomTitleFormatting',
            // Title Formatting - Children
            'titleTextAlign', 'titleFontSize', 'titleFontWeight', 'titleFontStyle', 'titleTextTransform',
            'titleLetterSpacing', 'titleWordSpacing', 'titleTextDecoration', 'titleFontFamily'
        );
        foreach ($allowed_settings as $key) {
            if (isset($_POST[$key])) {
                $validated = $this->validate_attribute($key, $_POST[$key]);
                if ($validated !== null) {
                    $theme_settings[$key] = $validated;
                    error_log("VALIDATED: $key = " . var_export($validated, true));
                } else {
                    error_log("REJECTED: $key - invalid value");
                }
            }
        }

        if (empty($theme_id) || empty($theme_name)) {
            wp_send_json_error(array('message' => 'Theme ID and name are required'));
            return;
        }

        if ($theme_id === 'default') {
            wp_send_json_error(array('message' => 'Cannot modify the default theme'));
            return;
        }

        // Validate and sanitize theme settings (second layer of validation)
        try {
            $sanitized_settings = $this->sanitize_theme_settings($theme_settings);
        } catch (Exception $e) {
            wp_send_json_error(array('message' => 'Error sanitizing settings: ' . $e->getMessage()));
            return;
        } catch (Error $e) {
            wp_send_json_error(array('message' => 'Fatal error sanitizing settings: ' . $e->getMessage()));
            return;
        }

        $themes = get_option('accordion_themes', array());
        if (!is_array($themes)) {
            $themes = array();
        }

        $themes[$theme_id] = array_merge(
            array(
                'theme_id' => $theme_id,
                'theme_name' => $theme_name
            ),
            $sanitized_settings
        );

        $result = update_option('accordion_themes', $themes);

        if ($result === false && get_option('accordion_themes') !== $themes) {
            wp_send_json_error(array('message' => 'Failed to save theme - database error'));
            return;
        }

        // Return all themes (default is already in database)
        wp_send_json_success(array(
            'message' => 'Theme saved successfully',
            'themes' => $themes
        ));
    }

    /**
     * Delete accordion theme
     */
    public function delete_accordion_theme() {
        // Check nonce - use false to prevent die() on failure
        $nonce_check = check_ajax_referer('accordion_themes', 'nonce', false);
        if (!$nonce_check) {
            wp_send_json_error(array('message' => 'Invalid security token'));
            return;
        }

        // Allow any user who can edit posts to delete accordion themes
        // This is appropriate since themes are site-wide settings that affect content presentation
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(array('message' => 'Unauthorized access'));
            return;
        }

        $theme_id = isset($_POST['theme_id']) ? sanitize_key($_POST['theme_id']) : '';

        if (empty($theme_id)) {
            wp_send_json_error(array('message' => 'Theme ID is required'));
            return;
        }

        if ($theme_id === 'default') {
            wp_send_json_error(array('message' => 'Cannot delete the default theme'));
            return;
        }

        $themes = get_option('accordion_themes', array());
        if (!is_array($themes)) {
            $themes = array();
        }

        if (!isset($themes[$theme_id])) {
            wp_send_json_error(array('message' => 'Theme not found'));
            return;
        }

        unset($themes[$theme_id]);
        $result = update_option('accordion_themes', $themes);

        if ($result === false && get_option('accordion_themes') !== $themes) {
            wp_send_json_error(array('message' => 'Failed to delete theme'));
            return;
        }

        // Return all themes (default is already in database)
        wp_send_json_success(array(
            'message' => 'Theme deleted successfully',
            'themes' => $themes
        ));
    }

    /**
     * Get default theme settings
     * COMPLETE SNAPSHOT: All attributes have real values, no nulls
     * Loaded from theme-default.php
     */
    private function get_default_theme() {
        $theme_file = GUTEN_NAV_PLUGIN_PATH . 'include/theme-default.php';

        if (!file_exists($theme_file)) {
            error_log('Guten Nav Plugin: theme-default.php not found');
            return array();
        }

        // Load complete default theme snapshot (all 33+ attributes with values)
        $default_theme = include $theme_file;

        return $default_theme;
    }

    /**
     * DEPRECATED - Auto-sync no longer needed
     *
     * Previously synced Default theme from auto-generated accordion-defaults.php.
     * Now theme-default.php is manually maintained and loaded directly.
     *
     * This function is kept to prevent fatal errors but does nothing.
     * Can be safely removed in future cleanup.
     */
    public function maybe_update_default_theme() {
        // No-op - theme-default.php is manually maintained
        // Loaded directly via get_default_theme() when needed
        return;
    }

    /**
     * Sync Default theme to database (Options API)
     * Called during plugin activation to store default theme in database
     *
     * This ensures the default theme is loaded from database instead of
     * reading the PHP file on every AJAX request.
     */
    private function sync_default_theme_to_db() {
        // Get the complete default theme from PHP file
        $default_theme = $this->get_default_theme();

        // Get existing themes from database
        $themes = get_option('accordion_themes', array());
        if (!is_array($themes)) {
            $themes = array();
        }

        // Store default theme in database with theme metadata
        $themes['default'] = array_merge(
            array(
                'theme_id' => 'default',
                'theme_name' => 'Default'
            ),
            $default_theme
        );

        // Save to database
        update_option('accordion_themes', $themes);

        error_log('Guten Nav Plugin: Default theme synced to database');
    }

    /**
     * Validates and sanitizes attribute value based on type
     * CRITICAL: All user input MUST go through this function
     * Per section 9.1 of ACCORDION-THEME-SYSTEM-V2-SPEC.md
     */
    private function validate_attribute($key, $value) {
        // Define attribute types
        $color_attrs = array('headerBackgroundColor', 'headerTextColor', 'headerHoverColor',
                           'contentBackgroundColor', 'borderColor', 'dividerBorderColor');
        $number_attrs = array('borderWidth', 'dividerBorderWidth', 'borderRadiusTopLeft',
                        'borderRadiusTopRight', 'borderRadiusBottomLeft', 'borderRadiusBottomRight');
        $boolean_attrs = array('showIcon', 'animateIcon', 'useHeading', 'useHeadingStyles',
                         'useCustomTitleFormatting');
        $enum_attrs = array(
            'borderStyle' => array('none', 'solid', 'dashed', 'dotted', 'double', 'groove', 'ridge', 'inset', 'outset'),
            'dividerBorderStyle' => array('none', 'solid', 'dashed', 'dotted', 'double', 'groove', 'ridge', 'inset', 'outset'),
            'animationSpeed' => array('fast', 'normal', 'slow', 'none'),
            'iconType' => array('character', 'emoji', 'image'),
            'iconPosition' => array('left', 'right', 'extreme-right'),
            'headingLevel' => array('h1', 'h2', 'h3', 'h4', 'h5', 'h6'),
            'titleTextAlign' => array('left', 'center', 'right', 'justify'),
            'titleFontWeight' => array('100', '200', '300', '400', '500', '600', '700', '800', '900', 'normal', 'bold'),
            'titleFontStyle' => array('normal', 'italic', 'oblique'),
            'titleTextTransform' => array('none', 'capitalize', 'uppercase', 'lowercase'),
            'titleTextDecoration' => array('none', 'underline', 'overline', 'line-through'),
        );

        // Color validation (hex, rgb, rgba, hsl, hsla, transparent)
        if (in_array($key, $color_attrs)) {
            return $this->sanitize_color($value);
        }

        // Number validation with range clamping
        if (in_array($key, $number_attrs)) {
            $num = intval($value);

            // Range validation
            if (strpos($key, 'borderRadius') !== false) {
                return max(0, min(100, $num)); // Clamp 0-100px
            }
            if (strpos($key, 'Width') !== false) {
                return max(0, min(20, $num)); // Clamp 0-20px
            }

            return $num;
        }

        // Boolean validation (strict) - CRITICAL FIX for boolean false issue
        if (in_array($key, $boolean_attrs)) {
            if ($value === true || $value === 'true' || $value === '1' || $value === 1) {
                return true;
            }
            if ($value === false || $value === 'false' || $value === '0' || $value === 0 || $value === '') {
                return false;
            }
            error_log("VALIDATION ERROR: Invalid boolean for $key: " . var_export($value, true));
            return false; // Default to false for invalid
        }

        // Enum validation
        if (isset($enum_attrs[$key])) {
            if (in_array($value, $enum_attrs[$key], true)) {
                return $value;
            }
            error_log("VALIDATION ERROR: Invalid enum for $key: $value (expected: " . implode(', ', $enum_attrs[$key]) . ")");
            return $enum_attrs[$key][0]; // Default to first option
        }

        // CSS values (font-size, spacing, etc.)
        if (in_array($key, array('titleFontSize', 'titleLetterSpacing', 'titleWordSpacing'))) {
            return sanitize_text_field($value); // Allow CSS units (px, em, rem, etc.)
        }

        // Font family
        if ($key === 'titleFontFamily') {
            return sanitize_text_field($value);
        }

        // Icon character/emoji
        if ($key === 'icon') {
            return sanitize_text_field($value);
        }

        // String sanitization (default)
        return sanitize_text_field($value);
    }

    /**
     * Sanitize theme settings
     */
    private function sanitize_theme_settings($settings) {
        $sanitized = array();

        // Colors
        if (isset($settings['headerBackgroundColor'])) {
            $sanitized['headerBackgroundColor'] = $this->sanitize_color($settings['headerBackgroundColor']);
        }
        if (isset($settings['headerTextColor'])) {
            $sanitized['headerTextColor'] = $this->sanitize_color($settings['headerTextColor']);
        }
        if (isset($settings['headerHoverColor'])) {
            $sanitized['headerHoverColor'] = $this->sanitize_color($settings['headerHoverColor']);
        }
        if (isset($settings['contentBackgroundColor'])) {
            $sanitized['contentBackgroundColor'] = $this->sanitize_color($settings['contentBackgroundColor']);
        }
        if (isset($settings['contentBackgroundTransparent'])) {
            $sanitized['contentBackgroundTransparent'] = filter_var($settings['contentBackgroundTransparent'], FILTER_VALIDATE_BOOLEAN);
        }

        // Border
        if (isset($settings['borderColor'])) {
            $sanitized['borderColor'] = $this->sanitize_color($settings['borderColor']);
        }
        if (isset($settings['borderWidth'])) {
            $width = intval($settings['borderWidth']);
            $sanitized['borderWidth'] = ($width >= 0 && $width <= 10) ? $width : 1;
        }
        if (isset($settings['borderStyle'])) {
            $style = sanitize_text_field($settings['borderStyle']);
            $allowed_styles = $this->get_allowed_border_styles();
            $sanitized['borderStyle'] = in_array($style, $allowed_styles) ? $style : 'solid';
        }

        // Divider Border (no enableDividerBorder - it's UI-only)
        if (isset($settings['dividerBorderColor'])) {
            $sanitized['dividerBorderColor'] = $this->sanitize_color($settings['dividerBorderColor']);
        }
        if (isset($settings['dividerBorderWidth'])) {
            $width = intval($settings['dividerBorderWidth']);
            $sanitized['dividerBorderWidth'] = ($width >= 0 && $width <= 10) ? $width : 1;
        }
        if (isset($settings['dividerBorderStyle'])) {
            $style = sanitize_text_field($settings['dividerBorderStyle']);
            $allowed_styles = $this->get_allowed_border_styles();
            $sanitized['dividerBorderStyle'] = in_array($style, $allowed_styles) ? $style : 'solid';
        }

        // Border radius (individual values)
        if (isset($settings['borderRadiusTopLeft'])) {
            $sanitized['borderRadiusTopLeft'] = $this->sanitize_radius($settings['borderRadiusTopLeft']);
        }
        if (isset($settings['borderRadiusTopRight'])) {
            $sanitized['borderRadiusTopRight'] = $this->sanitize_radius($settings['borderRadiusTopRight']);
        }
        if (isset($settings['borderRadiusBottomLeft'])) {
            $sanitized['borderRadiusBottomLeft'] = $this->sanitize_radius($settings['borderRadiusBottomLeft']);
        }
        if (isset($settings['borderRadiusBottomRight'])) {
            $sanitized['borderRadiusBottomRight'] = $this->sanitize_radius($settings['borderRadiusBottomRight']);
        }

        // Icon
        if (isset($settings['showIcon'])) {
            $sanitized['showIcon'] = filter_var($settings['showIcon'], FILTER_VALIDATE_BOOLEAN);
        }
        if (isset($settings['icon'])) {
            $sanitized['icon'] = sanitize_text_field($settings['icon']);
        }
        if (isset($settings['iconType'])) {
            $type = sanitize_text_field($settings['iconType']);
            $sanitized['iconType'] = in_array($type, array('character', 'emoji', 'image')) ? $type : 'character';
        }
        if (isset($settings['iconPosition'])) {
            $pos = sanitize_text_field($settings['iconPosition']);
            $sanitized['iconPosition'] = in_array($pos, array('left', 'right', 'extreme-right')) ? $pos : 'left';
        }
        if (isset($settings['animateIcon'])) {
            $sanitized['animateIcon'] = filter_var($settings['animateIcon'], FILTER_VALIDATE_BOOLEAN);
        }

        // Animation
        if (isset($settings['animationSpeed'])) {
            $speed = sanitize_text_field($settings['animationSpeed']);
            $sanitized['animationSpeed'] = in_array($speed, array('fast', 'normal', 'slow', 'none')) ? $speed : 'normal';
        }

        // Title Formatting - Toggles
        if (isset($settings['useHeading'])) {
            $sanitized['useHeading'] = filter_var($settings['useHeading'], FILTER_VALIDATE_BOOLEAN);
        }
        if (isset($settings['headingLevel'])) {
            $level = sanitize_text_field($settings['headingLevel']);
            $sanitized['headingLevel'] = in_array($level, array('h1', 'h2', 'h3', 'h4', 'h5', 'h6')) ? $level : 'h2';
        }
        if (isset($settings['useHeadingStyles'])) {
            $sanitized['useHeadingStyles'] = filter_var($settings['useHeadingStyles'], FILTER_VALIDATE_BOOLEAN);
        }
        if (isset($settings['useCustomTitleFormatting'])) {
            $sanitized['useCustomTitleFormatting'] = filter_var($settings['useCustomTitleFormatting'], FILTER_VALIDATE_BOOLEAN);
        }

        // Title Formatting - Visual Properties
        if (isset($settings['titleTextAlign'])) {
            $align = sanitize_text_field($settings['titleTextAlign']);
            $sanitized['titleTextAlign'] = in_array($align, array('left', 'center', 'right', 'justify')) ? $align : null;
        }
        if (isset($settings['titleFontSize'])) {
            // Allow CSS units: px, em, rem, %, etc.
            $sanitized['titleFontSize'] = sanitize_text_field($settings['titleFontSize']);
        }
        if (isset($settings['titleFontWeight'])) {
            $weight = sanitize_text_field($settings['titleFontWeight']);
            $allowed_weights = array('100', '200', '300', '400', '500', '600', '700', '800', '900', 'normal', 'bold');
            $sanitized['titleFontWeight'] = in_array($weight, $allowed_weights) ? $weight : null;
        }
        if (isset($settings['titleFontStyle'])) {
            $style = sanitize_text_field($settings['titleFontStyle']);
            $sanitized['titleFontStyle'] = in_array($style, array('normal', 'italic', 'oblique')) ? $style : null;
        }
        if (isset($settings['titleTextTransform'])) {
            $transform = sanitize_text_field($settings['titleTextTransform']);
            $sanitized['titleTextTransform'] = in_array($transform, array('none', 'capitalize', 'uppercase', 'lowercase')) ? $transform : null;
        }
        if (isset($settings['titleLetterSpacing'])) {
            $sanitized['titleLetterSpacing'] = sanitize_text_field($settings['titleLetterSpacing']);
        }
        if (isset($settings['titleWordSpacing'])) {
            $sanitized['titleWordSpacing'] = sanitize_text_field($settings['titleWordSpacing']);
        }
        if (isset($settings['titleTextDecoration'])) {
            $decoration = sanitize_text_field($settings['titleTextDecoration']);
            $sanitized['titleTextDecoration'] = in_array($decoration, array('none', 'underline', 'overline', 'line-through')) ? $decoration : null;
        }
        if (isset($settings['titleFontFamily'])) {
            $sanitized['titleFontFamily'] = sanitize_text_field($settings['titleFontFamily']);
        }

        return $sanitized;
    }

    /**
     * Sanitize color value (hex, rgba, hsla, or transparent)
     */
    private function sanitize_color($color) {
        if ($color === 'transparent') {
            return 'transparent';
        }

        // Handle 8-character hex colors with alpha channel (#RRGGBBAA)
        if (preg_match('/^#[0-9A-Fa-f]{8}$/', $color)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("Alpha hex color validated: $color");
            }
            return $color;
        }

        // Handle standard hex colors (#RGB or #RRGGBB)
        $hex = sanitize_hex_color($color);
        if ($hex) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("Standard hex color - Input: $color, Output: $hex");
            }
            return $hex;
        }

        // Handle rgba() format: rgba(r, g, b, a)
        if (preg_match('/^rgba\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(0|1|0?\.\d+)\s*\)$/i', $color, $matches)) {
            $r = intval($matches[1]);
            $g = intval($matches[2]);
            $b = intval($matches[3]);
            $a = floatval($matches[4]);

            // Validate RGB values (0-255) and alpha (0-1)
            if ($r >= 0 && $r <= 255 && $g >= 0 && $g <= 255 && $b >= 0 && $b <= 255 && $a >= 0 && $a <= 1) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("RGBA color validated: $color");
                }
                return $color;
            }
        }

        // Handle rgb() format: rgb(r, g, b)
        if (preg_match('/^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/i', $color, $matches)) {
            $r = intval($matches[1]);
            $g = intval($matches[2]);
            $b = intval($matches[3]);

            // Validate RGB values (0-255)
            if ($r >= 0 && $r <= 255 && $g >= 0 && $g <= 255 && $b >= 0 && $b <= 255) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("RGB color validated: $color");
                }
                return $color;
            }
        }

        // Handle hsla() format: hsla(h, s%, l%, a)
        if (preg_match('/^hsla\(\s*(\d+)\s*,\s*(\d+)%\s*,\s*(\d+)%\s*,\s*(0|1|0?\.\d+)\s*\)$/i', $color, $matches)) {
            $h = intval($matches[1]);
            $s = intval($matches[2]);
            $l = intval($matches[3]);
            $a = floatval($matches[4]);

            // Validate HSL values (h: 0-360, s: 0-100, l: 0-100, a: 0-1)
            if ($h >= 0 && $h <= 360 && $s >= 0 && $s <= 100 && $l >= 0 && $l <= 100 && $a >= 0 && $a <= 1) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("HSLA color validated: $color");
                }
                return $color;
            }
        }

        // Handle hsl() format: hsl(h, s%, l%)
        if (preg_match('/^hsl\(\s*(\d+)\s*,\s*(\d+)%\s*,\s*(\d+)%\s*\)$/i', $color, $matches)) {
            $h = intval($matches[1]);
            $s = intval($matches[2]);
            $l = intval($matches[3]);

            // Validate HSL values (h: 0-360, s: 0-100, l: 0-100)
            if ($h >= 0 && $h <= 360 && $s >= 0 && $s <= 100 && $l >= 0 && $l <= 100) {
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log("HSL color validated: $color");
                }
                return $color;
            }
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("Color validation failed for: $color");
        }
        return null;
    }

    /**
     * Get allowed border styles
     */
    private function get_allowed_border_styles() {
        return array('none', 'hidden', 'solid', 'dashed', 'dotted', 'double', 'groove', 'ridge', 'inset', 'outset');
    }

    /**
     * Sanitize border radius value
     */
    private function sanitize_radius($value) {
        $radius = intval($value);
        return ($radius >= 0 && $radius <= 100) ? $radius : 6;
    }

    /**
     * Inject accordion theme CSS variables
     */
    private function inject_accordion_theme_styles() {
        $themes = get_option('accordion_themes', array());

        if (empty($themes)) {
            // No themes at all, inject empty comment for debugging
            wp_add_inline_style('guten-nav-accordion', "/* No accordion themes found */\n");
            return;
        }

        $css = "/* Accordion Theme Styles - " . count($themes) . " theme(s) */\n";

        foreach ($themes as $theme_id => $theme) {
            // Skip default theme (it's in the base CSS file)
            if ($theme_id === 'default') {
                continue;
            }

            $css .= ".accordion-theme-{$theme_id} {\n";

            // Colors
            if (!empty($theme['headerBackgroundColor'])) {
                $css .= "    --header-bg-color: {$theme['headerBackgroundColor']};\n";
            }
            if (!empty($theme['headerTextColor'])) {
                $css .= "    --header-text-color: {$theme['headerTextColor']};\n";
            }
            if (!empty($theme['headerHoverColor'])) {
                $css .= "    --header-hover-color: {$theme['headerHoverColor']};\n";
            }
            if (!empty($theme['contentBackgroundColor'])) {
                $css .= "    --content-bg-color: {$theme['contentBackgroundColor']};\n";
            }

            // Main border
            if (!empty($theme['borderColor'])) {
                $css .= "    --border-color: {$theme['borderColor']};\n";
            }
            if (isset($theme['borderWidth']) && $theme['borderWidth'] !== null && $theme['borderWidth'] !== '') {
                $css .= "    --border-width: {$theme['borderWidth']}px;\n";
            }
            if (!empty($theme['borderStyle'])) {
                $css .= "    --border-style: {$theme['borderStyle']};\n";
            }

            // Divider border
            if (!empty($theme['dividerBorderColor'])) {
                $css .= "    --divider-border-color: {$theme['dividerBorderColor']};\n";
            }
            if (isset($theme['dividerBorderWidth']) && $theme['dividerBorderWidth'] !== null && $theme['dividerBorderWidth'] !== '') {
                $css .= "    --divider-border-width: {$theme['dividerBorderWidth']}px;\n";
            }
            if (!empty($theme['dividerBorderStyle'])) {
                $css .= "    --divider-border-style: {$theme['dividerBorderStyle']};\n";
            }

            // Border radius (apply if any value is non-zero)
            $tl = isset($theme['borderRadiusTopLeft']) ? intval($theme['borderRadiusTopLeft']) : 0;
            $tr = isset($theme['borderRadiusTopRight']) ? intval($theme['borderRadiusTopRight']) : 0;
            $bl = isset($theme['borderRadiusBottomLeft']) ? intval($theme['borderRadiusBottomLeft']) : 0;
            $br = isset($theme['borderRadiusBottomRight']) ? intval($theme['borderRadiusBottomRight']) : 0;

            // Only add border radius if at least one value is non-zero
            if ($tl !== 0 || $tr !== 0 || $bl !== 0 || $br !== 0) {
                $css .= "    --border-radius: {$tl}px {$tr}px {$br}px {$bl}px;\n";
            }

            // Title Formatting
            if (!empty($theme['titleTextAlign'])) {
                $css .= "    --title-text-align: {$theme['titleTextAlign']};\n";
            }
            if (!empty($theme['titleFontSize'])) {
                $css .= "    --title-font-size: {$theme['titleFontSize']};\n";
            }
            if (!empty($theme['titleFontWeight'])) {
                $css .= "    --title-font-weight: {$theme['titleFontWeight']};\n";
            }
            if (!empty($theme['titleFontStyle'])) {
                $css .= "    --title-font-style: {$theme['titleFontStyle']};\n";
            }
            if (!empty($theme['titleTextTransform'])) {
                $css .= "    --title-text-transform: {$theme['titleTextTransform']};\n";
            }
            if (!empty($theme['titleLetterSpacing'])) {
                $css .= "    --title-letter-spacing: {$theme['titleLetterSpacing']};\n";
            }
            if (!empty($theme['titleWordSpacing'])) {
                $css .= "    --title-word-spacing: {$theme['titleWordSpacing']};\n";
            }
            if (!empty($theme['titleTextDecoration'])) {
                $css .= "    --title-text-decoration: {$theme['titleTextDecoration']};\n";
            }
            if (!empty($theme['titleFontFamily'])) {
                $css .= "    --title-font-family: {$theme['titleFontFamily']};\n";
            }

            $css .= "}\n\n";
        }

        // Inject the CSS
        wp_add_inline_style('guten-nav-accordion', $css);
    }

    /**
     * Inject page style CSS variables (Phase 3 - Section 8.1)
     * Per section 8.1 of ACCORDION-THEME-SYSTEM-V2-SPEC.md
     */
    private function inject_accordion_page_styles() {
        global $post;

        if (!$post || !has_block('sammu/accordion', $post)) {
            return;
        }

        $page_styles = get_post_meta($post->ID, '_accordion_page_styles', true);

        if (empty($page_styles) || !is_array($page_styles)) {
            return;
        }

        $css = "/* Accordion Page Styles - Post {$post->ID} */\n";

        foreach ($page_styles as $style_id => $style_data) {
            $css .= ".accordion-page-style-{$style_id} {\n";

            // Inject CSS variables for each override
            foreach ($style_data['overrides'] as $attr => $value) {
                $css_var = $this->attribute_to_css_var($attr);
                if ($css_var) {
                    // Format value appropriately (add px for numbers, etc.)
                    $formatted_value = $this->format_css_value($attr, $value);
                    $css .= "    {$css_var}: {$formatted_value};\n";
                }
            }

            $css .= "}\n\n";
        }

        wp_add_inline_style('guten-nav-accordion', $css);
    }

    /**
     * Convert attribute name to CSS variable
     */
    private function attribute_to_css_var($attr) {
        $map = array(
            'headerBackgroundColor' => '--header-bg-color',
            'headerTextColor' => '--header-text-color',
            'headerHoverColor' => '--header-hover-color',
            'contentBackgroundColor' => '--content-bg-color',
            'borderColor' => '--border-color',
            'borderWidth' => '--border-width',
            'borderStyle' => '--border-style',
            'dividerBorderColor' => '--divider-border-color',
            'dividerBorderWidth' => '--divider-border-width',
            'dividerBorderStyle' => '--divider-border-style',
            'borderRadiusTopLeft' => '--border-radius-top-left',
            'borderRadiusTopRight' => '--border-radius-top-right',
            'borderRadiusBottomLeft' => '--border-radius-bottom-left',
            'borderRadiusBottomRight' => '--border-radius-bottom-right',
            'titleTextAlign' => '--title-text-align',
            'titleFontSize' => '--title-font-size',
            'titleFontWeight' => '--title-font-weight',
            'titleFontStyle' => '--title-font-style',
            'titleTextTransform' => '--title-text-transform',
            'titleLetterSpacing' => '--title-letter-spacing',
            'titleWordSpacing' => '--title-word-spacing',
            'titleTextDecoration' => '--title-text-decoration',
            'titleFontFamily' => '--title-font-family',
        );

        return isset($map[$attr]) ? $map[$attr] : null;
    }

    /**
     * Format CSS value (add px for numbers, etc.)
     */
    private function format_css_value($attr, $value) {
        // Number attributes that need 'px' suffix
        $number_attrs = array('borderWidth', 'dividerBorderWidth', 'borderRadiusTopLeft',
                            'borderRadiusTopRight', 'borderRadiusBottomLeft', 'borderRadiusBottomRight');

        if (in_array($attr, $number_attrs)) {
            return $value . 'px';
        }

        // All other values (colors, strings, etc.) - return as-is
        return $value;
    }

    // ===== AUTO-DEDUPLICATION SYSTEM (PHASE 3) =====

    /**
     * Auto-optimize accordion customizations on post save
     * Per section 6.1 of ACCORDION-THEME-SYSTEM-V2-SPEC.md
     *
     * PERFORMANCE OPTIMIZATION: Hash-based throttling (99% reduction in processing)
     * Only processes when accordion blocks actually change
     */
    public function auto_optimize_accordions($post_id, $post, $update) {
        // Skip autosaves, revisions, and non-accordion posts
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (wp_is_post_revision($post_id)) return;
        if (!has_block('sammu/accordion', $post)) return;

        // Quick check: Hash only accordion blocks (lighter than full parse)
        // Extract JSON from accordion block comments
        preg_match_all('/<!-- wp:sammu\/accordion (.*?) -->/s', $post->post_content, $matches);
        $accordion_blocks_data = implode('', $matches[1]); // Concatenate all accordion JSON
        $new_hash = md5($accordion_blocks_data);

        $old_hash = get_post_meta($post_id, '_accordion_blocks_hash', true);

        if ($old_hash === $new_hash) {
            error_log("AUTO-OPTIMIZE: Skipping post $post_id - accordion blocks unchanged");
            return;
        }

        error_log("=== AUTO-OPTIMIZE: Post $post_id (accordions changed) ===");

        // Allow users to disable auto-optimization via filter
        if (!apply_filters('guten_nav_accordion_auto_optimize', true, $post_id)) {
            error_log("AUTO-OPTIMIZE: Disabled by filter for post $post_id");
            return;
        }

        // Run deduplication
        $this->deduplicate_accordion_customizations($post_id);

        // Update hash AFTER successful optimization
        update_post_meta($post_id, '_accordion_blocks_hash', $new_hash);
    }

    /**
     * Deduplication algorithm
     * Per section 6.2 of ACCORDION-THEME-SYSTEM-V2-SPEC.md
     *
     * Detects 2+ identical customizations and creates page styles
     */
    private function deduplicate_accordion_customizations($post_id) {
        $post = get_post($post_id);
        $blocks = parse_blocks($post->post_content);

        // Step 1: Extract all customizations with hashes
        $customizations_by_hash = array();

        foreach ($blocks as $index => $block) {
            if ($block['blockName'] !== 'sammu/accordion') continue;

            $attrs = $block['attrs'];

            // Skip if already using page style
            if (isset($attrs['_pageStyleRef'])) continue;

            // Extract inline customizations
            $deltas = $this->extract_inline_deltas($attrs);
            if (empty($deltas)) continue;

            // Generate hash
            $base_theme = isset($attrs['selectedTheme']) ? $attrs['selectedTheme'] : 'default';
            $hash = $this->compute_customization_hash($base_theme, $deltas);

            if (!isset($customizations_by_hash[$hash])) {
                $customizations_by_hash[$hash] = array(
                    'base_theme' => $base_theme,
                    'deltas' => $deltas,
                    'block_indices' => array(),
                );
            }

            $customizations_by_hash[$hash]['block_indices'][] = $index;
        }

        error_log("Found " . count($customizations_by_hash) . " unique customization patterns");

        // Step 2: Find duplicates (2+ blocks with same hash)
        $page_styles = get_post_meta($post_id, '_accordion_page_styles', true);
        if (!is_array($page_styles)) $page_styles = array();

        $needs_update = false;

        foreach ($customizations_by_hash as $hash => $data) {
            $usage_count = count($data['block_indices']);

            if ($usage_count < 2) {
                error_log("Hash $hash: only 1 usage, keeping inline");
                continue; // No duplication
            }

            error_log("Hash $hash: $usage_count usages, creating page style");

            // Step 3: Create or reuse page style
            $style_id = $this->find_page_style_by_hash($page_styles, $hash);

            if (!$style_id) {
                $style_id = $this->generate_page_style_id($page_styles);
                $page_styles[$style_id] = array(
                    'base_theme' => $data['base_theme'],
                    'overrides' => $data['deltas'],
                    'hash' => $hash,
                    'usage_count' => $usage_count,
                    'auto_generated' => true,
                    'created' => current_time('timestamp'),
                );
                error_log("Created new page style: $style_id");
            } else {
                $page_styles[$style_id]['usage_count'] = $usage_count;
                error_log("Reusing existing page style: $style_id");
            }

            // Step 4: Replace inline attributes with page style reference
            foreach ($data['block_indices'] as $block_index) {
                $attrs = $blocks[$block_index]['attrs'];

                // Remove all delta attributes
                foreach ($data['deltas'] as $attr => $value) {
                    unset($attrs[$attr]);
                }

                // Add page style reference
                $attrs['_pageStyleRef'] = $style_id;
                unset($attrs['isCustomized']); // No longer inline customized

                $blocks[$block_index]['attrs'] = $attrs;
                $needs_update = true;
            }
        }

        // Step 5: Cleanup unused page styles
        $page_styles = $this->cleanup_unused_page_styles($page_styles, $blocks);

        // Step 6: Save changes
        if ($needs_update) {
            update_post_meta($post_id, '_accordion_page_styles', $page_styles);

            $new_content = serialize_blocks($blocks);

            remove_action('save_post', array($this, 'auto_optimize_accordions'), 10);
            wp_update_post(array(
                'ID' => $post_id,
                'post_content' => $new_content,
            ));
            add_action('save_post', array($this, 'auto_optimize_accordions'), 10, 3);

            error_log("✓ Optimization complete");
        }
    }

    /**
     * Extract inline delta attributes from block
     */
    private function extract_inline_deltas($attrs) {
        $customization_attrs = array(
            'headerBackgroundColor', 'headerTextColor', 'headerHoverColor',
            'contentBackgroundColor', 'borderColor', 'borderWidth', 'borderStyle',
            'dividerBorderColor', 'dividerBorderWidth', 'dividerBorderStyle',
            'borderRadiusTopLeft', 'borderRadiusTopRight',
            'borderRadiusBottomLeft', 'borderRadiusBottomRight',
            'animationSpeed', 'showIcon', 'icon', 'iconType',
            'iconPosition', 'animateIcon', 'useHeading', 'headingLevel',
            'useHeadingStyles', 'useCustomTitleFormatting',
            'titleTextAlign', 'titleFontSize', 'titleFontWeight',
            'titleFontStyle', 'titleTextTransform', 'titleLetterSpacing',
            'titleWordSpacing', 'titleTextDecoration', 'titleFontFamily',
        );

        $deltas = array();
        foreach ($customization_attrs as $attr) {
            if (isset($attrs[$attr])) {
                $deltas[$attr] = $attrs[$attr];
            }
        }

        return $deltas;
    }

    /**
     * Compute hash for customization (base_theme + deltas)
     */
    private function compute_customization_hash($base_theme, $deltas) {
        ksort($deltas); // Ensure consistent ordering
        return md5($base_theme . '|' . json_encode($deltas));
    }

    /**
     * Find page style by hash
     */
    private function find_page_style_by_hash($page_styles, $hash) {
        foreach ($page_styles as $style_id => $style_data) {
            if (isset($style_data['hash']) && $style_data['hash'] === $hash) {
                return $style_id;
            }
        }
        return null;
    }

    /**
     * Generate unique 3-character page style ID
     */
    private function generate_page_style_id($existing_styles) {
        $chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
        $max_attempts = 100;

        for ($i = 0; $i < $max_attempts; $i++) {
            $id = '';
            for ($j = 0; $j < 3; $j++) {
                $id .= $chars[rand(0, strlen($chars) - 1)];
            }

            if (!isset($existing_styles[$id])) {
                return $id;
            }
        }

        // Fallback: use timestamp-based ID
        return substr(md5(microtime()), 0, 3);
    }

    /**
     * Cleanup unused page styles
     */
    private function cleanup_unused_page_styles($page_styles, $blocks) {
        $used_refs = array();

        foreach ($blocks as $block) {
            if ($block['blockName'] === 'sammu/accordion' &&
                isset($block['attrs']['_pageStyleRef'])) {
                $used_refs[] = $block['attrs']['_pageStyleRef'];
            }
        }

        foreach ($page_styles as $style_id => $style_data) {
            if (isset($style_data['auto_generated']) &&
                $style_data['auto_generated'] === true &&
                !in_array($style_id, $used_refs)) {

                error_log("Removing unused page style: $style_id");
                unset($page_styles[$style_id]);
            }
        }

        return $page_styles;
    }
}

// Initialize plugin
$guten_nav_plugin = new GutenNavPlugin();

// Register activation hook to sync default theme to database
register_activation_hook(__FILE__, function() {
    // We need to manually load the class and call sync since this runs before __construct
    $theme_file = GUTEN_NAV_PLUGIN_PATH . 'include/theme-default.php';

    if (file_exists($theme_file)) {
        $default_theme = include $theme_file;

        $themes = get_option('accordion_themes', array());
        if (!is_array($themes)) {
            $themes = array();
        }

        $themes['default'] = array_merge(
            array(
                'theme_id' => 'default',
                'theme_name' => 'Default'
            ),
            $default_theme
        );

        update_option('accordion_themes', $themes);

        error_log('Guten Nav Plugin: Default theme synced to database on activation');
    }
});