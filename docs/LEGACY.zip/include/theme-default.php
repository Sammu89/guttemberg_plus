<?php
/**
 * Complete Default Theme Snapshot
 *
 * COMPLETE SNAPSHOT ARCHITECTURE:
 * ===============================
 * This file defines the Default theme with ALL 33+ attributes having explicit values.
 * NO null values - every attribute has a real, concrete default.
 *
 * Visual attributes use values from accordion.css
 * Logical attributes (booleans/strings) use hardcoded defaults
 *
 * This is loaded once on plugin initialization and stored in DB as a complete theme.
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

return array(
    'theme_id' => 'default',
    'theme_name' => 'Default',

    // === COLORS ===
    // Values from accordion.css
    'headerBackgroundColor' => '#007cba',
    'headerTextColor' => '#ffffff',
    'headerHoverColor' => '#005a87',
    'contentBackgroundColor' => '#f8f9fa',

    // === MAIN BORDER ===
    'borderColor' => '#ddd',
    'borderWidth' => 1,
    'borderStyle' => 'solid',

    // === DIVIDER BORDER ===
    'dividerBorderColor' => '#ddd',
    'dividerBorderWidth' => 1,
    'dividerBorderStyle' => 'solid',

    // === BORDER RADIUS ===
    'borderRadiusTopLeft' => 6,
    'borderRadiusTopRight' => 6,
    'borderRadiusBottomLeft' => 6,
    'borderRadiusBottomRight' => 6,

    // === ANIMATION ===
    'animationSpeed' => 'normal',

    // === ICON ===
    'showIcon' => true,
    'icon' => '▼',
    'iconType' => 'character',
    'iconPosition' => 'left',
    'animateIcon' => true,

    // === TITLE FORMATTING - Toggles ===
    'useHeading' => false,
    'headingLevel' => 'h2',
    'useHeadingStyles' => false,
    'useCustomTitleFormatting' => false,

    // === TITLE FORMATTING - Visual Properties ===
    // These are disabled by default (useCustomTitleFormatting = false)
    // But we still provide real values for complete snapshot
    'titleTextAlign' => 'left',
    'titleFontSize' => '16px',
    'titleFontWeight' => 'normal',
    'titleFontStyle' => 'normal',
    'titleTextTransform' => 'none',
    'titleLetterSpacing' => 'normal',
    'titleWordSpacing' => 'normal',
    'titleTextDecoration' => 'none',
    'titleFontFamily' => 'inherit',
);
