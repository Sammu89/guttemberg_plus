# Shared Block System: Data Flow, State Management, and Event Synchronization

## Shared Architecture Overview

This document describes the data flow and state management architecture used by **both Accordion and Tabs blocks**. The system is designed with shared infrastructure from the beginning, with both blocks using the same logic, hooks, and patterns.

**Key Principle**: All state management logic is implemented in `src/shared/theme-system/` and is shared between block types. Block-specific differences (CSS files, database options, event names) are handled via a `blockType` parameter.

## Table of Contents

1. [Data Flow Overview](#1-data-flow-overview)
2. [Loading Sequence](#2-loading-sequence)
3. [CSS Parsing and Default Values](#3-css-parsing-and-default-values)
4. [Effective Value Resolution](#4-effective-value-resolution)
5. [Sidebar Control Updates](#5-sidebar-control-updates)
6. [Customization Detection Flow](#6-customization-detection-flow)
7. [Theme Switching Flow](#7-theme-switching-flow)
8. [Saving Theme Flow (Update Existing)](#8-saving-theme-flow-update-existing)
9. [Creating New Theme Flow](#9-creating-new-theme-flow)
10. [Event Synchronization](#10-event-synchronization)
11. [Customization Cache Management](#11-customization-cache-management)
12. [Post Save Flow](#12-post-save-flow)
13. [Race Conditions to Avoid](#13-race-conditions-to-avoid)
14. [State Management Architecture](#14-state-management-architecture)
15. [AJAX Operations](#15-ajax-operations)

---

## 1. Data Flow Overview

The accordion system has four primary data flow paths:

### 1.1 Database (Themes) → Editor → UI Controls

```
┌─────────────────────────────────────────────────────────────────┐
│ WordPress Database (wp_options)                                 │
│  - accordion_themes: { theme_abc: {...} }                       │
│  - tabs_themes: { theme_xyz: {...} }                            │
└────────────────┬────────────────────────────────────────────────┘
                 │
                 │ AJAX Request (on editor mount)
                 │ Action: get_[blocktype]_themes
                 │ (e.g., get_accordion_themes or get_tabs_themes)
                 ▼
┌─────────────────────────────────────────────────────────────────┐
│ useThemeManagement Hook (React State)                           │
│  - Location: src/shared/theme-system/theme-manager.js           │
│  - themes: Object (keyed by theme ID)                           │
│  - isLoading: boolean                                           │
│  - blockType parameter determines which DB option to load       │
└────────────────┬────────────────────────────────────────────────┘
                 │
                 │ Pass to useEffectiveValues hook
                 │ Combine with block attributes
                 ▼
┌─────────────────────────────────────────────────────────────────┐
│ useEffectiveValues Hook (Computed, Memoized)                    │
│  - Location: src/shared/theme-system/cascade-resolver.js        │
│  - effectiveValues: { titleBackgroundColor: '#fff', ... }       │
│  - Resolves via 3-tier cascade                                  │
│  - Uses CSS defaults from window.[blocktype]Defaults            │
└────────────────┬────────────────────────────────────────────────┘
                 │
                 │ Pass to Inspector Controls
                 ▼
┌─────────────────────────────────────────────────────────────────┐
│ Sidebar Controls (ColorPicker, SelectControl, etc.)             │
│  - Location: src/shared/components/ (shared UI components)      │
│  - Display effective value to user                              │
│  - User sees what's ACTUALLY rendered (resolved value)          │
└─────────────────────────────────────────────────────────────────┘
```

**Why this flow:**
- Themes are the source of truth for global styling
- Effective values ensure sidebar always shows what user will see
- 3-tier cascade allows overrides at block/theme/default levels

### 1.2 UI Controls → Block Attributes → Database (Customizations)

```
┌─────────────────────────────────────────────────────────────────┐
│ User Changes Color Picker                                       │
│  - User selects #ff0000 for titleBackgroundColor                │
└────────────────┬────────────────────────────────────────────────┘
                 │
                 │ onChange handler fires
                 ▼
┌─────────────────────────────────────────────────────────────────┐
│ setAttributes({ titleBackgroundColor: '#ff0000' })              │
│  - Block attribute updated in WordPress Gutenberg state         │
│  - Triggers re-render                                           │
└────────────────┬────────────────────────────────────────────────┘
                 │
                 │ Customization detection (useEffect)
                 │ Compares block attr vs theme value
                 ▼
┌─────────────────────────────────────────────────────────────────┐
│ Auto-detect: isCustomized = true                                │
│  - setAttributes({ isCustomized: true })                        │
│  - Sidebar shows "(custom)" indicator                           │
└────────────────┬────────────────────────────────────────────────┘
                 │
                 │ User clicks "Save Post"
                 ▼
┌─────────────────────────────────────────────────────────────────┐
│ WordPress Serializes Block to post_content                      │
│  - <!-- wp:custom/accordion {...attributes} -->              │
│  - titleBackgroundColor: '#ff0000' saved inline in HTML         │
└─────────────────────────────────────────────────────────────────┘
                 │
                 │ On next page load
                 ▼
┌─────────────────────────────────────────────────────────────────┐
│ Block Mounts with Saved Attributes                              │
│  - Customization persists across sessions                       │
└─────────────────────────────────────────────────────────────────┘
```

**Why this flow:**
- Immediate feedback (sidebar updates instantly)
- Automatic customization detection (no manual marking)
- Persistence through WordPress post_content

### 1.3 Themes → Multiple Blocks

```
┌─────────────────────────────────────────────────────────────────┐
│ Page has 3 Accordion Blocks                                     │
│  - Block A: uses "Dark Mode" theme, id 34gh3                              │
│  - Block B: uses "Dark Mode" theme , id 34gh3                              │
│  - Block C: uses "Light Mode" theme , id hj23                            │
└─────────────────────────────────────────────────────────────────┘
                 │
                 │ All blocks reference same theme object
                 ▼
┌─────────────────────────────────────────────────────────────────┐
│ Shared Theme State (from useThemeManagement)                    │
│  - themes: {                                                    │
│      'theme_34gh3': { titleBackgroundColor: '#222', ... },      │
│      'theme_hj23': { titleBackgroundColor: '#fff', ... }        │
│    }                                                            │
└─────────────────────────────────────────────────────────────────┘
                 │
                 │ User updates "Dark Mode" theme in Block A
                 │ (changes titleBackgroundColor to #111)
                 ▼
┌─────────────────────────────────────────────────────────────────┐
│ CustomEvent Dispatched: '[blocktype]ThemeUpdated'               │
│  - accordionThemeUpdated for accordion blocks                   │
│  - tabsThemeUpdated for tabs blocks                             │
│  - detail: { themeId: 'theme_34gh3', themes: {...}, operation } │
│  - Event dispatched by src/shared/theme-system/theme-manager.js │
└────────────────┬────────────────────────────────────────────────┘
                 │
                 │ Event listeners in ALL blocks of same type fire
                 ▼
┌─────────────────────────────────────────────────────────────────┐
│ Block A: Triggered update, clears customizations (already done) │
│ Block B: Receives event, re-renders      │
│ Block C: Receives event, ignores (different theme)              │
└─────────────────────────────────────────────────────────────────┘
                 │
                 │ Result
                 ▼
┌─────────────────────────────────────────────────────────────────┐
│ Both Block A and B now show #111 background                     │
│ Block C unchanged (uses different theme)                        │
└─────────────────────────────────────────────────────────────────┘
```

**Why this flow:**
- Single source of truth for themes (no duplication)
- Real-time synchronization across all blocks
- Efficient updates (only affected blocks re-render)

### 1.4 One Block → Other Blocks (Event Synchronization)

See section [9. Event Synchronization](#9-event-synchronization) for detailed flow.

---

## 2. Loading Sequence

**Critical:** The order matters to prevent race conditions and undefined values.

```
Step 1: Editor Loads, Mounts Accordion Block
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────┐
│ WordPress Gutenberg Editor Initializes      │
│  - Parse post_content for blocks            │
│  - Find <!-- wp:custom/accordion -->     │
│  - Extract saved attributes                 │
└─────────────┬───────────────────────────────┘
              │
              │ React renders Edit component
              ▼
┌─────────────────────────────────────────────┐
│ Edit Component Mounts                       │
│  - attributes: { selectedTheme: 'dark', ... }│
│  - allThemes: {} (empty - not loaded yet)  │
└─────────────┬───────────────────────────────┘
              │
              │ useThemeManagement hook runs
              ▼

Step 2: Fetch Themes from Database (AJAX)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────┐
│ useThemeManagement Hook                     │
│  - State: isLoading = true                  │
│  - State: themes = {}                       │
└─────────────┬───────────────────────────────┘
              │
              │ useEffect(() => loadThemes(), [])
              │ Runs ONCE on mount
              ▼
┌─────────────────────────────────────────────┐
│ AJAX Request to Server                      │
│  - Action: get_accordion_themes             │
│  - URL: /wp-admin/admin-ajax.php            │
└─────────────┬───────────────────────────────┘
              │
              │ Server queries wp_options
              │ Returns: { success: true, data: { themes: {...} } }
              ▼
┌─────────────────────────────────────────────┐
│ Response Received                           │
│  - Parse JSON                               │
│  - Validate response.success                │
│  - Extract response.data.themes             │
└─────────────┬───────────────────────────────┘
              │
              │ Update React state
              ▼

Step 3: Wait for Themes to Load (Loading State)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────┐
│ useThemeManagement Updates State            │
│  - setThemes(data.themes)                   │
│  - setIsLoading(false)                      │
└─────────────┬───────────────────────────────┘
              │
              │ React re-renders
              ▼
┌─────────────────────────────────────────────┐
│ Edit Component Re-renders                   │
│  - isLoading: false ✓                       │
│  - allThemes: { theme_id: {...}, ... } ✓     │
└─────────────┬───────────────────────────────┘
              │
              │ Guard condition passes:
              │ if (!isLoading && allThemes)
              ▼

Step 4: Resolve Effective Values (3-Tier Cascade)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────┐
│ useEffectiveValues Hook Runs                │
│  - Input: attributes, allThemes             │
│  - Process: 3-tier cascade for each attr    │
└─────────────┬───────────────────────────────┘
              │
              │ For each attribute (33+ total):
              │ Check: block → theme → default (from CSS)
              ▼
┌─────────────────────────────────────────────┐
│ Example: titleBackgroundColor               │
│  - Block attr: undefined                    │
│  - Theme value: '#222' ✓ (use this)         │
│  - Default: '#fff' (from accordion.css)     │
│ Result: effectiveValue = '#222'             │
└─────────────┬───────────────────────────────┘
              │
              │ Build effectiveValues object
              │ { titleBackgroundColor: '#222', accordionBorderWidth: 1, ... }
              ▼

Step 5: Populate Sidebar Controls
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────┐
│ Inspector Controls Render                   │
│  - Pass effectiveValues to each control     │
└─────────────┬───────────────────────────────┘
              │
              │ Example: ColorPickerControl
              ▼
┌─────────────────────────────────────────────┐
│ <ColorPickerControl                         │
│   value={effectiveValues.titleBgColor}      │
│   onChange={(val) => setAttributes({        │
│     titleBackgroundColor: val               │
│   })}                                       │
│ />                                          │
│                                             │
│ Displays: #222 (from theme)                 │
└─────────────┬───────────────────────────────┘
              │
              ▼

Step 6: Render Accordion Preview
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────┐
│ Block Preview Renders                       │
│  - Use effectiveValues for styles           │
│  - Apply CSS variables                      │
│  - Show visual preview to user              │
└─────────────────────────────────────────────┘
```

### Why This Order Matters

**Race Condition 1: Rendering UI before themes load**
```javascript
// ❌ BAD - Race condition
if (!isLoading) {  // Only checks loading, not themes
  return <ColorPicker value={theme.headerBg} />  // theme is undefined!
}

// ✅ GOOD - Waits for both
if (!isLoading && allThemes && Object.keys(allThemes).length > 0) {
  return <ColorPicker value={effectiveValues.headerBg} />  // Safe
}
```

**Race Condition 2: Resolving effective values before themes load**
```javascript
// ❌ BAD - Returns undefined
const effectiveValue = useMemo(() => {
  const theme = allThemes[selectedTheme];  // allThemes is {}
  return theme?.titleBackgroundColor;  // undefined
}, [allThemes]);

// ✅ GOOD - Waits for themes
const effectiveValue = useMemo(() => {
  if (!allThemes || Object.keys(allThemes).length === 0) {
    return window.accordionDefaults.titleBackgroundColor;  // From CSS
  }
  // ... 3-tier cascade
}, [allThemes]);
```

**Race Condition 3: Customization detection before themes load**
```javascript
// ❌ BAD - False positives
useEffect(() => {
  const isCustomized = attributes.headerBg !== theme.headerBg;
  // theme.headerBg is undefined, so comparison always fails
}, [attributes]);

// ✅ GOOD - Waits for themes
useEffect(() => {
  if (isLoading || !allThemes) return;  // Guard
  const isCustomized = hasCustomizations;  // Safe to check
}, [isLoading, allThemes, hasCustomizations]);
```

---

## 3. CSS Parsing and Default Values

The default values for all accordion attributes come from the `accordion.css` file, making it the **single source of truth** for defaults. This section explains how PHP parses the CSS file and provides those defaults to JavaScript.

### 3.1 Why CSS as Source of Truth

**Problem Before v6.0:**
Defaults were scattered across PHP arrays, JavaScript objects, and CSS files. Changing a default value required updating 3+ files.

**Solution in v6.0:**
All defaults defined ONCE in `accordion.css` at `:root`. PHP parses this file and provides values to JavaScript via `wp_localize_script`.

### 3.2 The CSS File Structure

```css
/* accordion.css */
:root {
  /* All default values defined here */
  --accordion-default-title-color: #333333;
  --accordion-default-title-bg: #f5f5f5;
  --accordion-default-title-size: 16px;
  --accordion-default-border-width: 1px;
  /* ... all other defaults */
}

.accordion-theme-default .accordion-title {
  color: var(--custom-title-color, var(--accordion-default-title-color));
  /*      ↑ per-block override      ↑ default fallback                 */
}
```

### 3.3 PHP Parsing Process

```php
/**
 * Parse accordion.css and extract default values
 * Cached with file modification time for performance
 */
function get_accordion_plugin_defaults() {
    // Check transient cache
    $cached = get_transient('accordion_parsed_defaults');
    $cssPath = plugin_dir_path(__FILE__) . 'assets/css/accordion.css';
    $currentModTime = filemtime($cssPath);

    if ($cached !== false &&
        isset($cached['mtime']) &&
        $cached['mtime'] === $currentModTime) {
        return $cached['defaults'];
    }

    // Parse CSS file
    $css = file_get_contents($cssPath);
    $defaults = parse_css_defaults($css);

    // Cache with file modification time
    set_transient('accordion_parsed_defaults', [
        'mtime' => $currentModTime,
        'defaults' => $defaults
    ], YEAR_IN_SECONDS);

    return $defaults;
}
```

### 3.4 JavaScript Receives Defaults

```php
// In PHP - enqueue script with localized defaults
function enqueue_accordion_editor_assets() {
    wp_enqueue_script('accordion-editor', /* ... */);

    $defaults = get_accordion_plugin_defaults();
    wp_localize_script('accordion-editor', 'accordionDefaults', $defaults);
}
```

```javascript
// In JavaScript - access defaults
const DEFAULTS = window.accordionDefaults || {};

// Use in cascade resolution
const effectiveValue = attributes.titleColor ??
                       theme.titleColor ??
                       DEFAULTS.titleColor;
```

### 3.5 Cache Invalidation

The cache automatically invalidates when the CSS file changes:
- PHP checks `filemtime()` on every request
- If modification time differs, cache is regenerated
- For development: manually clear with `delete_transient('accordion_parsed_defaults')`

### 3.6 Data Flow Diagram

```
┌───────────────────────────────────────────────────────┐
│ accordion.css                                         │
│  :root {                                              │
│    --accordion-default-title-color: #333;             │
│  }                                                    │
└──────────────────┬────────────────────────────────────┘
                   │
                   │ PHP parses on first request
                   ▼
┌───────────────────────────────────────────────────────┐
│ get_accordion_plugin_defaults()                       │
│  - Extracts :root CSS variables                       │
│  - Maps CSS names → attribute names                   │
│  - Parses values to PHP types                         │
└──────────────────┬────────────────────────────────────┘
                   │
                   │ Cached in transient (with mtime)
                   ▼
┌───────────────────────────────────────────────────────┐
│ wp_localize_script('accordionDefaults', [...])        │
│  - PHP array → JavaScript object                      │
└──────────────────┬────────────────────────────────────┘
                   │
                   │ Available in editor
                   ▼
┌───────────────────────────────────────────────────────┐
│ window.accordionDefaults                              │
│  { titleColor: '#333', titleFontSize: 16, ... }       │
└───────────────────────────────────────────────────────┘
```

---

## 4. Effective Value Resolution

The **effective value** is what the user actually sees in the sidebar and preview. It's resolved automatically on every render using a 3-tier cascade.

### 4.1 Input, Process, Output

```
INPUT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ 1. Block Attributes (from WordPress Gutenberg)      │
│    - selectedTheme: 'theme_34gh3'                   │
│    - titleBackgroundColor: undefined (not set)      │
│    - accordionBorderWidth: 2 (customized)           │
├─────────────────────────────────────────────────────┤
│ 2. Selected Theme (from database)                   │
│    - themes['theme_34gh3']:                         │
│      { titleBackgroundColor: '#222',                │
│        accordionBorderWidth: 1 }                    │
├─────────────────────────────────────────────────────┤
│ 3. Default Values (from accordion.css)              │
│    - window.accordionDefaults:                      │
│      { titleBackgroundColor: '#fff',                │
│        accordionBorderWidth: 1 }                    │
│    - Parsed from :root CSS variables by PHP         │
└─────────────────────────────────────────────────────┘

PROCESS (3-Tier Cascade)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
For EACH attribute (titleBackgroundColor example):

┌─────────────────────────────────────────────────────┐
│ Tier 1: Check Block Attribute (highest priority)   │
│  - attributes.titleBackgroundColor === undefined    │
│  - Skip to next tier                                │
└─────────────────────────────────────────────────────┘
                      ↓
┌─────────────────────────────────────────────────────┐
│ Tier 2: Check Selected Theme                       │
│  - theme.titleBackgroundColor === '#222' ✓          │
│  - USE THIS VALUE                                   │
└─────────────────────────────────────────────────────┘
                      ↓
┌─────────────────────────────────────────────────────┐
│ Tier 3: Check Default (not reached)                │
│  - window.accordionDefaults.titleBackgroundColor    │
│  - === '#fff' (from accordion.css)                  │
└─────────────────────────────────────────────────────┘

For accordionBorderWidth:

┌─────────────────────────────────────────────────────┐
│ Tier 1: Check Block Attribute                      │
│  - attributes.accordionBorderWidth === 2 ✓          │
│  - USE THIS VALUE (stop here)                      │
└─────────────────────────────────────────────────────┘

OUTPUT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ effectiveValues Object (33+ attributes resolved)    │
│  {                                                  │
│    titleBackgroundColor: '#222',   // from theme    │
│    accordionBorderWidth: 2,        // from block    │
│    accordionBorderColor: '#666',   // from theme    │
│    showIcon: true,                 // from theme    │
│    ...                                              │
│  }                                                  │
└─────────────────────────────────────────────────────┘
```

### 4.2 When This Happens

**Automatically on EVERY render** via React `useMemo`:

```javascript
// blocks/shared/hooks/useEffectiveValues.js
const effectiveValues = useMemo(() => {
  const effectiveValues = {};
  const defaults = window.accordionDefaults || {};

  Object.keys(attributeConfig).forEach(attr => {
    effectiveValues[attr] = computeEffectiveValue(
      attr,
      attributes,       // Block attributes
      selectedTheme,    // Theme
      defaults          // Defaults from CSS (via PHP)
    );
  });

  return effectiveValues;
}, [attributes, allThemes, selectedTheme]);
```

**Re-computation triggers:**
- User changes a sidebar control → `attributes` changes
- User switches theme → `selectedTheme` changes
- Theme is updated → `allThemes` changes

### 4.3 Why This Exists

**Without effective values:**
```javascript
// ❌ Sidebar shows wrong value
<ColorPicker
  value={attributes.titleBackgroundColor}  // undefined
/>
// User sees empty color picker, but preview shows theme color

// ❌ Code duplication everywhere
const displayValue = attributes.titleBg || theme.titleBg || window.accordionDefaults.titleBg;
const borderValue = attributes.accordionBorder || theme.accordionBorder || window.accordionDefaults.accordionBorder;
// Repeated in 50+ places
```

**With effective values:**
```javascript
// ✅ Sidebar shows correct value
<ColorPicker
  value={effectiveValues.titleBackgroundColor}  // '#222' (from theme)
/>
// User sees what's actually rendered

// ✅ Single source of truth
const effectiveValues = useEffectiveValues(/* ... */);
// Computed once, used everywhere
```

---

## 5. Sidebar Control Updates

What happens when a user changes a value in the sidebar.

```
Step 1: User Interacts with Control
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ User clicks ColorPicker for titleBackgroundColor    │
│  - Current value: '#222' (from theme)               │
│  - User selects: '#ff0000'                          │
└────────────────────┬────────────────────────────────┘
                     │
                     │ onChange handler fires
                     ▼

Step 2: onChange Handler Called
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ onChange Handler                                    │
│  - Receives newValue: '#ff0000'                     │
│  - Calls setAttributes({                            │
│      titleBackgroundColor: '#ff0000'                │
│    })                                               │
└────────────────────┬────────────────────────────────┘
                     │
                     │ WordPress Gutenberg updates state
                     ▼

Step 3: setAttributes Called
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ WordPress Gutenberg Block State                     │
│  - Merges new attribute into block state            │
│  - attributes = {                                   │
│      selectedTheme: 'theme_34gh3',                  │
│      titleBackgroundColor: '#ff0000',  // NEW       │
│      accordionBorderWidth: 2,                       │
│      ...                                            │
│    }                                                │
└────────────────────┬────────────────────────────────┘
                     │
                     │ React detects state change
                     │ Triggers re-render
                     ▼

Step 4: Customization Detection
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ useEffect for Auto-detection Runs                   │
│  - Dependency: [attributes, allThemes]              │
│  - useCustomizationState hook detects changes       │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Compare block vs theme
                     ▼
┌─────────────────────────────────────────────────────┐
│ Customization Detection Logic                       │
│  - Block value: '#ff0000'                           │
│  - Theme value: '#222'                              │
│  - Are they different? YES ✓                        │
│  - hasCustomizations = true                         │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Update isCustomized flag
                     ▼
┌─────────────────────────────────────────────────────┐
│ setAttributes({ isCustomized: true })               │
│  - Block now marked as customized                   │
│  - Triggers another re-render                       │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼

Step 5: Effective Values Recalculated
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ useEffectiveValues Hook Re-runs                     │
│  - Dependencies changed (attributes updated)        │
│  - Re-compute all effective values                  │
└────────────────────┬────────────────────────────────┘
                     │
                     │ For titleBackgroundColor:
                     ▼
┌─────────────────────────────────────────────────────┐
│ 3-Tier Cascade                                      │
│  - Tier 1 (Block): '#ff0000' ✓ USE THIS            │
│  - Tier 2 (Theme): '#222'                           │
│  - Tier 3 (Default): '#fff' (from CSS)              │
│                                                     │
│ Result: effectiveValues.titleBackgroundColor        │
│         = '#ff0000'                                 │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼

Step 6: Sidebar Controls Re-render
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ ColorPicker Re-renders                              │
│  - value={effectiveValues.titleBackgroundColor}     │
│  - Now shows: '#ff0000' ✓                           │
│  - User sees their change reflected                 │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼

Step 7: Preview Updates
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Accordion Preview Re-renders                        │
│  - editorStyles = {                                 │
│      '--header-bg-color': '#ff0000'  // NEW         │
│    }                                                │
│  - Visual preview updates with new red background   │
└─────────────────────────────────────────────────────┘
```

### Code Example

```javascript
// blocks/accordion/components/inspector/AppearancePanel.js
<ColorPickerControl
  label="Title Background Color"
  value={effectiveValues.titleBackgroundColor}  // Step 1: Display effective value
  onChange={(newValue) => {                     // Step 2: onChange fires
    setAttributes({                             // Step 3: Update attribute
      titleBackgroundColor: newValue
    });
    // Step 4-7 happen automatically via React
  }}
/>
```

---

## 6. Customization Detection Flow

The system automatically detects when a block has customizations (differs from its theme).

```
Trigger: ANY Attribute Change
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ useEffect Hook (edit.js lines 333-366)             │
│  - Dependencies: [attributes, allThemes,            │
│                   hasCustomizations]                │
│  - Runs after EVERY attribute change                │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Guard: Skip if themes not loaded
                     ▼
┌─────────────────────────────────────────────────────┐
│ if (isLoading || !allThemes) return;                │
│  - Prevents false positives during loading          │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Get theme to compare against
                     ▼
┌─────────────────────────────────────────────────────┐
│ const themeToCompare = baseTheme || selectedTheme;  │
│ const themeData = allThemes[themeToCompare];        │
│  - If customized: compare to baseTheme              │
│  - If clean: compare to selectedTheme               │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Use centralized detection
                     ▼
┌─────────────────────────────────────────────────────┐
│ useCustomizationState Hook                          │
│  - Compares EVERY customization attribute           │
│  - Returns hasCustomizations boolean                │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Compare each attribute
                     ▼

For EACH of 33+ Customization Attributes:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Example: titleBackgroundColor                       │
│  - Block value: '#ff0000'                           │
│  - Theme value: '#222'                              │
│  - Are they different? YES → customized             │
├─────────────────────────────────────────────────────┤
│ Example: accordionBorderWidth                       │
│  - Block value: undefined (not set)                 │
│  - Theme value: 1                                   │
│  - Block value is undefined → NOT customized        │
├─────────────────────────────────────────────────────┤
│ Example: showIcon                                   │
│  - Block value: false                               │
│  - Theme value: true                                │
│  - Are they different? YES → customized             │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Aggregate results
                     ▼
┌─────────────────────────────────────────────────────┐
│ Detection Result                                    │
│  - If ANY attribute differs: hasCustomizations=true │
│  - If ALL match or undefined: hasCustomizations=false│
└────────────────────┬────────────────────────────────┘
                     │
                     │ Sync with isCustomized flag
                     ▼

Sync Logic:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Case 1: Has customizations but NOT marked           │
│  - hasCustomizations: true                          │
│  - isCustomized: false                              │
│  - Action: setAttributes({ isCustomized: true })    │
└─────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────┐
│ Case 2: No customizations but IS marked             │
│  - hasCustomizations: false                         │
│  - isCustomized: true                               │
│  - Action: setAttributes({ isCustomized: false })   │
└─────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────┐
│ Case 3: State already correct                       │
│  - hasCustomizations === isCustomized               │
│  - Action: No change (skip setAttributes)           │
└─────────────────────────────────────────────────────┘
```

### Key Points

1. **Automatic** - Developer never calls a "mark as customized" function
2. **Comprehensive** - Checks ALL 33+ attributes every time
3. **Accurate** - Uses centralized `useCustomizationState` hook
4. **Null-safe** - `undefined` values are NOT customizations
5. **Theme-aware** - Compares against correct theme (base or selected)

### Code Reference

```javascript
// blocks/accordion/edit.js (lines 333-366)
useEffect(() => {
  if (isLoading || !allThemes || Object.keys(allThemes).length === 0) {
    return; // Guard: wait for themes to load
  }

  const themeToCompare = baseTheme || selectedTheme || 'default';
  const themeData = allThemes[themeToCompare];

  if (!themeData) {
    return; // Guard: theme doesn't exist
  }

  // Centralized detection from shared hooks
  const actuallyHasCustomizations = hasCustomizations;

  // Sync isCustomized attribute with actual state
  if (actuallyHasCustomizations && !isCustomized) {
    setAttributes({ isCustomized: true, baseTheme: themeToCompare });
  } else if (!actuallyHasCustomizations && isCustomized) {
    setAttributes({ isCustomized: false, baseTheme: themeToCompare });
  }
}, [allThemes, isLoading, isCustomized, hasCustomizations]);
```

---

## 7. Theme Switching Flow

What happens when a user selects a different theme from the dropdown.

```
Step 1: User Selects New Theme
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Current State:                                      │
│  - selectedTheme: 'Example'                       │
│  - isCustomized: true                               │
│  - titleBackgroundColor: '#ff0000' (customized)    │
│  - accordionBorderWidth: 2 (customized)                      │
└────────────────────┬────────────────────────────────┘
                     │
                     │ User clicks dropdown
                     │ Selects "Light Mode"
                     ▼
┌─────────────────────────────────────────────────────┐
│ ThemeSelector onChange Fires                        │
│  - value: 'theme_hj23'                              │
│  - Calls handleThemeChange('theme_hj23')            │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼

Step 2: Cache Current Customizations
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ handleThemeChange checks: Is block customized?      │
│  - isCustomized: true ✓                             │
│  - selectedTheme === baseTheme: true ✓              │
│  - Action: Cache customizations before switching    │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Collect all customization attrs
                     ▼
┌─────────────────────────────────────────────────────┐
│ const currentCustomizations = {};                   │
│ customizationAttributes.forEach(attr => {           │
│   currentCustomizations[attr] = attributes[attr];   │
│ });                                                 │
│                                                     │
│ Result: {                                           │
│   titleBackgroundColor: '#ff0000',                 │
│   accordionBorderWidth: 2,                                   │
│   isCustomized: true,                               │
│   baseTheme: 'theme_34gh3'                            │
│ }                                                   │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Store in cache (React state)
                     ▼
┌─────────────────────────────────────────────────────┐
│ setCustomizationCache(prev => ({                    │
│   ...prev,                                          │
│   'theme_34gh3': currentCustomizations                │
│ }));                                                │
│                                                     │
│ Cache now: {                                        │
│   'theme_34gh3': { headerBg: '#ff0000', ... }         │
│ }                                                   │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼

Step 3: Clear All Customization Attributes
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ clearAllCustomizations(attributes, attributeConfig) │
│  - Returns object with all attrs set to undefined   │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Returns: {
                     │   titleBackgroundColor: undefined,
                     │   accordionBorderWidth: undefined,
                     │   accordionBorderColor: undefined,
                     │   ... (all 33+ attrs)
                     │ }
                     ▼

Step 4: Apply New Theme
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ setAttributes({                                     │
│   ...clearedAttributes,  // All customizations=undefined│
│   selectedTheme: 'theme_hj23',                      │
│   baseTheme: 'theme_hj23',                          │
│   isCustomized: false                               │
│ });                                                 │
└────────────────────┬────────────────────────────────┘
                     │
                     │ React re-renders
                     ▼

Step 5: Effective Values Resolve to New Theme
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ useEffectiveValues Re-runs                          │
│  - selectedTheme: 'theme_hj23'                      │
│  - Block attrs: all undefined                       │
└────────────────────┬────────────────────────────────┘
                     │
                     │ For titleBackgroundColor:
                     ▼
┌─────────────────────────────────────────────────────┐
│ 3-Tier Cascade                                      │
│  - Tier 1 (Block): undefined                        │
│  - Tier 2 (Theme): '#fff' ✓ USE THIS               │
│  - Tier 3 (Default): '#fff' (from CSS)              │
│                                                     │
│ Result: effectiveValues.titleBackgroundColor       │
│         = '#fff' (from new theme)                   │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼

Step 6: Sidebar Updates
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ All Sidebar Controls Re-render                      │
│  - ColorPicker now shows: '#fff'                    │
│  - RangeControl for accordionBorderWidth shows: 1            │
│  - All values from new theme                        │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼

Step 7: Preview Updates
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Accordion Preview Re-renders                        │
│  - Background changes from red to white             │
│  - Border changes from 2px to 1px                   │
│  - All new theme styles applied                     │
└─────────────────────────────────────────────────────┘
```

### Restoring from Cache

If user switches BACK to "Dark Mode (custom)":

```
Step 1: User Selects "{theme}-customized"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ ThemeSelector onChange Fires                        │
│  - value: 'dark-mode-customized'                    │
│  - Ends with '-customized' → restore from cache     │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Extract theme ID
                     ▼
┌─────────────────────────────────────────────────────┐
│ const themeId = value.replace('-customized', '');   │
│  - themeId: 'theme_34gh3'                             │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Get cached customizations
                     ▼
┌─────────────────────────────────────────────────────┐
│ const cached = customizationCache['theme_34gh3'];     │
│  - cached: {                                        │
│      titleBackgroundColor: '#ff0000',              │
│      accordionBorderWidth: 2,                                │
│      isCustomized: true,                            │
│      baseTheme: 'theme_34gh3'                         │
│    }                                                │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Restore all at once
                     ▼
┌─────────────────────────────────────────────────────┐
│ setAttributes({                                     │
│   selectedTheme: 'theme_34gh3',                       │
│   ...cached  // Restore all customizations          │
│ });                                                 │
│                                                     │
│ Block now has customizations back                   │
└─────────────────────────────────────────────────────┘
```

---

## 8. Saving Theme Flow (Update Existing)

What happens when user clicks "Update theme" to save customizations to an existing theme.

```
Step 1: User Clicks "Update Theme"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Current State:                                      │
│  - selectedTheme: 'theme_34gh3'                       │
│  - baseTheme: 'theme_34gh3'                           │
│  - isCustomized: true                               │
│  - Block attrs: { titleBackgroundColor: '#ff0000' }│
│  - Theme values: { titleBackgroundColor: '#222' }  │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Button onClick fires
                     ▼
┌─────────────────────────────────────────────────────┐
│ handleSaveTheme(themeId, effectiveValues)           │
│  - themeId: 'theme_34gh3'                             │
│  - effectiveValues: ALL resolved values (block+theme)│
└────────────────────┬────────────────────────────────┘
                     │
                     ▼

Step 2: Collect ALL Effective Values
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ collectEffectiveSettings() (edit.js lines 509-527)  │
│  - Loops through ALL customization attributes       │
│  - For EACH attribute, gets effective value         │
└────────────────────┬────────────────────────────────┘
                     │
                     │ For each of 33+ attributes:
                     ▼
┌─────────────────────────────────────────────────────┐
│ Example: titleBackgroundColor                      │
│  - Effective value: '#ff0000' (from block)          │
│  - Include in snapshot                              │
├─────────────────────────────────────────────────────┤
│ Example: accordionBorderWidth                                │
│  - Effective value: 1 (from theme, not customized)  │
│  - Include in snapshot                              │
├─────────────────────────────────────────────────────┤
│ Example: showIcon                                   │
│  - Effective value: true (from theme)               │
│  - Include in snapshot                              │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Build complete snapshot
                     ▼
┌─────────────────────────────────────────────────────┐
│ const settings = {                                  │
│   theme_name: 'Dark Mode',                          │
│   titleBackgroundColor: '#ff0000',  // customized  │
│   titleColor: '#fff',           // from theme  │
│   accordionBorderWidth: 1,                    // from theme  │
│   accordionBorderColor: '#666',               // from theme  │
│   showIcon: true,                    // from theme  │
│   ... // ALL 33+ attributes                         │
│ };                                                  │
│                                                     │
│ This is a COMPLETE SNAPSHOT with NO nulls           │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼

Step 3: Save to Database
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ updateTheme(themeId, settings)                      │
│  - themeId: 'theme_34gh3'                             │
│  - settings: { complete snapshot }                  │
└────────────────────┬────────────────────────────────┘
                     │
                     │ AJAX POST request
                     ▼
┌─────────────────────────────────────────────────────┐
│ WordPress AJAX Handler                              │
│  - Action: save_accordion_theme                     │
│  - Merge settings into existing theme               │
│  - Save to wp_options: accordion_themes             │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Server returns updated themes
                     ▼
┌─────────────────────────────────────────────────────┐
│ Response: {                                         │
│   success: true,                                    │
│   data: {                                           │
│     themes: {                                       │
│       'theme_34gh3': {                                │
│         theme_name: 'Dark Mode',                    │
│         titleBackgroundColor: '#ff0000', // UPDATED│
│         ... // all other attributes                 │
│       },                                            │
│       'default': { ... },                           │
│       ...                                           │
│     }                                               │
│   }                                                 │
│ }                                                   │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼

Step 4: Dispatch Custom Event
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ const event = new CustomEvent('accordionThemeUpdated',{│
│   detail: {                                         │
│     themeId: 'theme_34gh3',                           │
│     themes: updatedThemes,                          │
│     operation: 'update',                            │
│     sourceBlockId: clientId                         │
│   }                                                 │
│ });                                                 │
│ window.dispatchEvent(event);                        │
└────────────────────┬────────────────────────────────┘
                     │
                     │ ALL accordion blocks listening
                     ▼

Step 5: All Blocks Update Themselves
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
See Section 9: Event Synchronization

Step 6: Clear Current Block Customizations
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ clearAllCustomizations(attributes, attributeConfig) │
│  - Sets all customization attrs to undefined        │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Apply updates
                     ▼
┌─────────────────────────────────────────────────────┐
│ setAttributes({                                     │
│   titleBackgroundColor: undefined,  // cleared     │
│   accordionBorderWidth: undefined,            // cleared     │
│   ... // all 33+ attrs cleared                      │
│   isCustomized: false,                              │
│   baseTheme: 'theme_34gh3'                            │
│ });                                                 │
└────────────────────┬────────────────────────────────┘
                     │
                     │ React re-renders
                     ▼

Step 7: Sidebar Reads from Updated Theme
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ useEffectiveValues Re-runs                          │
│  - Block attrs: all undefined (cleared)             │
│  - Selected theme: 'theme_34gh3' (updated in DB)      │
└────────────────────┬────────────────────────────────┘
                     │
                     │ For titleBackgroundColor:
                     ▼
┌─────────────────────────────────────────────────────┐
│ 3-Tier Cascade                                      │
│  - Tier 1 (Block): undefined                        │
│  - Tier 2 (Theme): '#ff0000' ✓ USE THIS            │
│                    (now saved in theme!)            │
│  - Tier 3 (Default): '#fff' (from CSS)              │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Result: Sidebar shows '#ff0000'
                     │ But now it's from THEME, not block
                     ▼
┌─────────────────────────────────────────────────────┐
│ UI State                                            │
│  - ColorPicker shows: '#ff0000' ✓                   │
│  - isCustomized: false ✓                            │
│  - Theme dropdown shows: "Dark Mode" (not "custom") │
│  - Preview unchanged (same visual)                  │
└─────────────────────────────────────────────────────┘
```

### Why Complete Snapshots

**What are Complete Snapshots:**
Themes are stored as complete snapshots in the database - every customizable attribute has an explicit value with no nulls. This makes themes portable, predictable, and easy to apply.

```javascript
// Theme stored in database (complete snapshot):
{
  titleBackgroundColor: '#222',
  accordionBorderWidth: 1,
  titleColor: '#fff',
  // ... ALL 33+ attributes present
}
```

**Cascade Resolution with Complete Snapshots:**
```javascript
// 3-tier cascade still applies:
// 1. Block attribute (if set)
// 2. Theme value (complete snapshot from database)
// 3. Default (from accordion.css via PHP parsing)

// Theme values come from database, defaults come from CSS
const resolved = attributes.titleColor ?? theme.titleColor ?? window.accordionDefaults.titleColor;
```

**Why This Approach:**
- **Themes are portable**: Complete snapshots can be exported/imported
- **Predictable**: Every theme has explicit values for all attributes
- **Null inheritance for defaults**: Some attributes like `iconColor` inherit from `titleColor` when null in the DEFAULT layer (not in themes)
- **Performance**: No need to walk up multiple inheritance chains

---

## 9. Creating New Theme Flow

What happens when user clicks "Save as new theme".

```
Step 1: User Clicks "Save as New Theme"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Current State:                                      │
│  - selectedTheme: 'theme_34gh3'                       │
│  - baseTheme: 'theme_34gh3'                           │
│  - isCustomized: true                               │
│  - Block customizations: { headerBg: '#ff0000' }    │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Button onClick fires
                     ▼
┌─────────────────────────────────────────────────────┐
│ Prompt for Theme Name                               │
│  - User enters: "My Red Theme"                      │
└────────────────────┬────────────────────────────────┘
                     │
                     │ handleCreateTheme fires
                     ▼

Step 2: Collect ALL Effective Values
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ collectEffectiveSettings()                          │
│  - Same as "Update Theme"                           │
│  - Gets ALL resolved values (block + theme)         │
│  - Creates complete snapshot                        │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────┐
│ const settings = {                                  │
│   titleBackgroundColor: '#ff0000',  // customized  │
│   accordionBorderWidth: 1,                    // from theme  │
│   showIcon: true,                    // from theme  │
│   ... // ALL 33+ attributes                         │
│ };                                                  │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼

Step 3: Generate Unique Theme ID
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ createTheme(themeName, settings)                    │
│  - Calls generateThemeId()                          │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Generate unique ID
                     ▼
┌─────────────────────────────────────────────────────┐
│ const themeId = generateThemeId();                  │
│  - Uses timestamp + random string                   │
│  - Example: 'theme_1234567890_abc'                  │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼

Step 4: Save to Database
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ AJAX POST Request                                   │
│  - Action: save_accordion_theme                     │
│  - Data: {                                          │
│      theme_id: 'theme_1234567890_abc',              │
│      theme_name: 'My Red Theme',                    │
│      ...settings  // All 33+ attributes             │
│    }                                                │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Server processes
                     ▼
┌─────────────────────────────────────────────────────┐
│ WordPress AJAX Handler                              │
│  - Check if theme_id exists (NO → create new)       │
│  - Add to accordion_themes array                    │
│  - Save to wp_options                               │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Server returns ALL themes
                     ▼
┌─────────────────────────────────────────────────────┐
│ Response: {                                         │
│   success: true,                                    │
│   data: {                                           │
│     themes: {                                       │
│       'default': { ... },                           │
│       'theme_34gh3': { ... },                         │
│       'theme_1234567890_abc': {  // NEW THEME       │
│         theme_name: 'My Red Theme',                 │
│         titleBackgroundColor: '#ff0000',           │
│         ... // all attributes                       │
│       }                                             │
│     }                                               │
│   }                                                 │
│ }                                                   │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼

Step 5: Update Client State
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ useThemeManagement Updates                          │
│  - setThemes(response.data.themes)                  │
│  - New theme now available in dropdown              │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼

Step 6: Dispatch Custom Event
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ const event = new CustomEvent('accordionThemeUpdated',{│
│   detail: {                                         │
│     themeId: 'theme_1234567890_abc',                │
│     themes: updatedThemes,                          │
│     operation: 'create'                             │
│   }                                                 │
│ });                                                 │
│ window.dispatchEvent(event);                        │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Other blocks receive new theme list
                     ▼

Step 7: Switch Current Block to New Theme
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ clearAllCustomizations(attributes, attributeConfig) │
│  - Clear ALL customization attributes               │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Apply in ONE atomic operation
                     ▼
┌─────────────────────────────────────────────────────┐
│ setAttributes({                                     │
│   ...clearedAttributes,  // All attrs = undefined   │
│   themeId: 'theme_1234567890_abc',  // NEW          │
│   selectedTheme: 'theme_1234567890_abc',            │
│   baseTheme: 'theme_1234567890_abc',                │
│   isCustomized: false                               │
│ });                                                 │
└────────────────────┬────────────────────────────────┘
                     │
                     │ React re-renders
                     ▼

Step 8: Sidebar Reads from New Theme
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ useEffectiveValues Re-runs                          │
│  - selectedTheme: 'theme_1234567890_abc'            │
│  - Block attrs: all undefined                       │
└────────────────────┬────────────────────────────────┘
                     │
                     │ 3-tier cascade resolves to new theme
                     ▼
┌─────────────────────────────────────────────────────┐
│ effectiveValues = newTheme values                   │
│  - titleBackgroundColor: '#ff0000' (from new theme)│
│  - All values from new theme                        │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────┐
│ UI Updates                                          │
│  - Theme dropdown shows: "My Red Theme"             │
│  - isCustomized: false (clean theme)                │
│  - Sidebar values unchanged (same as before)        │
│  - Preview unchanged (visual consistency)           │
└─────────────────────────────────────────────────────┘
```

### Key Differences from Update Theme

| Aspect | Update Theme | Create New Theme |
|--------|--------------|------------------|
| Theme ID | Existing theme ID | Generate new unique ID |
| Database Operation | Overwrite existing theme | Add new theme entry |
| Original Theme | Modified in database | Unchanged |
| Current Block | Stays on same theme | Switches to new theme |
| Other Blocks | Update if using same theme | No change (different theme) |

---

## 10. Event Synchronization

When one block updates a theme, ALL blocks using that theme must update in real-time.

```
Scenario: 3 Blocks on Same Page
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Block A: uses "Dark Mode" theme                     │
│ Block B: uses "Dark Mode" theme                     │
│ Block C: uses "Light Mode" theme                    │
└─────────────────────────────────────────────────────┘

Step 1: Block A Updates "Dark Mode" Theme
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Block A:                                            │
│  - User changes titleBackgroundColor to #111       │
│  - Clicks "Update theme"                            │
│  - handleSaveTheme executes                         │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Save to database
                     ▼
┌─────────────────────────────────────────────────────┐
│ updateTheme('theme_34gh3', { headerBg: '#111', ... }) │
│  - Server updates dark-mode theme in wp_options     │
│  - Returns updated themes list                      │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼

Step 2: Block A Dispatches Event
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Block A (useThemeManagement hook, lines 206-217)    │
│                                                     │
│ const event = new CustomEvent('accordionThemeUpdated',{│
│   detail: {                                         │
│     themeId: 'theme_34gh3',                           │
│     themes: updatedThemes,                          │
│     operation: 'update',                            │
│     sourceBlockId: 'block-a-client-id'              │
│   }                                                 │
│ });                                                 │
│ window.dispatchEvent(event);                        │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Event propagates to window
                     ▼

Step 3: ALL Blocks Receive Event
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Block A Event Listener (edit.js lines 263-322)      │
│  - Receives own event                               │
│  - sourceBlockId === clientId → SKIP               │
│  - (Already cleared customizations in handleSaveTheme)│
└─────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────┐
│ Block B Event Listener                              │
│  - Receives event                                   │
│  - sourceBlockId !== clientId ✓                     │
│  - operation === 'update' ✓                         │
│  - selectedTheme === 'theme_34gh3' ✓                  │
│  - Action: Clear customizations                     │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Call switchToCleanTheme
                     ▼
┌─────────────────────────────────────────────────────┐
│ Block B Updates                                     │
│  - clearCustomizations()                            │
│  - setAttributes({                                  │
│      ...cleared,                                    │
│      selectedTheme: 'theme_34gh3',                    │
│      isCustomized: false                            │
│    })                                               │
│  - Re-renders with new theme values                 │
└─────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────┐
│ Block C Event Listener                              │
│  - Receives event                                   │
│  - selectedTheme === 'theme_hj23'                   │
│  - NOT using 'theme_34gh3' → SKIP                     │
│  - No action taken                                  │
└─────────────────────────────────────────────────────┘

Step 4: useThemeManagement Updates Themes
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ All Blocks (useThemeManagement, lines 89-105)       │
│                                                     │
│ useEffect(() => {                                   │
│   const handleThemeUpdate = (event) => {            │
│     const { themes } = event.detail;                │
│     if (themes) {                                   │
│       setThemes(themes);  // Update local state     │
│     }                                               │
│   };                                                │
│                                                     │
│   window.addEventListener('accordionThemeUpdated',  │
│                            handleThemeUpdate);      │
│ }, []);                                             │
└────────────────────┬────────────────────────────────┘
                     │
                     │ All blocks now have updated themes
                     ▼

Step 5: All Blocks Re-render
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Block A:                                            │
│  - themes state updated                             │
│  - effectiveValues re-computed                      │
│  - Sidebar shows new theme values                   │
│  - Preview updates to #111 background               │
├─────────────────────────────────────────────────────┤
│ Block B:                                            │
│  - themes state updated                             │
│  - customizations cleared                           │
│  - effectiveValues re-computed                      │
│  - Preview updates to #111 background               │
├─────────────────────────────────────────────────────┤
│ Block C:                                            │
│  - themes state updated (has new dark-mode data)    │
│  - No visual change (uses light-mode theme)         │
└─────────────────────────────────────────────────────┘
```

### Event Flow Diagram

```
    Block A               Block B               Block C
(Dark Mode Custom)    (Dark Mode Clean)    (Light Mode Clean)
      │                     │                     │
      │ User updates        │                     │
      │ theme               │                     │
      ├─────────────────────┼─────────────────────┤
      │                     │                     │
      │ Save to DB          │                     │
      │                     │                     │
      │ Dispatch Event ─────┼────────────────────>│
      │  (accordionThemeUpdated)                  │
      │                     │                     │
      │                     │ Receive Event       │
      │                     │ ✓ Same theme        │
      │                     │ ✓ Update operation  │
      │                     │ → Clear customizations
      │                     │                     │
      │ Receive Own Event   │                     │ Receive Event
      │ ✓ sourceBlockId match                     │ ✗ Different theme
      │ → SKIP              │                     │ → SKIP
      │                     │                     │
      ├─────────────────────┼─────────────────────┤
      │                     │                     │
      │ Re-render           │ Re-render           │ (no change)
      │ (new theme values)  │ (new theme values)  │
      ▼                     ▼                     ▼
```

### Event Detail Structure

```javascript
{
  themeId: 'theme_34gh3',           // Theme that was modified
  themes: { /* all themes */ },   // Updated themes list
  operation: 'update',            // 'create' | 'update' | 'delete'
  sourceBlockId: 'block-a-id'     // Block that triggered update
}
```

### Why sourceBlockId Matters

**Without sourceBlockId:**
```javascript
// ❌ Block A clears customizations TWICE
// 1. In handleSaveTheme (correct)
// 2. In event listener (wrong - race condition)

// Result: Flickering UI, double state updates
```

**With sourceBlockId:**
```javascript
// ✅ Block A ignores own event
if (sourceBlockId === clientId) {
  console.log('Skipping - this block triggered the update');
  return;
}

// Result: Clean, single update
```

---

## 11. Customization Cache Management

The cache stores temporary customizations when switching between themes.

### 10.1 Cache Structure

```javascript
// React state in useAccordionState hook
const [customizationCache, setCustomizationCache] = useState({
  // Key: theme ID
  // Value: object with all customization attributes
  'theme_34gh3': {
    titleBackgroundColor: '#ff0000',
    accordionBorderWidth: 2,
    showIcon: false,
    isCustomized: true,
    baseTheme: 'theme_34gh3'
  },
  'theme_hj23': {
    titleColor: '#000',
    accordionBorderColor: '#ccc',
    isCustomized: true,
    baseTheme: 'theme_hj23'
  }
});
```

### 10.2 When Cache is Updated

```
Scenario 1: Switching FROM Customized Theme
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Current State:                                      │
│  - selectedTheme: 'theme_34gh3'                       │
│  - isCustomized: true                               │
│  - Block has customizations                         │
└────────────────────┬────────────────────────────────┘
                     │
                     │ User selects "Light Mode" (clean)
                     ▼
┌─────────────────────────────────────────────────────┐
│ handleThemeChange Detects:                          │
│  - isCustomized && selectedTheme === baseTheme      │
│  - Action: Cache before switching                   │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Collect customizations
                     ▼
┌─────────────────────────────────────────────────────┐
│ const currentCustomizations = {};                   │
│ customizationAttributes.forEach(attr => {           │
│   currentCustomizations[attr] = attributes[attr];   │
│ });                                                 │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Store in cache
                     ▼
┌─────────────────────────────────────────────────────┐
│ setCustomizationCache(prev => ({                    │
│   ...prev,                                          │
│   'theme_34gh3': currentCustomizations                │
│ }));                                                │
└─────────────────────────────────────────────────────┘

Scenario 2: Switching TO Customized Theme
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ User selects "Dark Mode (custom)" from dropdown     │
└────────────────────┬────────────────────────────────┘
                     │
                     │ value.endsWith('-customized')
                     ▼
┌─────────────────────────────────────────────────────┐
│ Extract theme ID                                    │
│ const themeId = value.replace('-customized', '');   │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Get from cache
                     ▼
┌─────────────────────────────────────────────────────┐
│ const cached = customizationCache['theme_34gh3'];     │
│ if (cached) {                                       │
│   setAttributes({                                   │
│     selectedTheme: 'theme_34gh3',                     │
│     ...cached  // Restore all customizations        │
│   });                                               │
│ }                                                   │
└─────────────────────────────────────────────────────┘
```

### 10.3 When Cache is Cleared

```
Case 1: Theme Update
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ User clicks "Update theme"                          │
│  - Customizations saved to database                 │
│  - Cache for that theme no longer needed            │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────┐
│ setCustomizationCache(prev => {                     │
│   const newCache = { ...prev };                     │
│   delete newCache['theme_34gh3'];                     │
│   return newCache;                                  │
│ });                                                 │
└─────────────────────────────────────────────────────┘

Case 2: Theme Creation
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ User clicks "Save as new theme"                     │
│  - New theme created in database                    │
│  - Block switches to new theme                      │
│  - Cache cleared for new theme ID                   │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────┐
│ setCustomizationCache(prev => {                     │
│   const newCache = { ...prev };                     │
│   delete newCache[newThemeId];                      │
│   return newCache;                                  │
│ });                                                 │
└─────────────────────────────────────────────────────┘

Case 3: Post Save (LOST)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ User saves post                                     │
│  - WordPress serializes block attributes            │
│  - Cache is React state (not saved to DB)           │
│  - On next page load, cache is EMPTY                │
└─────────────────────────────────────────────────────┘
```

### 10.4 Warning System

```javascript
// edit.js lines 378-415
useEffect(() => {
  // Detect save transition
  if (isSavingPost && !lastSaveState) {
    const hasCachedCustomizations = Object.keys(customizationCache).length > 0;

    if (hasCachedCustomizations && !isCustomized) {
      // User is saving while cache has data
      // Cached customizations will be LOST

      const cachedThemes = Object.keys(customizationCache)
        .map(themeId => allThemes[themeId]?.theme_name || themeId)
        .join(', ');

      createWarningNotice(
        `⚠️ You have unsaved accordion customizations in cache for: ${cachedThemes}. ` +
        `These will be lost when you save. Switch back to customized themes to preserve them.`,
        { isDismissible: true, type: 'warning' }
      );
    }
  }
}, [isSavingPost, customizationCache, isCustomized]);
```

**Example Warning:**
```
⚠️ You have unsaved accordion customizations in cache for: Dark Mode, Light Mode.
   These will be lost when you save. Switch back to customized themes to preserve them.
```

---

## 12. Post Save Flow

What happens when user saves the post.

```
Step 1: User Clicks "Save Post" or "Update"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Current Block State:                                │
│  - selectedTheme: 'theme_34gh3'                       │
│  - titleBackgroundColor: '#ff0000' (customized)    │
│  - accordionBorderWidth: undefined (not customized)          │
│  - isCustomized: true                               │
│  - customizationCache: { 'theme_hj23': { ... } }    │
└────────────────────┬────────────────────────────────┘
                     │
                     │ WordPress triggers save
                     ▼

Step 2: WordPress Serializes Block
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Block Serialization (to post_content)               │
│  - WordPress loops through all blocks               │
│  - Calls block.save() for each                      │
│  - Converts to HTML comments                        │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Serialize attributes
                     ▼
┌─────────────────────────────────────────────────────┐
│ Saved HTML in post_content:                         │
│                                                     │
│ <!-- wp:custom/accordion {                       │
│   "selectedTheme": "dark-mode",                     │
│   "titleBackgroundColor": "#ff0000",               │
│   "isCustomized": true,                             │
│   "baseTheme": "dark-mode",                         │
│   "accordionId": "accordion-abc"                    │
│   ... (only DEFINED attributes saved)               │
│ } -->                                               │
│ <div class="accordion">...</div>                    │
│ <!-- /wp:custom/accordion -->                    │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Note: Cache NOT saved
                     ▼
┌─────────────────────────────────────────────────────┐
│ Customization Cache:                                │
│  - Lives in React state only                        │
│  - NOT part of block attributes                     │
│  - NOT serialized to post_content                   │
│  - LOST after save                                  │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼

Step 3: Database Update
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ WordPress Updates wp_posts Table                    │
│  - UPDATE wp_posts                                  │
│    SET post_content = '...'                         │
│    WHERE ID = 123                                   │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Save complete
                     ▼

Step 4: Next Page Load
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ User Refreshes Editor                               │
│  - WordPress parses post_content                    │
│  - Extracts block attributes from HTML comment      │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Parse attributes
                     ▼
┌─────────────────────────────────────────────────────┐
│ Block Mounts with Saved Attributes:                 │
│  - selectedTheme: 'theme_34gh3' ✓                     │
│  - titleBackgroundColor: '#ff0000' ✓               │
│  - isCustomized: true ✓                             │
│  - customizationCache: {} ← EMPTY (lost)            │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Result
                     ▼
┌─────────────────────────────────────────────────────┐
│ Block State After Load:                             │
│  - Customizations: Preserved ✓                      │
│  - Theme reference: Preserved ✓                     │
│  - Cache: Lost (as designed)                        │
│  - Visual appearance: Identical to before save ✓    │
└─────────────────────────────────────────────────────┘
```

### What Gets Saved vs Lost

| Data | Saved to DB | Restored on Load | Notes |
|------|-------------|------------------|-------|
| selectedTheme | ✓ | ✓ | Theme reference persisted |
| baseTheme | ✓ | ✓ | For customized blocks |
| isCustomized | ✓ | ✓ | Customization flag |
| Customization attrs | ✓ | ✓ | Only if defined (not undefined) |
| customizationCache | ✗ | ✗ | React state only, not persisted |
| effectiveValues | ✗ | ✗ | Computed, not stored |

### Attributes Serialization Rules

```javascript
// ✓ Saved (defined values)
{
  titleBackgroundColor: '#ff0000',  // User customized
  isCustomized: true,                // Set by system
  selectedTheme: 'theme_34gh3'         // User selected
}

// ✗ NOT Saved (undefined values)
{
  accordionBorderWidth: undefined,  // Not customized, removed from HTML
  accordionBorderColor: undefined,  // Not customized, removed from HTML
  showIcon: undefined      // Not customized, removed from HTML
}
```

**Why undefined values are NOT saved:**
- Keeps HTML clean (no null pollution)
- Smaller file size
- Clear distinction: defined = customized, undefined = use theme

---

## 13. Race Conditions to Avoid

### 12.1 Don't Render UI Before Themes Load

```javascript
// ❌ BAD - Race condition
function Edit({ attributes }) {
  const { themes, isLoading } = useThemeManagement('accordion');

  // UI renders immediately, themes is {}
  return (
    <ColorPicker
      value={themes[attributes.selectedTheme]?.headerBg}  // undefined!
    />
  );
}

// ✅ GOOD - Wait for themes
function Edit({ attributes }) {
  const { themes, isLoading } = useThemeManagement('accordion');

  if (isLoading || !themes || Object.keys(themes).length === 0) {
    return <div>Loading...</div>;
  }

  // Safe: themes are loaded
  return <ColorPicker value={effectiveValues.headerBg} />;
}
```

### 12.2 Don't Resolve Effective Values Before Themes Load

```javascript
// ❌ BAD - Returns undefined
const effectiveValue = useMemo(() => {
  const theme = allThemes[selectedTheme];  // allThemes is {}
  return attributes.headerBg || theme?.headerBg;  // theme is undefined
}, [attributes, allThemes, selectedTheme]);

// ✅ GOOD - Guard against empty themes
const effectiveValue = useMemo(() => {
  if (!allThemes || Object.keys(allThemes).length === 0) {
    return attributeConfig.titleBackgroundColor.defaultValue;
  }

  // 3-tier cascade (safe)
  return computeEffectiveValue(/* ... */);
}, [attributes, allThemes, selectedTheme]);
```

### 12.3 Don't Call onThemeChange During Theme Creation

```javascript
// ❌ BAD - Double state update
async function createTheme(themeName, themeData) {
  const result = await createTheme(themeName, themeData);

  if (result) {
    // handleCreateTheme will set theme IDs
    onThemeChange(result.themeId);  // RACE: Double update!
  }
}

// ✅ GOOD - Let caller handle state
async function createTheme(themeName, themeData) {
  const result = await createTheme(themeName, themeData);

  // Return result, don't call onThemeChange
  // Caller (handleCreateTheme) manages state transition
  return result;
}
```

**Why this causes issues:**
1. `createTheme` dispatches event with new theme
2. Event listener calls `switchToCleanTheme`
3. `onThemeChange` also called → double setAttributes
4. React batch updates conflict
5. UI flickers, state inconsistent

### 12.4 Don't Clear Customizations Twice

```javascript
// ❌ BAD - Clears twice for source block
useEffect(() => {
  const handleThemeUpdate = (event) => {
    const { themeId, operation } = event.detail;

    if (operation === 'update' && selectedTheme === themeId) {
      switchToCleanTheme(themeId);  // Clears customizations
      // Problem: handleSaveTheme already cleared them!
    }
  };

  window.addEventListener('accordionThemeUpdated', handleThemeUpdate);
}, [selectedTheme, switchToCleanTheme]);

// ✅ GOOD - Skip source block
useEffect(() => {
  const handleThemeUpdate = (event) => {
    const { themeId, operation, sourceBlockId } = event.detail;

    // Don't clear if this block triggered the update
    if (sourceBlockId === clientId) {
      console.log('Skipping - this block triggered update');
      return;
    }

    if (operation === 'update' && selectedTheme === themeId) {
      switchToCleanTheme(themeId);  // Clear only once
    }
  };

  window.addEventListener('accordionThemeUpdated', handleThemeUpdate);
}, [selectedTheme, switchToCleanTheme, clientId]);
```

**Why sourceBlockId matters:**
- Block A clicks "Update theme"
- `handleSaveTheme` clears customizations (correct)
- Event dispatched with `sourceBlockId: blockA.clientId`
- Block A's event listener fires
- WITHOUT check: Clears again → flicker, wrong state
- WITH check: Skips → clean, correct state

---

## 14. State Management Architecture

### 13.1 State Layers

```
Layer 1: WordPress Gutenberg State (Persistent)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Block Attributes (managed by WordPress)             │
│  - Saved to post_content on save                    │
│  - Restored on page load                            │
│  - Updated via setAttributes()                      │
│                                                     │
│ Examples:                                           │
│  - selectedTheme: 'theme_34gh3'                       │
│  - titleBackgroundColor: '#ff0000'                 │
│  - isCustomized: true                               │
│  - title: 'My Accordion'                            │
└─────────────────────────────────────────────────────┘

Layer 2: Database State (Global, Shared)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Themes (wp_options: accordion_themes)               │
│  - Loaded via AJAX on mount                         │
│  - Shared across ALL accordion blocks               │
│  - Updated via AJAX operations                      │
│  - Stored in React state (themes)                   │
│                                                     │
│ Structure:                                          │
│  {                                                  │
│    'default': { theme_name: 'Default', ... },       │
│    'theme_34gh3': { theme_name: 'Dark', ... }         │
│  }                                                  │
└─────────────────────────────────────────────────────┘

Layer 3: React Component State (Transient)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Local UI State (useAccordionState hook)             │
│  - NOT saved to database                            │
│  - Reset on page reload                             │
│  - Used for temporary UI state                      │
│                                                     │
│ Examples:                                           │
│  - customizationCache: {}                           │
│  - enableDividerBorder: boolean                     │
│  - saveNotification: { type, message }              │
└─────────────────────────────────────────────────────┘

Layer 4: Computed State (Derived, Memoized)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Effective Values (useEffectiveValues hook)          │
│  - Computed from attributes + themes + pageStyles   │
│  - Re-computed on dependency changes                │
│  - Never stored, always derived                     │
│  - Used for sidebar display and preview             │
│                                                     │
│ Examples:                                           │
│  - effectiveValues.headerBg: '#ff0000'              │
│  - effectiveValues.accordionBorderWidth: 2                   │
└─────────────────────────────────────────────────────┘
```

### 13.2 State Flow

```
User Action (e.g., change color)
        │
        ▼
┌────────────────────┐
│ setAttributes({    │  ← Layer 1: WordPress Gutenberg
│   headerBg: '#f00' │
│ })                 │
└────────┬───────────┘
         │
         │ Triggers re-render
         ▼
┌────────────────────┐
│ useEffectiveValues │  ← Layer 4: Computed
│ re-runs (useMemo)  │
└────────┬───────────┘
         │
         │ Dependencies changed
         ▼
┌────────────────────┐
│ 3-tier cascade     │  ← Uses Layer 1 (attributes) + Layer 2 (themes) + Layer 3 (CSS defaults)
│ resolves value     │
└────────┬───────────┘
         │
         ▼
┌────────────────────┐
│ UI updates         │  ← Sidebar + Preview
│ - Sidebar shows    │
│   new value        │
│ - Preview renders  │
└────────────────────┘
```

### 13.3 State Persistence

| State | Component Mount | Page Reload | Post Save | Notes |
|-------|-----------------|-------------|-----------|-------|
| Block Attributes | Preserved | Preserved | Saved to DB | WordPress manages |
| Themes List | Fetched | Fetched | N/A | Loaded via AJAX |
| Customization Cache | Empty | Empty | Lost | React state only |
| Effective Values | Computed | Computed | Not stored | Always derived |
| UI State (loading, errors) | Empty | Empty | Lost | Temporary |

---

## 15. AJAX Operations

All theme operations communicate with the server via WordPress AJAX.

### 14.1 Load Themes

```
Operation: GET themes from database
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Client: loadThemes('accordion')                     │
└────────────────────┬────────────────────────────────┘
                     │
                     │ POST /wp-admin/admin-ajax.php
                     ▼
┌─────────────────────────────────────────────────────┐
│ Request Body:                                       │
│  - action: 'get_accordion_themes'                   │
│  - nonce: '...'                                     │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Server processes
                     ▼
┌─────────────────────────────────────────────────────┐
│ WordPress PHP Handler                               │
│  - Verify nonce                                     │
│  - Load from wp_options: accordion_themes           │
│  - Return JSON response                             │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Response
                     ▼
┌─────────────────────────────────────────────────────┐
│ {                                                   │
│   success: true,                                    │
│   data: {                                           │
│     themes: {                                       │
│       'default': { ... },                           │
│       'theme_34gh3': { ... }                          │
│     }                                               │
│   }                                                 │
│ }                                                   │
└─────────────────────────────────────────────────────┘
```

**Error Handling:**
- Timeout (30s) → "Request timed out"
- Network error → "Network error. Please check connection"
- HTTP 403 → "Permission denied"
- Invalid JSON → "Invalid server response"

### 14.2 Save New Theme

```
Operation: CREATE theme in database
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Client: saveTheme('accordion', themeId, themeData)  │
└────────────────────┬────────────────────────────────┘
                     │
                     │ POST /wp-admin/admin-ajax.php
                     ▼
┌─────────────────────────────────────────────────────┐
│ Request Body:                                       │
│  - action: 'save_accordion_theme'                   │
│  - nonce: '...'                                     │
│  - theme_id: 'theme_123'                            │
│  - theme_name: 'My Theme'                           │
│  - titleBackgroundColor: '#ff0000'                 │
│  - ... (all 33+ attributes flattened)               │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Server processes
                     ▼
┌─────────────────────────────────────────────────────┐
│ WordPress PHP Handler                               │
│  - Verify nonce                                     │
│  - Check if theme_id exists                         │
│  - Create new theme entry                           │
│  - Save to wp_options: accordion_themes             │
│  - Return ALL themes (including new one)            │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Response
                     ▼
┌─────────────────────────────────────────────────────┐
│ {                                                   │
│   success: true,                                    │
│   data: {                                           │
│     themes: {                                       │
│       'default': { ... },                           │
│       'theme_123': { theme_name: 'My Theme', ... }  │
│     }                                               │
│   }                                                 │
│ }                                                   │
└─────────────────────────────────────────────────────┘
```

### 14.3 Update Theme

```
Operation: UPDATE existing theme in database
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Client: updateTheme('accordion', themeId, updates)  │
└────────────────────┬────────────────────────────────┘
                     │
                     │ POST /wp-admin/admin-ajax.php
                     ▼
┌─────────────────────────────────────────────────────┐
│ Request Body:                                       │
│  - action: 'save_accordion_theme'                   │
│  - nonce: '...'                                     │
│  - theme_id: 'theme_34gh3'                            │
│  - theme_name: 'Dark Mode'                          │
│  - titleBackgroundColor: '#111' (updated)          │
│  - ... (all attributes)                             │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Server processes
                     ▼
┌─────────────────────────────────────────────────────┐
│ WordPress PHP Handler                               │
│  - Verify nonce                                     │
│  - Check if theme_id exists (YES → update)          │
│  - Merge updates into existing theme                │
│  - Save to wp_options: accordion_themes             │
│  - Return ALL themes (with updated values)          │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Response
                     ▼
┌─────────────────────────────────────────────────────┐
│ {                                                   │
│   success: true,                                    │
│   data: {                                           │
│     themes: {                                       │
│       'theme_34gh3': {                                │
│         titleBackgroundColor: '#111' // UPDATED    │
│       }                                             │
│     }                                               │
│   }                                                 │
│ }                                                   │
└─────────────────────────────────────────────────────┘
```

### 14.4 Delete Theme

```
Operation: DELETE theme from database
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Client: deleteTheme('accordion', themeId)           │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Confirm dialog
                     ▼
┌─────────────────────────────────────────────────────┐
│ if (!window.confirm('Delete theme?')) return;       │
└────────────────────┬────────────────────────────────┘
                     │
                     │ POST /wp-admin/admin-ajax.php
                     ▼
┌─────────────────────────────────────────────────────┐
│ Request Body:                                       │
│  - action: 'delete_accordion_theme'                 │
│  - nonce: '...'                                     │
│  - theme_id: 'theme_34gh3'                            │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Server processes
                     ▼
┌─────────────────────────────────────────────────────┐
│ WordPress PHP Handler                               │
│  - Verify nonce                                     │
│  - Prevent deletion of 'default' theme              │
│  - Remove theme from accordion_themes               │
│  - Save updated array to wp_options                 │
│  - Return remaining themes                          │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Response
                     ▼
┌─────────────────────────────────────────────────────┐
│ {                                                   │
│   success: true,                                    │
│   data: {                                           │
│     themes: {                                       │
│       'default': { ... }                            │
│       // 'theme_34gh3' removed                        │
│     }                                               │
│   }                                                 │
│ }                                                   │
└─────────────────────────────────────────────────────┘
```

### 14.5 Rename Theme

```
Operation: UPDATE theme name only
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─────────────────────────────────────────────────────┐
│ Client: updateTheme('accordion', themeId, {         │
│   theme_name: 'New Name'                            │
│ })                                                  │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Uses same endpoint as update
                     │ POST /wp-admin/admin-ajax.php
                     ▼
┌─────────────────────────────────────────────────────┐
│ Request Body:                                       │
│  - action: 'save_accordion_theme'                   │
│  - theme_id: 'theme_34gh3'                            │
│  - theme_name: 'Dark Mode Renamed' (updated)        │
└────────────────────┬────────────────────────────────┘
                     │
                     │ Server merges name change
                     ▼
┌─────────────────────────────────────────────────────┐
│ Returns updated themes with new name                │
└─────────────────────────────────────────────────────┘
```

### 14.6 Error Handling

All AJAX operations use centralized error handling:

```javascript
// blocks/shared/utils/ajax-adapter.js
try {
  const response = await fetch(ajaxurl, { method: 'POST', body: formData });

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }

  const result = await response.json();

  if (!result.success) {
    throw new Error(result.data?.message || 'Unknown error');
  }

  return result.data;
} catch (error) {
  console.error('AJAX Error:', error);
  throw error;
}
```

**Common Error Responses:**
- Network timeout → "Request timed out. Please check your connection"
- No internet → "No internet connection. Please check your network"
- 403 Forbidden → "Permission denied. You may not have access"
- 500 Server Error → "Server error. Please try again later"
- Invalid nonce → "Authentication failed. Please refresh the page"

---

## Summary

This document covered the complete data flow and state management architecture of the accordion system:

1. **Data flows** from database → themes → effective values → UI controls
2. **Loading happens sequentially** to prevent race conditions
3. **Effective values** resolve via 3-tier cascade automatically
4. **Customization detection** is automatic, not manual
5. **Theme switching** caches customizations for restoration
6. **Theme updates** create complete snapshots and synchronize across blocks
7. **Event synchronization** keeps all blocks in sync in real-time
8. **Customization cache** is transient (lost on post save)
9. **Post save** persists block attributes but not cache
10. **Race conditions** are prevented through careful guard conditions
11. **State layers** include WordPress, database, React, and computed states
12. **AJAX operations** handle all server communication with robust error handling
13. **CSS parsing** provides single source of truth for default values

All flows work together to provide a seamless, real-time, multi-block theme management system.

---

## 16. Shared Architecture: Implementing New Blocks

### 16.1 Overview

The data flow and state management system is designed as **shared infrastructure** used by multiple block types. When implementing a new collapsible block (like Tabs), you can reuse all the hooks, utilities, and patterns described in this document.

### 16.2 Shared Modules

All state management logic is located in `src/shared/theme-system/`:

**Core Hooks**:
- `useThemeManagement(blockType)` - Theme loading, CRUD operations, event dispatching
- `useEffectiveValues(attributes, themes, cssDefaults, blockType)` - 3-tier cascade resolution
- `useCustomizationDetection(attributes, themes, currentThemeId)` - Auto-detect customizations

**Supporting Modules**:
- `theme-storage.js` - Database read/write operations for themes
- `cascade-resolver.js` - Value cascade logic with CSS defaults
- `theme-validator.js` - Validation functions for theme operations
- `event-dispatcher.js` - Custom event creation and dispatching

### 16.3 Block-Specific Configuration

When implementing a new block type, provide these block-specific values:

**Required Parameters**:
```javascript
const blockType = 'accordion'; // or 'tabs', 'collapse', etc.

// CSS Defaults (from PHP parsing)
const cssDefaults = window.accordionDefaults; // or window.tabsDefaults

// Database Option Names
const dbOption = `${blockType}_themes`; // accordion_themes, tabs_themes

// Event Names
const eventName = `${blockType}ThemeUpdated`; // accordionThemeUpdated, tabsThemeUpdated

// AJAX Actions
const ajaxAction = `get_${blockType}_themes`; // get_accordion_themes, get_tabs_themes
```

**Usage in Hooks**:
```javascript
// In your block's Edit component
const {
  themes,
  isLoading,
  createTheme,
  updateTheme,
  deleteTheme,
  renameTheme
} = useThemeManagement('accordion'); // Pass blockType here

const effectiveValues = useEffectiveValues(
  attributes,
  themes,
  window.accordionDefaults, // Block-specific CSS defaults
  'accordion' // blockType
);

const isCustomized = useCustomizationDetection(
  attributes,
  themes,
  attributes.currentTheme
);
```

### 16.4 Event System Integration

**Event Naming Convention**:
- Accordion: `accordionThemeUpdated`
- Tabs: `tabsThemeUpdated`
- Future blocks: `[blocktype]ThemeUpdated`

**Event Listeners**:
```javascript
useEffect(() => {
  const handleThemeUpdate = (event) => {
    const { themeId, themes, operation } = event.detail;

    // Only respond if this block uses the updated theme
    if (attributes.currentTheme === themeId) {
      // Reload themes or refresh effective values
      setAttributes({ _timestamp: Date.now() }); // Trigger re-render
    }
  };

  // Subscribe to events for THIS block type only
  window.addEventListener(`${blockType}ThemeUpdated`, handleThemeUpdate);

  return () => {
    window.removeEventListener(`${blockType}ThemeUpdated`, handleThemeUpdate);
  };
}, [attributes.currentTheme, blockType]);
```

### 16.5 CSS Defaults Integration

**PHP Setup** (done once per block type):
```php
// In plugin init
function enqueue_accordion_editor_assets() {
  // Parse CSS file
  $defaults = parse_css_defaults('accordion.css', 'accordion-default-');

  // Pass to JavaScript
  wp_localize_script(
    'accordion-block-editor',
    'accordionDefaults',
    $defaults
  );
}
```

**JavaScript Usage** (in block Edit component):
```javascript
// CSS defaults are available globally
const cssDefaults = window.accordionDefaults;

// Pass to cascade resolver
const effectiveValues = useEffectiveValues(
  attributes,
  themes,
  cssDefaults, // From window.accordionDefaults
  'accordion'
);
```

### 16.6 Database Schema Separation

**Accordion Themes**:
- Option name: `accordion_themes`
- Contains only accordion theme data
- Independent from other block types

**Tabs Themes**:
- Option name: `tabs_themes`
- Contains only tabs theme data
- Independent from accordion

**Key Principle**: Themes are **NOT convertible** between block types. Each block maintains its own theme library.

### 16.7 Implementation Checklist for New Blocks

When adding a new collapsible block type (e.g., "Collapse" or "Drawer"), follow these steps:

**Step 1: Create CSS File**
- [ ] Create `assets/css/[blocktype].css` with `:root` variables
- [ ] Define all default values as CSS custom properties
- [ ] Use naming convention: `--[blocktype]-default-[attribute]`

**Step 2: PHP Integration**
- [ ] Add PHP parsing function for new CSS file
- [ ] Use shared `parse_css_defaults()` function
- [ ] Pass defaults to JS via `wp_localize_script` as `window.[blocktype]Defaults`
- [ ] Register AJAX actions: `get_[blocktype]_themes`, `save_[blocktype]_theme`, etc.

**Step 3: Block Registration**
- [ ] Register block as `wp:custom/[blocktype]`
- [ ] Define block attributes (match naming conventions)
- [ ] Include `currentTheme`, `customizationCache`, and structural attributes

**Step 4: JavaScript Integration**
- [ ] Import shared hooks: `useThemeManagement`, `useEffectiveValues`, `useCustomizationDetection`
- [ ] Pass `blockType` parameter to all shared hooks
- [ ] Use `window.[blocktype]Defaults` for CSS defaults
- [ ] Subscribe to `[blocktype]ThemeUpdated` events

**Step 5: UI Components**
- [ ] Import shared components from `src/shared/components/`
- [ ] Use `ThemeSelector`, `ColorPanel`, `TypographyPanel`, etc.
- [ ] Configure with block-specific parameters

**Step 6: Testing**
- [ ] Test theme CRUD operations
- [ ] Test 3-tier cascade resolution
- [ ] Test event synchronization between blocks
- [ ] Verify themes are separate from other block types
- [ ] Test customization detection

### 16.8 Benefits of Shared Architecture

**For Developers**:
- **No Code Duplication**: Write logic once, use in multiple blocks
- **Consistent Behavior**: All blocks work the same way
- **Easier Testing**: Test shared modules, not every block
- **Faster Implementation**: New blocks can be added in hours, not days

**For Users**:
- **Consistent UX**: Same theme system across all blocks
- **Familiar Patterns**: Learn once, use everywhere
- **Reliable**: Shared code is battle-tested

**For Maintenance**:
- **Single Source of Truth**: Fix bugs in one place
- **Easier Updates**: Update shared modules, all blocks benefit
- **Clear Architecture**: New developers understand quickly

---

## Changelog

**v2.0 (2025-10-12) - v6.0 Architecture Alignment**

This update aligns DATA-FLOW-AND-STATE.md with the v6.0 architecture changes defined in FRONTEND-RENDERING.md v6.0.

**Major Changes:**
- **3-Tier Cascade**: Updated from 4-tier to 3-tier cascade system
  - Removed: Tier 2 (Page Style Override)
  - New hierarchy: Block attributes → Theme → Default (from CSS)
  - Updated all diagrams, examples, and flow descriptions

- **CSS as Single Source of Truth**: Changed default value source
  - Old: `attributeConfig.defaultValue` and `themes['default']` database object
  - New: `accordion.css` parsed by PHP, exposed via `window.accordionDefaults`
  - Added Section 3: "CSS Parsing and Default Values" with detailed explanation

- **Updated Naming Conventions**: Renamed attributes throughout all examples
  - `headerBackgroundColor` → `titleBackgroundColor`
  - `headerTextColor` → `titleColor`
  - `headerHoverColor` → `hoverTitleColor`
  - `borderWidth` → `accordionBorderWidth`
  - `borderColor` → `accordionBorderColor`

- **Updated Cascade Functions**: Modified resolution function signatures
  - `computeEffectiveValue()`: Removed `pageStyle` parameter
  - Changed from 4-tier to 3-tier logic in all code examples
  - Updated `useMemo` dependencies to remove `pageStyles`

- **Clarified Complete Snapshots**: Updated "Why Complete Snapshots" section
  - Explained that THEMES are complete snapshots (no nulls)
  - Clarified that DEFAULT layer is CSS-based (not database)
  - Documented null inheritance for specific attributes (iconColor, iconSize, etc.)
  - Removed contradiction about "no nulls" being absolute

- **Added CSS Parsing Documentation**: New Section 3
  - Explains `get_accordion_plugin_defaults()` function
  - Documents caching strategy with file modification time
  - Shows PHP → JavaScript data flow via `wp_localize_script`
  - Provides data flow diagram for CSS parsing system

- **Removed Page Style References**: Eliminated all mentions of
  - `_accordion_page_styles` post meta
  - Page-level overrides in cascade
  - Tier 2 in cascade diagrams and examples
  - `pageStyle` and `pageStyles` parameters in functions

- **Updated Data Flow Diagrams**: Modified all flow visualizations
  - Removed page-style layer from all cascade examples
  - Added CSS parsing layer to loading sequence
  - Updated effective value resolution to 3 tiers
  - Corrected all Tier numbering (was 0-3, now 1-3)

**Technical Details:**
- Section numbering updated (added Section 3, renumbered 3→4, 4→5, etc.)
- All attribute names updated in code examples and diagrams
- All cascade resolution examples updated to 3-tier
- Default value references changed from database/config to CSS-based
- Race condition examples updated with new default source
- Summary updated to reflect 3-tier cascade

**Compatibility:**
- Maintains backward compatibility for data flow concepts
- Core event synchronization unchanged
- AJAX operations unchanged
- Customization detection logic unchanged (just updated attribute names)

**Related Documentation:**
- Aligns with FRONTEND-RENDERING.md v6.0
- Complements BLOCK-ATTRIBUTES-SCHEMA.md naming conventions
- Matches EDITOR-UI-REQUIREMENTS.md attribute references
