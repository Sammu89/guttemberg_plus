document.addEventListener( 'DOMContentLoaded', function () {
	const autoMenus = document.querySelectorAll( '.auto-menu' );

	autoMenus.forEach( function ( menu ) {
		initializeAutoMenu( menu );
	} );

	function initializeAutoMenu( menu ) {
		// Add smooth scrolling to menu links
		const menuLinks = menu.querySelectorAll( 'a[href^="#"]' );
		menuLinks.forEach( function ( link ) {
			link.addEventListener( 'click', function ( e ) {
				e.preventDefault();
				const targetId = this.getAttribute( 'href' ).substring( 1 );
				const targetElement = document.getElementById( targetId );

				if ( targetElement ) {
					targetElement.scrollIntoView( {
						behavior: 'smooth',
						block: 'start',
					} );
				}
			} );
		} );

		// Add toggle functionality for nested menus
		const nestedItems = menu.querySelectorAll( 'li:has(ul)' );
		nestedItems.forEach( function ( item ) {
			const link = item.querySelector( 'a' );
			const submenu = item.querySelector( 'ul' );

			if ( link && submenu ) {
				// Create toggle button
				const toggleButton = document.createElement( 'button' );
				toggleButton.className = 'submenu-toggle';
				toggleButton.innerHTML = '▼';
				toggleButton.setAttribute( 'aria-expanded', 'false' );

				// Insert toggle button after the link
				link.insertAdjacentElement( 'afterend', toggleButton );

				// Add click event to toggle
				toggleButton.addEventListener( 'click', function ( e ) {
					e.preventDefault();
					const isExpanded =
						this.getAttribute( 'aria-expanded' ) === 'true';

					if ( isExpanded ) {
						submenu.style.display = 'none';
						this.innerHTML = '▼';
						this.setAttribute( 'aria-expanded', 'false' );
					} else {
						submenu.style.display = 'block';
						this.innerHTML = '▲';
						this.setAttribute( 'aria-expanded', 'true' );
					}
				} );

				// Initially hide submenus
				submenu.style.display = 'none';
			}
		} );
	}
} );
