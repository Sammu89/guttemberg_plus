document.addEventListener( 'DOMContentLoaded', function () {
	const tabsBlocks = document.querySelectorAll( '.tabs-block' );

	tabsBlocks.forEach( function ( tabsBlock ) {
		// Create tab navigation
		const tabNavigation = createTabNavigation( tabsBlock );
		const tabContents = tabsBlock.querySelectorAll( '.tab-content' );

		if ( tabNavigation && tabContents.length > 0 ) {
			// Insert navigation at the beginning of the tabs block
			tabsBlock.insertBefore( tabNavigation, tabsBlock.firstChild );

			// Add click listeners to tab navigation
			const tabButtons = tabNavigation.querySelectorAll( 'li' );
			tabButtons.forEach( function ( button, index ) {
				button.addEventListener( 'click', function () {
					activateTab( index, tabButtons, tabContents );
				} );
			} );
		}
	} );

	function createTabNavigation( tabsBlock ) {
		const tabContents = tabsBlock.querySelectorAll( '.tab-content' );

		if ( tabContents.length === 0 ) {
			return null;
		}

		const nav = document.createElement( 'ul' );
		nav.className = 'tab-nav';

		tabContents.forEach( function ( content, index ) {
			const li = document.createElement( 'li' );
			li.setAttribute( 'data-tab', index );
			li.textContent = content.previousElementSibling
				? content.previousElementSibling.textContent
				: 'Tab ' + ( index + 1 );

			if ( index === 0 ) {
				li.classList.add( 'active' );
			}

			nav.appendChild( li );
		} );

		return nav;
	}

	function activateTab( activeIndex, tabButtons, tabContents ) {
		// Remove active class from all tabs and contents
		tabButtons.forEach( function ( button ) {
			button.classList.remove( 'active' );
		} );

		tabContents.forEach( function ( content ) {
			content.classList.remove( 'active' );
		} );

		// Add active class to selected tab and content
		tabButtons[ activeIndex ].classList.add( 'active' );
		tabContents[ activeIndex ].classList.add( 'active' );
	}
} );
