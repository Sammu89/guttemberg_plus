/* eslint-env browser */
document.addEventListener( 'DOMContentLoaded', function () {
	const accordionBlocks = document.querySelectorAll( '.accordion-block' );

	accordionBlocks.forEach( function ( accordion ) {
		initializeAccordion( accordion );
	} );

	function initializeAccordion( accordion ) {
		const toggle = accordion.querySelector( '.accordion-toggle' );
		const content = accordion.querySelector( '.accordion-content' );

		if ( ! toggle || ! content ) {
			return;
		}

		// Check if already initialized to prevent duplicate listeners
		if ( accordion.dataset.accordionInitialized === 'true' ) {
			return;
		}
		accordion.dataset.accordionInitialized = 'true';

		// Set initial state
		const isInitiallyOpen = content.classList.contains( 'open' );
		if ( isInitiallyOpen ) {
			accordion.classList.add( 'is-open' );
			toggle.setAttribute( 'aria-expanded', 'true' );
			content.removeAttribute( 'hidden' );
			// Set max-height for initially open accordions to prevent content from being cut
			content.style.maxHeight = 'none';
		} else {
			accordion.classList.remove( 'is-open' );
			toggle.setAttribute( 'aria-expanded', 'false' );
			content.setAttribute( 'hidden', '' );
		}

		// Add click event listener
		toggle.addEventListener( 'click', function ( e ) {
			e.preventDefault();
			toggleAccordion( accordion, content, toggle );
		} );

		// Add keyboard support (Space key for buttons)
		toggle.addEventListener( 'keydown', function ( e ) {
			if ( e.key === ' ' ) {
				e.preventDefault();
				toggleAccordion( accordion, content, toggle );
			}
			// Enter key is handled natively by button element
		} );
	}

	function toggleAccordion( accordion, content, toggle ) {
		const isOpen = content.classList.contains( 'open' );

		if ( isOpen ) {
			// Closing: Remove 'open' class immediately to include padding in the animation
			content.classList.remove( 'open' );
			accordion.classList.remove( 'is-open' );
			toggle.setAttribute( 'aria-expanded', 'false' );

			// Get the height after removing open class (without padding)
			const height = content.scrollHeight;

			// Set explicit height temporarily
			content.style.maxHeight = height + 'px';

			// Force reflow to ensure the height is set before transition
			// eslint-disable-next-line no-unused-expressions
			content.offsetHeight;

			content.style.maxHeight = '0';

			// After transition completes, add hidden attribute for accessibility
			content.addEventListener(
				'transitionend',
				function addHidden( e ) {
					// Only respond to max-height transition to avoid double-firing
					if ( e.propertyName !== 'max-height' ) {
						return;
					}

					if ( ! content.classList.contains( 'open' ) ) {
						content.setAttribute( 'hidden', '' );
					}
					content.removeEventListener( 'transitionend', addHidden );
				}
			);
		} else {
			// Opening: Remove hidden attribute first for accessibility
			content.removeAttribute( 'hidden' );

			// Add 'open' class first (which adds padding), then measure height
			content.classList.add( 'open' );
			accordion.classList.add( 'is-open' );
			toggle.setAttribute( 'aria-expanded', 'true' );

			// Use requestAnimationFrame to ensure CSS has been applied before measuring
			// This prevents the two-step animation issue where padding is applied after measurement
			requestAnimationFrame( function () {
				// Now measure the full height including padding
				const height = content.scrollHeight;
				content.style.maxHeight = height + 'px';

				// After transition completes, remove max-height restriction
				content.addEventListener(
					'transitionend',
					function removeMaxHeight( e ) {
						// Only respond to max-height transition to avoid double-firing
						if ( e.propertyName !== 'max-height' ) {
							return;
						}

						if ( content.classList.contains( 'open' ) ) {
							content.style.maxHeight = 'none';
						}
						content.removeEventListener(
							'transitionend',
							removeMaxHeight
						);
					}
				);
			} );
		}
	}
} );
