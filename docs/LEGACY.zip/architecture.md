# Project: Guten Nav Plugin

## Summary
A lightweight WordPress plugin providing three specialized Gutenberg navigation blocks: Tabs (Enhanced Agent), Auto Menu (Smart Agent), and Dropdown (Flexible Agent). Each block offers extensive customization options, conditional asset loading for performance, and accessibility features. The plugin uses a hybrid architecture with JavaScript blocks for the editor and PHP processing for frontend functionality.

**NEW (Phase 2)**: The plugin now includes a **centralized customization core** (`blocks/shared/customization-core/`) that provides reusable theme management, attribute resolution, and customization detection logic. This core enables all blocks (Accordion, Tabs, etc.) to share common functionality without code duplication, reducing the codebase by ~30% while enabling rapid development of new blocks.

## User Workflow
1. Install and activate plugin in WordPress admin
2. Create/edit post or page in Gutenberg editor
3. Insert desired navigation block from "Widgets" category
4. Configure block settings using inspector controls (sidebar)
5. Add content to blocks using InnerBlocks
6. Publish page - CSS/JS assets auto-load based on block presence
7. Frontend displays functional navigation with smooth interactions

## Runtime Components & Entrypoints
- `guten-nav-plugin.php`: Main plugin registration and block processing
- `blocks/*/index.js`: Block editor implementations and configurations
- `assets/js/*.js`: Frontend JavaScript for interactivity
- `assets/css/*.css`: Styling for all visual variants and animations

## File → Responsibility Map

### Core Plugin
- `guten-nav-plugin.php`: [NEEDS MANUAL UPDATE]

### Shared Customization Core (NEW - Phase 2)

**Purpose**: Centralized logic for theme management, attribute resolution, and customization detection. Used by all blocks (Accordion, Tabs, etc.).

#### THEME ARCHITECTURE: COMPLETE SNAPSHOT SYSTEM

**Core Principle**: Every theme is a self-contained complete snapshot with ALL attribute values (no nulls, no inheritance).

**Theme Structure**:
- Every theme contains ALL 33+ attributes with real, concrete values
- NO null values in themes (each attribute has a proper default)
- NO inheritance or cascading between themes
- Each theme is completely independent and immutable
- Default theme loaded from `include/theme-default.php` on plugin init

**Block Attributes**:
- Clean block: Attributes are UNDEFINED (removed from saved HTML)
- Customized block: Attributes ARE DEFINED (saved in block HTML)
- Simple rule: If attribute exists on block → customized, else → clean

**Value Resolution** (Simple 2-Level):
```javascript
effectiveValue = blockAttributes[attr] ?? theme[attr]
```
- NO third level needed (themes have complete data)
- NO cascading or priority complexity
- Theme ALWAYS has a value, so resolution always succeeds

**Customization Detection** (Simple):
```javascript
isCustomized = Object.keys(blockAttributes).some(attr => attr in CUSTOMIZATION_ATTRS)
```
- No value comparison needed
- No deep equality checks
- Just check if ANY customization attribute is defined on block

**Update Theme Flow**:
1. Collect ALL current effective values: `block ?? theme` for each of 33+ attributes
2. Save complete snapshot to database (all values, no nulls)
3. Clear ALL block attributes to undefined (removes from HTML)
4. Sidebar now reads from updated theme
5. Result: Clean block with theme snapshot

**Save As New Theme Flow**:
- Same as update, but creates NEW theme instead of modifying existing
- Original theme remains unchanged
- Block switches to new theme

#### Core Modules (`blocks/shared/customization-core/`)
- `index.js`: Public API exports for all core functions
- `theme-manager.js`: Pure functions for theme CRUD operations (create, update, delete, get themes)
- `attribute-resolver.js`: Simple 2-level value resolution (block ?? theme)
- `customization-detector.js`: Detection logic for customized attributes and sections
- `attribute-operations.js`: Utilities for clearing/resetting attributes (eliminates 6× duplication in Accordion)
- `validation.js`: Schema validation for attribute values and configs
- `constants.js`: Shared constants and error messages

#### React Hooks (`blocks/shared/hooks/`)
- `useThemeManagement.js`: React hook wrapping theme CRUD with WordPress AJAX integration
- `useEffectiveValues.js`: React hook for memoized effective value computation
- `useCustomizationState.js`: React hook combining detection + clearing operations
- `useThemeHandlers.js`: Centralized theme operation handlers (update, create, rename, switch)

#### WordPress Adapters (`blocks/shared/utils/`)
- `ajax-adapter.js`: Generic AJAX handler for theme operations (replaces block-specific ajax.js)
- `style-helpers.js`: CSS generation utilities (buildInlineStyles, getBorderRadiusValue, getAlignmentMargins)

**Key Design Principles**:
1. **Complete Snapshots**: Every theme has ALL values, no nulls, no inheritance
2. **Block-agnostic**: Core never hard-codes block-specific attribute names
3. **Pure functions first**: 90% of core logic is testable without WordPress/React
4. **Config-driven**: Each block defines its own ATTRIBUTE_CONFIG, core consumes it
5. **Per-block storage**: Themes stored separately per block type (`guten_nav_{blockType}_themes`)
6. **Simple resolution**: Two-level only (block ?? theme), no cascading complexity

### Block Definitions

#### Accordion Block (Refactored - Phase 2 Migration Planned)
- `blocks/accordion/index.js`: Block registration entry point (11 lines)
- `blocks/accordion/edit.js`: Editor component with theme management and inspector controls (1,271 lines) **[TO BE REFACTORED]**
- `blocks/accordion/save.js`: Frontend rendering logic (222 lines) **[TO BE REFACTORED]**
- `blocks/accordion/config.js`: Accordion-specific ATTRIBUTE_CONFIG (33 attributes) **[NEW in Phase 3]**
- `blocks/accordion/constants.js`: UI-specific constants (border styles, alignment options, animation speeds, UI constants)
- `blocks/accordion/block.json`: Block configuration and attributes

**Phase 2 Changes**: After migration, Accordion will consume shared core hooks instead of maintaining 20+ duplicated transformations internally. Expected reduction: ~1,000 lines (from 3,500 → 2,500 lines).

**Components (10 files):**
- `blocks/accordion/components/AccordionIcon.js`: Reusable icon component for both editor and frontend
- `blocks/accordion/components/ColorPickerControl.js`: Enhanced color picker with fallback and customization tracking
- `blocks/accordion/components/ThemeSelector.js`: Theme dropdown for toolbar and inspector
- `blocks/accordion/components/ThemeListItem.js`: Individual theme item in theme management modal
- `blocks/accordion/components/ErrorBoundary.js`: React error boundary for graceful error handling
- `blocks/accordion/components/inspector/SettingsPanel.js`: Main settings (theme, alignment, width)
- `blocks/accordion/components/inspector/AppearancePanel.js`: Color controls for all visual elements
- `blocks/accordion/components/inspector/BorderPanel.js`: Border style and width controls
- `blocks/accordion/components/inspector/BorderRadiusPanel.js`: Corner radius controls
- `blocks/accordion/components/inspector/IconPanel.js`: Icon configuration and preview
- `blocks/accordion/components/inspector/AnimationPanel.js`: Animation speed and easing controls

**Hooks (3 files → 1 after Phase 3):**
- `blocks/accordion/hooks/useThemeManagement.js`: **[TO BE REMOVED]** Replaced by `shared/hooks/useThemeManagement.js`
- `blocks/accordion/hooks/useAccordionState.js`: Accordion-specific state management (stays block-specific)
- `blocks/accordion/hooks/useEffectiveValue.js`: **[TO BE REMOVED]** Replaced by `shared/hooks/useEffectiveValues.js`

**Utilities (3 files → 0 after Phase 3):**
- `blocks/accordion/utils/ajax.js`: **[TO BE REMOVED]** Replaced by `shared/utils/ajax-adapter.js`
- `blocks/accordion/utils/validation.js`: **[TO BE REMOVED]** Replaced by `shared/customization-core/validation.js`
- `blocks/accordion/utils/styleHelpers.js`: **[TO BE MOVED]** Moved to `shared/utils/style-helpers.js`

#### Other Blocks
- `blocks/auto-menu/index.js`: Auto menu block implementation
- `blocks/auto-menu/block.json`: Auto menu block configuration
- `blocks/tab-panel/index.js`: Tab panel child block
- `blocks/tab-panel/block.json`: Tab panel configuration
- `blocks/tabs/index.js`: Tabs container block
- `blocks/tabs/block.json`: Tabs block configuration

### Frontend Assets
- `assets/css/accordion.css`: [NEEDS MANUAL UPDATE]
- `assets/css/auto-menu.css`: [NEEDS MANUAL UPDATE]
- `assets/css/tabs.css`: [NEEDS MANUAL UPDATE]
- `assets/js/accordion.js`: [NEEDS MANUAL UPDATE]
- `assets/js/auto-menu.js`: [NEEDS MANUAL UPDATE]
- `assets/js/tabs.js`: [NEEDS MANUAL UPDATE]

### Documentation
- `BUILD.md`: [NEEDS MANUAL UPDATE]
- `CLAUDE.md`: [NEEDS MANUAL UPDATE]
- `README.md`: [NEEDS MANUAL UPDATE]
- `TODO.md`: [NEEDS MANUAL UPDATE]
- `claude.md`: Documentation system entry point
- `architecture.md`: This file - global project overview

## Data & Control Flow
1. **Block Registration**: Plugin loads, registers all block types via `register_block_type()`
2. **Editor Experience**: User inserts blocks, JavaScript renders editor interfaces with inspector controls
3. **Content Saving**: Block data saved with attributes in post content as HTML/data attributes
4. **Frontend Loading**: WordPress checks for block presence, conditionally enqueues CSS/JS assets
5. **Content Processing**: PHP filters process saved blocks (auto-menu heading extraction, tabs restructuring)
6. **Frontend Rendering**: Browser loads styled, functional components with JavaScript interactions
7. **User Interaction**: JavaScript handles tab switching, dropdown toggling, smooth scrolling

### Accordion Block Component Hierarchy
```
Edit Component (edit.js)
├── ErrorBoundary
│   └── Theme Management & State
│       ├── useThemeManagement (hook) - AJAX operations
│       ├── useAccordionState (hook) - local state & cache
│       └── useEffectiveValue (hook) - value resolution
├── BlockControls (toolbar)
│   ├── ThemeSelector
│   └── Alignment Controls
├── InspectorControls (sidebar)
│   ├── SettingsPanel (always visible)
│   │   ├── ThemeSelector
│   │   ├── Alignment Controls
│   │   └── Width Controls
│   ├── AppearancePanel
│   │   └── ColorPickerControl (×7)
│   ├── BorderPanel
│   │   └── Border & Divider Controls
│   ├── BorderRadiusPanel
│   │   └── Corner Radius Controls
│   ├── IconPanel
│   │   ├── AccordionIcon (preview)
│   │   └── Icon Configuration
│   └── AnimationPanel
│       └── Speed & Easing Controls
└── Block Content
    ├── RichText (heading)
    ├── AccordionIcon
    └── InnerBlocks (content)

Save Component (save.js)
├── Accordion Container
│   ├── RichText.Content (heading)
│   ├── AccordionIcon
│   └── InnerBlocks.Content
```

### Accordion Block Data Flow
1. **Theme Loading**: Component mounts → useThemeManagement calls AJAX → themes loaded from WordPress options
2. **Theme Selection**: User selects theme → attributes updated → useEffectiveValue resolves display values
3. **Customization**: User changes color/border → attribute set → customizationCache updated → "customized" indicator shown
4. **Theme Update**: User clicks "Update theme" → AJAX saves changes → theme data persisted → notification shown
5. **Value Resolution**: For each setting: Check attribute → Check theme → Use default (via useEffectiveValue hook)
6. **Error Handling**: Any error in theme operations → ErrorBoundary catches → Fallback UI displayed

## Integrations & External Services
- **WordPress Core**: Block API, hook system, asset enqueueing, content filtering
- **Gutenberg**: Block editor components, InnerBlocks, inspector controls
- **Browser APIs**: DOM manipulation, smooth scrolling, keyboard events, ARIA attributes
- **No External Dependencies**: Self-contained plugin with vanilla JavaScript

## Tests & Coverage
- **Status**: UNKNOWN - No test files identified in codebase
- **Coverage**: No automated testing infrastructure detected
- **Recommendation**: Implement unit tests for PHP processing and integration tests for block functionality

## Recent Changes (auto log)
- 2025-10-07: **Phase 2 Complete** - Designed centralized customization core architecture (design.md, migration-plan.md, test-checklist.md)
- 2025-10-07: **Phase 2** - Created `blocks/shared/customization-core/` specification (6 modules, 3 hooks, 2 adapters)
- 2025-10-07: **Phase 2** - Migration plan finalized: 3-week timeline, 12 modules to create, ~1,000 line reduction expected
- 2025-10-07: Architecture.md updated with Phase 2 centralized core design and migration roadmap
- 2025-10-04: Accordion block refactoring completed - 1 file (1,655 lines) split into 21 modular files (4,265 total lines)
- 2025-10-04: Added 10 reusable components, 3 custom hooks, and 3 utility modules to accordion block
- 2025-10-04: Implemented JSDoc documentation, accessibility improvements, and error handling
- 2025-10-04: Architecture documentation updated with complete accordion block structure


## Risks & TODOs
- **Browser Compatibility**: Auto-menu uses CSS `:has()` selector (limited support in older browsers)
- **Error Handling**: No validation for malformed block data or invalid configurations
- **Testing**: No automated tests for PHP processing or JavaScript functionality
- **Icon Management**: Inconsistent icon handling between editor and frontend (dropdown block)
- **Performance**: Inline styles used instead of CSS classes for some dynamic styling
- **Accessibility**: Limited keyboard navigation in tabs block
- **Maintenance**: Manual documentation updates required when code changes
