# WordPress Gutenberg Blocks - AI Agent Quick Reference

## Project Summary

Building 3 interconnected WordPress Gutenberg blocks (Accordion, Tabs, TOC) with a unified theme system. Total: ~8,290 LOC across 5 phases.

## Core Architecture (Non-Negotiable)

### 3-Tier Value Cascade
```
Block Customization (highest) → Theme → CSS Default (lowest)
```
- **Rule**: First defined value wins, NO merging
- All customizable attributes default to `null`
- CSS `:root` variables = single source of truth

### Complete Snapshot Themes
- Saved themes contain ALL attributes with explicit values (no nulls)
- Separate storage per block: `accordion_themes`, `tabs_themes`, `toc_themes`
- Event isolation: Changes to one block type don't affect others

### WordPress Libraries Integration
- ✅ **@wordpress/data** - Theme CRUD only (NOT cascade resolution)
- ✅ **@wordpress/components** - UI panels (60-70%)
- ✅ **@wordpress/scripts** - Build system with custom CSS parser
- ✅ **@wordpress/a11y** - Screen reader announcements only

## Critical Rules

### MUST DO
1. Load themes before rendering (prevents race conditions)
2. Use `getAllEffectiveValues()` for UI (never read raw attributes)
3. Clear customizations after theme update
4. Keep cascade-resolver.js pure function (no Redux integration)

### MUST NOT DO
1. Don't use @wordpress/data for cascade resolution
2. Don't merge cascade tiers
3. Don't treat booleans differently (same cascade rules)
4. Don't render before themes load

## File Structure

```
shared/
├── theme-system/
│   ├── cascade-resolver.js (CUSTOM - pure function)
│   └── theme-manager.js (thin wrapper over store)
├── data/
│   └── store.js (@wordpress/data Redux store)
├── components/ (use @wordpress/components)
├── attributes/ (all default to null)
└── utils/ (ID generator, ARIA helpers)

php/
├── css-defaults/ (auto-generated from CSS)
├── theme-storage.php
└── theme-rest-api.php

blocks/
├── accordion/
├── tabs/
└── toc/
```

## Implementation Phases

**Phase 0** (Build System): Setup webpack + CSS parser loader (~270 LOC)
**Phase 1** (Shared Infrastructure): 8 modules, MUST complete first (~2,520 LOC)
**Phase 2-4** (Blocks): Can run parallel after Phase 1 (~5,300 LOC total)
**Phase 5** (Integration): Cross-block testing (~200 LOC)

## Key Modules (Phase 1)

1. **CSS Parsing** - Parse `:root` vars → PHP arrays → `window.[blockType]Defaults`
2. **Cascade Resolver** - Pure function, <5ms, NO store integration
3. **@wordpress/data Store** - Theme CRUD with `useSelect`/`useDispatch`
4. **Theme Storage PHP** - REST API endpoints for CRUD operations
5. **Theme Manager** - Thin wrapper over store (backward compatibility)
6. **Shared Attributes** - All customizable attrs default to `null`
7. **Shared UI Components** - Wrap @wordpress/components, show effective values
8. **Shared Utilities** - ID gen, ARIA helpers, keyboard nav, validation

## Store Usage Pattern

```javascript
import { useSelect, useDispatch } from '@wordpress/data';
import { getAllEffectiveValues } from '@shared/theme-system/cascade-resolver';

function Edit({ attributes, setAttributes }) {
  const blockType = 'accordion';

  // Load themes from store
  const themes = useSelect(select =>
    select('gutenberg-blocks/themes').getThemes(blockType)
  );

  const { createTheme, updateTheme } = useDispatch('gutenberg-blocks/themes');

  // Get current theme
  const currentTheme = themes[attributes.currentTheme];

  // Resolve effective values (cascade)
  const effectiveValues = getAllEffectiveValues(
    attributes,
    currentTheme,
    window.accordionDefaults
  );

  // Theme operations
  await createTheme(blockType, 'My Theme', effectiveValues);
}
```

## Testing Priorities

1. **Event Isolation** - Accordion themes don't affect Tabs/TOC
2. **Cascade Performance** - `getAllEffectiveValues()` <5ms
3. **Theme Operations** - Create/Update/Delete/Rename/Switch all work
4. **ARIA Compliance** - Unique IDs, correct attributes, keyboard nav

## Documentation Files

### Quick Reference
- **claude.md** (this file) - Quick AI agent reference
- **README.md** - Master guide with all implementation details

### Core Architecture (Read before implementing)
- **THEME-SYSTEM-ARCHITECTURE.md** - Foundation: 3-tier cascade, theme system, CSS defaults
- **DATA-FLOW-AND-STATE.md** - How data flows, state management with @wordpress/data
- **FRONTEND-RENDERING.md** - How blocks render on frontend
- **EDITOR-UI-REQUIREMENTS.md** - Complete UI/UX specs for block editor
- **BLOCK-ATTRIBUTES-SCHEMA.md** - Data dictionary for all attributes

### Block Specs (Read when implementing specific blocks)
- **ACCORDION-HTML-STRUCTURE.md** - Accordion block: HTML, ARIA, keyboard nav
- **TABS-ACCORDION-INTEGRATION.md** - Tabs block: orientation, hover mode, responsive
- **TOC-BLOCK-IMPLEMENTATION.md** - TOC block: heading detection, numbering, filtering

### Integration & Strategy
- **WP-LIBRARIES-INTEGRATION-AUDIT.md** - WordPress libraries feasibility analysis
- **core-api-reference.md** - API reference for shared modules
- **WORDPRESS-INTEGRATION-SUMMARY.md** - Integration summary (legacy)
- **IMPLEMENTATION-STRATEGY.md** - Implementation strategy (legacy)

## Agent Protocol

1. **Read documentation** before coding
2. **Write max 200-300 LOC per session** (prevent token exhaustion)
3. **PAUSE if uncertain** - Ask user, don't assume
4. **Update PROJECT_STATUS.md** after each task
5. **Run testing checklist** for each module

## Current Status

✅ Documentation complete
🎯 Ready for Phase 0 (build system setup)
📋 Next: Install dependencies, create webpack config, test build system
