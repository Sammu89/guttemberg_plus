# Shared Theme System Architecture

**A Conceptual Overview of the Complete Snapshot Theme System for Accordion and Tabs Blocks**

**Version 3.0 - Shared Architecture + CSS as Single Source of Truth**

---

## Table of Contents

1. [Theme System Overview](#1-theme-system-overview)
2. [Shared Architecture Philosophy](#2-shared-architecture-philosophy)
3. [The 3-Tier Value Cascade](#3-the-3-tier-value-cascade)
4. [CSS as Single Source of Truth](#4-css-as-single-source-of-truth)
5. [Theme Data Structure](#5-theme-data-structure)
6. [Customization vs Theme Workflow](#6-customization-vs-theme-workflow)
7. [Theme Operations](#7-theme-operations)
8. [The Customization Cache](#8-the-customization-cache)
9. [Boolean Toggle Behavior](#9-boolean-toggle-behavior)
10. [Attribute Types](#10-attribute-types)
11. [Editor vs Frontend](#11-editor-vs-frontend)
12. [Database Schema](#12-database-schema)
13. [Shared Implementation Structure](#13-shared-implementation-structure)

---

## 1. Theme System Overview

### What Themes Are and Why They Exist

Themes are **complete, self-contained snapshots** of styling and behavior configuration for blocks (Accordion and Tabs). Each theme contains explicit values for ALL customizable attributes (colors, borders, icons, animations, title formatting, etc.).

**Core Principle:** A theme is a complete configuration template that can be reused across multiple blocks of the same type throughout your WordPress site.

**Block-Type Specific:** While the theme system architecture is shared, themes themselves are block-type specific:
- **Accordion themes** apply only to accordion blocks
- **Tabs themes** apply only to tabs blocks
- Themes can be converted between block types (shared attributes copy, unique attributes use defaults)

**Why Themes Exist:**

- **Consistency**: Apply uniform styling across multiple accordions site-wide
- **Reusability**: Define a configuration once, use it everywhere
- **Efficiency**: Update one theme to change all accordions using it
- **Maintainability**: Central source of truth for accordion styling
- **Flexibility**: Mix themes with per-block customizations as needed

### Difference Between Themes and Per-Block Customizations

| Aspect | Themes | Per-Block Customizations |
|--------|--------|--------------------------|
| **Scope** | Site-wide, affects ALL blocks using the theme | Single block only |
| **Storage** | Database (wp_options table) | Post content (block attributes in HTML) |
| **Output** | CSS classes in `<head>` | Inline CSS variables on element |
| **Updates** | Updating theme updates ALL blocks using it | Changes affect only this block |
| **Use Case** | Consistent styling across multiple pages/posts | One-off tweaks for specific blocks |
| **Structure** | Complete snapshot with ALL attributes defined | Only stores DIFFERENCES from theme |

### When to Use Themes vs Customizations

**Use Themes When:**

- You want consistent styling across multiple accordions
- You're creating a design system for your site
- You need to update many accordions at once
- You're defining reusable templates

**Use Customizations When:**

- You need to highlight a single accordion differently
- Making small, one-off adjustments (e.g., one red accordion among blue ones)
- Experimenting with changes before committing to a theme
- Styling is specific to content context

**Best Practice:** Start with a theme (or default), customize individual blocks as needed, then decide if customizations should become a new theme or remain block-specific.

---

## 2. Shared Architecture Philosophy

### Core Principle: "One System, Multiple Block Types"

The theme system is designed as **shared infrastructure** used by multiple block types (Accordion, Tabs, and future collapsible blocks). The architecture, code, and logic are shared, while each block type maintains its own theme library.

### What Is Shared

**Shared across all block types:**

1. **Theme System Logic** (`src/shared/theme-system/`):
   - 3-tier cascade resolution algorithm
   - Theme CRUD operations (create, update, delete, rename, switch)
   - Customization cache mechanism
   - Theme validation logic
   - Event system for updates

2. **CSS Parsing System** (`src/shared/utils/css-parser.js`):
   - Parse CSS `:root` variables from CSS files
   - Cache with file modification time
   - Convert CSS values to JavaScript objects
   - Used by both `accordion.css` and `tabs.css`

3. **Attribute Definitions** (`src/shared/attributes/`):
   - Common attribute names and structures (all default to `null`)
   - Shared attributes: colors, typography, borders, spacing, icons
   - Ensures naming consistency across blocks

4. **UI Components** (`src/shared/components/`):
   - ThemeSelector dropdown
   - ColorPanel, TypographyPanel, BorderPanel, etc.
   - CustomizationWarning dialogs
   - Consistent user experience

5. **Database Operations** (`src/shared/storage/`):
   - Theme save/load functions
   - Transient caching
   - Version-based invalidation

### What Is Block-Specific

**Unique per block type:**

1. **Theme Storage**:
   - Accordion themes: `wp_options['accordion_themes']`
   - Tabs themes: `wp_options['tabs_themes']`
   - Stored separately, not shared between blocks

2. **CSS Defaults File**:
   - Accordion: `assets/css/accordion.css` with `--accordion-default-*` variables
   - Tabs: `assets/css/tabs.css` with `--tabs-default-*` variables

3. **Block-Specific Attributes**:
   - Accordion: `initiallyOpen`, `allowMultipleOpen`, `iconRotation`
   - Tabs: `orientation`, `useHover`, `defaultActiveTab`, `makeResponsive`

4. **HTML Structure** and ARIA patterns (different interactive patterns)

### Implementation Structure

**Shared modules location:**
```
src/
├── shared/
│   ├── theme-system/
│   │   ├── theme-manager.js       # CRUD operations
│   │   ├── cascade-resolver.js    # 3-tier resolution
│   │   ├── theme-storage.js       # Database operations
│   │   ├── theme-validator.js     # Validation logic
│   │   └── theme-events.js        # Event system
│   ├── attributes/
│   │   ├── color-attributes.js
│   │   ├── typography-attributes.js
│   │   ├── border-attributes.js
│   │   ├── spacing-attributes.js
│   │   ├── icon-attributes.js
│   │   └── meta-attributes.js
│   ├── components/
│   │   ├── ThemeSelector.js
│   │   ├── ColorPanel.js
│   │   ├── TypographyPanel.js
│   │   ├── BorderPanel.js
│   │   └── CustomizationWarning.js
│   └── utils/
│       ├── css-parser.js          # Parse CSS defaults
│       ├── id-generator.js
│       └── validation.js
```

**Block-specific implementation:**
```
blocks/
├── accordion/
│   ├── block.json               # Imports shared + accordion-specific attributes
│   ├── edit.js                  # Uses shared components
│   ├── save.js
│   └── accordion-attributes.js  # Accordion-only attributes
└── tabs/
    ├── block.json               # Imports shared + tabs-specific attributes
    ├── edit.js                  # Uses same shared components
    ├── save.js
    └── tabs-attributes.js       # Tabs-only attributes
```

### Benefits of Shared Architecture

1. **Code Reuse**: Theme logic written once, used by all blocks
2. **Consistency**: Same behavior and UI patterns across blocks
3. **Maintainability**: Fix bugs once, all blocks benefit
4. **Extensibility**: New block types can plug into existing system
5. **Single Source of Truth**: CSS files drive all defaults
6. **Performance**: Shared code means smaller bundle sizes

### Theme Independence

**IMPORTANT:** Accordion themes and Tabs themes are completely separate and **NOT convertible**:

- Accordion themes work only with accordion blocks
- Tabs themes work only with tabs blocks
- No conversion functionality between block types
- Each block type has its own independent theme library

**Why separate:**
- Different interactive patterns require different styling approaches
- Block-specific attributes (like `orientation` for tabs, `iconRotation` for accordion) make conversion impractical
- Simpler user experience - clear separation between block types

---

## 3. The 3-Tier Value Cascade

The theme system resolves attribute values through a **3-tier cascade** with clear priority ordering. When displaying an accordion, the system checks each tier from highest to lowest priority until it finds a defined value.

### Visual Representation

```
┌─────────────────────────────────────────────────────────┐
│  LAYER 1: Default Theme (Base)                          │
│  Priority: LOWEST                                       │
│  Storage: accordion.css (:root CSS variables)          │
│  Example: --accordion-default-title-color: #333333     │
│  PHP: Parsed and cached with file modification time    │
│  JS: Available via window.accordionDefaults            │
└─────────────────────────────────────────────────────────┘
                          ↓
                  (can be overridden by)
                          ↓
┌─────────────────────────────────────────────────────────┐
│  LAYER 2: Custom Saved Themes                           │
│  Priority: MEDIUM                                       │
│  Storage: Database (wp_options: accordion_themes)      │
│  Output: CSS classes in <head> with fallback vars     │
│  Example: .accordion-theme-dark-mode { ... }           │
└─────────────────────────────────────────────────────────┘
                          ↓
                  (can be overridden by)
                          ↓
┌─────────────────────────────────────────────────────────┐
│  LAYER 3: Per-Accordion Customizations                 │
│  Priority: HIGHEST                                      │
│  Storage: Block attributes → inline CSS variables      │
│  Example: style="--custom-title-color: #ff0000"        │
└─────────────────────────────────────────────────────────┘
```

### Layer Descriptions

#### Layer 1: Default Theme (Lowest Priority - Base)

**What it is:** The built-in default styling defined in `accordion.css` as `:root` CSS custom properties.

**When it's used:** As the base fallback for all values not defined in custom themes or per-accordion customizations.

**Storage location:** `assets/css/accordion.css` file as `:root` CSS variables.

**Example CSS:**
```css
:root {
  --accordion-default-title-color: #333333;
  --accordion-default-title-bg: #f5f5f5;
  --accordion-default-title-size: 16px;
  /* ... all styling defaults */
}
```

**PHP Integration:**
- PHP parses this CSS file on first request using `parse_css_defaults()`
- Values are cached in transient with file modification time check
- Cache auto-invalidates when CSS file changes
- Makes defaults available to JavaScript via `wp_localize_script()`

**JavaScript Access:**
```javascript
const DEFAULTS = window.accordionDefaults || {};
// { titleColor: '#333333', titleFontSize: 16, ... }
```

**Priority:** Last resort fallback - only used when no theme or customization defines the value.

**Maintenance Benefit:** Change one CSS file, everything updates automatically (frontend, PHP, JavaScript).

#### Layer 2: Custom Saved Themes (Medium Priority)

**What it is:** User-created themes stored in database as complete snapshots.

**When it's used:** When an accordion selects a custom theme (e.g., "Dark Mode", "Light Mode").

**Storage location:** Database (`wp_options` table: `accordion_themes`) as serialized PHP arrays.

**Structure:**
```php
array(
  'dark-mode' => array(
    'theme_id' => 'dark-mode',
    'theme_name' => 'Dark Mode',
    'titleColor' => '#ffffff',
    'titleBackgroundColor' => '#222222',
    // ... all 33+ attributes with explicit values
  ),
  'light-mode' => array(/* ... */),
)
```

**CSS Output:** Generated as CSS classes in `<head>` using two-level CSS variable pattern:

```css
.accordion-theme-dark-mode {
  border-width: var(--custom-border-width, 1px);
  border-color: var(--custom-border-color, #222222);
}

.accordion-theme-dark-mode .accordion-title {
  color: var(--custom-title-color, #ffffff);
  background-color: var(--custom-title-bg, #222222);
  font-size: var(--custom-title-size, 18px);
}
```

**Priority:** Overrides default values, but loses to per-accordion customizations.

**Caching:** Theme CSS is cached in transients with version-based invalidation.

#### Layer 3: Per-Accordion Customizations (Highest Priority)

**What it is:** Attribute values saved directly on the block in post content as inline CSS variables.

**When it's used:** When a user customizes an individual accordion block.

**Storage location:** Post HTML (Gutenberg block attributes), output as inline `style` attribute.

**Example HTML:**
```html
<div class="wp-block-custom-accordion accordion-theme-dark-mode"
     style="--custom-title-color: #ff0000; --custom-title-size: 20px;">
  <!-- Only customized values are inline -->
</div>
```

**Priority:** Always wins over all other layers.

**Efficiency:** Only explicit customizations are output inline (not all attributes).

### How the Cascade Resolution Works

**Resolution Algorithm:**

```
For each attribute (e.g., titleColor):
  1. Check block attributes → if defined, USE IT and STOP
  2. Check selected theme → if defined, USE IT and STOP
  3. Check default values (from accordion.css) → USE IT and STOP
  4. If all layers undefined → return null (shouldn't happen with proper defaults)
```

**CSS Cascade Implementation:**

```css
/* Layer 1: Default (in accordion.css) */
:root {
  --accordion-default-title-color: #333333;
}

/* Layer 2: Theme (generated in <head>) */
.accordion-theme-dark-mode .accordion-title {
  color: var(--custom-title-color, #ffffff); /* fallback to theme */
}

/* Layer 3: Per-accordion (inline) */
<div style="--custom-title-color: #ff0000;"> /* wins */
```

**Effective Result:** Title color is #ff0000 (Layer 3 overrides Layer 2's #ffffff).

**Key Properties:**

- **First Match Wins**: As soon as a value is found, resolution stops
- **No Merging**: Values don't combine; the highest-priority layer wins completely
- **Independent Per-Attribute**: Each attribute resolves independently
- **CSS-Based**: The cascade is implemented using CSS custom properties
- **Predictable**: Always follows the same priority order

### Null Inheritance

Some attributes inherit from others when null:

- `iconColor` → inherits from `titleColor`
- `iconSize` → inherits from `titleFontSize`
- `hoverTitleColor` → inherits from `titleColor`
- `activeTitleColor` → inherits from `titleColor`
- `activeTitleBackgroundColor` → inherits from `titleBackgroundColor`

This inheritance is resolved in PHP's `resolve_null_inheritance()` function when generating theme CSS.

---

## 4. CSS as Single Source of Truth

### The v6.0 Architecture

**Core Principle:** All default values are defined ONCE in CSS files at `:root`. Everything else reads from there.

**Files:**
- **Accordion:** `assets/css/accordion.css` (defines `--accordion-default-*` variables)
- **Tabs:** `assets/css/tabs.css` (defines `--tabs-default-*` variables)

### Example: Accordion Defaults

**File:** `assets/css/accordion.css`

```css
:root {
  /* Wrapper/Container */
  --accordion-default-border-width: 1px;
  --accordion-default-border-style: solid;
  --accordion-default-border-color: #e0e0e0;
  --accordion-default-border-radius-tl: 4px;
  --accordion-default-border-radius-tr: 4px;
  --accordion-default-border-radius-br: 4px;
  --accordion-default-border-radius-bl: 4px;
  --accordion-default-shadow: none;
  --accordion-default-margin-bottom: 16px;

  /* Title */
  --accordion-default-title-color: #333333;
  --accordion-default-title-bg: #f5f5f5;
  --accordion-default-title-size: 16px;
  --accordion-default-title-weight: 600;
  --accordion-default-title-style: normal;
  --accordion-default-title-transform: none;
  --accordion-default-title-decoration: none;
  --accordion-default-title-align: left;
  --accordion-default-title-padding-top: 12px;
  --accordion-default-title-padding-right: 12px;
  --accordion-default-title-padding-bottom: 12px;
  --accordion-default-title-padding-left: 12px;

  /* Content */
  --accordion-default-content-bg: transparent;
  --accordion-default-content-padding-top: 16px;
  --accordion-default-content-padding-right: 16px;
  --accordion-default-content-padding-bottom: 16px;
  --accordion-default-content-padding-left: 16px;

  /* Divider */
  --accordion-default-divider-width: 1px;
  --accordion-default-divider-style: solid;
  --accordion-default-divider-color: #e0e0e0;

  /* Hover/Active states default to null (inherit via PHP logic) */
}
```

### PHP Parsing System

**Function:** `get_accordion_plugin_defaults()`

```php
function get_accordion_plugin_defaults() {
    // Check transient cache
    $cached = get_transient('accordion_parsed_defaults');

    if ($cached !== false) {
        // Verify CSS hasn't changed
        $cssPath = plugin_dir_path(__FILE__) . 'assets/css/accordion.css';
        $currentModTime = filemtime($cssPath);

        if (isset($cached['mtime']) && $cached['mtime'] === $currentModTime) {
            return $cached['defaults']; // Cache hit
        }
    }

    // Parse CSS file
    $css = file_get_contents($cssPath);
    $defaults = parse_css_defaults($css);

    // Add behavioral defaults (can't be CSS variables)
    $defaults['showIcon'] = true;
    $defaults['iconPosition'] = 'right';
    $defaults['iconTypeClosed'] = '▾';
    $defaults['iconTypeOpen'] = 'none';
    $defaults['iconRotation'] = 180;
    $defaults['initiallyOpen'] = false;
    $defaults['headingLevel'] = 'none';
    $defaults['useHeadingStyles'] = false;

    // Add null inheritance markers
    $defaults['iconColor'] = null;
    $defaults['iconSize'] = null;
    $defaults['hoverTitleColor'] = null;
    $defaults['activeTitleColor'] = null;
    $defaults['activeTitleBackgroundColor'] = null;

    // Cache with file modification time
    set_transient('accordion_parsed_defaults', [
        'mtime' => filemtime($cssPath),
        'defaults' => $defaults
    ], YEAR_IN_SECONDS);

    return $defaults;
}
```

### JavaScript Integration

**PHP Localization:**

```php
function enqueue_accordion_editor_assets() {
    $asset_file = include plugin_dir_path(__FILE__) . 'build/editor.asset.php';

    wp_enqueue_script(
        'accordion-editor',
        plugins_url('build/editor.js', __FILE__),
        $asset_file['dependencies'],
        $asset_file['version']
    );

    // Pass parsed defaults to JavaScript
    $defaults = get_accordion_plugin_defaults();
    wp_localize_script('accordion-editor', 'accordionDefaults', $defaults);
}
```

**JavaScript Usage:**

```javascript
// editor.js
const DEFAULTS = window.accordionDefaults || {};

registerBlockType('custom/accordion', {
    attributes: {
        accordionId: { type: 'string', default: generateId() },
        title: { type: 'string', default: '' },
        currentTheme: { type: 'string', default: '' },

        // All customizable attributes default to null
        titleColor: { type: 'string', default: null },
        titleFontSize: { type: 'number', default: null },
        // ...
    },

    edit: ({ attributes, setAttributes }) => {
        // Resolve effective values using cascade
        const effectiveValues = resolveEffectiveValues(attributes, DEFAULTS);

        return (
            <ColorPicker
                label="Title Color"
                value={effectiveValues.titleColor} // Shows result of cascade
                onChange={(color) => setAttributes({ titleColor: color })}
            />
        );
    },
});
```

### Maintenance Workflow

**To change a default value:**

1. Edit `accordion.css`:
   ```css
   :root {
     --accordion-default-title-padding-top: 16px; /* was 12px */
   }
   ```

2. Save file.

3. Done! Everything updates automatically:
   - ✅ Frontend rendering (CSS variables)
   - ✅ PHP theme generation (parses CSS, cache invalidates)
   - ✅ JavaScript editor (gets from PHP on next load)

**No need to:**
- Update PHP constants
- Update JavaScript files
- Rebuild assets
- Clear caches manually (automatic via filemtime)

---

## 4. Theme Data Structure

### What Attributes Belong in a Theme

A theme contains ALL customizable styling and behavior attributes. In the accordion system, this includes 33+ attributes across multiple categories.

**Naming Conventions (v6.0):**
- Use `title` prefix (not "header"): `titleColor`, `titleBackgroundColor`
- Use `accordion` prefix for wrapper: `accordionBorderWidth`, `accordionBorderColor`
- Use nested objects: `titlePadding.top`, `accordionBorderRadius.topLeft`

**Complete List:**

**Colors:**
- `titleColor`
- `titleBackgroundColor`
- `hoverTitleColor` (inherits from titleColor if null)
- `activeTitleColor` (inherits from titleColor if null)
- `activeTitleBackgroundColor` (inherits from titleBackgroundColor if null)
- `contentBackgroundColor`

**Accordion Wrapper Border:**
- `accordionBorderWidth`
- `accordionBorderStyle`
- `accordionBorderColor`
- `accordionBorderRadius` (object):
  - `topLeft`
  - `topRight`
  - `bottomRight`
  - `bottomLeft`
- `accordionShadow`
- `accordionMarginBottom`

**Divider Border (title/content separator):**
- `dividerBorderWidth`
- `dividerBorderStyle`
- `dividerBorderColor`

**Title Formatting:**
- `titleFontSize`
- `titleFontWeight`
- `titleFontStyle`
- `titleTextTransform`
- `titleTextDecoration`
- `titleAlignment`
- `titlePadding` (object):
  - `top`
  - `right`
  - `bottom`
  - `left`

**Content Padding:**
- `contentPadding` (object):
  - `top`
  - `right`
  - `bottom`
  - `left`

**Icon Configuration:**
- `showIcon`
- `iconColor` (inherits from titleColor if null)
- `iconSize` (inherits from titleFontSize if null)
- `iconPosition` ('left', 'right', 'extreme-right')
- `iconTypeClosed` (default: '▾')
- `iconTypeOpen` (default: 'none')
- `iconRotation` (default: 180)

**Behavioral:**
- `initiallyOpen` (boolean)
- `headingLevel` ('none', 'h1'-'h6')
- `useHeadingStyles` (boolean)

### Theme Object Structure

```javascript
{
  theme_id: "dark-mode",
  theme_name: "Dark Mode",
  version: 1, // Increments on update for cache invalidation

  // Colors
  titleColor: "#ffffff",
  titleBackgroundColor: "#222222",
  hoverTitleColor: "#cccccc",
  activeTitleColor: "#ffffff",
  activeTitleBackgroundColor: "#111111",
  contentBackgroundColor: "#2a2a2a",

  // Wrapper
  accordionBorderWidth: 1,
  accordionBorderStyle: "solid",
  accordionBorderColor: "#444444",
  accordionBorderRadius: {
    topLeft: 4,
    topRight: 4,
    bottomRight: 4,
    bottomLeft: 4
  },
  accordionShadow: "0 2px 4px rgba(0,0,0,0.3)",
  accordionMarginBottom: 16,

  // Divider
  dividerBorderWidth: 1,
  dividerBorderStyle: "solid",
  dividerBorderColor: "#444444",

  // Title formatting
  titleFontSize: 18,
  titleFontWeight: "600",
  titleFontStyle: "normal",
  titleTextTransform: "none",
  titleTextDecoration: "none",
  titleAlignment: "left",
  titlePadding: {
    top: 12,
    right: 12,
    bottom: 12,
    left: 12
  },

  // Content
  contentPadding: {
    top: 16,
    right: 16,
    bottom: 16,
    left: 16
  },

  // Icon
  showIcon: true,
  iconColor: null, // inherits from titleColor
  iconSize: null, // inherits from titleFontSize
  iconPosition: "right",
  iconTypeClosed: "▾",
  iconTypeOpen: "none",
  iconRotation: 180,

  // Behavioral
  initiallyOpen: false,
  headingLevel: "none",
  useHeadingStyles: false
}
```

### How Themes Are Stored

**Storage:** WordPress options table (`wp_options`)

**Option Name:** `accordion_themes`

**Format:** PHP serialized array (keyed by theme_id)

```php
array(
  'dark-mode' => [ /* theme object */ ],
  'light-mode' => [ /* theme object */ ],
  'custom-abc123' => [ /* theme object */ ],
)
```

**Access:**
```php
$themes = get_option('accordion_themes', []);
$darkMode = $themes['dark-mode'] ?? null;
```

**Note:** The "default" theme is NOT stored in the database in v6.0. It exists only as CSS variables in `accordion.css`.

---

## 5. Customization vs Theme Workflow

This section describes the complete user workflow from selecting a theme to saving customizations.

### User Starts with a Theme (or Default)

**Initial State:** Every accordion block starts with no theme selected (uses default from accordion.css) or a selected custom theme.

```javascript
// No theme selected - uses default
{ currentTheme: '', isCustomized: false }

// Or custom theme selected
{ currentTheme: 'dark-mode', isCustomized: false }
```

At this point, the block has NO inline customization attributes. Everything comes from the theme or default (Layer 1 or 2 in cascade).

### User Modifies Settings → Becomes "Customized"

**Action:** User changes title color from default to red.

**What Happens:**

1. Sidebar color picker is clicked
2. New color value is saved to block attributes
3. System detects attribute differs from theme/default
4. Block's `isCustomized` flag automatically becomes `true`
5. Dropdown shows "[Theme Name] (custom)" or "Default (custom)"

**Resulting State:**

```javascript
{
  currentTheme: "dark-mode", // or '' for default
  baseTheme: "dark-mode",
  isCustomized: true,
  titleColor: "#ff0000" // ← NEW customization
}
```

**Cascade in Action:** The `titleColor` now comes from Layer 3 (block attribute), overriding the theme's or default's value.

**Frontend Output:**
```html
<div class="wp-block-custom-accordion accordion-theme-dark-mode"
     style="--custom-title-color: #ff0000;">
```

### User Can Switch Back to Clean Theme (Customizations Cached)

**Action:** User selects clean theme (without "(custom)") from dropdown.

**What Happens:**

1. **Before switching:** Customizations are saved to the **Customization Cache** (in-memory, session-only)
2. Block's customization attributes are cleared
3. Block switches to clean theme
4. `isCustomized` becomes `false`

**Cache State:**

```javascript
customizationCache = {
  "dark-mode": {
    titleColor: "#ff0000",
    isCustomized: true,
    baseTheme: "dark-mode"
  }
}
```

**Resulting Block Attributes:**

```javascript
{
  currentTheme: "dark-mode",
  baseTheme: "dark-mode",
  isCustomized: false
  // titleColor removed
}
```

**Key Point:** Customizations are NOT lost—they're cached temporarily, allowing comparison.

### User Can Switch Back to Customized Version

**Action:** User selects "Dark Mode (custom)" from dropdown.

**What Happens:**

1. System retrieves cached customizations
2. Cached attributes are restored to block
3. `isCustomized` becomes `true`

**Benefit:** Users can freely compare clean theme vs customized version without losing work.

### User Can Save Customizations as New Theme

**Action:** User clicks "Save as new theme" and enters name "My Red Theme".

**What Happens:**

1. **Collect Effective Values**: System gathers ALL attribute values using the 3-tier cascade
   - For customized attributes: uses block's inline value
   - For non-customized attributes: uses theme's value or default
   - Result: Complete snapshot with explicit values

2. **Generate Theme ID**: Server creates unique identifier (e.g., "custom-abc123")

3. **Save to Database**: New theme stored in `accordion_themes` option

4. **Increment Version**: Version counter starts at 1 for new themes

5. **Switch Block to New Theme**:
   ```javascript
   {
     currentTheme: "custom-abc123",
     baseTheme: "custom-abc123",
     isCustomized: false
     // ALL customization attributes cleared
   }
   ```

6. **Clear Customizations**: All inline attributes removed (they're now in the theme)

7. **Invalidate Cache**: Delete transient for this theme if it existed

**Result:**
- New reusable theme created
- Block now uses new theme (no customizations)
- Other blocks can now select "My Red Theme"

### User Can Update Existing Theme

**Action:** User is on "My Red Theme (custom)" and clicks "Update theme".

**What Happens:**

1. **Collect Effective Values**: All current values (customizations + theme values)

2. **Update Database**: Theme in database is overwritten with new values

3. **Increment Version**: Version counter increments (e.g., 1 → 2)

4. **Invalidate Cache**: Delete transient `accordion_theme_{theme_id}_css`

5. **Clear Customizations on This Block**:
   ```javascript
   {
     currentTheme: "custom-abc123",
     isCustomized: false
     // Customization attributes cleared
   }
   ```

6. **Broadcast Update**: System notifies ALL accordion blocks site-wide

7. **Update Other Blocks**: All blocks using this theme automatically reflect changes on next page load

**Critical Difference from "Save as New":**
- Updates MODIFY existing theme (affects all blocks using it)
- Save as New CREATES new theme (doesn't affect existing theme)

---

## 6. Theme Operations

### Create New Theme

**Purpose:** Save current effective values as a new, reusable theme.

**Flow:**

1. Collect all effective values via cascade resolution
2. Generate unique theme ID
3. Save to database (`accordion_themes` option)
4. Set version = 1
5. Switch block to new theme, clear customizations
6. Broadcast event to refresh theme lists

**Result:** New theme available site-wide, original theme unchanged.

### Update Theme

**Purpose:** Overwrite existing theme with current effective values.

**Flow:**

1. Collect all effective values
2. Merge into existing theme in database
3. Increment version (for cache invalidation)
4. Save to database
5. Delete cached theme CSS transient
6. Clear customizations on this block
7. Broadcast update event

**Effect:** ALL blocks using this theme update automatically.

### Delete Theme

**Purpose:** Remove theme from system.

**Flow:**

1. Verify theme is not default (cannot delete default)
2. Remove from database
3. Delete cached theme CSS transient
4. Broadcast deletion event
5. Blocks using deleted theme fallback to default

**Safety:** Blocks automatically detect missing theme and fallback gracefully.

### Rename Theme

**Purpose:** Change theme's display name.

**Flow:**

1. Load theme from database
2. Update only `theme_name` field
3. Save to database
4. Broadcast update event

**Non-Destructive:** No visual changes, only affects dropdown display.

### Switch Theme

**Purpose:** Change which theme a block uses.

**Flow:**

1. If currently customized: Save customizations to cache
2. Clear all customization attributes
3. Update `currentTheme` to new theme ID
4. Set `isCustomized = false` (or true if restoring cached version)
5. Block re-renders with new theme values

---

## 7. The Customization Cache

### What It Is

The Customization Cache is a **session-only, in-memory storage** mechanism that preserves customizations when users switch between themes to compare them.

**Technical Nature:**
- JavaScript object stored in React component state
- Lives only during editing session
- NOT saved to database
- Discarded when editor is closed or post is saved

**Structure:**

```javascript
customizationCache = {
  "dark-mode": {
    titleColor: "#ff0000",
    titleFontSize: 20,
    isCustomized: true,
    baseTheme: "dark-mode"
  },
  "": { // default theme customizations
    titleBackgroundColor: "#f0f0f0",
    isCustomized: true,
    baseTheme: ""
  }
}
```

### Why It Exists

**Problem Without Cache:**
- User customizes theme → wants to compare with another theme
- Switching themes → customizations lost forever
- Can't easily A/B test different themes with same customizations

**Solution With Cache:**
- Switching away: Customizations saved to cache
- Switching back: Customizations restored from cache
- Non-destructive comparison enabled

### When Cache Is Cleared

**Automatic Clearing:**
1. Post save/publish (editing session ends)
2. Browser refresh (page reload)
3. Editor close (navigate away)
4. Theme update (customizations committed to theme)
5. Theme creation (customizations become theme)

**Warning System:**
If user attempts to save with customizations in cache but clean theme selected, warn that cached customizations will be lost.

---

## 8. Boolean Toggle Behavior

### Booleans Follow the 3-Tier Cascade

Boolean attributes (true/false values) work **EXACTLY** like colors, borders, and other attribute types. They are NOT special cases.

**Example Booleans:**
- `showIcon`
- `initiallyOpen`
- `useHeadingStyles`

### Resolution Example

```javascript
// Block has no showIcon defined
Block Attribute: showIcon = undefined
Theme Value: showIcon = true
Default Value: showIcon = true

Effective Value: true (Layer 2 wins)

// User toggles it off
Block Attribute: showIcon = false
Theme Value: showIcon = true
Default Value: showIcon = true

Effective Value: false (Layer 3 wins)
```

### Sidebar Controls Must Read Effective Values

**WRONG:**
```javascript
<ToggleControl
  checked={attributes.showIcon} // undefined shows as OFF
  onChange={(value) => setAttributes({ showIcon: value })}
/>
```

**CORRECT:**
```javascript
<ToggleControl
  checked={effectiveValues.showIcon} // shows actual state
  onChange={(value) => setAttributes({ showIcon: value })}
/>
```

---

## 9. Attribute Types

Accordion block attributes are divided into two categories.

### Customization Attributes (Themeable)

**Definition:** Attributes that define styling and behavior, shared across blocks when using themes.

**Characteristics:**
- Stored in themes (database)
- Can be customized per-block (inline)
- Follow 3-tier cascade
- Cleared when switching themes
- Subject to customization detection

**List:** See section 4 (Theme Data Structure) for complete list.

### Non-Customization Attributes (Always Per-Block)

**Definition:** Attributes that define block-specific content and state, never shared via themes.

**Characteristics:**
- Always stored per-block
- Never stored in themes
- Not subject to cascade
- Never cleared when switching themes

**List:**

**Content:**
- `title`: Accordion's title text
- `accordionId`: Unique identifier for ARIA

**Behavior State:**
- `isOpen`: Whether accordion starts open (Note: `initiallyOpen` is themeable, `isOpen` is runtime state)
- `isOpenInEditor`: Whether accordion is expanded in editor UI

**Theme Metadata:**
- `currentTheme`: Which theme is selected
- `baseTheme`: Original theme before customization
- `isCustomized`: Flag indicating customizations exist
- `customizationCache`: Session storage for theme comparison

---

## 10. Editor vs Frontend

### Editor: Real-Time Cascade Resolution

**Environment:** WordPress Gutenberg block editor

**Cascade Resolution:**
- **When:** Every render cycle
- **How:** JavaScript computes effective values via 3-tier cascade
- **Data Sources:**
  - Layer 3: Block attributes (React component props)
  - Layer 2: Selected theme (from `window.accordionThemes`)
  - Layer 1: Default values (from `window.accordionDefaults`)

**Process:**

```javascript
const effectiveValues = {};

Object.keys(ATTRIBUTE_CONFIG).forEach(attr => {
  // Layer 3: Block customization
  if (attributes[attr] !== null && attributes[attr] !== undefined) {
    effectiveValues[attr] = attributes[attr];
    return;
  }

  // Layer 2: Theme value
  if (currentTheme && themes[currentTheme]?.[attr] !== undefined) {
    effectiveValues[attr] = themes[currentTheme][attr];
    return;
  }

  // Layer 1: Default
  effectiveValues[attr] = DEFAULTS[attr];
});
```

**Sidebar Display:**
Sidebar controls display effective values, not raw attributes.

### Frontend: CSS Cascade (No JavaScript Needed)

**Environment:** Public-facing website (PHP rendering)

**No JavaScript Cascade:** Values are resolved via CSS custom properties.

**HTML Output:**

**Non-Customized Block:**
```html
<div class="wp-block-custom-accordion accordion-theme-dark-mode">
  <!-- CSS class provides all styling -->
</div>
```

**Customized Block:**
```html
<div class="wp-block-custom-accordion accordion-theme-dark-mode"
     style="--custom-title-color: #ff0000;">
  <!-- CSS variables override theme -->
</div>
```

**CSS Handles Cascade:**

```css
/* Layer 1: Default (accordion.css) */
:root {
  --accordion-default-title-color: #333333;
}

/* Layer 2: Theme (generated in <head>) */
.accordion-theme-dark-mode .accordion-title {
  color: var(--custom-title-color, #ffffff);
  /*     ↑ Layer 3 override   ↑ Layer 2 value */
}

/* Layer 3: Inline (on element) */
/* Automatically wins via CSS specificity */
```

**Performance:** No JavaScript needed for styling, pure CSS cascade.

---

## 12. Database Schema

### Where Themes Are Stored

**Table:** `wp_options`

**Option Names:**
- Accordion themes: `accordion_themes`
- Tabs themes: `tabs_themes`

**Format:** PHP serialized array (per block type)

**Accordion Example:**
```php
// Option name: 'accordion_themes'
array(
  'dark-mode' => array(
    'theme_id' => 'dark-mode',
    'theme_name' => 'Dark Mode',
    'blockType' => 'accordion',
    'version' => 3,
    'titleColor' => '#ffffff',
    // ... all accordion attributes
  ),
  'light-mode' => array(/* ... */),
)
```

**Tabs Example:**
```php
// Option name: 'tabs_themes'
array(
  'modern-horizontal' => array(
    'theme_id' => 'modern-horizontal',
    'theme_name' => 'Modern Horizontal',
    'blockType' => 'tabs',
    'version' => 1,
    'titleColor' => '#ffffff',
    'orientation' => 'horizontal',
    // ... all tabs attributes
  ),
)
```

### Access Patterns

**Load All Themes:**
```php
$themes = get_option('accordion_themes', []);
```

**Create Theme:**
```php
$themes = get_option('accordion_themes', []);
$themes['new-id'] = $themeData;
update_option('accordion_themes', $themes);
```

**Update Theme:**
```php
$themes = get_option('accordion_themes', []);
$themes['existing-id']['titleColor'] = '#ff0000';
$themes['existing-id']['version']++; // Increment version
update_option('accordion_themes', $themes);

// Invalidate CSS cache
delete_transient("accordion_theme_existing-id_css");
```

**Delete Theme:**
```php
$themes = get_option('accordion_themes', []);
unset($themes['theme-id']);
update_option('accordion_themes', $themes);
delete_transient("accordion_theme_theme-id_css");
```

### Caching Strategy

**CSS Defaults Cache:**
- Transient: `accordion_parsed_defaults`
- Includes: file modification time
- Invalidates: when CSS file changes

**Theme CSS Cache:**
- Transient: `accordion_theme_{theme_id}_css`
- Includes: theme version
- Invalidates: when theme version increments

**Performance:**
- CSS parsing: ~50ms uncached, ~5ms cached
- Theme CSS generation: Once per version
- Only used themes output on page

---

---

## 13. Shared Implementation Structure

### Philosophy: Build Shared from the Beginning

**IMPORTANT:** When implementing this architecture, the shared infrastructure must be created FIRST, not extracted later.

### Implementation Order

**Phase 1: Create Shared Infrastructure** (Do this FIRST)

1. Create `src/shared/` directory structure
2. Implement shared theme system modules (`theme-manager.js`, `cascade-resolver.js`, etc.)
3. Define shared attributes (`color-attributes.js`, `typography-attributes.js`, etc.)
4. Build shared UI components (`ThemeSelector.js`, `ColorPanel.js`, etc.)
5. Create shared utilities (`css-parser.js`, `id-generator.js`, etc.)

**Phase 2: Implement Accordion Block** (Use shared modules from start)

1. Create `blocks/accordion/` structure
2. Import shared attributes + define accordion-specific attributes
3. Use shared UI components in `edit.js`
4. Use shared theme system for all theme operations
5. Parse `accordion.css` using shared CSS parser

**Phase 3: Implement Tabs Block** (Reuse everything)

1. Create `blocks/tabs/` structure
2. Import shared attributes + define tabs-specific attributes
3. Use same shared UI components
4. Use same shared theme system
5. Parse `tabs.css` using same shared CSS parser

### Key Functions That Must Be Shared

**Theme Operations** (`src/shared/theme-system/theme-manager.js`):
```javascript
export function createTheme(blockType, themeName, values)
export function updateTheme(blockType, themeName, values)
export function deleteTheme(blockType, themeName)
export function renameTheme(blockType, oldName, newName)
export function getAllThemes(blockType)
```

**Note:** No `convertTheme()` function - accordion and tabs themes are not convertible.

**Cascade Resolution** (`src/shared/theme-system/cascade-resolver.js`):
```javascript
export function getEffectiveValue(attribute, blockAttrs, theme, defaults)
export function getAllEffectiveValues(blockAttrs, theme, defaults)
export function detectCustomizations(blockAttrs, theme, defaults)
```

**CSS Parsing** (`src/shared/utils/css-parser.js`):
```javascript
export function parseCSSDefaults(cssContent)
export function extractCSSVariables(cssContent, prefix)
export function convertCSSValueToJS(cssValue, type)
```

### What NOT to Do

❌ **Don't build accordion first, then extract shared code later**
❌ **Don't duplicate theme logic between blocks**
❌ **Don't hardcode defaults in JavaScript**
❌ **Don't create separate theme systems**

✅ **Do build shared infrastructure first**
✅ **Do import shared modules from the start**
✅ **Do use CSS files as single source of truth**
✅ **Do use same theme system for both blocks**

### Benefits of This Approach

1. **No Refactoring Required**: Shared code from day one
2. **Consistency Guaranteed**: Same logic for both blocks
3. **Easier Testing**: Test shared modules once
4. **Future-Proof**: New blocks plug into existing system
5. **Maintainability**: One place to fix bugs

---

## Conclusion

The Shared Theme System Architecture v3.0 provides a robust, scalable, and maintainable framework for managing block styling and behavior across Accordion, Tabs, and future collapsible blocks.

**Key Principles:**

1. **Shared Architecture** - One theme system, multiple block types
2. **CSS as Single Source of Truth** - All defaults in CSS files, change once and everything updates
3. **3-Tier Cascade** - Default (CSS) → Themes (database) → Per-block (inline)
4. **Block-Type Specific Themes** - Themes stored separately but share same system logic
5. **Complete Theme Snapshots** - Every theme has all attributes defined
6. **Null Inheritance** - Some attributes inherit from others when not explicitly set
7. **Two-Level CSS Variables** - `--custom-*` for overrides, `--[block]-default-*` for fallbacks
8. **Version-Based Caching** - Efficient cache invalidation via version increments

**Document Version:** 3.0 (Shared Architecture + v6.0 CSS System)
**Last Updated:** 2025-10-12
**Aligned With:** TABS-ACCORDION-INTEGRATION.md v2.0, FRONTEND-RENDERING.md v6.0
**Authored By:** Claude Code (Anthropic)
