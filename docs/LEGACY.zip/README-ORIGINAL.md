# WordPress Gutenberg Blocks Plugin - Master Implementation Guide


---

## Table of Contents

1. [Project Overview](#project-overview)
2. [Architecture Summary](#architecture-summary)
3. [WordPress Libraries Integration](#wordpress-libraries-integration)
4. [Build System & Dependencies](#build-system--dependencies)
5. [Implementation Strategy](#implementation-strategy)
6. [Phase-by-Phase Implementation](#phase-by-phase-implementation)
7. [AI Agent System](#ai-agent-system)
8. [Critical Rules & Constraints](#critical-rules--constraints)
9. [Testing & Validation](#testing--validation)
10. [Risk Management](#risk-management)

---

## Project Overview

### What We're Building

Three interconnected WordPress Gutenberg blocks with a unified architecture:

1. **Accordion Block** - Collapsible content sections with expand/collapse behavior
2. **Tabs Block** - Horizontal/vertical tabbed content with responsive accordion fallback
3. **Table of Contents (TOC) Block** - Automatic heading detection and navigation

### Core Features

- **Unified Theme System** - Shared customization themes across all blocks
- **3-Tier Value Cascade** - CSS defaults → Theme → Block customizations
- **CSS as Single Source of Truth** - Designer-friendly workflow
- **Complete ARIA Compliance** - W3C accessibility standards
- **Modern Build System** - @wordpress/scripts with hot reload

### Code Estimates

| Component | Lines of Code | Status |
|-----------|---------------|---------|
| **Phase 0**: Build System | 270 | Ready |
| **Phase 1**: Shared Infrastructure | 2,520 | Planned |
| **Phase 2**: Accordion Block | 1,600 | Planned |
| **Phase 3**: Tabs Block | 1,800 | Planned |
| **Phase 4**: TOC Block | 1,900 | Planned |
| **Phase 5**: Integration Tests | 200 | Planned |
| **Total** | **8,290 LOC** | 16.6% reduction via WP libraries |

---

## Architecture Summary

### The 3-Tier Value Cascade

**Priority Order** (highest to lowest):
1. **Block Customizations** - Per-block inline overrides (highest priority)
2. **Theme Values** - Site-wide reusable templates
3. **CSS Defaults** - Fallback values from CSS `:root` variables

**Rule**: First defined value wins. No merging.

**Example**:
```javascript
// Block has titleColor customization
attributes.titleColor = '#ff0000'; // Used ✅

// Current theme has titleColor
currentTheme.titleColor = '#00ff00'; // Ignored

// CSS default
:root { --accordion-default-title-color: '#333333'; } // Ignored
```

### Complete Snapshot Themes

- When saving a theme, **ALL attributes** are stored with explicit values
- No `null` values in saved themes (themes are complete snapshots)
- Updating a theme propagates changes to all blocks using it
- Themes are portable and self-contained

### Separate Storage Per Block Type

- **Accordion themes**: `wp_options['accordion_themes']`
- **Tabs themes**: `wp_options['tabs_themes']`
- **TOC themes**: `wp_options['toc_themes']`

**Critical**: No cross-contamination between block types

### CSS as Single Source of Truth

1. Designer edits CSS file with `:root` variables
2. Webpack loader parses CSS at build time
3. PHP arrays auto-generated in `php/css-defaults/`
4. WordPress exposes via `wp_localize_script`
5. JavaScript receives via `window.[blockType]Defaults`

**Benefits**:
- No hardcoded defaults in JavaScript
- Single file to update for design changes
- Version control tracks default changes

---

## WordPress Libraries Integration

### Summary of Integration Decisions

| Library | Usage | LOC Impact | Status |
|---------|-------|------------|--------|
| **@wordpress/scripts** | Build system, webpack, hot reload | +270 (Phase 0) | ✅ Integrated |
| **@wordpress/data** | Theme management store only | -100 (state mgmt) | ✅ Integrated |
| **@wordpress/components** | UI panels (60-70%) | -540 (UI code) | ✅ Integrated |
| **@wordpress/a11y** | Screen reader announcements | -30 (ARIA code) | ✅ Integrated |
| **@wordpress/rich-text** | NOT USED | N/A | ❌ Avoided |

**Net Savings**: 980 LOC (10.6% reduction) + improved code quality

---

### 1. @wordpress/scripts (Build System)

**Used For**:
- Webpack configuration with multiple entry points
- Babel transpilation (JSX → ES5)
- ESLint (WordPress coding standards)
- CSS extraction and minification
- Hot module reload in development

**Custom Extensions**:
- CSS variable parser loader (`:root` → PHP arrays)
- Multiple entry points (accordion, tabs, toc, shared)
- Webpack aliases for easy imports

**Configuration**: See Phase 0.3 for `webpack.config.js` setup

---

### 2. @wordpress/data (State Management)

**✅ Used For** (Selective Integration):
- Theme CRUD operations (create, update, delete, rename)
- Theme storage and retrieval via REST API
- Automatic UI updates on theme changes
- Event isolation across block types

**❌ NOT Used For**:
- Cascade resolution (kept 100% custom for performance)
- Block attribute management (editor handles this)
- Editor UI state (WordPress core handles this)

**Store Name**: `'gutenberg-blocks/themes'`

**Store State Structure**:
```javascript
{
  accordionThemes: { /* theme objects */ },
  tabsThemes: { /* theme objects */ },
  tocThemes: { /* theme objects */ },
  isLoading: false,
  error: null
}
```

**Usage in Blocks**:
```javascript
import { useSelect, useDispatch } from '@wordpress/data';

// In edit.js
const themes = useSelect((select) =>
  select('gutenberg-blocks/themes').getThemes('accordion')
);

const { createTheme, updateTheme } = useDispatch('gutenberg-blocks/themes');

// Create theme
await createTheme('accordion', 'My Theme', effectiveValues);
```

**What This Replaces**:
- ❌ `theme-events.js` (~100 LOC) - Store subscriptions replace custom events
- ❌ Manual state management in theme-manager.js (~200 LOC) - Redux via store
- ❌ Custom event dispatching (~50 LOC) - Store handles updates automatically

---

### 3. @wordpress/components (UI Panels)

**Replaces Custom Components**:
- `ColorPalette` → custom color picker (~100 LOC saved)
- `FontSizePicker` → custom typography controls (~120 LOC saved)
- `RangeControl` → custom sliders (~80 LOC saved)
- `SelectControl` → custom dropdowns (~60 LOC saved)
- `ToggleControl` → custom toggles (~40 LOC saved)
- `PanelBody` → inspector panel structure (~60 LOC saved)

**Custom Wrapper Pattern**:
```javascript
// shared/src/components/CustomizableControl.js
function CustomizableControl({ value, effectiveValue, onChange, ...props }) {
  const isCustomized = value !== null;

  return (
    <div className="customizable-control">
      <RangeControl
        value={effectiveValue} // Show resolved value
        onChange={onChange}
        {...props}
      />
      {isCustomized && <span className="customization-badge">*</span>}
    </div>
  );
}
```

**Kept Custom**:
- `ThemeSelector` (~150 LOC) - Complex theme dropdown with create/update/delete
- `CustomizationWarning` (~80 LOC) - Block-specific workflow logic

---

### 4. @wordpress/a11y (Accessibility)

**Used For** (Minimal):
```javascript
import { speak } from '@wordpress/a11y';

// Announce state changes to screen readers
speak('Accordion expanded', 'polite');
speak('Theme updated successfully', 'assertive');
```

**NOT Used For**:
- ❌ ARIA attribute management (custom sync with visual state required)
- ❌ Keyboard navigation (block-specific handlers needed)
- ❌ Focus management (requirement: focus stays on button)
- ❌ ID generation (custom 4-digit format required)

**Savings**: ~30 LOC (8% of ARIA module)

---

## Build System & Dependencies

### Environment Requirements

- **WordPress**: 6.4+ (tested on 6.4, 6.5, 6.6)
- **Node.js**: 18.x or 20.x LTS
- **npm**: 8.0+
- **PHP**: 7.4+ (WordPress requirement)

### Dependencies

**Production** (Required at Runtime):
```json
{
  "@wordpress/components": "^27.0.0",
  "@wordpress/data": "^9.0.0",
  "@wordpress/a11y": "^4.0.0",
  "@wordpress/api-fetch": "^7.0.0",
  "@wordpress/element": "^5.0.0",
  "@wordpress/i18n": "^5.0.0",
  "@wordpress/compose": "^6.0.0",
  "@wordpress/block-editor": "^12.0.0",
  "@wordpress/blocks": "^12.0.0"
}
```

**Development** (Build Time Only):
```json
{
  "@wordpress/scripts": "^27.0.0"
}
```

### Build Commands

**Development Mode**:
```bash
npm start

# Features:
# - Hot module reload (<2s for changes)
# - Fast refresh for React components
# - Source maps for debugging
# - CSS variables auto-parsed to PHP on change
# - Development server on http://localhost:8887
```

**Production Build**:
```bash
npm run build

# Outputs:
# - blocks/accordion/build/index.js (minified)
# - blocks/tabs/build/index.js (minified)
# - blocks/toc/build/index.js (minified)
# - shared/build/index.js (minified)
# - php/css-defaults/*.php (auto-generated)
# - All CSS extracted and optimized
```

**Quality Checks**:
```bash
npm run lint:js --fix   # Fix JS issues (WordPress standards)
npm run lint:css --fix  # Fix CSS issues
npm run format          # Auto-format all code
npm run test:unit       # Run unit tests (Phase 5)
```

### Directory Structure

```
project/
├── blocks/
│   ├── accordion/
│   │   ├── src/
│   │   │   ├── index.js (entry point)
│   │   │   ├── edit.js
│   │   │   ├── save.js
│   │   │   └── style.css
│   │   ├── build/ (generated)
│   │   └── block.json
│   ├── tabs/ (same structure)
│   └── toc/ (same structure)
├── shared/
│   ├── src/
│   │   ├── index.js
│   │   ├── theme-system/
│   │   │   ├── cascade-resolver.js (CRITICAL - 100% custom)
│   │   │   └── theme-manager.js (thin wrapper over store)
│   │   ├── data/
│   │   │   ├── store.js (@wordpress/data store)
│   │   │   └── index.js
│   │   ├── components/
│   │   │   ├── ThemeSelector.js
│   │   │   ├── ColorPanel.js (uses @wordpress/components)
│   │   │   └── TypographyPanel.js
│   │   ├── attributes/
│   │   │   ├── color-attributes.js
│   │   │   └── typography-attributes.js
│   │   └── utils/
│   │       ├── id-generator.js
│   │       ├── aria-helpers.js
│   │       └── keyboard-nav.js
│   └── build/ (generated)
├── assets/
│   └── css/
│       ├── accordion.css (:root variables)
│       ├── tabs.css
│       └── toc.css
├── php/
│   ├── css-defaults/ (generated PHP arrays)
│   ├── theme-storage.php
│   └── theme-rest-api.php
├── build-tools/
│   └── css-vars-parser-loader.js (custom webpack loader)
├── webpack.config.js
└── package.json
```

---

## Implementation Strategy

### Module Dependency Graph

```
Phase 0: Build System
└── npm dependencies + webpack + CSS parser loader

Phase 1: Shared Infrastructure (MUST complete before blocks)
├── 1.1 CSS Parsing System
├── 1.2 Cascade Resolver (CUSTOM - no WP integration)
├── 1.3a WordPress Data Store (@wordpress/data)
├── 1.3b Theme Storage PHP Backend (REST API)
├── 1.4 Theme Manager (thin wrapper)
├── 1.5 Shared Attributes
├── 1.6 Shared UI Components (@wordpress/components)
├── 1.7 Shared Utilities (ID, ARIA, keyboard, validation)
└── 1.8 Store Usage Examples

Phase 2-4: Block Implementations (Can run in parallel after Phase 1)
├── Uses shared modules
├── Uses @wordpress/data (useSelect/useDispatch)
├── Uses @wordpress/components for UI
└── Uses @wordpress/a11y for announcements

Phase 5: Integration & Testing
└── Cross-block validation
```

### LOC Breakdown by Phase

| Phase | Original | With WP Libs | Savings | % Saved |
|-------|----------|--------------|---------|---------|
| Phase 0 | 0 | 270 | +270 | New |
| Phase 1 | 3,270 | 2,520 | 750 | 23% |
| Phase 2 | 1,800 | 1,600 | 200 | 11% |
| Phase 3 | 2,000 | 1,800 | 200 | 10% |
| Phase 4 | 2,200 | 1,900 | 300 | 14% |
| Phase 5 | N/A | 200 | +200 | New |
| **Total** | **9,270** | **8,290** | **980** | **10.6%** |

**Key Savings Sources**:
- Removed `theme-events.js`: 100 LOC (store subscriptions replace)
- Reduced `theme-manager.js`: 200 LOC (thin wrapper vs full implementation)
- UI components: 540 LOC (@wordpress/components)
- ARIA announcements: 30 LOC (@wordpress/a11y)
- State management: 110 LOC (Redux via @wordpress/data)

---

## Phase-by-Phase Implementation

### PHASE 0: Build System Setup (REQUIRED FIRST)


**LOC**: ~270 lines (configuration files)
**Agent**: Strategy Agent

#### 0.1 Install Dependencies

```bash
npm init -y

# Install WordPress build tooling
npm install --save-dev @wordpress/scripts@^27.0.0

# Install WordPress runtime dependencies
npm install @wordpress/data@^9.0.0 \
            @wordpress/api-fetch@^7.0.0 \
            @wordpress/components@^27.0.0 \
            @wordpress/element@^5.0.0 \
            @wordpress/i18n@^5.0.0 \
            @wordpress/a11y@^4.0.0 \
            @wordpress/compose@^6.0.0 \
            @wordpress/block-editor@^12.0.0 \
            @wordpress/blocks@^12.0.0
```

**Checklist**:
- [ ] `npm install` completes without errors
- [ ] No version conflicts
- [ ] Node 18.x or 20.x verified

---

#### 0.2 Configure package.json (~50 LOC)

```json
{
  "name": "gutenberg-blocks-plugin",
  "version": "1.0.0",
  "scripts": {
    "build": "wp-scripts build",
    "start": "wp-scripts start",
    "lint:js": "wp-scripts lint-js --fix",
    "lint:css": "wp-scripts lint-style --fix",
    "format": "wp-scripts format",
    "test:unit": "wp-scripts test-unit-js"
  }
}
```

---

#### 0.3 Create webpack.config.js (~120 LOC)

```javascript
const defaultConfig = require('@wordpress/scripts/config/webpack.config');
const path = require('path');

module.exports = {
  ...defaultConfig,

  // Multiple entry points
  entry: {
    'blocks/accordion/build/index': './blocks/accordion/src/index.js',
    'blocks/tabs/build/index': './blocks/tabs/src/index.js',
    'blocks/toc/build/index': './blocks/toc/src/index.js',
    'shared/build/index': './shared/src/index.js'
  },

  output: {
    path: path.resolve(__dirname),
    filename: '[name].js'
  },

  module: {
    rules: [
      ...defaultConfig.module.rules,
      {
        // Custom CSS :root variable parser
        test: /\.(css|scss)$/,
        include: /assets\/css/,
        use: [
          ...defaultConfig.module.rules.find(rule =>
            rule.test?.toString().includes('css')
          ).use,
          {
            loader: path.resolve('./build-tools/css-vars-parser-loader.js'),
            options: {
              outputPath: './php/css-defaults/'
            }
          }
        ]
      }
    ]
  },

  // Webpack aliases for easy imports
  resolve: {
    ...defaultConfig.resolve,
    alias: {
      '@shared': path.resolve(__dirname, 'shared/src')
    }
  }
};
```

**Documentation**: FRONTEND-RENDERING.md (CSS Defaults section)

---

#### 0.4 Create CSS Variables Parser Loader (~100 LOC)

**File**: `build-tools/css-vars-parser-loader.js`

**Purpose**: Parse `:root` CSS variables → generate PHP arrays

**Input** (accordion.css):
```css
:root {
  --accordion-default-title-color: #333333;
  --accordion-default-title-font-size: 18px;
  --accordion-default-title-font-weight: 600;
}
```

**Output** (php/css-defaults/accordion.php):
```php
<?php
// Auto-generated from assets/css/accordion.css
// Modified: 2025-10-12 14:30:00

return array(
  'titleColor' => '#333333',
  'titleFontSize' => '18',
  'titleFontWeight' => '600',
);
```

**Implementation**:
```javascript
const fs = require('fs');
const path = require('path');

module.exports = function(source) {
  const callback = this.async();
  const options = this.getOptions();

  // Parse :root { --var-name: value; }
  const rootVars = {};
  const rootRegex = /:root\s*\{([^}]+)\}/g;
  const varRegex = /--([a-z0-9-]+)\s*:\s*([^;]+);/g;

  let rootMatch;
  while ((rootMatch = rootRegex.exec(source)) !== null) {
    let varMatch;
    while ((varMatch = varRegex.exec(rootMatch[1])) !== null) {
      // Convert --accordion-default-title-color → titleColor
      const varName = varMatch[1]
        .replace(/-default-/g, '')
        .replace(/-([a-z])/g, (_, letter) => letter.toUpperCase());
      const varValue = varMatch[2].trim().replace(/px|rem|%/g, '');
      rootVars[varName] = varValue;
    }
  }

  // Generate PHP file
  const blockType = path.basename(this.resourcePath, '.css');
  const phpPath = path.join(options.outputPath, `${blockType}.php`);
  const phpContent = `<?php
// Auto-generated from ${path.relative(process.cwd(), this.resourcePath)}
// Modified: ${new Date().toISOString()}

return array(
${Object.entries(rootVars).map(([key, value]) =>
  `  '${key}' => '${value}',`
).join('\n')}
);
`;

  fs.mkdirSync(path.dirname(phpPath), { recursive: true });
  fs.writeFileSync(phpPath, phpContent);

  callback(null, source);
};
```

**Testing Checklist**:
- [ ] Parses accordion.css correctly
- [ ] Generates valid PHP array file
- [ ] Handles color values (hex, rgb, rgba)
- [ ] Handles numeric values (px, rem, %)
- [ ] Updates on CSS file change
- [ ] Caches with file modification time

---

#### 0.5 Create Directory Structure

```bash
mkdir -p blocks/{accordion,tabs,toc}/src
mkdir -p blocks/{accordion,tabs,toc}/build
mkdir -p shared/src/{theme-system,data,components,attributes,utils}
mkdir -p shared/build
mkdir -p build-tools
mkdir -p php/css-defaults
mkdir -p assets/css
```

---

#### 0.6 Test Build System

```bash
# Test development build
npm start
# Expected: ✓ webpack compiled successfully

# Test production build
npm run build
# Expected: All build/ directories populated

# Verify generated files
ls -la blocks/accordion/build/index.js
ls -la php/css-defaults/accordion.php
```

**Testing Checklist**:
- [ ] `npm start` enables hot reload
- [ ] `npm run build` generates all output files
- [ ] CSS variables parsed to PHP files
- [ ] No webpack errors or warnings
- [ ] Source maps generated for debugging

---

**PHASE 0 CHECKPOINT**

**User Action Required**: Approve build system before Phase 1

**Deliverables**:
- ✅ All dependencies installed
- ✅ webpack.config.js configured
- ✅ CSS parser loader working
- ✅ Directory structure created
- ✅ Build commands functional

---

### PHASE 1: Shared Infrastructure (CRITICAL)

**Duration**: ~6 days (8 tasks)
**LOC**: 2,520 lines
**Agent**: Infrastructure Agent

**MUST complete before ANY block implementation**

---

#### 1.1 CSS Parsing System (~250 LOC)

**Files**:
- `shared/src/utils/css-parser.php` (~150 lines)
- `shared/src/utils/css-parser.js` (~100 lines)

**Requirements**:
- Load generated PHP arrays from `php/css-defaults/`
- Cache values with file modification time
- Expose via `wp_localize_script` as `window.[blockType]Defaults`
- Return `null` for missing variables

**PHP Implementation**:
```php
<?php
// shared/src/utils/css-parser.php

function load_css_defaults($block_type) {
  $file = __DIR__ . "/../../php/css-defaults/{$block_type}.php";

  if (!file_exists($file)) {
    return array();
  }

  $cache_key = "css_defaults_{$block_type}_" . filemtime($file);
  $cached = wp_cache_get($cache_key, 'gutenberg-blocks');

  if ($cached !== false) {
    return $cached;
  }

  $defaults = include $file;
  wp_cache_set($cache_key, $defaults, 'gutenberg-blocks', 3600);

  return $defaults;
}

// Expose to editor
function enqueue_css_defaults() {
  $accordion_defaults = load_css_defaults('accordion');
  wp_localize_script(
    'accordion-block-editor',
    'accordionDefaults',
    $accordion_defaults
  );
}
add_action('enqueue_block_editor_assets', 'enqueue_css_defaults');
```

**JavaScript Helper**:
```javascript
// shared/src/utils/css-parser.js

/**
 * Get CSS default value for an attribute
 * @param {string} blockType - 'accordion', 'tabs', or 'toc'
 * @param {string} attribute - Attribute name (e.g., 'titleColor')
 * @returns {*} Default value or null
 */
export function getCSSDefault(blockType, attribute) {
  const defaults = window[`${blockType}Defaults`];
  return defaults?.[attribute] ?? null;
}

/**
 * Get all CSS defaults for a block type
 * @param {string} blockType
 * @returns {Object} All defaults
 */
export function getAllCSSDefaults(blockType) {
  return window[`${blockType}Defaults`] || {};
}
```

**Testing Checklist**:
- [ ] Loads php/css-defaults/accordion.php correctly
- [ ] Caches values with modification time
- [ ] Returns null for missing variables
- [ ] JavaScript receives correct defaults object
- [ ] Works for all block types (accordion, tabs, toc)

**Documentation**: THEME-SYSTEM-ARCHITECTURE.md (Section: CSS as Single Source of Truth)

---

#### 1.2 Cascade Resolution System (~200 LOC)

**File**: `shared/src/theme-system/cascade-resolver.js`

**⚠️ CRITICAL**: Keep 100% custom - DO NOT integrate with @wordpress/data

**Requirements**:
- Pure function (no side effects, no Redux integration)
- Target performance: <5ms for `getAllEffectiveValues()`
- First defined value wins, no merging
- Works for all attribute types (string, number, object, boolean)

**Implementation**:
```javascript
/**
 * Get effective value for a single attribute via 3-tier cascade
 *
 * Priority order (highest to lowest):
 * 1. Block customization (attributes[name])
 * 2. Theme value (theme[name])
 * 3. CSS default (defaults[name])
 *
 * @param {string} name - Attribute name
 * @param {Object} attributes - Block attributes
 * @param {Object} theme - Current theme object (may be null)
 * @param {Object} defaults - CSS defaults object
 * @returns {*} First defined value in cascade
 */
export function getEffectiveValue(name, attributes, theme, defaults) {
  // Tier 1: Block customization (highest priority)
  if (attributes[name] !== null && attributes[name] !== undefined) {
    return attributes[name];
  }

  // Tier 2: Theme value
  if (theme && theme[name] !== null && theme[name] !== undefined) {
    return theme[name];
  }

  // Tier 3: CSS default (fallback)
  if (defaults && defaults[name] !== null && defaults[name] !== undefined) {
    return defaults[name];
  }

  // No value found in cascade
  return null;
}

/**
 * Get all effective values for all attributes
 *
 * @param {Object} attributes - Block attributes
 * @param {Object} theme - Current theme object
 * @param {Object} defaults - CSS defaults object
 * @returns {Object} Resolved values for all attributes
 */
export function getAllEffectiveValues(attributes, theme, defaults) {
  const effectiveValues = {};

  // Get all possible attribute names from all sources
  const allNames = new Set([
    ...Object.keys(attributes || {}),
    ...Object.keys(theme || {}),
    ...Object.keys(defaults || {})
  ]);

  // Resolve each attribute
  for (const name of allNames) {
    effectiveValues[name] = getEffectiveValue(name, attributes, theme, defaults);
  }

  return effectiveValues;
}

/**
 * Check if an attribute is customized (differs from theme/CSS default)
 *
 * @param {string} name - Attribute name
 * @param {Object} attributes - Block attributes
 * @returns {boolean} True if attribute has non-null value
 */
export function isCustomized(name, attributes) {
  return attributes[name] !== null && attributes[name] !== undefined;
}

/**
 * Get customization source for an attribute
 *
 * @param {string} name - Attribute name
 * @param {Object} attributes - Block attributes
 * @param {Object} theme - Current theme object
 * @param {Object} defaults - CSS defaults object
 * @returns {'block' | 'theme' | 'css' | null}
 */
export function getValueSource(name, attributes, theme, defaults) {
  if (attributes[name] !== null && attributes[name] !== undefined) {
    return 'block';
  }
  if (theme && theme[name] !== null && theme[name] !== undefined) {
    return 'theme';
  }
  if (defaults && defaults[name] !== null && defaults[name] !== undefined) {
    return 'css';
  }
  return null;
}
```

**Testing Checklist**:
- [ ] Block customization overrides theme
- [ ] Theme overrides CSS default
- [ ] CSS default used when others null
- [ ] Works for strings, numbers, objects, booleans
- [ ] Performance: <5ms for getAllEffectiveValues() with 50 attributes
- [ ] No side effects (pure function)
- [ ] Edge case: All values null returns null
- [ ] Edge case: Empty objects handled correctly

**Documentation**: THEME-SYSTEM-ARCHITECTURE.md (Section: 3-Tier Value Cascade)

---

#### 1.3a WordPress Data Store (~170 LOC)

**Files**:
- `shared/src/data/store.js` (~150 lines)
- `shared/src/data/index.js` (~20 lines)

**Requirements**:
- Create Redux store via @wordpress/data
- Store name: `'gutenberg-blocks/themes'`
- Separate state keys per block type (event isolation)
- CRUD actions with apiFetch
- Selectors with blockType filtering

**Implementation**:
```javascript
// shared/src/data/store.js

import { createReduxStore, register } from '@wordpress/data';
import apiFetch from '@wordpress/api-fetch';

const STORE_NAME = 'gutenberg-blocks/themes';

const DEFAULT_STATE = {
  accordionThemes: {},
  tabsThemes: {},
  tocThemes: {},
  isLoading: false,
  error: null
};

const store = createReduxStore(STORE_NAME, {
  reducer(state = DEFAULT_STATE, action) {
    switch (action.type) {
      case 'SET_THEMES':
        return {
          ...state,
          [`${action.blockType}Themes`]: action.themes
        };

      case 'THEME_CREATED':
        return {
          ...state,
          [`${action.blockType}Themes`]: {
            ...state[`${action.blockType}Themes`],
            [action.name]: action.theme
          }
        };

      case 'THEME_UPDATED':
        return {
          ...state,
          [`${action.blockType}Themes`]: {
            ...state[`${action.blockType}Themes`],
            [action.name]: action.theme
          }
        };

      case 'THEME_DELETED':
        const { [action.name]: deleted, ...remaining } =
          state[`${action.blockType}Themes`];
        return {
          ...state,
          [`${action.blockType}Themes`]: remaining
        };

      case 'THEME_RENAMED':
        const { [action.oldName]: renamed, ...rest } =
          state[`${action.blockType}Themes`];
        return {
          ...state,
          [`${action.blockType}Themes`]: {
            ...rest,
            [action.newName]: { ...renamed, name: action.newName }
          }
        };

      case 'SET_LOADING':
        return { ...state, isLoading: action.isLoading };

      case 'SET_ERROR':
        return { ...state, error: action.error };

      default:
        return state;
    }
  },

  actions: {
    *loadThemes(blockType) {
      yield { type: 'SET_LOADING', isLoading: true };
      try {
        const themes = yield {
          type: 'API_FETCH',
          request: {
            path: `/gutenberg-blocks/v1/themes/${blockType}`,
            method: 'GET'
          }
        };
        return { type: 'SET_THEMES', blockType, themes };
      } catch (error) {
        return { type: 'SET_ERROR', error: error.message };
      } finally {
        yield { type: 'SET_LOADING', isLoading: false };
      }
    },

    *createTheme(blockType, name, values) {
      const theme = yield {
        type: 'API_FETCH',
        request: {
          path: '/gutenberg-blocks/v1/themes',
          method: 'POST',
          data: { blockType, name, values }
        }
      };
      return { type: 'THEME_CREATED', blockType, name, theme };
    },

    *updateTheme(blockType, name, values) {
      const theme = yield {
        type: 'API_FETCH',
        request: {
          path: `/gutenberg-blocks/v1/themes/${blockType}/${name}`,
          method: 'PUT',
          data: { values }
        }
      };
      return { type: 'THEME_UPDATED', blockType, name, theme };
    },

    *deleteTheme(blockType, name) {
      yield {
        type: 'API_FETCH',
        request: {
          path: `/gutenberg-blocks/v1/themes/${blockType}/${name}`,
          method: 'DELETE'
        }
      };
      return { type: 'THEME_DELETED', blockType, name };
    },

    *renameTheme(blockType, oldName, newName) {
      yield {
        type: 'API_FETCH',
        request: {
          path: `/gutenberg-blocks/v1/themes/${blockType}/${oldName}/rename`,
          method: 'POST',
          data: { newName }
        }
      };
      return { type: 'THEME_RENAMED', blockType, oldName, newName };
    }
  },

  selectors: {
    getThemes(state, blockType) {
      return state[`${blockType}Themes`] || {};
    },

    getTheme(state, blockType, name) {
      return state[`${blockType}Themes`]?.[name];
    },

    hasTheme(state, blockType, name) {
      return !!state[`${blockType}Themes`]?.[name];
    },

    isLoading(state) {
      return state.isLoading;
    },

    getError(state) {
      return state.error;
    }
  },

  controls: {
    API_FETCH({ request }) {
      return apiFetch(request);
    }
  }
});

register(store);

export default store;
```

**Testing Checklist**:
- [ ] Store registers successfully
- [ ] Selectors return correct data
- [ ] Actions dispatch correctly
- [ ] API calls use apiFetch
- [ ] Event isolation: accordion/tabs/toc themes separate
- [ ] Loading state updates correctly
- [ ] Error handling works

**Documentation**: WP-LIBRARIES-INTEGRATION-AUDIT.md (Section 4)

---

#### 1.3b Theme Storage PHP Backend (~350 LOC)

**Files**:
- `php/theme-storage.php` (~200 lines)
- `php/theme-rest-api.php` (~150 lines)

**Requirements**:
- WordPress REST API endpoints
- Database operations via `wp_options` table
- Separate storage: `accordion_themes`, `tabs_themes`, `toc_themes`
- Security: Nonces, capability checks (`edit_posts`)
- Validation: Theme name, values schema

**REST API Endpoints**:
```
GET    /wp-json/gutenberg-blocks/v1/themes/{blockType}
POST   /wp-json/gutenberg-blocks/v1/themes
PUT    /wp-json/gutenberg-blocks/v1/themes/{blockType}/{name}
DELETE /wp-json/gutenberg-blocks/v1/themes/{blockType}/{name}
POST   /wp-json/gutenberg-blocks/v1/themes/{blockType}/{name}/rename
```

**Implementation** (php/theme-rest-api.php):
```php
<?php

// Register REST API routes
add_action('rest_api_init', function() {
  // Get all themes for block type
  register_rest_route('gutenberg-blocks/v1', '/themes/(?P<blockType>[a-z]+)', array(
    'methods' => 'GET',
    'callback' => 'get_block_themes',
    'permission_callback' => function() {
      return current_user_can('edit_posts');
    }
  ));

  // Create new theme
  register_rest_route('gutenberg-blocks/v1', '/themes', array(
    'methods' => 'POST',
    'callback' => 'create_theme',
    'permission_callback' => function() {
      return current_user_can('edit_posts');
    }
  ));

  // Update theme
  register_rest_route('gutenberg-blocks/v1', '/themes/(?P<blockType>[a-z]+)/(?P<name>[^/]+)', array(
    'methods' => 'PUT',
    'callback' => 'update_theme',
    'permission_callback' => function() {
      return current_user_can('edit_posts');
    }
  ));

  // Delete theme
  register_rest_route('gutenberg-blocks/v1', '/themes/(?P<blockType>[a-z]+)/(?P<name>[^/]+)', array(
    'methods' => 'DELETE',
    'callback' => 'delete_theme',
    'permission_callback' => function() {
      return current_user_can('edit_posts');
    }
  ));

  // Rename theme
  register_rest_route('gutenberg-blocks/v1', '/themes/(?P<blockType>[a-z]+)/(?P<name>[^/]+)/rename', array(
    'methods' => 'POST',
    'callback' => 'rename_theme',
    'permission_callback' => function() {
      return current_user_can('edit_posts');
    }
  ));
});

function get_block_themes($request) {
  $block_type = $request['blockType'];
  $option_name = "{$block_type}_themes";

  $themes = get_option($option_name, array());

  return rest_ensure_response($themes);
}

function create_theme($request) {
  $block_type = $request['blockType'];
  $name = sanitize_text_field($request['name']);
  $values = $request['values'];

  // Validate theme name
  if (empty($name) || !preg_match('/^[a-zA-Z0-9\s\-_]+$/', $name)) {
    return new WP_Error('invalid_name', 'Invalid theme name', array('status' => 400));
  }

  $option_name = "{$block_type}_themes";
  $themes = get_option($option_name, array());

  // Check for duplicate
  if (isset($themes[$name])) {
    return new WP_Error('duplicate_name', 'Theme name already exists', array('status' => 409));
  }

  // Save theme
  $themes[$name] = array(
    'name' => $name,
    'values' => $values,
    'created' => current_time('mysql'),
    'modified' => current_time('mysql')
  );

  update_option($option_name, $themes);

  return rest_ensure_response($themes[$name]);
}

function update_theme($request) {
  $block_type = $request['blockType'];
  $name = $request['name'];
  $values = $request['values'];

  $option_name = "{$block_type}_themes";
  $themes = get_option($option_name, array());

  if (!isset($themes[$name])) {
    return new WP_Error('not_found', 'Theme not found', array('status' => 404));
  }

  $themes[$name]['values'] = $values;
  $themes[$name]['modified'] = current_time('mysql');

  update_option($option_name, $themes);

  return rest_ensure_response($themes[$name]);
}

function delete_theme($request) {
  $block_type = $request['blockType'];
  $name = $request['name'];

  $option_name = "{$block_type}_themes";
  $themes = get_option($option_name, array());

  if (!isset($themes[$name])) {
    return new WP_Error('not_found', 'Theme not found', array('status' => 404));
  }

  unset($themes[$name]);
  update_option($option_name, $themes);

  return rest_ensure_response(array('success' => true));
}

function rename_theme($request) {
  $block_type = $request['blockType'];
  $old_name = $request['name'];
  $new_name = sanitize_text_field($request['newName']);

  // Validate new name
  if (empty($new_name) || !preg_match('/^[a-zA-Z0-9\s\-_]+$/', $new_name)) {
    return new WP_Error('invalid_name', 'Invalid theme name', array('status' => 400));
  }

  $option_name = "{$block_type}_themes";
  $themes = get_option($option_name, array());

  if (!isset($themes[$old_name])) {
    return new WP_Error('not_found', 'Theme not found', array('status' => 404));
  }

  if (isset($themes[$new_name])) {
    return new WP_Error('duplicate_name', 'New theme name already exists', array('status' => 409));
  }

  // Rename
  $themes[$new_name] = $themes[$old_name];
  $themes[$new_name]['name'] = $new_name;
  $themes[$new_name]['modified'] = current_time('mysql');
  unset($themes[$old_name]);

  update_option($option_name, $themes);

  return rest_ensure_response($themes[$new_name]);
}
```

**Testing Checklist**:
- [ ] REST API endpoints register correctly
- [ ] Permissions checked (`edit_posts` capability)
- [ ] Themes save to correct `wp_option` key
- [ ] Returns JSON responses
- [ ] Handles errors gracefully (404, 409, 400)
- [ ] Validates theme names (alphanumeric + spaces/dashes)
- [ ] Duplicate names rejected
- [ ] Timestamps set correctly

**Documentation**: THEME-SYSTEM-ARCHITECTURE.md (Section: Database Schema)

---

#### 1.4 Theme Manager (~100 LOC)

**File**: `shared/src/theme-system/theme-manager.js`

**Requirements**:
- Thin wrapper around @wordpress/data store
- Export helper functions for backward compatibility
- DO NOT duplicate store logic

**Implementation**:
```javascript
import { dispatch, select } from '@wordpress/data';

const STORE_NAME = 'gutenberg-blocks/themes';

/**
 * Load themes for a block type
 * @param {string} blockType - 'accordion', 'tabs', or 'toc'
 * @returns {Promise<Object>} Themes object
 */
export async function loadThemes(blockType) {
  return dispatch(STORE_NAME).loadThemes(blockType);
}

/**
 * Get all themes for a block type
 * @param {string} blockType
 * @returns {Object} Themes object
 */
export function getThemes(blockType) {
  return select(STORE_NAME).getThemes(blockType);
}

/**
 * Get single theme
 * @param {string} blockType
 * @param {string} name
 * @returns {Object|undefined} Theme object
 */
export function getTheme(blockType, name) {
  return select(STORE_NAME).getTheme(blockType, name);
}

/**
 * Create new theme
 * @param {string} blockType
 * @param {string} name
 * @param {Object} values - Complete snapshot (all attributes with values)
 * @returns {Promise}
 */
export async function createTheme(blockType, name, values) {
  return dispatch(STORE_NAME).createTheme(blockType, name, values);
}

/**
 * Update existing theme
 * @param {string} blockType
 * @param {string} name
 * @param {Object} values - Complete snapshot
 * @returns {Promise}
 */
export async function updateTheme(blockType, name, values) {
  return dispatch(STORE_NAME).updateTheme(blockType, name, values);
}

/**
 * Delete theme
 * @param {string} blockType
 * @param {string} name
 * @returns {Promise}
 */
export async function deleteTheme(blockType, name) {
  return dispatch(STORE_NAME).deleteTheme(blockType, name);
}

/**
 * Rename theme
 * @param {string} blockType
 * @param {string} oldName
 * @param {string} newName
 * @returns {Promise}
 */
export async function renameTheme(blockType, oldName, newName) {
  return dispatch(STORE_NAME).renameTheme(blockType, oldName, newName);
}
```

**Testing Checklist**:
- [ ] All 5 operations work via store
- [ ] Helper functions wrap store correctly
- [ ] Backward compatible with expected API
- [ ] Works for all block types (accordion, tabs, toc)
- [ ] Async operations return promises

**Documentation**: THEME-SYSTEM-ARCHITECTURE.md (Section: Theme Operations)

---

#### 1.5 Shared Attribute Definitions (~460 LOC)

**Files**:
- `shared/src/attributes/color-attributes.js` (~100 lines)
- `shared/src/attributes/typography-attributes.js` (~100 lines)
- `shared/src/attributes/border-attributes.js` (~80 lines)
- `shared/src/attributes/spacing-attributes.js` (~80 lines)
- `shared/src/attributes/icon-attributes.js` (~60 lines)
- `shared/src/attributes/meta-attributes.js` (~40 lines)

**Requirements**:
- ALL customizable attributes default to `null`
- Consistent naming conventions (camelCase)
- Type definitions (string, number, object, boolean)

**Example** (color-attributes.js):
```javascript
/**
 * Shared color attributes for all blocks
 * All values default to null (cascade to theme/CSS)
 */
export const colorAttributes = {
  // Title colors
  titleColor: {
    type: 'string',
    default: null
  },
  titleBackgroundColor: {
    type: 'string',
    default: null
  },
  titleColorHover: {
    type: 'string',
    default: null
  },
  titleBackgroundColorHover: {
    type: 'string',
    default: null
  },

  // Content colors
  contentColor: {
    type: 'string',
    default: null
  },
  contentBackgroundColor: {
    type: 'string',
    default: null
  },

  // Border colors
  borderColor: {
    type: 'string',
    default: null
  },
  borderColorHover: {
    type: 'string',
    default: null
  }
};
```

**Testing Checklist**:
- [ ] All customizable attributes have `default: null`
- [ ] Attribute names match documentation (BLOCK-ATTRIBUTES-SCHEMA.md)
- [ ] No duplicate definitions across files
- [ ] Type definitions correct (string, number, object, boolean)

**Documentation**: BLOCK-ATTRIBUTES-SCHEMA.md (Section: Shared Attributes)

---

#### 1.6 Shared UI Components (~470 LOC)

**Files**:
- `shared/src/components/ThemeSelector.js` (~150 lines) - CUSTOM
- `shared/src/components/ColorPanel.js` (~70 lines) - Uses @wordpress/components
- `shared/src/components/TypographyPanel.js` (~80 lines) - Uses @wordpress/components
- `shared/src/components/BorderPanel.js` (~70 lines) - Uses @wordpress/components
- `shared/src/components/IconPanel.js` (~50 lines) - Uses @wordpress/components
- `shared/src/components/CustomizationWarning.js` (~50 lines) - CUSTOM

**Key Component** (ColorPanel.js):
```javascript
import { PanelBody, ColorPalette } from '@wordpress/components';
import { __ } from '@wordpress/i18n';

/**
 * Color panel using WordPress components
 * Shows effective values from cascade, saves customizations
 */
export function ColorPanel({
  blockType,
  attributes,
  effectiveValues,
  setAttributes
}) {
  const handleColorChange = (attribute) => (newValue) => {
    setAttributes({ [attribute]: newValue });
  };

  const isCustomized = (attr) => attributes[attr] !== null;

  return (
    <PanelBody title={__('Colors', 'gutenberg-blocks')} initialOpen={true}>

      {/* Title Color */}
      <div className="customizable-control">
        <label>
          {__('Title Color', 'gutenberg-blocks')}
          {isCustomized('titleColor') && <span className="badge">*</span>}
        </label>
        <ColorPalette
          value={effectiveValues.titleColor}
          onChange={handleColorChange('titleColor')}
        />
      </div>

      {/* Title Background Color */}
      <div className="customizable-control">
        <label>
          {__('Title Background', 'gutenberg-blocks')}
          {isCustomized('titleBackgroundColor') && <span className="badge">*</span>}
        </label>
        <ColorPalette
          value={effectiveValues.titleBackgroundColor}
          onChange={handleColorChange('titleBackgroundColor')}
        />
      </div>

      {/* Content Color */}
      <div className="customizable-control">
        <label>
          {__('Content Color', 'gutenberg-blocks')}
          {isCustomized('contentColor') && <span className="badge">*</span>}
        </label>
        <ColorPalette
          value={effectiveValues.contentColor}
          onChange={handleColorChange('contentColor')}
        />
      </div>

    </PanelBody>
  );
}
```

**Testing Checklist**:
- [ ] ThemeSelector shows all themes for block type
- [ ] ColorPanel displays effective colors (not raw attributes)
- [ ] Components accept blockType parameter
- [ ] Customization badges (*) appear when values differ from theme
- [ ] @wordpress/components render correctly
- [ ] onChange callbacks update attributes

**Documentation**: EDITOR-UI-REQUIREMENTS.md (Section: Shared Architecture Implementation)

---

#### 1.7 Shared Utilities (~400 LOC)

**Files**:
- `shared/src/utils/id-generator.js` (~80 lines)
- `shared/src/utils/aria-helpers.js` (~120 lines)
- `shared/src/utils/keyboard-nav.js` (~100 lines)
- `shared/src/utils/validation.js` (~100 lines)

**Example** (id-generator.js):
```javascript
/**
 * Generate unique 4-digit IDs with format: [prefix]-[0-9][a-z][a-z][a-z]
 * Examples: acc-3a7k, tab-9xfm, toc-2bvn
 */

const usedIds = new Set();

/**
 * Generate unique ID
 * @param {string} prefix - 'acc', 'tab', or 'toc'
 * @returns {string} Unique ID (e.g., 'acc-3a7k')
 */
export function generateUniqueId(prefix) {
  let attempts = 0;
  const maxAttempts = 100;

  while (attempts < maxAttempts) {
    const id = `${prefix}-${generateRandomSegment()}`;

    // Check uniqueness on page
    if (!usedIds.has(id) && !document.getElementById(id)) {
      usedIds.add(id);
      return id;
    }

    attempts++;
  }

  // Fallback: timestamp-based
  return `${prefix}-${Date.now().toString(36).slice(-4)}`;
}

/**
 * Generate 4-character segment: [0-9][a-z][a-z][a-z]
 */
function generateRandomSegment() {
  const digit = Math.floor(Math.random() * 10);
  const letter1 = String.fromCharCode(97 + Math.floor(Math.random() * 26));
  const letter2 = String.fromCharCode(97 + Math.floor(Math.random() * 26));
  const letter3 = String.fromCharCode(97 + Math.floor(Math.random() * 26));

  return `${digit}${letter1}${letter2}${letter3}`;
}

/**
 * Release ID from used set (for block deletion)
 * @param {string} id
 */
export function releaseId(id) {
  usedIds.delete(id);
}
```

**Testing Checklist**:
- [ ] IDs are unique across page
- [ ] Format matches [0-9][a-z][a-z][a-z]
- [ ] ARIA relationships correctly established
- [ ] Keyboard navigation handlers work (Enter, Space, Arrows)
- [ ] Validation catches invalid inputs

**Documentation**: ACCORDION-HTML-STRUCTURE.md (Section: ARIA Attributes)

---

#### 1.8 Store Usage Examples (~50 LOC)

**File**: `shared/src/data/usage-example.js` (documentation/reference)

**Purpose**: Show blocks how to use @wordpress/data store

**Example**:
```javascript
// Example: How to use the store in a block's edit.js

import { useSelect, useDispatch } from '@wordpress/data';
import { useEffect } from '@wordpress/element';
import { getAllEffectiveValues } from '@shared/theme-system/cascade-resolver';
import { getAllCSSDefaults } from '@shared/utils/css-parser';

function Edit({ attributes, setAttributes }) {
  const blockType = 'accordion';

  // 1. Select themes from store
  const { themes, isLoading } = useSelect((select) => ({
    themes: select('gutenberg-blocks/themes').getThemes(blockType),
    isLoading: select('gutenberg-blocks/themes').isLoading()
  }), [blockType]);

  // 2. Get dispatch functions
  const { loadThemes, createTheme, updateTheme } = useDispatch('gutenberg-blocks/themes');

  // 3. Load themes on mount
  useEffect(() => {
    loadThemes(blockType);
  }, [blockType, loadThemes]);

  // 4. Get current theme object
  const currentTheme = themes[attributes.currentTheme];

  // 5. Resolve effective values using cascade
  const cssDefaults = getAllCSSDefaults(blockType);
  const effectiveValues = getAllEffectiveValues(
    attributes,
    currentTheme,
    cssDefaults
  );

  // 6. Handle theme operations
  const handleCreateTheme = async (name) => {
    await createTheme(blockType, name, effectiveValues);
    setAttributes({ currentTheme: name });
  };

  const handleUpdateTheme = async (name) => {
    await updateTheme(blockType, name, effectiveValues);
    // Clear customizations after update
    clearCustomizations(setAttributes);
  };

  if (isLoading) {
    return <div>Loading themes...</div>;
  }

  return (
    <div>
      {/* Block editor UI */}
    </div>
  );
}

/**
 * Clear all customizations (set to null)
 */
function clearCustomizations(setAttributes) {
  // Get all customizable attribute names
  const customizableAttrs = [
    'titleColor', 'titleBackgroundColor', 'titleFontSize',
    // ... all customizable attributes
  ];

  const clearedAttrs = {};
  customizableAttrs.forEach(attr => {
    clearedAttrs[attr] = null;
  });

  setAttributes(clearedAttrs);
}
```

**Testing Checklist**:
- [ ] Themes load on editor mount
- [ ] useSelect re-renders on theme changes
- [ ] useDispatch actions work correctly
- [ ] Store updates trigger UI updates
- [ ] No race conditions

**Documentation**: WP-LIBRARIES-INTEGRATION-AUDIT.md (Section 4)

---

**PHASE 1 CHECKPOINT**

**Coordination Agent Tasks**:
1. Verify all shared modules exist
2. Run manual testing checklists
3. Validate @wordpress/data integration
4. Test cascade resolver performance (<5ms target)
5. Verify event isolation (accordion/tabs/toc separate)
6. Generate Phase 1 completion report

**User Action**: Review report, approve Phase 2 start

**Deliverables**:
- ✅ CSS parsing system (PHP + JS)
- ✅ Cascade resolver (100% custom, <5ms)
- ✅ WordPress Data Store (@wordpress/data)
- ✅ Theme Storage PHP Backend (REST API)
- ✅ Theme Manager (thin wrapper)
- ✅ Shared Attributes (all default to null)
- ✅ Shared UI Components (@wordpress/components)
- ✅ Shared Utilities (ID, ARIA, keyboard, validation)
- ✅ Store usage examples

**Total LOC**: 2,520 lines (750 LOC saved vs original)

---

### PHASE 2-4: Block Implementations

**Overview**: Implement Accordion, Tabs, and TOC blocks using shared infrastructure

**Can Run in Parallel**: After Phase 1 complete

**Estimated LOC**:
- Phase 2 (Accordion): 1,600 LOC
- Phase 3 (Tabs): 1,800 LOC
- Phase 4 (TOC): 1,900 LOC

**Common Structure** (each block):
1. CSS Defaults file (`:root` variables)
2. Block Registration (block.json + PHP)
3. Edit Component (uses shared modules + store)
4. Inspector Panels (uses @wordpress/components)
5. Save & Frontend (resolves values, generates HTML)

**Key Integration Points**:
- Uses `useSelect` / `useDispatch` for themes
- Uses `getAllEffectiveValues` for cascade
- Uses @wordpress/components for UI
- Uses @wordpress/a11y for announcements

**Documentation**:
- Accordion: ACCORDION-HTML-STRUCTURE.md
- Tabs: TABS-ACCORDION-INTEGRATION.md
- TOC: TOC-BLOCK-IMPLEMENTATION.md

**Testing Checklist** (each block):
- [ ] Block appears in inserter
- [ ] Can create/update/delete themes
- [ ] Theme switching works
- [ ] Customizations persist correctly
- [ ] 3-tier cascade resolves properly
- [ ] Frontend interactions work
- [ ] ARIA attributes correct
- [ ] Keyboard navigation functional

---

### PHASE 5: Integration & Testing (~200 LOC)

**Goal**: Verify all blocks work together


**Tasks**:
1. **Cross-block theme isolation testing**
   - Create accordion theme → verify tabs/TOC unaffected
   - Update tabs theme → verify accordion/TOC unaffected
   - Delete TOC theme → verify accordion/tabs unaffected

2. **Performance profiling**
   - Cascade resolution: <5ms target
   - Theme switch time: <100ms target
   - Build time: <30s production build

3. **Accessibility audit**
   - WCAG AA compliance
   - Screen reader testing
   - Keyboard navigation
   - No duplicate IDs on page

4. **Integration tests** (~200 LOC)
   ```javascript
   // Example integration test
   describe('Theme Isolation', () => {
     it('accordion themes do not affect tabs', () => {
       // Create accordion theme
       createTheme('accordion', 'Test', { titleColor: '#ff0000' });

       // Verify tabs themes unchanged
       const tabsThemes = getThemes('tabs');
       expect(tabsThemes).not.toHaveProperty('Test');
     });
   });
   ```

**Success Criteria**:
- [ ] All blocks work together without conflicts
- [ ] Event isolation verified
- [ ] Performance targets met
- [ ] Accessibility: WCAG AA compliance
- [ ] No console errors or warnings
- [ ] Documentation complete and accurate

---

## AI Agent System

### Agent Roles

#### 1. Strategy Agent (Run FIRST, once)

**Purpose**: Analyze documentation and create implementation strategy

**Tasks**:
1. Read ALL 9 architecture documents (including WP-LIBRARIES-INTEGRATION-AUDIT.md)
2. Create detailed implementation strategy
3. Generate module dependency graph
4. Estimate LOC per module
5. Identify risk areas
6. Setup build system (Phase 0)

**Output**: This document + working build environment

---

#### 2. Coordination Agent (Active throughout)

**Purpose**: Orchestrate all agents, track progress

**Responsibilities**:
- Assign tasks to specialist agents
- Track phase completion and checkpoint validation
- Ensure agents follow architecture patterns
- Maintain `PROJECT_STATUS.md` with current state
- Validate agents pause when uncertain

**State Tracking** (PROJECT_STATUS.md):
```markdown
# Project Status

## Current Phase
Phase: 1 - Shared Infrastructure
Progress: 45% (4 of 8 modules complete)

## Last Completed Task
Task: 1.4 - Theme Manager
LOC: 100
Completed: 2025-10-12 15:30

## Active Task
Task: 1.5 - Shared Attributes
Status: In Progress

## Next Tasks
1. 1.6 - Shared UI Components
2. 1.7 - Shared Utilities
3. 1.8 - Store Usage Examples

## Blockers
[None currently]

## Phase Checkpoints
- [x] Phase 0: Build System
- [ ] Phase 1: Shared Infrastructure
- [ ] Phase 2: Accordion Block
- [ ] Phase 3: Tabs Block
- [ ] Phase 4: TOC Block
- [ ] Phase 5: Integration
```

---

#### 3. Specialist Agents (Multiple, task-specific)

**Types**:
- **Infrastructure Agent**: Builds shared modules (Phase 1)
- **Block Agent**: Implements individual blocks (Phases 2-4)
- **Integration Agent**: Tests integration (Phase 5)

**Rules for ALL Specialist Agents**:
- Read assigned documentation BEFORE coding
- Write maximum ~200-300 lines per session
- Create manual testing checklist for each task
- Report completion with brief summary
- **MUST PAUSE** if encountering:
  - Missing information in documentation
  - Contradictions between documents
  - Uncertainty about implementation approach
  - Need for architectural decision

**Pause Format**:
```
🛑 AGENT PAUSE: [Brief reason]

Task: [Current task name]
Agent: [Your role]

Issue:
[Detailed description of uncertainty]

Documentation References:
- [Document name, section]

Question:
[Specific question for user]

Options Considered:
1. [Option A with pros/cons]
2. [Option B with pros/cons]

Recommendation:
[Your recommendation or "Need user decision"]
```

---

### Session Management

**LOC Limits Per Session**:
- Small tasks: ~100-150 lines (utilities)
- Medium tasks: ~200-300 lines (standard modules)
- Large tasks: ~300-400 lines MAX (split if larger)

**Never exceed**: 400 lines in single session (prevents token exhaustion)

**Resuming After Session Expiry**:
1. Read `PROJECT_STATUS.md`
2. Read relevant documentation for active/next task
3. Verify previous files exist and work
4. Continue from active task or start next task
5. Update `PROJECT_STATUS.md` when completing work

---

## Critical Rules & Constraints

### MUST DO

1. ✅ **Load themes before rendering** - Prevents undefined values
2. ✅ **Resolve effective values via cascade** - Don't read raw attributes in UI
3. ✅ **All customizable attributes default to null** - For CSS cascade
4. ✅ **Clear customizations after theme update** - Prevents stale inline values
5. ✅ **Synchronize ARIA with visual state** - Accessibility requirement
6. ✅ **Use unique IDs for ARIA relationships** - No duplicate IDs
7. ✅ **Validate HTML against W3C standards** - Accessibility compliance

### MUST NOT DO

1. ❌ **Don't use @wordpress/data for cascade** - Keep custom for performance
2. ❌ **Don't render before themes load** - Causes race conditions
3. ❌ **Don't read attributes directly in sidebar** - Shows wrong values
4. ❌ **Don't treat booleans specially** - Same cascade as all attributes
5. ❌ **Don't merge cascade tiers** - First defined value wins, stop
6. ❌ **Don't use divs with role=button** - Use native buttons
7. ❌ **Don't forget hidden attribute** - CSS alone insufficient

### What MUST Stay Custom

1. **cascade-resolver.js** - 100% custom (performance critical, <5ms target)
2. **aria-helpers.js** - Custom ARIA sync with visual state
3. **keyboard-nav.js** - Block-specific keyboard handlers
4. **id-generator.js** - Custom 4-digit format [0-9][a-z][a-z][a-z]
5. **3-tier cascade logic** - First defined value wins, no merging

---

## Testing & Validation

### Phase 1 Testing

**CSS Parsing**:
- [ ] Loads php/css-defaults/accordion.php correctly
- [ ] Caches values with modification time
- [ ] Returns null for missing variables
- [ ] JavaScript receives correct defaults object

**Cascade Resolver**:
- [ ] Block customization overrides theme
- [ ] Theme overrides CSS default
- [ ] CSS default used when others null
- [ ] Works for all types (string, number, object, boolean)
- [ ] Performance: <5ms for getAllEffectiveValues()

**@wordpress/data Store**:
- [ ] Store registers successfully
- [ ] Selectors return correct data
- [ ] Actions dispatch correctly
- [ ] API calls use apiFetch
- [ ] Event isolation: accordion/tabs/toc themes separate

**Theme Storage PHP**:
- [ ] REST API endpoints register correctly
- [ ] Permissions checked (`edit_posts` capability)
- [ ] Themes save to correct wp_option key
- [ ] Returns JSON responses
- [ ] Handles errors gracefully

---

### Cross-Block Testing (Phase 5)

**Event Isolation**:
- [ ] Create accordion theme → tabs/TOC unaffected
- [ ] Update tabs theme → accordion/TOC unaffected
- [ ] Delete TOC theme → accordion/tabs unaffected

**Performance**:
- [ ] Cascade resolution: <5ms
- [ ] Theme switch time: <100ms
- [ ] Build time: <30s production
- [ ] Hot reload: <2s for changes

**Accessibility**:
- [ ] WCAG AA compliance
- [ ] Screen reader announcements work
- [ ] Keyboard navigation functional
- [ ] No duplicate IDs on page
- [ ] ARIA attributes sync with visual state

---

### Build System Testing

**Phase 0 Validation**:
- [ ] `npm install` completes without errors
- [ ] `npm start` enables hot reload
- [ ] `npm run build` generates all output files
- [ ] CSS variables parsed to PHP files
- [ ] No webpack errors or warnings
- [ ] Source maps generated for debugging

---

## Risk Management

### Risk Assessment Matrix

| Risk | Probability | Impact | Mitigation | Rollback Time |
|------|-------------|--------|------------|---------------|
| @wordpress/data event isolation failure | Low | High | Integration tests (Phase 5) | 2-3 days |
| Cascade resolution performance | Medium | Medium | Keep custom, profile | N/A (already custom) |
| CSS parser build failure | Low | High | Validate CSS format, add tests | 1 day (manual PHP gen) |
| WordPress version lock-in | High | Low | Document min version, test 3 versions | N/A (expected) |
| @wordpress/components cascade compatibility | Low | Medium | Test with all 3 tiers, wrapper utils | 1-2 days (selective revert) |

### Rollback Plan

**Tier 1** (1-2 hours):
- Remove @wordpress/a11y `speak()`, restore custom

**Tier 2** (1-2 days):
- Revert @wordpress/components to custom panels (selective)

**Tier 3** (2-3 days):
- Restore theme-events.js, revert @wordpress/data integration

**Total Risk Window**: 3-5 days worst-case for complete rollback

---

## Success Metrics

### Code Quality
- ✅ 10.6% LOC reduction (980 lines saved)
- ✅ WordPress coding standards compliance
- ✅ Improved accessibility (@wordpress/a11y)
- ✅ Better maintainability (less custom code)

### Performance
- ✅ Cascade resolution: <5ms target
- ✅ Theme switch time: <100ms target
- ✅ Build time: <30s production build
- ✅ Hot reload: <2s for changes

### Compatibility
- ✅ WordPress 6.4+ support
- ✅ Node.js 18.x/20.x LTS
- ✅ Last 3 WP major versions tested
- ✅ WCAG AA compliance

### Developer Experience
- ✅ Hot module reload (instant feedback)
- ✅ ESLint auto-fix (WordPress standards)
- ✅ Source maps (easy debugging)
- ✅ Fast Refresh (React component updates)

---

## Documentation Guide

### Quick Reference Files

- **README.md** (this file) - Master implementation guide with all phases, code examples, and detailed specs
- **claude.md** - AI agent quick reference (~150 lines) - Fast project overview for token efficiency
- **PROJECT-MASTER-GUIDE.md** - Consolidated version of README (kept for compatibility)

### Core Architecture Documents

**Read these BEFORE implementing:**

1. **THEME-SYSTEM-ARCHITECTURE.md** (~2,000 lines)
   - **Purpose**: The foundation of the entire system
   - Shared theme system for all blocks
   - 3-tier cascade: CSS → Theme → Block customizations
   - Theme storage strategy (separate databases per block)
   - CSS as single source of truth
   - Theme operations (create, update, delete, rename, switch)

2. **DATA-FLOW-AND-STATE.md** (~2,500 lines)
   - **Purpose**: How data moves through the system
   - Complete data flow from CSS to frontend
   - State management patterns with @wordpress/data
   - Event synchronization system
   - Loading sequences and race condition prevention
   - Effective value resolution via cascade

3. **FRONTEND-RENDERING.md** (~1,100 lines)
   - **Purpose**: How blocks render on the frontend
   - Frontend vs editor rendering differences
   - CSS variable generation system
   - Value resolution at save time
   - HTML output patterns
   - JavaScript requirements for interactions

4. **EDITOR-UI-REQUIREMENTS.md** (~3,800 lines)
   - **Purpose**: Complete UI/UX specifications for block editor
   - Block editor UI/UX patterns
   - Inspector sidebar panel specifications
   - Theme selector workflow (shared component)
   - Customization detection and warnings
   - Visual states and error handling

5. **BLOCK-ATTRIBUTES-SCHEMA.md** (~1,450 lines)
   - **Purpose**: Data dictionary for all attributes
   - Attribute definitions and data types
   - Shared vs block-specific attributes
   - Customizable vs structural attributes
   - Validation rules and serialization
   - Theme data structure

6. **WP-LIBRARIES-INTEGRATION-AUDIT.md**
   - **Purpose**: WordPress libraries integration analysis
   - Feasibility analysis for @wordpress/data, @wordpress/components, etc.
   - Integration decisions and rationale
   - LOC savings calculations
   - Risk assessments and rollback plans

### Block-Specific Documents

7. **ACCORDION-HTML-STRUCTURE.md** (~1,200 lines)
   - **Purpose**: Complete Accordion block specification
   - Accordion-specific HTML structure
   - ARIA attributes for expand/collapse pattern
   - Keyboard navigation (Enter/Space)
   - W3C WAI-ARIA best practices
   - Accessibility and SEO considerations

8. **TABS-ACCORDION-INTEGRATION.md** (~1,750 lines)
   - **Purpose**: Complete Tabs block specification
   - Tabs-specific attributes and behaviors
   - Horizontal/vertical orientation
   - Hover mode and keyboard navigation (arrows)
   - Responsive accordion fallback for mobile
   - Integration with shared architecture

9. **TOC-BLOCK-IMPLEMENTATION.md** (~2,500+ lines)
   - **Purpose**: Complete Table of Contents specification
   - Automatic heading detection system
   - Flexible filtering (include/exclude modes)
   - Advanced numbering styles
   - Per-level typography system
   - Optional collapsible behavior
   - Sticky/fixed positioning

### Support Documents

10. **core-api-reference.md**
    - **Purpose**: API reference for shared modules
    - Function signatures and parameters
    - Return types and examples
    - Usage patterns

11. **WORDPRESS-INTEGRATION-SUMMARY.md**
    - **Purpose**: Summary of WordPress libraries integration (legacy, see README instead)
    - Integration summary and status
    - LOC impact analysis
    - Next steps

12. **IMPLEMENTATION-STRATEGY.md**
    - **Purpose**: Detailed implementation strategy (legacy, see README instead)
    - Module dependency graph
    - LOC estimates by phase
    - Risk analysis

### How to Use These Documents

**For AI Agents Starting Fresh**:
1. Read `claude.md` first (2-3 minutes, essential context)
2. Read `README.md` for your assigned phase
3. Read relevant architecture docs (e.g., THEME-SYSTEM-ARCHITECTURE.md for Phase 1)
4. Reference block-specific docs when implementing blocks (Phases 2-4)

**For Understanding Architecture**:
- Start with THEME-SYSTEM-ARCHITECTURE.md (foundation)
- Then DATA-FLOW-AND-STATE.md (how it all connects)
- Then EDITOR-UI-REQUIREMENTS.md (user experience)

**For Implementing Specific Features**:
- Theme system → THEME-SYSTEM-ARCHITECTURE.md
- Frontend rendering → FRONTEND-RENDERING.md
- Block attributes → BLOCK-ATTRIBUTES-SCHEMA.md
- Accordion block → ACCORDION-HTML-STRUCTURE.md
- Tabs block → TABS-ACCORDION-INTEGRATION.md
- TOC block → TOC-BLOCK-IMPLEMENTATION.md

---

## Quick Start Commands

### First Time Setup

```bash
# 1. Clone/navigate to project
cd /path/to/project

# 2. Install dependencies
npm init -y
npm install

# 3. Create directory structure
mkdir -p blocks/{accordion,tabs,toc}/{src,build}
mkdir -p shared/{src,build}
mkdir -p php/css-defaults
mkdir -p build-tools
mkdir -p assets/css

# 4. Start development
npm start

# 5. Build for production
npm run build
```

### Development Workflow

```bash
# Start dev server with hot reload
npm start

# Lint and fix code
npm run lint:js --fix
npm run lint:css --fix

# Format code
npm run format

# Build for production
npm run build

# Run tests
npm run test:unit
```

---

## Next Steps

**Immediate Actions**:
1. ✅ Review this master guide
2. ✅ Approve WordPress library integration strategy
3. ✅ Confirm build system approach

**Phase 0** (Strategy Agent ):
1. Execute: `npm init -y && npm install`
2. Create: webpack.config.js, css-vars-parser-loader.js
3. Test: `npm start` and `npm run build`
4. **Checkpoint**: User approves build system

**Phase 1** (Infrastructure Agent - ~6 days):
1. Implement 8 shared modules (Tasks 1.1-1.8)
2. Integrate @wordpress/data store
3. Test cascade resolution performance
4. **Checkpoint**: User approves shared infrastructure

**Phases 2-4** (Block Agents parallel):
1. Implement Accordion, Tabs, TOC blocks
2. Use shared infrastructure
3. **Checkpoints**: User approves each block

**Phase 5** 
1. Cross-block integration testing
2. Performance profiling
3. Accessibility audit
4. **Final Checkpoint**: User approves for production


---

## Status

**✅ DOCUMENTATION COMPLETE**

**Ready For**: Phase 0 implementation (build system setup)

**Confidence Level**: HIGH
- Core constraints preserved
- Integration tested conceptually
- Rollback plans in place
- Clear task breakdown
- Comprehensive testing strategy

**Recommendation**: **PROCEED WITH IMPLEMENTATION**

---

Contradictions Identified
These are minor and seem like remnants from pre-v6.0 updates. They won't derail implementation but could confuse a coding agent scanning quickly:

Attribute Naming Inconsistencies:

In BLOCK-ATTRIBUTES-SCHEMA.md Changelog (v2.0), it notes fixes like iconTypeClosed default to "▾" (was "plus"), but in ACCORDION-HTML-STRUCTURE.md Section 3 (Icons), it still references "plus/minus" as an example without updating to the new default. Similarly, DATA-FLOW-AND-STATE.md examples use old "headerBackgroundColor" in some diagrams (e.g., Section 1.2), while others use "titleBackgroundColor".
Impact: Coding agent might use outdated names in examples. Fix Suggestion: Global search/replace all "header*" to "title*", and update icon examples to match schema defaults.


Cascade Tiers in Older References:

core-api-reference.md Section v6.0 correctly states 3-tier, but in its Changelog (v1.0), it references an old 4-tier implicitly (e.g., "pageStyle" param in functions). DATA-FLOW-AND-STATE.md Changelog also mentions removing the 4-tier.
Impact: Low, as main content is updated, but could confuse if agent reads changelogs first. Fix Suggestion: Add a bold note in changelogs: "Ignore pre-v6.0 references to 4-tier; current is 3-tier."


Behavioral Defaults:

core-api-reference.md v6.0 notes some defaults (e.g., iconRotation: 0) are hardcoded in PHP parsing (not CSS), which aligns with BLOCK-ATTRIBUTES-SCHEMA.md. But FRONTEND-RENDERING.md implies all defaults are in CSS, without explicitly calling out exceptions.
Impact: Minor; agent might assume all in CSS. Fix Suggestion: Add a subsection in FRONTEND-RENDERING.md: "Exceptions: Behavioral defaults (e.g., booleans like showIcon) are hardcoded in PHP parser."



No major contradictions (e.g., no docs claim themes are shared between block types).
Ambiguities and Questions
These are areas where a coding agent might pause and make assumptions, leading to inconsistent code. I've phrased them as questions for you to clarify/add to the docs. Most relate to unspecified behaviors or error states.

Theme Deletion Impact: What happens if a theme is deleted while blocks are using it? (THEME-SYSTEM-ARCHITECTURE.md Section 7 mentions deleteTheme, but not fallback). Does the block fall back to 'default' theme, keep a snapshot, or error? Clarify in theme-manager.js docs.
Invalid CSS Parse: If accordion.css is malformed (e.g., syntax error), how does PHP handle it? (FRONTEND-RENDERING.md Section Parsing). Fall back to hardcoded defaults, log error, or crash? Add to parse_css_defaults() spec.
Multiple Blocks on Page: DATA-FLOW-AND-STATE.md Section 10 mentions event synchronization, but what if multiple accordion blocks on a page use the same theme—does updating propagate to all via events? (Yes, implied, but explicit confirmation needed for TOC-BLOCK-IMPLEMENTATION.md, as TOC allows multiple per post).
Heading Detection in Editor vs Frontend: For TOC (TOC-BLOCK-IMPLEMENTATION.md Section 2.1), client-side DOM scan is mentioned, but how does it handle dynamic blocks (e.g., reusable blocks or innerBlocks added post-mount)? Rescan on every editor change, or use WP data store? Also, exclude TOC's own headings?
Responsive Fallback for Tabs: TABS-ACCORDION-INTEGRATION.md Section 8 says "reuses accordion logic," but does this mean full code reuse (e.g., render accordion HTML on mobile) or just behavioral? If full, how to handle tabs-specific attrs like orientation on fallback?
Customization Cache Serialization: BLOCK-ATTRIBUTES-SCHEMA.md says customizationCache is non-serialized (transient), but DATA-FLOW-AND-STATE.md Section 11 implies it's in attributes. Clarify: Is it saved to post_content or recomputed on load?
Validation Enforcement: core-api-reference.md has validateAttributeValue, but when/where is it called? (e.g., on setAttributes, AJAX save, or frontend render). Add to attribute-operations.js spec.
No Themes Defined: If no themes exist (fresh install), what is the fallback? (Implied 'default' from CSS, but THEME-SYSTEM-ARCHITECTURE.md Section 5 says themes store complete snapshots—does a 'default' theme auto-create?)
Icon Rotation Units: SCHEMA says iconRotation is number (degrees), but is it always degrees, or support other units? (e.g., 'turn' in CSS). Clarify in validation rules.
ARIA for TOC Collapsible: TOC-BLOCK-IMPLEMENTATION.md Section 5 reuses accordion collapse, but does it adapt ARIA (e.g., role=region for TOC content)? Align with ACCORDION-HTML-STRUCTURE.md.

Edge Cases to Consider/Document


1. Attribute Naming Inconsistencies - Lets always default to "▾", and instead of header, lets use title
2 Cascade Tiers in Older References:Remove completely all references to a 4-tier
3 - Make sure to state wich variables are NOT possible to be declared in CSS. And those, we declare in php, be consistent about this
Ambiguities and Questions
1- What happens if a theme is deleted while blocks are using it - block fall back to 'default' theme
2 - Invalid CSS Parse: log error and crash
3 - Multiple Blocks on Page - updating propagate to all via events
4. Heading Detection in Editor vs Frontend - Exclude TOC headings, on guttenberg editor you can dinamicaly scan, and on frontend use the logic you talked about, for it to work. Or, if its simpler, you can generate TOC on editor and when user publishes, the TOC is transformed to HTML without needing dinamic stuff as it will be build as a html list. Whatever is more pratical and effectiv5 - Responsive Fallback for Tabs - just behavioral
6 - Customizations are in post data - lets go with Recomputing is fast and ensures the cache is always up-to-date (e.g., if theme changes).
7 - add validation where you need to, to insure input data is always coherent

8 - No Themes Defined - the Default theme is used, and this theme basically reads all possible variables from accordion.css
9 - Icon Rotation Units - can support deg, turn, rad
10 - Yes, adapt ARIA to content




Edge Cases to Consider/Document
- Large post (1000+ headings in TOC) or many themes (50+)—throttle scans? (TOC Section 21.8 mentions <100ms, but add limits).  yes throttle scans, but in TOC if you opt for my approach of dinamicaly build on editor and on frontpage its coded as a simple list, this problem wont exist
- Conflicts - copied blocks auto generate an id
- Migrations - no legacy whatsoever, were producing
- No JavaScript - accordion always open, tabs as list
- RTL Support - - NO RTL support
- Nested Blocks  - tabs can have nesting. accordions dont
- Empty States - dont show message, assume the emptyness as normal
- User Permissions - every user that can add a post
-Cache Busting: —force browser refresh
- Internationalization: Title tex - should change according to the theme localization and translation files
- Error Recovery: AJAX failure, notify user and ask for manual retry