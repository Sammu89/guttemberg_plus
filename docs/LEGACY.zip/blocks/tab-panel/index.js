import { registerBlockType } from '@wordpress/blocks';
import {
	useBlockProps,
	InnerBlocks,
	InspectorControls,
} from '@wordpress/block-editor';
import { PanelBody, TextControl, SelectControl } from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import ErrorBoundary from '../shared/components/ErrorBoundary';

registerBlockType( 'sammu/tab-panel', {
	edit: ( { attributes, setAttributes } ) => {
		const blockProps = useBlockProps( {
			className: 'tab-panel-editor',
		} );

		const { tabIndex, tabTitle, tabIcon, showIcon } = attributes;

		const iconOptions = [
			{ label: 'None', value: '' },
			{ label: '📄 Document', value: '📄' },
			{ label: '⚙️ Settings', value: '⚙️' },
			{ label: '📊 Analytics', value: '📊' },
			{ label: '👤 Profile', value: '👤' },
			{ label: '📞 Contact', value: '📞' },
			{ label: '🏠 Home', value: '🏠' },
			{ label: '💼 Business', value: '💼' },
			{ label: '🛒 Shopping', value: '🛒' },
			{ label: '📧 Email', value: '📧' },
			{ label: '📱 Mobile', value: '📱' },
			{ label: '🔧 Tools', value: '🔧' },
			{ label: '📈 Growth', value: '📈' },
			{ label: '🎯 Target', value: '🎯' },
			{ label: '💡 Ideas', value: '💡' },
			{ label: '🔒 Security', value: '🔒' },
			{ label: '📅 Calendar', value: '📅' },
			{ label: '🏆 Awards', value: '🏆' },
			{ label: '📚 Education', value: '📚' },
			{ label: '🎨 Creative', value: '🎨' },
		];

		return (
			<ErrorBoundary blockName="Tab Panel">
				<InspectorControls>
					<PanelBody
						title={ __( 'Tab Settings', 'guten-nav-plugin' ) }
					>
						<TextControl
							label={ __( 'Tab Title', 'guten-nav-plugin' ) }
							value={ tabTitle }
							onChange={ ( value ) =>
								setAttributes( { tabTitle: value } )
							}
						/>

						{ showIcon && (
							<>
								<SelectControl
									label={ __(
										'Tab Icon',
										'guten-nav-plugin'
									) }
									value={ tabIcon }
									options={ iconOptions }
									onChange={ ( value ) =>
										setAttributes( { tabIcon: value } )
									}
								/>

								<TextControl
									label={ __(
										'Custom Icon (Emoji or Unicode)',
										'guten-nav-plugin'
									) }
									value={ tabIcon }
									onChange={ ( value ) =>
										setAttributes( { tabIcon: value } )
									}
									help={ __(
										'You can enter a custom emoji or unicode character',
										'guten-nav-plugin'
									) }
								/>
							</>
						) }
					</PanelBody>
				</InspectorControls>
				<div { ...blockProps }>
					<div className="tab-panel-header">
						{ showIcon && tabIcon && (
							<span className="tab-icon">{ tabIcon }</span>
						) }
						<strong>{ tabTitle }</strong>
						{ showIcon && ! tabIcon && (
							<span className="tab-icon-placeholder">
								{ __( '(No icon)', 'guten-nav-plugin' ) }
							</span>
						) }
					</div>
					<div className="tab-panel-content">
						<InnerBlocks
							templateLock={ false }
							placeholder={ __(
								'Add content to this tab…',
								'guten-nav-plugin'
							) }
						/>
					</div>
				</div>
			</ErrorBoundary>
		);
	},

	save: ( { attributes } ) => {
		const blockProps = useBlockProps.save();
		const { tabIndex, tabTitle, tabIcon, showIcon } = attributes;

		return (
			<>
				<li
					className={ tabIndex === 0 ? 'active' : '' }
					data-tab={ tabIndex }
				>
					{ showIcon && tabIcon && (
						<span className="tab-icon">{ tabIcon }</span>
					) }
					{ tabTitle }
				</li>
				<div
					className={ `tab-content ${
						tabIndex === 0 ? 'active' : ''
					}` }
					data-tab={ tabIndex }
				>
					<InnerBlocks.Content />
				</div>
			</>
		);
	},
} );
