import { registerBlockType } from '@wordpress/blocks';
import { useBlockProps, InspectorControls } from '@wordpress/block-editor';
import {
	PanelBody,
	CheckboxControl,
	TextControl,
	SelectControl,
	ToggleControl,
	Button,
	BaseControl,
} from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import { useState } from '@wordpress/element';
import ErrorBoundary from '../shared/components/ErrorBoundary';

registerBlockType( 'sammu/auto-menu', {
	edit: ( { attributes, setAttributes } ) => {
		const blockProps = useBlockProps( {
			className: 'auto-menu-editor',
		} );

		const {
			menuTitle,
			showTitle,
			titleLevel,
			includedHeadings,
			includeClasses,
			excludeClasses,
			classFilterMode,
			showPreview,
		} = attributes;

		const [ newIncludeClass, setNewIncludeClass ] = useState( '' );
		const [ newExcludeClass, setNewExcludeClass ] = useState( '' );

		const headingLevels = [
			{ label: 'H1', value: 'h1' },
			{ label: 'H2', value: 'h2' },
			{ label: 'H3', value: 'h3' },
			{ label: 'H4', value: 'h4' },
			{ label: 'H5', value: 'h5' },
			{ label: 'H6', value: 'h6' },
		];

		const toggleHeading = ( heading ) => {
			const newIncluded = includedHeadings.includes( heading )
				? includedHeadings.filter( ( h ) => h !== heading )
				: [ ...includedHeadings, heading ];
			setAttributes( { includedHeadings: newIncluded } );
		};

		const addIncludeClass = () => {
			if (
				newIncludeClass.trim() &&
				! includeClasses.includes( newIncludeClass.trim() )
			) {
				setAttributes( {
					includeClasses: [
						...includeClasses,
						newIncludeClass.trim(),
					],
					classFilterMode:
						classFilterMode === 'none'
							? 'include'
							: classFilterMode,
				} );
				setNewIncludeClass( '' );
			}
		};

		const removeIncludeClass = ( classToRemove ) => {
			setAttributes( {
				includeClasses: includeClasses.filter(
					( cls ) => cls !== classToRemove
				),
			} );
		};

		const addExcludeClass = () => {
			if (
				newExcludeClass.trim() &&
				! excludeClasses.includes( newExcludeClass.trim() )
			) {
				setAttributes( {
					excludeClasses: [
						...excludeClasses,
						newExcludeClass.trim(),
					],
					classFilterMode:
						classFilterMode === 'none'
							? 'exclude'
							: classFilterMode,
				} );
				setNewExcludeClass( '' );
			}
		};

		const removeExcludeClass = ( classToRemove ) => {
			setAttributes( {
				excludeClasses: excludeClasses.filter(
					( cls ) => cls !== classToRemove
				),
			} );
		};

		return (
			<ErrorBoundary blockName="Auto Menu">
				<InspectorControls>
					<PanelBody
						title={ __( 'Menu Title', 'guten-nav-plugin' ) }
						initialOpen={ true }
					>
						<ToggleControl
							label={ __(
								'Show menu title',
								'guten-nav-plugin'
							) }
							checked={ showTitle }
							onChange={ ( value ) =>
								setAttributes( { showTitle: value } )
							}
						/>

						{ showTitle && (
							<>
								<TextControl
									label={ __(
										'Menu Title',
										'guten-nav-plugin'
									) }
									value={ menuTitle }
									onChange={ ( value ) =>
										setAttributes( { menuTitle: value } )
									}
									placeholder={ __(
										'Table of Contents',
										'guten-nav-plugin'
									) }
								/>

								<SelectControl
									label={ __(
										'Title Level',
										'guten-nav-plugin'
									) }
									value={ titleLevel }
									options={ [
										{ label: 'H1', value: 'h1' },
										{ label: 'H2', value: 'h2' },
										{ label: 'H3', value: 'h3' },
										{ label: 'H4', value: 'h4' },
										{ label: 'H5', value: 'h5' },
										{ label: 'H6', value: 'h6' },
									] }
									onChange={ ( value ) =>
										setAttributes( { titleLevel: value } )
									}
									help={ __(
										'Choose the heading level for the menu title (H1 recommended only if this is the main page heading)',
										'guten-nav-plugin'
									) }
								/>
							</>
						) }
					</PanelBody>

					<PanelBody
						title={ __( 'Heading Levels', 'guten-nav-plugin' ) }
						initialOpen={ false }
					>
						<BaseControl
							label={ __(
								'Include these heading levels:',
								'guten-nav-plugin'
							) }
							help={ __(
								'Select which heading levels (H1-H6) to include in the menu',
								'guten-nav-plugin'
							) }
						>
							<div className="heading-checkboxes">
								{ headingLevels.map( ( level ) => (
									<CheckboxControl
										key={ level.value }
										label={ level.label }
										checked={ includedHeadings.includes(
											level.value
										) }
										onChange={ () =>
											toggleHeading( level.value )
										}
									/>
								) ) }
							</div>
						</BaseControl>
					</PanelBody>

					<PanelBody
						title={ __( 'Class Filtering', 'guten-nav-plugin' ) }
						initialOpen={ false }
					>
						<SelectControl
							label={ __( 'Filter Mode', 'guten-nav-plugin' ) }
							value={ classFilterMode }
							options={ [
								{ label: 'No class filtering', value: 'none' },
								{
									label: 'Only include headings with these classes',
									value: 'include',
								},
								{
									label: 'Exclude headings with these classes',
									value: 'exclude',
								},
							] }
							onChange={ ( value ) =>
								setAttributes( { classFilterMode: value } )
							}
						/>

						{ classFilterMode === 'include' && (
							<div className="class-manager">
								<BaseControl
									label={ __(
										'Include Classes',
										'guten-nav-plugin'
									) }
								>
									<div className="class-input-group">
										<TextControl
											value={ newIncludeClass }
											onChange={ setNewIncludeClass }
											placeholder={ __(
												'Enter class name',
												'guten-nav-plugin'
											) }
											onKeyDown={ ( e ) => {
												if ( e.key === 'Enter' ) {
													e.preventDefault();
													addIncludeClass();
												}
											} }
										/>
										<Button
											variant="secondary"
											onClick={ addIncludeClass }
											disabled={
												! newIncludeClass.trim()
											}
										>
											{ __( 'Add', 'guten-nav-plugin' ) }
										</Button>
									</div>
									<div className="class-list">
										{ includeClasses.map( ( cls ) => (
											<div
												key={ cls }
												className="class-item"
											>
												<span>{ cls }</span>
												<Button
													isSmall
													isDestructive
													onClick={ () =>
														removeIncludeClass(
															cls
														)
													}
												>
													×
												</Button>
											</div>
										) ) }
									</div>
								</BaseControl>
							</div>
						) }

						{ classFilterMode === 'exclude' && (
							<div className="class-manager">
								<BaseControl
									label={ __(
										'Exclude Classes',
										'guten-nav-plugin'
									) }
								>
									<div className="class-input-group">
										<TextControl
											value={ newExcludeClass }
											onChange={ setNewExcludeClass }
											placeholder={ __(
												'Enter class name',
												'guten-nav-plugin'
											) }
											onKeyDown={ ( e ) => {
												if ( e.key === 'Enter' ) {
													e.preventDefault();
													addExcludeClass();
												}
											} }
										/>
										<Button
											variant="secondary"
											onClick={ addExcludeClass }
											disabled={
												! newExcludeClass.trim()
											}
										>
											{ __( 'Add', 'guten-nav-plugin' ) }
										</Button>
									</div>
									<div className="class-list">
										{ excludeClasses.map( ( cls ) => (
											<div
												key={ cls }
												className="class-item"
											>
												<span>{ cls }</span>
												<Button
													isSmall
													isDestructive
													onClick={ () =>
														removeExcludeClass(
															cls
														)
													}
												>
													×
												</Button>
											</div>
										) ) }
									</div>
								</BaseControl>
							</div>
						) }
					</PanelBody>

					<PanelBody
						title={ __( 'Preview Options', 'guten-nav-plugin' ) }
						initialOpen={ false }
					>
						<ToggleControl
							label={ __(
								'Show settings preview',
								'guten-nav-plugin'
							) }
							help={ __(
								'Display current filter settings in the editor',
								'guten-nav-plugin'
							) }
							checked={ showPreview }
							onChange={ ( value ) =>
								setAttributes( { showPreview: value } )
							}
						/>
					</PanelBody>
				</InspectorControls>

				<div { ...blockProps }>
					<div className="auto-menu-placeholder">
						<div className="auto-menu-icon">📋</div>
						{ showTitle && menuTitle && (
							<div className="menu-title-preview">
								<strong>
									{ titleLevel.toUpperCase() }: { menuTitle }
								</strong>
							</div>
						) }
						<p>
							{ __(
								'Automatic Menu will be generated from headings',
								'guten-nav-plugin'
							) }
						</p>
						<small>
							{ __(
								'This will scan your page content for headings and create a navigation menu automatically.',
								'guten-nav-plugin'
							) }
						</small>

						{ showPreview && (
							<div className="auto-menu-settings-preview">
								<strong>
									{ __(
										'Current Settings:',
										'guten-nav-plugin'
									) }
								</strong>
								{ showTitle && (
									<div className="setting-item">
										<span>
											{ __(
												'Title:',
												'guten-nav-plugin'
											) }{ ' ' }
										</span>
										<code>
											{ menuTitle || 'Not set' } (
											{ titleLevel.toUpperCase() })
										</code>
									</div>
								) }
								<div className="setting-item">
									<span>
										{ __(
											'Headings:',
											'guten-nav-plugin'
										) }{ ' ' }
									</span>
									<code>
										{ includedHeadings
											.join( ', ' )
											.toUpperCase() }
									</code>
								</div>
								{ classFilterMode === 'include' &&
									includeClasses.length > 0 && (
										<div className="setting-item">
											<span>
												{ __(
													'Include classes:',
													'guten-nav-plugin'
												) }{ ' ' }
											</span>
											<code>
												{ includeClasses.join( ', ' ) }
											</code>
										</div>
									) }
								{ classFilterMode === 'exclude' &&
									excludeClasses.length > 0 && (
										<div className="setting-item">
											<span>
												{ __(
													'Exclude classes:',
													'guten-nav-plugin'
												) }{ ' ' }
											</span>
											<code>
												{ excludeClasses.join( ', ' ) }
											</code>
										</div>
									) }
							</div>
						) }
					</div>
				</div>
			</ErrorBoundary>
		);
	},

	save: ( { attributes } ) => {
		const blockProps = useBlockProps.save( {
			className: 'auto-menu',
		} );

		// Store settings as data attributes for PHP processing
		const {
			menuTitle,
			showTitle,
			titleLevel,
			includedHeadings,
			includeClasses,
			excludeClasses,
			classFilterMode,
		} = attributes;

		return (
			<nav
				{ ...blockProps }
				data-menu-title={ menuTitle }
				data-show-title={ showTitle }
				data-title-level={ titleLevel }
				data-included-headings={ JSON.stringify( includedHeadings ) }
				data-include-classes={ JSON.stringify( includeClasses ) }
				data-exclude-classes={ JSON.stringify( excludeClasses ) }
				data-class-filter-mode={ classFilterMode }
			></nav>
		);
	},
} );
