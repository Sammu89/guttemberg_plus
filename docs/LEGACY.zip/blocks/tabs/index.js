import { registerBlockType } from '@wordpress/blocks';
import {
	useBlockProps,
	InnerBlocks,
	InspectorControls,
} from '@wordpress/block-editor';
import {
	PanelBody,
	Button,
	SelectControl,
	ColorPicker,
	ToggleControl,
	BaseControl,
} from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import ErrorBoundary from '../shared/components/ErrorBoundary';

registerBlockType( 'sammu/tabs', {
	edit: ( { attributes, setAttributes, clientId } ) => {
		const {
			tabCount,
			tabStyle,
			activeTabColor,
			tabAlignment,
			animationStyle,
			showTabIcons,
		} = attributes;

		const blockProps = useBlockProps( {
			className: `tabs-block-editor tabs-style-${ tabStyle } tabs-align-${ tabAlignment }`,
			style: {
				'--active-tab-color': activeTabColor,
			},
		} );

		const addTab = () => {
			setAttributes( { tabCount: tabCount + 1 } );
		};

		const removeTab = () => {
			if ( tabCount > 1 ) {
				setAttributes( { tabCount: tabCount - 1 } );
			}
		};

		// Create template for tab panels
		const template = Array.from( { length: tabCount }, ( _, index ) => [
			'sammu/tab-panel',
			{
				tabIndex: index,
				tabTitle: `Tab ${ index + 1 }`,
				showIcon: showTabIcons,
			},
		] );

		return (
			<ErrorBoundary blockName="Tabs">
				<InspectorControls>
					<PanelBody
						title={ __( 'Tab Management', 'guten-nav-plugin' ) }
						initialOpen={ true }
					>
						<div className="tab-count-controls">
							<Button onClick={ addTab } variant="secondary">
								{ __( 'Add Tab', 'guten-nav-plugin' ) }
							</Button>
							{ tabCount > 1 && (
								<Button
									onClick={ removeTab }
									variant="secondary"
								>
									{ __( 'Remove Tab', 'guten-nav-plugin' ) }
								</Button>
							) }
						</div>
						<div className="tab-count-display">
							{ __( 'Current tabs:', 'guten-nav-plugin' ) }{ ' ' }
							<strong>{ tabCount }</strong>
						</div>
					</PanelBody>

					<PanelBody
						title={ __( 'Tab Style', 'guten-nav-plugin' ) }
						initialOpen={ false }
					>
						<SelectControl
							label={ __( 'Tab Layout', 'guten-nav-plugin' ) }
							value={ tabStyle }
							options={ [
								{
									label: 'Horizontal (default)',
									value: 'horizontal',
								},
								{ label: 'Vertical', value: 'vertical' },
								{ label: 'Pills', value: 'pills' },
								{ label: 'Underline', value: 'underline' },
							] }
							onChange={ ( value ) =>
								setAttributes( { tabStyle: value } )
							}
						/>

						<SelectControl
							label={ __( 'Tab Alignment', 'guten-nav-plugin' ) }
							value={ tabAlignment }
							options={ [
								{ label: 'Left', value: 'left' },
								{ label: 'Center', value: 'center' },
								{ label: 'Right', value: 'right' },
								{ label: 'Justified', value: 'justified' },
							] }
							onChange={ ( value ) =>
								setAttributes( { tabAlignment: value } )
							}
							disabled={ tabStyle === 'vertical' }
						/>

						<BaseControl
							label={ __(
								'Active Tab Color',
								'guten-nav-plugin'
							) }
						>
							<ColorPicker
								color={ activeTabColor }
								onChange={ ( color ) =>
									setAttributes( { activeTabColor: color } )
								}
								disableAlpha
							/>
						</BaseControl>
					</PanelBody>

					<PanelBody
						title={ __( 'Advanced Options', 'guten-nav-plugin' ) }
						initialOpen={ false }
					>
						<SelectControl
							label={ __(
								'Animation Style',
								'guten-nav-plugin'
							) }
							value={ animationStyle }
							options={ [
								{ label: 'None', value: 'none' },
								{ label: 'Fade', value: 'fade' },
								{ label: 'Slide', value: 'slide' },
								{ label: 'Scale', value: 'scale' },
							] }
							onChange={ ( value ) =>
								setAttributes( { animationStyle: value } )
							}
						/>

						<ToggleControl
							label={ __( 'Show tab icons', 'guten-nav-plugin' ) }
							help={ __(
								'Allow each tab to have an optional icon',
								'guten-nav-plugin'
							) }
							checked={ showTabIcons }
							onChange={ ( value ) =>
								setAttributes( { showTabIcons: value } )
							}
						/>
					</PanelBody>
				</InspectorControls>

				<div { ...blockProps }>
					<div className="tabs-editor-header">
						<h4>
							{ __(
								'Tabs Block Configuration',
								'guten-nav-plugin'
							) }
						</h4>
						<div className="tabs-style-preview">
							{ __( 'Style:', 'guten-nav-plugin' ) }{ ' ' }
							<strong>{ tabStyle }</strong> |
							{ __( 'Alignment:', 'guten-nav-plugin' ) }{ ' ' }
							<strong>{ tabAlignment }</strong> |
							{ __( 'Animation:', 'guten-nav-plugin' ) }{ ' ' }
							<strong>{ animationStyle }</strong>
						</div>
					</div>
					<InnerBlocks
						template={ template }
						templateLock="all"
						allowedBlocks={ [ 'sammu/tab-panel' ] }
					/>
				</div>
			</ErrorBoundary>
		);
	},

	save: ( { attributes } ) => {
		const {
			tabStyle,
			activeTabColor,
			tabAlignment,
			animationStyle,
			showTabIcons,
		} = attributes;

		const blockProps = useBlockProps.save( {
			className: `tabs-block tabs-style-${ tabStyle } tabs-align-${ tabAlignment } tabs-animation-${ animationStyle }`,
			style: {
				'--active-tab-color': activeTabColor,
			},
			'data-show-icons': showTabIcons,
		} );

		return (
			<div { ...blockProps }>
				<InnerBlocks.Content />
			</div>
		);
	},
} );
