import { Component } from '@wordpress/element';
import { __ } from '@wordpress/i18n';

/**
 * Global Error Boundary Component for All Blocks
 *
 * Catches React errors in any child component and displays
 * a user-friendly fallback UI instead of breaking the entire editor.
 *
 * Features:
 * - Catches rendering errors in child components
 * - Logs detailed error information to console for debugging
 * - Displays user-friendly error message in the editor
 * - Provides graceful fallback UI
 * - Follows React ErrorBoundary patterns
 * - Handles null/undefined safety for all error properties
 *
 * @example
 * <ErrorBoundary blockName="Accordion">
 *   <YourComponent />
 * </ErrorBoundary>
 */
class ErrorBoundary extends Component {
	constructor( props ) {
		super( props );
		this.state = {
			hasError: false,
			error: null,
			errorInfo: null,
		};
	}

	/**
	 * Update state when an error is caught
	 *
	 * @param {Error} error - The error that was thrown
	 * @return {Object} - New state object
	 */
	static getDerivedStateFromError( error ) {
		return {
			hasError: true,
			error,
		};
	}

	/**
	 * Log error details to console for debugging
	 *
	 * @param {Error}  error     - The error that was thrown
	 * @param {Object} errorInfo - React component stack trace
	 */
	componentDidCatch( error, errorInfo ) {
		const blockName = this.props.blockName || 'Block';

		// Safely log error details to console for debugging
		// eslint-disable-next-line no-console -- Intentional error logging for debugging
		console.error( `${ blockName } Error:`, error || 'Unknown error' );

		if ( errorInfo ) {
			// eslint-disable-next-line no-console -- Intentional error logging for debugging
			console.error( 'Error Info:', errorInfo );

			if ( errorInfo.componentStack ) {
				// eslint-disable-next-line no-console -- Intentional error logging for debugging
				console.error( 'Component Stack:', errorInfo.componentStack );
			}
		}

		// Store error info in state for display if needed
		this.setState( {
			errorInfo,
		} );

		// If custom error handler is provided, call it
		if ( this.props.onError ) {
			this.props.onError( error, errorInfo );
		}
	}

	/**
	 * Reset error state (useful for retry functionality)
	 */
	resetError = () => {
		this.setState( {
			hasError: false,
			error: null,
			errorInfo: null,
		} );
	};

	render() {
		if ( this.state.hasError ) {
			// Custom fallback UI can be provided via props
			if ( this.props.fallback ) {
				return this.props.fallback;
			}

			const blockName = this.props.blockName || 'Block';

			// Default fallback UI
			return (
				<div
					style={ {
						padding: '20px',
						backgroundColor: '#fff3cd',
						border: '2px solid #ffc107',
						borderRadius: '4px',
						margin: '10px 0',
					} }
				>
					<div
						style={ {
							display: 'flex',
							alignItems: 'center',
							marginBottom: '12px',
						} }
					>
						<span
							style={ {
								fontSize: '24px',
								marginRight: '10px',
							} }
						>
							⚠️
						</span>
						<h3
							style={ {
								margin: 0,
								fontSize: '16px',
								fontWeight: '600',
								color: '#856404',
							} }
						>
							{ `${ blockName } ${ __( 'Error', 'guten-nav-plugin' ) }` }
						</h3>
					</div>

					<p
						style={ {
							margin: '0 0 12px 0',
							fontSize: '14px',
							color: '#856404',
							lineHeight: '1.5',
						} }
					>
						{ __(
							'Something went wrong with this block. Please try the following:',
							'guten-nav-plugin'
						) }
					</p>

					<ul
						style={ {
							margin: '0 0 12px 0',
							paddingLeft: '20px',
							fontSize: '13px',
							color: '#856404',
							lineHeight: '1.6',
						} }
					>
						<li>
							{ __(
								'Refresh the page and try again',
								'guten-nav-plugin'
							) }
						</li>
						<li>
							{ __(
								'Check the browser console for detailed error information',
								'guten-nav-plugin'
							) }
						</li>
						<li>
							{ __( 'Remove and re-add the block', 'guten-nav-plugin' ) }
						</li>
						<li>
							{ __(
								'Contact support if the problem persists',
								'guten-nav-plugin'
							) }
						</li>
					</ul>

					{ /* Show error message if available */ }
					{ this.state.error && (
						<details
							style={ {
								marginTop: '12px',
								padding: '10px',
								backgroundColor: '#fff',
								border: '1px solid #ffc107',
								borderRadius: '3px',
								fontSize: '12px',
							} }
						>
							<summary
								style={ {
									cursor: 'pointer',
									fontWeight: '600',
									color: '#856404',
									marginBottom: '8px',
								} }
							>
								{ __(
									'Technical Details (for developers)',
									'guten-nav-plugin'
								) }
							</summary>
							<div
								style={ {
									fontFamily: 'monospace',
									fontSize: '11px',
									color: '#d63638',
									whiteSpace: 'pre-wrap',
									wordBreak: 'break-word',
									marginTop: '8px',
								} }
							>
								<strong>
									{ __( 'Error:', 'guten-nav-plugin' ) }
								</strong>
								<br />
								{ this.state.error?.toString?.() || this.state.error?.message || String( this.state.error ) }

								{ this.state.errorInfo?.componentStack && (
									<>
										<br />
										<br />
										<strong>
											{ __(
												'Component Stack:',
												'guten-nav-plugin'
											) }
										</strong>
										<br />
										{ this.state.errorInfo.componentStack }
									</>
								) }
							</div>
						</details>
					) }

					{ /* Optional retry button */ }
					{ this.props.showRetry && (
						<button
							onClick={ this.resetError }
							style={ {
								marginTop: '12px',
								padding: '8px 16px',
								backgroundColor: '#ffc107',
								border: 'none',
								borderRadius: '3px',
								color: '#856404',
								fontSize: '13px',
								fontWeight: '600',
								cursor: 'pointer',
							} }
						>
							{ __( 'Try Again', 'guten-nav-plugin' ) }
						</button>
					) }
				</div>
			);
		}

		// No error, render children normally
		return this.props.children;
	}
}

export default ErrorBoundary;
