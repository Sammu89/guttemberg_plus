/**
 * Centralized Theme Handlers Hook
 *
 * Provides all theme-related handler functions for blocks
 * Eliminates duplication across accordion, tabs, auto-menu, etc.
 *
 * @module useThemeHandlers
 */

import { useCallback } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { speak } from '@wordpress/a11y';
import { clearAllCustomizations } from '../customization-core/index.js';

/**
 * Hook for centralized theme handler functions
 * Returns all handlers needed for theme management UI
 *
 * @param {string} blockType - Block type identifier (e.g., 'accordion', 'tabs')
 * @param {Object} options - Configuration options
 * @param {Object} options.attributes - Current block attributes
 * @param {Function} options.setAttributes - Function to update attributes
 * @param {Object} options.allThemes - All available themes
 * @param {Object} options.customizationCache - Cache of customized themes
 * @param {Function} options.setCustomizationCache - Function to update cache
 * @param {Array} options.customizationAttributes - Array of customization attribute names
 * @param {Object} options.attributeConfig - Attribute configuration object (e.g., ACCORDION_ATTRIBUTE_CONFIG)
 * @param {Function} options.clearCustomizations - Function to clear customizations
 * @param {Function} options.createTheme - Function to create new theme (from useThemeManagement)
 * @param {Function} options.updateTheme - Function to update theme (from useThemeManagement)
 * @param {Function} options.setSaveNotification - Optional notification setter
 *
 * @returns {Object} Handler functions
 * @returns {Function} return.handleSaveTheme - Save/update existing theme
 * @returns {Function} return.handleRenameTheme - Rename existing theme
 * @returns {Function} return.handleCreateTheme - Create new theme from customizations
 * @returns {Function} return.switchToCleanTheme - Clear customizations and switch theme
 * @returns {Function} return.handleThemeChange - Handle theme dropdown changes
 *
 * @example
 * const {
 *   handleSaveTheme,
 *   handleThemeChange,
 *   switchToCleanTheme,
 * } = useThemeHandlers('accordion', {
 *   attributes,
 *   setAttributes,
 *   allThemes,
 *   customizationCache,
 *   setCustomizationCache,
 *   customizationAttributes: ACCORDION_CUSTOMIZATION_ATTRIBUTES,
 *   clearCustomizations,
 *   createTheme,
 *   updateTheme,
 * });
 */
export default function useThemeHandlers(blockType, options) {
	const {
		attributes,
		setAttributes,
		allThemes,
		customizationCache,
		setCustomizationCache,
		customizationAttributes,
		attributeConfig,
		clearCustomizations,
		createTheme,
		updateTheme,
		setSaveNotification,
	} = options;

	const { selectedTheme, baseTheme, isCustomized } = attributes;

	/**
	 * Clear customizations and switch to clean theme
	 * Shared logic for both "Update theme" and "Save as new theme"
	 */
	const switchToCleanTheme = useCallback(
		(themeId) => {
			// Use shared clearing utility
			clearCustomizations();

			// Update theme IDs
			setAttributes({
				themeId,
				selectedTheme: themeId,
				baseTheme: themeId,
				isCustomized: false,
			});

			// Clear customization cache for this theme
			setCustomizationCache((prev) => {
				const newCache = { ...prev };
				delete newCache[themeId];
				return newCache;
			});
		},
		[clearCustomizations, setAttributes, setCustomizationCache, allThemes]
	);

	/**
	 * Save/update an existing theme with current settings
	 *
	 * ⚠️ CRITICAL: DO NOT MODIFY THIS WORKFLOW WITHOUT CAREFUL CONSIDERATION ⚠️
	 * This function implements the core theme update logic that ensures proper
	 * synchronization between inline customizations, database storage, and UI state.
	 *
	 * THEME ARCHITECTURE - COMPLETE SNAPSHOT SYSTEM
	 * ==============================================
	 *
	 * CORE PRINCIPLE: Every theme is a self-contained complete snapshot with ALL attribute values.
	 * There are NO null values in themes, NO inheritance, and NO cascading between themes.
	 *
	 * 1. THEME STRUCTURE
	 *    - Every theme contains ALL 33+ attributes with real, concrete values (no nulls)
	 *    - Default theme created from theme-default.php on plugin initialization
	 *    - Each theme is completely independent - no parent/child relationships
	 *    - Themes are immutable snapshots - updates create new complete versions
	 *
	 * 2. BLOCK ATTRIBUTES (THE SIMPLE RULE)
	 *    - Clean block: Block attributes are UNDEFINED (removed from HTML)
	 *    - Customized block: Block attributes ARE DEFINED (saved in HTML)
	 *    - Sidebar display: Shows block value OR theme value (simple fallback)
	 *    - No complex logic - just check if attribute exists on block
	 *
	 * 3. VALUE RESOLUTION (SIDEBAR DISPLAY)
	 *    Priority order is simple two-level:
	 *    - First: Check if block has the attribute defined → use it
	 *    - Second: Attribute undefined on block → use theme value
	 *    - NO third level, NO defaults, NO cascading
	 *    - Theme ALWAYS has a value (no nulls), so resolution always succeeds
	 *
	 * 4. CUSTOMIZATION DETECTION (SIMPLE)
	 *    - isCustomized = block has ANY attribute defined (not undefined)
	 *    - No value comparison needed
	 *    - No deep equality checks
	 *    - Just: Object.keys(blockAttributes).some(attr => attr in CUSTOMIZATION_ATTRS)
	 *
	 * UPDATE THEME FLOW:
	 * ==================
	 * This function saves current effective values as a COMPLETE SNAPSHOT
	 *
	 * Step 1: Collect ALL current effective values (block OR theme)
	 *    - For each of 33+ attributes: blockAttributes[attr] ?? theme[attr]
	 *    - Result: Complete object with ALL attributes having real values
	 *    - Example: { headerBackgroundColor: '#ff0000', borderWidth: 2, ... 31 more }
	 *
	 * Step 2: Save complete snapshot to database
	 *    - await updateTheme(themeId, completeSnapshot)
	 *    - Database now stores theme with ALL values (no nulls)
	 *    - Theme is self-contained and independent
	 *
	 * Step 3: Clear ALL block attributes to undefined
	 *    - clearAllCustomizations() removes attributes from block
	 *    - Block HTML now has zero inline attributes
	 *    - setAttributes({ attribute: undefined }) removes from saved HTML
	 *
	 * Step 4: Sidebar now reads from updated theme
	 *    - Block attributes are undefined
	 *    - Sidebar shows: blockAttributes[attr] ?? updatedTheme[attr]
	 *    - Since block attributes are undefined, theme values display
	 *    - Result: Sidebar shows the complete snapshot we just saved
	 *
	 * Step 5: Set isCustomized: false
	 *    - Block has no inline attributes
	 *    - "(custom)" indicator disappears from UI
	 *
	 * SAVE AS NEW THEME FLOW:
	 * =======================
	 * Identical to update, but creates NEW theme instead of modifying existing
	 *
	 * Step 1: Collect ALL current effective values (complete snapshot)
	 * Step 2: Create new theme in database with complete snapshot
	 * Step 3: Switch to new theme (themeId changes)
	 * Step 4: Clear ALL block attributes to undefined
	 * Step 5: Set isCustomized: false
	 *
	 * Result: New independent theme, original theme unchanged, block reads from new theme
	 *
	 * WHY NO NULLS:
	 * =============
	 * - Old system: Themes had nulls → complex 3-level cascade (block → theme → default)
	 * - New system: Themes have all values → simple 2-level (block ?? theme)
	 * - Eliminates: Race conditions, cascade bugs, undefined behavior edge cases
	 * - Simplifies: Customization detection, value resolution, theme updates
	 *
	 * WHY UNDEFINED (NOT NULL) FOR BLOCK ATTRIBUTES:
	 * ===============================================
	 * - undefined = attribute removed from saved HTML (clean)
	 * - null = attribute saved as null in HTML (pollutes saved content)
	 * - setAttributes({ attr: undefined }) removes the attribute
	 * - setAttributes({ attr: null }) saves null to database
	 */
	const handleSaveTheme = useCallback(
		async (themeId, themeData) => {
			try {
				console.log('===================== THEME UPDATE CLICKED =====================');

				// Log toggle values being saved
				const toggles = ['useHeading', 'useHeadingStyles', 'useCustomTitleFormatting', 'showIcon', 'animateIcon'];
				const toggleData = {};
				toggles.forEach(t => {
					if (themeData[t] !== undefined) toggleData[t] = themeData[t];
				});
				console.log('[UPDATE THEME] Toggle values being saved:', toggleData);

				// Get the current theme name from allThemes
				const themeName = allThemes[themeId]?.theme_name || themeId;

				// Step 1: Save customizations to database (update theme)
				// Include _sourceBlockId to prevent double-clearing on the same block
				const result = await updateTheme(themeId, {
					theme_name: themeName,
					...themeData,
					_sourceBlockId: options.clientId
				});

				// Log what came back from server
				const serverToggles = {};
				toggles.forEach(t => {
					if (result?.themes?.[themeId]?.[t] !== undefined) {
						serverToggles[t] = result.themes[themeId][t];
					}
				});
				console.log('[UPDATE THEME] Toggle values from server:', serverToggles);

				// Step 2: Clear ALL customizable attributes to null
				// After this, the block will read from the updated theme in database, not inline customizations
				const { clearAllCustomizations } = await import('../customization-core');
				const updates = clearAllCustomizations(attributes, attributeConfig);

				// Step 3: Apply the updates and mark as not customized
				// The sidebar will now read from the updated theme in database
				setAttributes({
					...updates,
					isCustomized: false,
					baseTheme: themeId,
				});

				// Step 4: Clear customization cache to force re-detection from fresh theme data
				setCustomizationCache((prev) => {
					const newCache = { ...prev };
					delete newCache[themeId];
					return newCache;
				});

				if (setSaveNotification) {
					setSaveNotification({ type: 'success', message: __('Theme updated successfully', 'guten-nav-plugin') });
				}
				return true;
			} catch (error) {
				console.error('[UPDATE THEME] Error:', error);
				if (setSaveNotification) {
					setSaveNotification({ type: 'error', message: error.message });
				}
				return false;
			}
		},
		[updateTheme, allThemes, attributes, attributeConfig, setAttributes, setCustomizationCache, setSaveNotification]
	);

	/**
	 * Rename an existing theme
	 */
	const handleRenameTheme = useCallback(
		async (themeId, newName) => {
			try {
				await updateTheme(themeId, { theme_name: newName });
				if (setSaveNotification) {
					setSaveNotification({ type: 'success', message: __('Theme renamed successfully', 'guten-nav-plugin') });
				}
				return true;
			} catch (error) {
				if (setSaveNotification) {
					setSaveNotification({ type: 'error', message: error.message });
				}
				return false;
			}
		},
		[updateTheme, setSaveNotification]
	);

	/**
	 * Create a new theme from current customizations
	 *
	 * ⚠️ CRITICAL: DO NOT MODIFY THIS WORKFLOW WITHOUT CAREFUL CONSIDERATION ⚠️
	 * This function implements the core theme creation logic that ensures proper
	 * synchronization between inline customizations, database storage, and UI state.
	 *
	 * SAVE AS NEW THEME FLOW:
	 * =======================
	 * Same as UPDATE THEME but creates new theme instead of modifying existing one.
	 * See handleSaveTheme documentation above for complete architecture explanation.
	 *
	 * Step 1: Collect ALL current effective values (complete snapshot)
	 *    - For each of 33+ attributes: blockAttributes[attr] ?? currentTheme[attr]
	 *    - Result: Complete object with ALL attributes having real values
	 *    - This creates a NEW independent theme with no connection to original
	 *
	 * Step 2: Create new theme in database
	 *    - await createTheme(themeName, completeSnapshot)
	 *    - Server generates unique theme ID
	 *    - Database stores complete snapshot with ALL values (no nulls)
	 *
	 * Step 3: Switch to new theme AND clear customizations atomically
	 *    - In ONE setAttributes call: set themeId/baseTheme/selectedTheme AND clear all customizations
	 *    - This prevents race conditions where theme IDs update but customizations remain
	 *    - Block now "points to" new theme with no inline customizations
	 *
	 * Step 4: Sidebar reads from new theme
	 *    - Block attributes are undefined
	 *    - Sidebar displays: blockAttributes[attr] ?? newTheme[attr]
	 *    - Since block attributes undefined, shows new theme values
	 *
	 * Step 5: Set isCustomized: false
	 *    - Clean block state (no inline customizations)
	 *
	 * KEY DIFFERENCE FROM UPDATE THEME:
	 * ==================================
	 * - Update: Overwrites existing theme in database (baseTheme modified)
	 * - Save New: Creates NEW theme, original theme unchanged, switches to new
	 * - Both create complete snapshots, but Update modifies, Save New creates
	 */
	const handleCreateTheme = useCallback(
		async (themeName, themeData) => {
			try {
				console.log('===================== SAVE AS NEW THEME CLICKED =====================');
				console.log('[CREATE THEME] Current attributes BEFORE create:', {
					themeId: attributes.themeId,
					selectedTheme: attributes.selectedTheme,
					baseTheme: attributes.baseTheme,
					headerBackgroundColor: attributes.headerBackgroundColor,
				});

				// Log toggle values being saved
				const toggles = ['useHeading', 'useHeadingStyles', 'useCustomTitleFormatting', 'showIcon', 'animateIcon'];
				const toggleData = {};
				toggles.forEach(t => {
					if (themeData[t] !== undefined) toggleData[t] = themeData[t];
				});
				console.log('[CREATE THEME] Toggle values being saved:', toggleData);

				// Step 1: Create new theme in database with complete snapshot
				console.log('[CREATE THEME] Calling createTheme with data:', {
					themeName,
					headerBackgroundColor: themeData.headerBackgroundColor
				});
				const result = await createTheme(themeName, themeData);

				if (result) {
					const { themeId, themes } = result;
					console.log('[CREATE THEME] Theme created successfully. New themeId:', themeId);

					// Log what came back from server
					const serverToggles = {};
					toggles.forEach(t => {
						if (themes?.[themeId]?.[t] !== undefined) {
							serverToggles[t] = themes[themeId][t];
						}
					});
					console.log('[CREATE THEME] Toggle values from server:', serverToggles);
					console.log('[CREATE THEME] New theme headerBackgroundColor from server:', themes[themeId]?.headerBackgroundColor);

					// Step 2: Clear ALL customizable attributes to undefined
					// After this, the block will read from the new theme in database, not inline customizations
					const { clearAllCustomizations } = await import('../customization-core');
					const updates = clearAllCustomizations(attributes, attributeConfig);
					console.log('[CREATE THEME] Cleared attributes:', updates);
					console.log('[CREATE THEME] headerBackgroundColor in cleared updates:', updates.headerBackgroundColor);

					// Step 3: Switch to new theme AND clear customizations in ONE atomic operation
					// This prevents race conditions where theme IDs are set but customizations aren't cleared
					// The sidebar will now read from the new theme in database
					const finalUpdates = {
						...updates,
						themeId,
						selectedTheme: themeId,
						baseTheme: themeId,
						isCustomized: false,
					};
					console.log('[CREATE THEME] About to call setAttributes with:', finalUpdates);
					console.log('[CREATE THEME] headerBackgroundColor in final updates:', finalUpdates.headerBackgroundColor);

					setAttributes(finalUpdates);

					console.log('[CREATE THEME] setAttributes called. Checking attributes after call:', {
						themeId: attributes.themeId,
						selectedTheme: attributes.selectedTheme,
						baseTheme: attributes.baseTheme,
						headerBackgroundColor: attributes.headerBackgroundColor,
					});

					// Step 4: Clear customization cache to force re-detection from fresh theme data
					setCustomizationCache((prev) => {
						const newCache = { ...prev };
						delete newCache[themeId];
						return newCache;
					});

					if (setSaveNotification) {
						setSaveNotification({ type: 'success', message: __('Theme created successfully', 'guten-nav-plugin') });
					}
				}
				return result;
			} catch (error) {
				console.error('[CREATE THEME] Error:', error);
				if (setSaveNotification) {
					setSaveNotification({ type: 'error', message: error.message });
				}
				return null;
			}
		},
		[createTheme, attributes, attributeConfig, setAttributes, setCustomizationCache, setSaveNotification]
	);

	/**
	 * Handle theme selection changes from dropdown
	 * Manages customization cache and theme switching
	 */
	const handleThemeChange = useCallback(
		(value) => {
			// If user selected "{themeId}-customized", restore customizations from cache
			if (value.endsWith('-customized')) {
				const themeId = value.replace('-customized', '');
				const cachedCustomizations = customizationCache[themeId];

				if (cachedCustomizations) {
					// Restore all customizations from cache (transient, not saved until post save)
					setAttributes({
						selectedTheme: themeId,
						...cachedCustomizations,
					});

					// Announce theme change to screen readers
					const themeName = allThemes[themeId]?.theme_name || themeId;
					speak(
						__(`Theme changed to ${themeName} with customizations`, 'guten-nav-plugin'),
						'polite'
					);
				}
				return;
			}

			// Before switching away from customized theme, save to cache
			if (isCustomized && selectedTheme === baseTheme) {
				const currentCustomizations = {};
				customizationAttributes.forEach((attr) => {
					currentCustomizations[attr] = attributes[attr];
				});

				// Store in transient cache (not saved to DB until user saves post)
				setCustomizationCache((prev) => ({
					...prev,
					[baseTheme]: {
						...currentCustomizations,
						isCustomized: true,
						baseTheme,
					},
				}));
			}

			// User selected a clean theme (not customized version)
			// Clear customization attributes and apply the selected theme in ONE atomic operation
			const clearedAttributes = clearAllCustomizations(attributes, attributeConfig);

			// Combine theme IDs with cleared customizations in single setAttributes call
			setAttributes({
				...clearedAttributes,
				selectedTheme: value,
				baseTheme: value,
				isCustomized: false,
			});

			// Announce theme change to screen readers
			const themeName = allThemes[value]?.theme_name || value;
			speak(__(`Theme changed to ${themeName}`, 'guten-nav-plugin'), 'polite');

			// Note: If user saves now, customizations are gone forever
			// If user switches back to "{theme}-customized", they're restored from cache
		},
		[
			customizationCache,
			isCustomized,
			selectedTheme,
			baseTheme,
			attributes,
			setAttributes,
			setCustomizationCache,
			allThemes,
			clearCustomizations,
			customizationAttributes,
		]
	);

	return {
		handleSaveTheme,
		handleRenameTheme,
		handleCreateTheme,
		switchToCleanTheme,
		handleThemeChange,
	};
}
