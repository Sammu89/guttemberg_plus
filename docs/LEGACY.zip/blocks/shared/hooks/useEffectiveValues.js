/**
 * React hook for computing effective values with 4-tier cascade
 * Per section 3.2 of ACCORDION-THEME-SYSTEM-V2-SPEC.md
 *
 * @module useEffectiveValues
 */

import { useMemo } from '@wordpress/element';
import { computeEffectiveValues } from '../customization-core/index.js';

/**
 * Hook that resolves ALL attributes at once for editor rendering
 * Uses 4-tier cascade: block → page style → theme → default
 *
 * @param {Object} attributes - Block attributes from edit component
 * @param {Object} allThemes - All available themes (including default)
 * @param {Object} pageStyles - Page styles for current post
 * @param {Object} attributeConfig - Block's ATTRIBUTE_CONFIG
 * @returns {Object} Effective values for all attributes
 *
 * @example
 * function Edit({ attributes }) {
 *   const effectiveValues = useEffectiveValues(
 *     attributes,
 *     allThemes,
 *     pageStyles,
 *     ACCORDION_ATTRIBUTE_CONFIG
 *   );
 *   // effectiveValues now contains resolved values from 4-tier cascade
 * }
 */
export default function useEffectiveValues(
    attributes,
    allThemes,
    pageStyles,
    attributeConfig
) {
    const { selectedTheme, _pageStyleRef } = attributes;

    return useMemo(() => {
        const theme = allThemes[selectedTheme] || allThemes['default'];
        const defaultTheme = allThemes['default'];
        const pageStyle = _pageStyleRef ? pageStyles[_pageStyleRef] : null;

        const effectiveValues = {};

        Object.keys(attributeConfig).forEach(attr => {
            effectiveValues[attr] = computeEffectiveValue(
                attr,
                attributes,
                pageStyle,
                theme,
                defaultTheme,
                attributeConfig
            );
        });

        console.log('[EFFECTIVE VALUES]', effectiveValues);
        return effectiveValues;
    }, [attributes, allThemes, pageStyles, attributeConfig, selectedTheme, _pageStyleRef]);
}

// Need to import computeEffectiveValue directly
import { computeEffectiveValue } from '../customization-core/attribute-resolver.js';
