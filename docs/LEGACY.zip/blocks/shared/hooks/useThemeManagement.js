/**
 * React hook for managing themes across blocks
 * Generic theme CRUD operations with WordPress AJAX integration
 *
 * @module useThemeManagement
 */

import { useState, useEffect, useCallback } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { loadThemes, saveTheme, updateTheme, deleteTheme } from '../utils/ajax-adapter.js';
import { prepareThemeForStorage, generateThemeId } from '../customization-core/index.js';

/**
 * Hook for managing block themes with AJAX operations
 * Provides complete theme lifecycle management: load, create, update, delete
 *
 * @param {string} blockType - Block type identifier (e.g., 'accordion', 'tabs')
 * @param {Object} options - Configuration options
 * @param {Object} options.attributeConfig - Block's ATTRIBUTE_CONFIG
 * @param {string} options.currentThemeId - Currently selected theme ID
 * @param {Function} options.onThemeChange - Callback when theme changes
 * @returns {Object} Theme state and operations
 * @returns {Object} return.themes - All available themes keyed by ID
 * @returns {Object|null} return.currentTheme - Currently selected theme object
 * @returns {boolean} return.isLoading - Whether themes are being loaded
 * @returns {boolean} return.isSaving - Whether a theme is being saved
 * @returns {boolean} return.isDeleting - Whether a theme is being deleted
 * @returns {string|null} return.error - Current error message
 * @returns {Function} return.loadThemes - Reload themes from server
 * @returns {Function} return.createTheme - Create new theme
 * @returns {Function} return.saveTheme - Save theme changes
 * @returns {Function} return.updateTheme - Update existing theme
 * @returns {Function} return.deleteTheme - Delete theme
 * @returns {Function} return.setError - Set error message
 *
 * @example
 * const { themes, currentTheme, createTheme, updateTheme } = useThemeManagement('accordion', {
 *   attributeConfig: ACCORDION_ATTRIBUTE_CONFIG,
 *   currentThemeId: attributes.themeId,
 *   onThemeChange: (themeId) => setAttributes({ themeId })
 * });
 */
export default function useThemeManagement(blockType, options = {}) {
	const { attributeConfig, currentThemeId, onThemeChange } = options;

	// State
	const [themes, setThemes] = useState({});
	const [isLoading, setIsLoading] = useState(true);
	const [isSaving, setIsSaving] = useState(false);
	const [isDeleting, setIsDeleting] = useState(false);
	const [error, setError] = useState(null);

	// Get current theme object from themes
	const currentTheme = currentThemeId && themes[currentThemeId] ? themes[currentThemeId] : null;

	/**
	 * Load all themes from server
	 */
	const loadThemesFromServer = useCallback(async () => {
		setIsLoading(true);
		setError(null);

		try {
			const data = await loadThemes(blockType);

			if (data?.themes) {
				setThemes(data.themes);
				setError(null);
			} else {
				throw new Error('Invalid theme data received from server');
			}
		} catch (err) {
			console.error('Error loading themes:', err);
			const errorMessage = err.message || 'Failed to load themes. Please refresh and try again.';
			setError(errorMessage);

			// Set fallback empty themes object
			setThemes({});
		} finally {
			setIsLoading(false);
		}
	}, [blockType]);

	// Load themes on mount
	useEffect(() => {
		loadThemesFromServer();
	}, [loadThemesFromServer]);

	// Listen for theme updates from other blocks
	useEffect(() => {
		const eventName = `${blockType}ThemeUpdated`;

		const handleThemeUpdate = (event) => {
			const { themes: updatedThemes } = event.detail || {};
			if (updatedThemes) {
				setThemes(updatedThemes);
			}
		};

		window.addEventListener(eventName, handleThemeUpdate);

		return () => {
			window.removeEventListener(eventName, handleThemeUpdate);
		};
	}, [blockType]);

	/**
	 * Create a new theme from current block attributes
	 */
	const createThemeFromAttributes = useCallback(
		async (themeName, blockAttributes) => {
			if (!themeName || !themeName.trim()) {
				const errorMsg = __('Theme name cannot be empty.', 'guten-nav-plugin');
				setError(errorMsg);
				return null;
			}

			if (!attributeConfig) {
				const errorMsg = __('Attribute configuration is missing.', 'guten-nav-plugin');
				setError(errorMsg);
				return null;
			}

			setIsSaving(true);
			setError(null);

			try {
				// Generate unique theme ID
				const themeId = generateThemeId();

				// Prepare theme data from block attributes
				const themeData = prepareThemeForStorage(blockAttributes, attributeConfig);
				themeData.theme_name = themeName.trim();

				// Save to server
				const data = await saveTheme(blockType, themeId, themeData);

				if (data?.themes) {
					setThemes(data.themes);
					setError(null);

					// Dispatch event to notify other blocks
					const event = new CustomEvent(`${blockType}ThemeUpdated`, {
						detail: { themeId, themes: data.themes, operation: 'create' },
					});
					window.dispatchEvent(event);

					// NOTE: We do NOT call onThemeChange here for theme creation
					// The caller (handleCreateTheme in useThemeHandlers) handles the full state transition
					// including setting theme IDs and clearing customizations in the correct order
					// Calling onThemeChange here causes a race condition where theme IDs are set
					// but customizations aren't cleared yet, leading to customization leakage

					return { themeId, themes: data.themes };
				}

				throw new Error('Invalid response from server');
			} catch (err) {
				console.error('Error creating theme:', err);
				const errorMessage = err.message || 'Failed to create theme. Please try again.';
				setError(errorMessage);
				return null;
			} finally {
				setIsSaving(false);
			}
		},
		[blockType, attributeConfig, onThemeChange]
	);

	/**
	 * Update an existing theme with new values
	 */
	const updateThemeData = useCallback(
		async (themeId, updates) => {
			if (!themeId) {
				const errorMsg = __('Theme ID is required.', 'guten-nav-plugin');
				setError(errorMsg);
				return null;
			}

			if (themeId === 'default') {
				const errorMsg = __('Default theme cannot be edited.', 'guten-nav-plugin');
				setError(errorMsg);
				return null;
			}

			if (!attributeConfig) {
				const errorMsg = __('Attribute configuration is missing.', 'guten-nav-plugin');
				setError(errorMsg);
				return null;
			}

			setIsSaving(true);
			setError(null);

			try {
				// Prepare updates for storage
				const preparedUpdates = prepareThemeForStorage(updates, attributeConfig);

				// Update on server
				const data = await updateTheme(blockType, themeId, preparedUpdates);

				if (data?.themes) {
					setThemes(data.themes);
					setError(null);

					// Dispatch event to notify other blocks
					// Include sourceBlockId so the block that triggered the update can ignore it
					const event = new CustomEvent(`${blockType}ThemeUpdated`, {
						detail: {
							themeId,
							themes: data.themes,
							operation: 'update',
							sourceBlockId: updates._sourceBlockId || null
						},
					});
					window.dispatchEvent(event);

					return { themes: data.themes };
				}

				throw new Error('Invalid response from server');
			} catch (err) {
				console.error('Error updating theme:', err);
				const errorMessage = err.message || 'Failed to update theme. Please try again.';
				setError(errorMessage);
				return null;
			} finally {
				setIsSaving(false);
			}
		},
		[blockType, attributeConfig]
	);

	/**
	 * Delete a theme
	 */
	const deleteThemeById = useCallback(
		async (themeId) => {
			if (!themeId) {
				const errorMsg = __('Theme ID is required.', 'guten-nav-plugin');
				setError(errorMsg);
				return false;
			}

			if (themeId === 'default') {
				const errorMsg = __('Cannot delete default theme.', 'guten-nav-plugin');
				setError(errorMsg);
				return false;
			}

			const themeName = themes[themeId]?.theme_name || themeId;
			const confirmMsg = __(`Delete theme "${themeName}"? This cannot be undone.`, 'guten-nav-plugin');

			if (!window.confirm(confirmMsg)) {
				return false;
			}

			setIsDeleting(true);
			setError(null);

			try {
				const data = await deleteTheme(blockType, themeId);

				if (data?.themes) {
					setThemes(data.themes);
					setError(null);

					// Dispatch event to notify other blocks
					const event = new CustomEvent(`${blockType}ThemeUpdated`, {
						detail: { themeId, themes: data.themes, operation: 'delete' },
					});
					window.dispatchEvent(event);

					// If deleted theme was currently selected, clear selection
					if (currentThemeId === themeId && onThemeChange) {
						onThemeChange('');
					}

					return true;
				}

				throw new Error('Invalid response from server');
			} catch (err) {
				console.error('Error deleting theme:', err);
				const errorMessage = err.message || 'Failed to delete theme. Please try again.';
				setError(errorMessage);
				return false;
			} finally {
				setIsDeleting(false);
			}
		},
		[blockType, themes, currentThemeId, onThemeChange]
	);

	return {
		themes,
		currentTheme,
		isLoading,
		isSaving,
		isDeleting,
		error,
		setError,
		loadThemes: loadThemesFromServer,
		createTheme: createThemeFromAttributes,
		updateTheme: updateThemeData,
		deleteTheme: deleteThemeById,
	};
}
