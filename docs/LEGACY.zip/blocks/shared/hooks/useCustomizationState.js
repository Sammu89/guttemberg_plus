/**
 * React hook for customization detection and clearing
 * Combines detection logic with clearing operations
 *
 * @module useCustomizationState
 */

import { useMemo, useCallback } from '@wordpress/element';
import {
	hasAnyCustomizations,
	detectAllCustomizations,
	getCustomizationsBySection,
	clearAllCustomizations,
	clearAttributesBySection,
	clearAttributesByList,
} from '../customization-core/index.js';

/**
 * Hook that provides customization state and clearing utilities
 *
 * @param {Object} attributes - Block attributes from edit component
 * @param {Object|null} theme - Current theme object (can be null)
 * @param {Object} attributeConfig - Block's ATTRIBUTE_CONFIG
 * @param {Function} setAttributes - WordPress setAttributes function
 * @returns {Object} Customization state and operations
 * @returns {boolean} return.hasCustomizations - True if any attribute is customized
 * @returns {Array<string>} return.customizedAttributes - Array of customized attribute names
 * @returns {Object} return.customizationsBySection - Customizations grouped by section
 * @returns {Function} return.clearCustomizations - Clears all customizations
 * @returns {Function} return.clearSection - Clears customizations in a specific section
 * @returns {Function} return.clearAttributes - Clears specific list of attributes
 *
 * @example
 * function Edit({ attributes, setAttributes }) {
 *   const { hasCustomizations, clearCustomizations, clearSection } =
 *     useCustomizationState(
 *       attributes,
 *       currentTheme,
 *       ACCORDION_ATTRIBUTE_CONFIG,
 *       setAttributes
 *     );
 *
 *   return (
 *     <>
 *       {hasCustomizations && (
 *         <Button onClick={clearCustomizations}>
 *           Clear All Customizations
 *         </Button>
 *       )}
 *       <Button onClick={() => clearSection('colors')}>
 *         Clear Color Customizations
 *       </Button>
 *     </>
 *   );
 * }
 */
export default function useCustomizationState(attributes, theme, attributeConfig, setAttributes) {
	// Detect if there are any customizations
	const hasCustomizations = useMemo(() => {
		return hasAnyCustomizations(attributes, theme, attributeConfig);
	}, [attributes, theme, attributeConfig]);

	// Get list of customized attributes
	const customizedAttributes = useMemo(() => {
		return detectAllCustomizations(attributes, theme, attributeConfig);
	}, [attributes, theme, attributeConfig]);

	// Get customizations grouped by section
	const customizationsBySection = useMemo(() => {
		return getCustomizationsBySection(attributes, theme, attributeConfig);
	}, [attributes, theme, attributeConfig]);

	// Clear all customizations
	const clearCustomizations = useCallback(() => {
		const updates = clearAllCustomizations(attributes, attributeConfig);
		if (Object.keys(updates).length > 0) {
			setAttributes(updates);
		}
	}, [attributes, attributeConfig, setAttributes]);

	// Clear customizations in a specific section
	const clearSection = useCallback(
		(section) => {
			const updates = clearAttributesBySection(section, attributes, attributeConfig);
			if (Object.keys(updates).length > 0) {
				setAttributes(updates);
			}
		},
		[attributes, attributeConfig, setAttributes]
	);

	// Clear specific list of attributes
	const clearAttributes = useCallback(
		(attributeNames) => {
			const updates = clearAttributesByList(attributeNames, attributes, attributeConfig);
			if (Object.keys(updates).length > 0) {
				setAttributes(updates);
			}
		},
		[attributes, attributeConfig, setAttributes]
	);

	return {
		hasCustomizations,
		customizedAttributes,
		customizationsBySection,
		clearCustomizations,
		clearSection,
		clearAttributes,
	};
}
