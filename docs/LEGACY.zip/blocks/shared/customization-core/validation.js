/**
 * Validation utilities for attribute configurations and values
 *
 * @module validation
 */

import { ERROR_MESSAGES, VALID_ATTRIBUTE_TYPES } from './constants.js';

/**
 * Validates an attribute configuration object
 * Ensures config has required structure and valid types
 *
 * @param {Object} attributeConfig - The attribute configuration to validate
 * @returns {{valid: boolean, errors: Array<string>}} Validation result
 *
 * @example
 * const config = {
 *   headerColor: { type: 'string', defaultValue: null, section: 'colors' }
 * };
 * const result = validateAttributeConfig(config);
 * if (!result.valid) {
 *   console.error(result.errors);
 * }
 */
export function validateAttributeConfig(attributeConfig) {
	const errors = [];

	if (!attributeConfig || typeof attributeConfig !== 'object') {
		errors.push(ERROR_MESSAGES.INVALID_ATTRIBUTE_CONFIG);
		return { valid: false, errors };
	}

	Object.entries(attributeConfig).forEach(([attrName, config]) => {
		if (!config || typeof config !== 'object') {
			errors.push(`Attribute "${attrName}": configuration must be an object`);
			return;
		}

		// Validate type field
		if (!config.type) {
			errors.push(`Attribute "${attrName}": missing required "type" field`);
		} else if (!VALID_ATTRIBUTE_TYPES.includes(config.type)) {
			errors.push(
				`Attribute "${attrName}": invalid type "${config.type}". Must be one of: ${VALID_ATTRIBUTE_TYPES.join(', ')}`
			);
		}

		// Validate defaultValue exists
		if (!('defaultValue' in config)) {
			errors.push(`Attribute "${attrName}": missing required "defaultValue" field`);
		}

		// Validate section is string if present
		if (config.section && typeof config.section !== 'string') {
			errors.push(`Attribute "${attrName}": "section" must be a string`);
		}

		// Validate childAttributes is array if present
		if (config.childAttributes && !Array.isArray(config.childAttributes)) {
			errors.push(`Attribute "${attrName}": "childAttributes" must be an array`);
		}

		// Validate treatFalseAsCustomization is boolean if present
		if (
			config.treatFalseAsCustomization !== undefined &&
			typeof config.treatFalseAsCustomization !== 'boolean'
		) {
			errors.push(`Attribute "${attrName}": "treatFalseAsCustomization" must be a boolean`);
		}
	});

	return {
		valid: errors.length === 0,
		errors,
	};
}

/**
 * Validates an attribute value against its configuration
 * Checks type compatibility and basic constraints
 *
 * @param {string} attributeName - Name of the attribute
 * @param {*} value - Value to validate
 * @param {Object} attributeConfig - The attribute configuration
 * @returns {{valid: boolean, error: string|null}} Validation result
 *
 * @example
 * const result = validateAttributeValue('borderWidth', 5, config);
 * if (!result.valid) {
 *   console.error(result.error);
 * }
 */
export function validateAttributeValue(attributeName, value, attributeConfig) {
	if (!attributeConfig[attributeName]) {
		return {
			valid: false,
			error: `${ERROR_MESSAGES.INVALID_ATTRIBUTE_NAME}: "${attributeName}"`,
		};
	}

	const config = attributeConfig[attributeName];
	const expectedType = config.type;

	// Null and undefined are always valid (revert to default)
	if (value === null || value === undefined) {
		return { valid: true, error: null };
	}

	// Type checking
	const actualType = Array.isArray(value) ? 'array' : typeof value;

	if (expectedType === 'number') {
		if (typeof value !== 'number' || isNaN(value)) {
			return {
				valid: false,
				error: `Attribute "${attributeName}": expected number, got ${actualType}`,
			};
		}
	} else if (expectedType === 'boolean') {
		if (typeof value !== 'boolean') {
			return {
				valid: false,
				error: `Attribute "${attributeName}": expected boolean, got ${actualType}`,
			};
		}
	} else if (expectedType === 'string') {
		if (typeof value !== 'string') {
			return {
				valid: false,
				error: `Attribute "${attributeName}": expected string, got ${actualType}`,
			};
		}
	} else if (expectedType === 'array') {
		if (!Array.isArray(value)) {
			return {
				valid: false,
				error: `Attribute "${attributeName}": expected array, got ${actualType}`,
			};
		}
	} else if (expectedType === 'object') {
		if (typeof value !== 'object' || Array.isArray(value)) {
			return {
				valid: false,
				error: `Attribute "${attributeName}": expected object, got ${actualType}`,
			};
		}
	}

	return { valid: true, error: null };
}

/**
 * Sanitizes an attribute value based on its type
 * Ensures value is safe and properly formatted
 *
 * @param {string} attributeName - Name of the attribute
 * @param {*} value - Value to sanitize
 * @param {Object} attributeConfig - The attribute configuration
 * @returns {*} Sanitized value
 *
 * @example
 * const clean = sanitizeAttributeValue('borderWidth', '5', config);
 * // Returns: 5 (number)
 */
export function sanitizeAttributeValue(attributeName, value, attributeConfig) {
	if (!attributeConfig[attributeName]) {
		return null;
	}

	const config = attributeConfig[attributeName];
	const expectedType = config.type;

	// Null and undefined pass through
	if (value === null || value === undefined) {
		return value;
	}

	// Type coercion
	switch (expectedType) {
		case 'number':
			const num = Number(value);
			return isNaN(num) ? config.defaultValue : num;

		case 'boolean':
			if (typeof value === 'boolean') return value;
			if (typeof value === 'string') {
				return value === 'true' || value === '1';
			}
			return Boolean(value);

		case 'string':
			return String(value);

		case 'array':
			return Array.isArray(value) ? value : config.defaultValue;

		case 'object':
			return typeof value === 'object' && !Array.isArray(value) ? value : config.defaultValue;

		default:
			return value;
	}
}
