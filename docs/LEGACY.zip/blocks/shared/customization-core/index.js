/**
 * Customization Core - Public API
 *
 * Centralized theme management, attribute resolution, and customization detection
 * for Gutenberg blocks. Framework-agnostic pure JavaScript.
 *
 * ARCHITECTURE: COMPLETE SNAPSHOT SYSTEM
 * =======================================
 * - Every theme is a complete snapshot with ALL attribute values (no nulls)
 * - Block attributes are undefined (removed) when using clean theme
 * - Value resolution is simple 2-level: block ?? theme (no cascading)
 * - Customization detection is simple: block has ANY attribute defined
 *
 * @module customization-core
 */

// Attribute Resolution
export {
	resolveValueWithPriority,
	computeEffectiveValue,
	computeEffectiveValues,
} from './attribute-resolver.js';

// Customization Detection
export {
	isAttributeCustomized,
	detectAllCustomizations,
	hasAnyCustomizations,
	getCustomizationsBySection,
} from './customization-detector.js';

// Attribute Operations
export {
	getAttributeDefaultValue,
	clearAttributesByList,
	clearAttributesBySection,
	clearAllCustomizations,
	resetAttributeToDefault,
} from './attribute-operations.js';

// Theme Management
export {
	normalizeThemeData,
	validateThemeStructure,
	mergeThemeData,
	extractCustomizationAttributes,
	prepareThemeForStorage,
	generateThemeId,
} from './theme-manager.js';

// Validation
export {
	validateAttributeConfig,
	validateAttributeValue,
	sanitizeAttributeValue,
} from './validation.js';

// Constants
export { ERROR_MESSAGES, VALID_ATTRIBUTE_TYPES, DEFAULT_SECTION, RESERVED_THEME_KEYS } from './constants.js';
