/**
 * Customization detection logic
 * Determines if attributes differ from theme/default values
 *
 * @module customization-detector
 */

/**
 * Checks if a single attribute is customized
 * An attribute is customized if its block value differs from theme value (or default if no theme)
 *
 * UNIFIED LOGIC: All attributes follow the same rule: blockValue !== themeValue → customized
 * No special cases for booleans, toggles, or strings.
 *
 * For toggles: Compare toggle value first. If toggle matches theme, check children (only when toggle is true).
 *
 * @param {string} attributeName - Name of the attribute
 * @param {Object} blockAttributes - All block attributes
 * @param {Object|null} theme - Theme data (can be null)
 * @param {Object} attributeConfig - Attribute configuration
 * @returns {boolean} True if attribute is customized
 *
 * @example
 * const isCustomized = isAttributeCustomized(
 *   'headerBackgroundColor',
 *   { headerBackgroundColor: '#ff0000' },
 *   { headerBackgroundColor: '#00ff00' },
 *   config
 * );
 * // Returns: true (block value differs from theme)
 *
 * @example
 * // Toggle attribute - toggle value itself is compared
 * const isCustomized = isAttributeCustomized(
 *   'showIcon',
 *   { showIcon: false },
 *   { showIcon: true },
 *   config
 * );
 * // Returns: true (toggle value changed)
 */
export function isAttributeCustomized(attributeName, blockAttributes, theme, attributeConfig) {
	if (!attributeConfig[attributeName]) {
		return false;
	}

	const config = attributeConfig[attributeName];

	// SIMPLE SNAPSHOT LOGIC: Block is customized if it has ANY value for this attribute
	// undefined = not customized (using theme value)
	// anything else = customized (block has inline value)
	const blockValue = blockAttributes[attributeName];
	const hasBlockValue = blockValue !== undefined;

	if (!hasBlockValue) {
		return false;
	}

	// For toggle attributes: If toggle has value, check children too
	if (config.isToggle && config.childAttributes) {
		// Toggle itself is customized (has value on block)
		// Also check if any children are customized
		const anyChildCustomized = config.childAttributes.some((childAttr) => {
			return isAttributeCustomized(childAttr, blockAttributes, theme, attributeConfig);
		});

		// Customized if toggle value exists OR any child is customized
		return true || anyChildCustomized; // Toggle having value means customized
	}

	// For non-toggle: having any value = customized
	return true;
}

/**
 * Detects all customized attributes
 * Returns array of attribute names that are customized
 *
 * @param {Object} blockAttributes - All block attributes
 * @param {Object|null} theme - Theme data (can be null)
 * @param {Object} attributeConfig - Attribute configuration
 * @returns {Array<string>} Array of customized attribute names
 *
 * @example
 * const customized = detectAllCustomizations(
 *   { headerBackgroundColor: '#ff0000', borderWidth: 2 },
 *   { headerBackgroundColor: '#00ff00', borderWidth: 2 },
 *   config
 * );
 * // Returns: ['headerBackgroundColor']
 */
export function detectAllCustomizations(blockAttributes, theme, attributeConfig) {
	const customizedAttributes = [];

	Object.keys(attributeConfig).forEach((attributeName) => {
		if (isAttributeCustomized(attributeName, blockAttributes, theme, attributeConfig)) {
			customizedAttributes.push(attributeName);
		}
	});

	return customizedAttributes;
}

/**
 * Checks if there are ANY customizations
 * More efficient than detectAllCustomizations when only need boolean result
 *
 * @param {Object} blockAttributes - All block attributes
 * @param {Object|null} theme - Theme data (can be null)
 * @param {Object} attributeConfig - Attribute configuration
 * @returns {boolean} True if any attribute is customized
 *
 * @example
 * const hasAny = hasAnyCustomizations(attributes, theme, config);
 * if (hasAny) {
 *   // Show "Clear Customizations" button
 * }
 */
export function hasAnyCustomizations(blockAttributes, theme, attributeConfig) {
	return Object.keys(attributeConfig).some((attributeName) => {
		return isAttributeCustomized(attributeName, blockAttributes, theme, attributeConfig);
	});
}

/**
 * Gets customizations grouped by section
 * Useful for section-specific clear operations
 *
 * @param {Object} blockAttributes - All block attributes
 * @param {Object|null} theme - Theme data (can be null)
 * @param {Object} attributeConfig - Attribute configuration
 * @returns {Object} Object with sections as keys, arrays of attribute names as values
 *
 * @example
 * const bySec = getCustomizationsBySection(attributes, theme, config);
 * // Returns: { colors: ['headerBackgroundColor'], border: ['borderWidth'] }
 */
export function getCustomizationsBySection(blockAttributes, theme, attributeConfig) {
	const sections = {};

	Object.entries(attributeConfig).forEach(([attributeName, config]) => {
		if (isAttributeCustomized(attributeName, blockAttributes, theme, attributeConfig)) {
			const section = config.section || 'general';

			if (!sections[section]) {
				sections[section] = [];
			}

			sections[section].push(attributeName);
		}
	});

	return sections;
}
