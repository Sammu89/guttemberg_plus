/**
 * Attribute value resolution - 4-tier cascade system
 * Per section 3 of ACCORDION-THEME-SYSTEM-V2-SPEC.md
 *
 * ARCHITECTURE: 4-TIER CASCADE
 * ============================
 * Tier 3: Inline block customization (highest priority)
 * Tier 2: Page style override (delta from base theme)
 * Tier 1: Selected global theme (complete snapshot)
 * Tier 0: Default theme (fallback, always has value)
 *
 * @module attribute-resolver
 */

/**
 * Resolves effective value with 4-tier cascade
 * Per section 3.1 of spec
 *
 * @param {string} attributeName - Attribute to resolve
 * @param {Object} blockAttributes - Block's inline attributes
 * @param {Object|null} pageStyle - Page style object (from post meta)
 * @param {Object|null} selectedTheme - Selected global theme
 * @param {Object|null} defaultTheme - Default theme (fallback)
 * @param {Object} [attributeConfig] - Optional attribute config for config defaults
 * @returns {*} Effective value for attribute
 */
export function computeEffectiveValue(
    attributeName,
    blockAttributes,
    pageStyle,
    selectedTheme,
    defaultTheme,
    attributeConfig
) {
    console.log(`[RESOLVE] ${attributeName}`, {
        block: blockAttributes[attributeName],
        pageStyle: pageStyle?.overrides?.[attributeName],
        theme: selectedTheme?.[attributeName],
        default: defaultTheme?.[attributeName]
    });

    // Tier 3: Inline block customization (highest priority)
    if (blockAttributes[attributeName] !== undefined) {
        console.log(`[RESOLVE] ✓ Using block inline: ${blockAttributes[attributeName]}`);
        return blockAttributes[attributeName];
    }

    // Tier 2: Page style override
    if (pageStyle?.overrides?.[attributeName] !== undefined) {
        console.log(`[RESOLVE] ✓ Using page style: ${pageStyle.overrides[attributeName]}`);
        return pageStyle.overrides[attributeName];
    }

    // Tier 1: Selected global theme
    if (selectedTheme?.[attributeName] !== undefined) {
        console.log(`[RESOLVE] ✓ Using theme: ${selectedTheme[attributeName]}`);
        return selectedTheme[attributeName];
    }

    // Tier 0: Default theme (fallback - may be undefined during initial load)
    if (defaultTheme?.[attributeName] !== undefined) {
        console.log(`[RESOLVE] ✓ Using default theme: ${defaultTheme[attributeName]}`);
        return defaultTheme[attributeName];
    }

    // Tier -1: Attribute config default value (when themes haven't loaded yet)
    if (attributeConfig?.[attributeName]?.defaultValue !== undefined) {
        console.log(`[RESOLVE] ✓ Using config default: ${attributeConfig[attributeName].defaultValue}`);
        return attributeConfig[attributeName].defaultValue;
    }

    // If all tiers are undefined (e.g., during theme loading), return undefined
    console.log(`[RESOLVE] ⚠ All tiers undefined for ${attributeName}, returning undefined`);
    return undefined;
}

/**
 * Legacy function - kept for backwards compatibility
 * @deprecated Use computeEffectiveValue with 4-tier cascade instead
 */
export function resolveValueWithPriority(blockValue, themeValue, defaultValue) {
	if (blockValue !== undefined) {
		return blockValue;
	}
	return themeValue !== undefined ? themeValue : defaultValue;
}

/**
 * Computes effective values for ALL attributes in config
 * Uses 4-tier cascade for each attribute
 *
 * @param {Object} blockAttributes - All block attributes
 * @param {Object|null} pageStyle - Page style object (from post meta)
 * @param {Object|null} selectedTheme - Selected global theme
 * @param {Object} defaultTheme - Default theme (fallback)
 * @param {Object} attributeConfig - Attribute configuration
 * @returns {Object} Object with effective values for all attributes
 */
export function computeEffectiveValues(
    blockAttributes,
    pageStyle,
    selectedTheme,
    defaultTheme,
    attributeConfig
) {
	const effectiveValues = {};

	Object.keys(attributeConfig).forEach((attributeName) => {
		effectiveValues[attributeName] = computeEffectiveValue(
			attributeName,
			blockAttributes,
			pageStyle,
			selectedTheme,
			defaultTheme,
			attributeConfig
		);
	});

	console.log('[EFFECTIVE VALUES] Computed:', effectiveValues);
	return effectiveValues;
}
