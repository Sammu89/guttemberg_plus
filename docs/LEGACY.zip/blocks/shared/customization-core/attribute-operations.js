/**
 * Attribute clear and reset operations
 * Clearing = setting to UNDEFINED (removing from block HTML)
 *
 * ARCHITECTURE: UNDEFINED vs NULL
 * ===============================
 * - undefined = attribute removed from saved HTML (clean block)
 * - null = attribute saved as null in HTML (pollutes content)
 * - setAttributes({ attr: undefined }) removes the attribute
 * - setAttributes({ attr: null }) saves null to database
 * - We ALWAYS use undefined for clearing
 *
 * @module attribute-operations
 */

/**
 * Gets the default value for an attribute (ALWAYS undefined)
 * In snapshot system, clearing means removing from block, not setting to default
 *
 * @param {string} attributeName - Name of the attribute
 * @param {Object} attributeConfig - Attribute configuration
 * @returns {undefined} Always undefined (removes attribute from block)
 *
 * @example
 * const defaultVal = getAttributeDefaultValue('borderWidth', config);
 * // Returns: undefined (will remove attribute from block)
 */
export function getAttributeDefaultValue(attributeName, attributeConfig) {
	if (!attributeConfig[attributeName]) {
		return undefined;
	}

	// In snapshot system, clearing means removing attribute (undefined)
	return undefined;
}

/**
 * Clears a list of attributes by setting them to undefined
 * Returns object with attributes to remove from block
 *
 * @param {Array<string>} attributeNames - Array of attribute names to clear
 * @param {Object} currentAttributes - Current block attributes
 * @param {Object} attributeConfig - Attribute configuration
 * @returns {Object} Object with attributes set to undefined (removes from block)
 *
 * @example
 * const updates = clearAttributesByList(
 *   ['headerBackgroundColor', 'borderWidth'],
 *   { headerBackgroundColor: '#ff0000', borderWidth: 2 },
 *   config
 * );
 * // Returns: { headerBackgroundColor: undefined, borderWidth: undefined }
 */
export function clearAttributesByList(attributeNames, currentAttributes, attributeConfig) {
	const updates = {};

	attributeNames.forEach((attrName) => {
		// If block has this attribute, mark it for removal (undefined)
		if (currentAttributes[attrName] !== undefined) {
			updates[attrName] = undefined;
		}
	});

	return updates;
}

/**
 * Clears all attributes in a specific section
 * Finds attributes by section name and clears them
 *
 * @param {string} section - Section name (e.g., 'colors', 'border')
 * @param {Object} currentAttributes - Current block attributes
 * @param {Object} attributeConfig - Attribute configuration
 * @returns {Object} Object with attributes to update
 *
 * @example
 * const updates = clearAttributesBySection(
 *   'colors',
 *   { headerBackgroundColor: '#ff0000', borderWidth: 2 },
 *   config
 * );
 * // Returns: { headerBackgroundColor: null } (only colors section)
 */
export function clearAttributesBySection(section, currentAttributes, attributeConfig) {
	// Find all attributes in this section
	const attributesInSection = Object.entries(attributeConfig)
		.filter(([_, config]) => config.section === section)
		.map(([attrName]) => attrName);

	return clearAttributesByList(attributesInSection, currentAttributes, attributeConfig);
}

/**
 * Clears ALL customization attributes
 * Resets every attribute in config to its default value
 *
 * @param {Object} currentAttributes - Current block attributes
 * @param {Object} attributeConfig - Attribute configuration
 * @returns {Object} Object with all attributes set to defaults
 *
 * @example
 * const updates = clearAllCustomizations(
 *   { headerBackgroundColor: '#ff0000', borderWidth: 2, accordionTitle: 'My Title' },
 *   config
 * );
 * // Returns: { headerBackgroundColor: null, borderWidth: null }
 * // Note: accordionTitle not in config, so not included
 */
export function clearAllCustomizations(currentAttributes, attributeConfig) {
	const allAttributes = Object.keys(attributeConfig);
	return clearAttributesByList(allAttributes, currentAttributes, attributeConfig);
}

/**
 * Resets a single attribute to its default value
 * Convenience function for single-attribute reset
 *
 * @param {string} attributeName - Name of the attribute
 * @param {Object} attributeConfig - Attribute configuration
 * @returns {*} Default value for the attribute
 *
 * @example
 * const defaultVal = resetAttributeToDefault('borderWidth', config);
 * // Returns: null
 */
export function resetAttributeToDefault(attributeName, attributeConfig) {
	return getAttributeDefaultValue(attributeName, attributeConfig);
}
