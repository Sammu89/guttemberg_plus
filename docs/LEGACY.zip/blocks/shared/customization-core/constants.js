/**
 * Shared constants for customization core
 *
 * @module constants
 */

/**
 * Error messages for validation and operations
 * @constant {Object}
 */
export const ERROR_MESSAGES = {
	INVALID_ATTRIBUTE_CONFIG: 'Attribute configuration is invalid or missing required fields',
	INVALID_ATTRIBUTE_NAME: 'Attribute name does not exist in configuration',
	INVALID_ATTRIBUTE_VALUE: 'Attribute value does not match expected type',
	INVALID_THEME_DATA: 'Theme data structure is invalid',
	MISSING_REQUIRED_FIELD: 'Required field is missing',
	TYPE_MISMATCH: 'Value type does not match configuration',
};

/**
 * Valid attribute types
 * @constant {Array<string>}
 */
export const VALID_ATTRIBUTE_TYPES = ['string', 'number', 'boolean', 'object', 'array'];

/**
 * Default section name for attributes without explicit section
 * @constant {string}
 */
export const DEFAULT_SECTION = 'general';

/**
 * Reserved metadata keys in theme objects
 * These keys are not considered customization attributes
 * @constant {Array<string>}
 */
export const RESERVED_THEME_KEYS = ['id', 'theme_id', 'name', 'theme_name', 'created', 'updated'];
