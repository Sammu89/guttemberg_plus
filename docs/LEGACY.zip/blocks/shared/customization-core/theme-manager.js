/**
 * Theme data management - Complete Snapshot System
 *
 * ARCHITECTURE: COMPLETE SNAPSHOTS WITH NO NULLS
 * ===============================================
 * - Every theme is a complete snapshot with ALL attribute values
 * - NO null values in themes (they have real defaults for everything)
 * - NO inheritance or cascading between themes
 * - Each theme is independent and self-contained
 *
 * When creating/updating themes:
 * 1. Collect ALL current effective values (block OR theme)
 * 2. Store as complete object with ALL 33+ attributes
 * 3. Result: Theme can stand alone without parent/default theme
 *
 * Pure functions for theme CRUD operations (no AJAX/persistence here)
 *
 * @module theme-manager
 */

import { RESERVED_THEME_KEYS, ERROR_MESSAGES } from './constants.js';
import { validateAttributeConfig } from './validation.js';

/**
 * Normalizes theme data to ensure consistency
 * Removes null/undefined values and ensures proper structure
 *
 * @param {Object} themeData - Raw theme data
 * @param {Object} attributeConfig - Block's ATTRIBUTE_CONFIG
 * @returns {Object} Normalized theme data
 *
 * @example
 * const normalized = normalizeThemeData(
 *   { headerColor: '#ff0000', borderWidth: null, unknownAttr: 'foo' },
 *   config
 * );
 * // Returns: { headerColor: '#ff0000' }
 * // (null removed, unknown attribute removed)
 */
export function normalizeThemeData(themeData, attributeConfig) {
	const normalized = {};

	// Preserve metadata keys
	RESERVED_THEME_KEYS.forEach((key) => {
		if (themeData[key] !== undefined) {
			normalized[key] = themeData[key];
		}
	});

	// Process customization attributes
	Object.keys(attributeConfig).forEach((attrName) => {
		const value = themeData[attrName];

		// Only include non-null/undefined values
		if (value !== null && value !== undefined) {
			normalized[attrName] = value;
		}
	});

	return normalized;
}

/**
 * Validates theme structure against attribute config
 * Checks for unknown attributes and type mismatches
 *
 * @param {Object} themeData - Theme data to validate
 * @param {Object} attributeConfig - Block's ATTRIBUTE_CONFIG
 * @returns {{valid: boolean, errors: Array<string>}} Validation result
 *
 * @example
 * const result = validateThemeStructure(themeData, config);
 * if (!result.valid) {
 *   console.error('Theme validation failed:', result.errors);
 * }
 */
export function validateThemeStructure(themeData, attributeConfig) {
	const errors = [];

	// Validate config first
	const configValidation = validateAttributeConfig(attributeConfig);
	if (!configValidation.valid) {
		return configValidation;
	}

	if (!themeData || typeof themeData !== 'object') {
		errors.push(ERROR_MESSAGES.INVALID_THEME_DATA);
		return { valid: false, errors };
	}

	// Check for unknown attributes (not in config and not metadata)
	Object.keys(themeData).forEach((key) => {
		const isMetadata = RESERVED_THEME_KEYS.includes(key);
		const isInConfig = attributeConfig.hasOwnProperty(key);

		if (!isMetadata && !isInConfig) {
			errors.push(`Unknown attribute "${key}" not found in configuration`);
		}
	});

	// Validate types for known attributes
	Object.entries(themeData).forEach(([key, value]) => {
		if (attributeConfig[key]) {
			const expectedType = attributeConfig[key].type;
			const actualType = Array.isArray(value) ? 'array' : typeof value;

			// Skip null/undefined (they're valid)
			if (value === null || value === undefined) {
				return;
			}

			// Type check
			if (expectedType === 'number' && typeof value !== 'number') {
				errors.push(`Attribute "${key}": expected number, got ${actualType}`);
			} else if (expectedType === 'boolean' && typeof value !== 'boolean') {
				errors.push(`Attribute "${key}": expected boolean, got ${actualType}`);
			} else if (expectedType === 'string' && typeof value !== 'string') {
				errors.push(`Attribute "${key}": expected string, got ${actualType}`);
			} else if (expectedType === 'array' && !Array.isArray(value)) {
				errors.push(`Attribute "${key}": expected array, got ${actualType}`);
			} else if (expectedType === 'object' && (typeof value !== 'object' || Array.isArray(value))) {
				errors.push(`Attribute "${key}": expected object, got ${actualType}`);
			}
		}
	});

	return {
		valid: errors.length === 0,
		errors,
	};
}

/**
 * Merges theme updates with existing theme data
 * Preserves metadata fields (theme_id, theme_name, etc.)
 *
 * @param {Object} existingTheme - Current theme data
 * @param {Object} updates - New values to merge
 * @param {Object} attributeConfig - Block's ATTRIBUTE_CONFIG
 * @returns {Object} Merged theme data
 *
 * @example
 * const merged = mergeThemeData(
 *   { theme_id: 'A7', headerColor: '#ff0000' },
 *   { headerColor: '#00ff00', borderWidth: 2 },
 *   config
 * );
 * // Returns: { theme_id: 'A7', headerColor: '#00ff00', borderWidth: 2 }
 */
export function mergeThemeData(existingTheme, updates, attributeConfig) {
	const merged = { ...existingTheme };

	// Apply updates only for known attributes
	Object.keys(attributeConfig).forEach((attrName) => {
		if (updates.hasOwnProperty(attrName)) {
			merged[attrName] = updates[attrName];
		}
	});

	return merged;
}

/**
 * Extracts customization attributes from block attributes
 * Filters out non-customization attributes (e.g., title, isOpen, themeId)
 *
 * @param {Object} blockAttributes - All block attributes
 * @param {Object} attributeConfig - Block's ATTRIBUTE_CONFIG
 * @returns {Object} Only customization attributes
 *
 * @example
 * const customizations = extractCustomizationAttributes(
 *   { headerColor: '#ff0000', accordionTitle: 'My Title', themeId: 'A7' },
 *   config
 * );
 * // Returns: { headerColor: '#ff0000' }
 * // (accordionTitle and themeId not in config, so excluded)
 */
export function extractCustomizationAttributes(blockAttributes, attributeConfig) {
	const customizations = {};

	Object.keys(attributeConfig).forEach((attrName) => {
		if (blockAttributes.hasOwnProperty(attrName)) {
			customizations[attrName] = blockAttributes[attrName];
		}
	});

	return customizations;
}

/**
 * Prepares theme data for storage
 * Removes null/undefined values, ensures proper types, normalizes structure
 *
 * @param {Object} themeData - Theme data to prepare
 * @param {Object} attributeConfig - Block's ATTRIBUTE_CONFIG
 * @returns {Object} Cleaned theme data ready for save
 *
 * @example
 * const prepared = prepareThemeForStorage(
 *   { headerColor: '#ff0000', borderWidth: null },
 *   config
 * );
 * // Returns: { headerColor: '#ff0000' }
 * // (null values removed)
 */
export function prepareThemeForStorage(themeData, attributeConfig) {
	// First normalize to clean structure
	const normalized = normalizeThemeData(themeData, attributeConfig);

	// Validate structure
	const validation = validateThemeStructure(normalized, attributeConfig);
	if (!validation.valid) {
		console.warn('Theme data has validation warnings:', validation.errors);
	}

	return normalized;
}

/**
 * Generates a unique 3-character theme ID
 * Uses random alphanumeric characters
 *
 * @returns {string} Unique theme ID (e.g., 'a7x', 'b2k', '9mz')
 *
 * @example
 * const id = generateThemeId();
 * // Returns: 'a7x' (3 random characters)
 */
export function generateThemeId() {
	const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
	let id = '';
	for (let i = 0; i < 3; i++) {
		id += chars.charAt(Math.floor(Math.random() * chars.length));
	}
	return id;
}
