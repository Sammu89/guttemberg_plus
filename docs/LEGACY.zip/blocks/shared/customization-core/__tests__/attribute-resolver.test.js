/**
 * Tests for attribute-resolver.js
 */

import {
	resolveValueWithPriority,
	computeEffectiveValue,
	computeEffectiveValues,
} from '../attribute-resolver.js';

describe('resolveValueWithPriority', () => {
	test('returns block value when present', () => {
		expect(resolveValueWithPriority('#ff0000', '#00ff00', '#000000')).toBe('#ff0000');
	});

	test('returns theme value when block value is null', () => {
		expect(resolveValueWithPriority(null, '#00ff00', '#000000')).toBe('#00ff00');
	});

	test('returns theme value when block value is undefined', () => {
		expect(resolveValueWithPriority(undefined, '#00ff00', '#000000')).toBe('#00ff00');
	});

	test('returns default value when block and theme are null', () => {
		expect(resolveValueWithPriority(null, null, '#000000')).toBe('#000000');
	});

	test('handles boolean values correctly', () => {
		expect(resolveValueWithPriority(true, false, false)).toBe(true);
		expect(resolveValueWithPriority(false, true, true)).toBe(false); // false is valid
	});

	test('handles number zero as valid value', () => {
		expect(resolveValueWithPriority(0, 10, 5)).toBe(0); // 0 is valid
	});

	test('handles empty string as valid value', () => {
		expect(resolveValueWithPriority('', 'theme', 'default')).toBe(''); // '' is valid
	});
});

describe('computeEffectiveValue', () => {
	const mockDefaultTheme = {
		headerBackgroundColor: null,
		borderWidth: 1,
	};

	test('returns block value when attribute is customized (Tier 3)', () => {
		const result = computeEffectiveValue(
			'headerBackgroundColor',
			{ headerBackgroundColor: '#ff0000' }, // block attributes
			null, // page style
			{ headerBackgroundColor: '#00ff00' }, // selected theme
			mockDefaultTheme, // default theme
			null // attribute config (not needed for this test)
		);
		expect(result).toBe('#ff0000');
	});

	test('returns page style value when block value is undefined (Tier 2)', () => {
		const result = computeEffectiveValue(
			'headerBackgroundColor',
			{}, // block attributes (empty)
			{ overrides: { headerBackgroundColor: '#0000ff' } }, // page style
			{ headerBackgroundColor: '#00ff00' }, // selected theme
			mockDefaultTheme, // default theme
			null // attribute config
		);
		expect(result).toBe('#0000ff');
	});

	test('returns theme value when block and page style are undefined (Tier 1)', () => {
		const result = computeEffectiveValue(
			'headerBackgroundColor',
			{}, // block attributes (empty)
			null, // no page style
			{ headerBackgroundColor: '#00ff00' }, // selected theme
			mockDefaultTheme, // default theme
			null // attribute config
		);
		expect(result).toBe('#00ff00');
	});

	test('returns default value when all higher tiers are undefined (Tier 0)', () => {
		const result = computeEffectiveValue(
			'borderWidth',
			{}, // block attributes (empty)
			null, // no page style
			{}, // theme (empty)
			mockDefaultTheme, // default theme
			null // attribute config
		);
		expect(result).toBe(1);
	});

	test('returns config default when all tiers are undefined', () => {
		const mockConfig = {
			someAttribute: {
				defaultValue: 'config-default-value'
			}
		};
		const result = computeEffectiveValue(
			'someAttribute',
			{}, // block attributes
			null, // no page style
			{}, // theme
			{}, // default theme (empty)
			mockConfig // attribute config
		);
		expect(result).toBe('config-default-value');
	});

	test('handles 4-tier cascade priority correctly', () => {
		// All tiers have values - should pick block (highest)
		const result = computeEffectiveValue(
			'headerBackgroundColor',
			{ headerBackgroundColor: '#ff0000' }, // Tier 3
			{ overrides: { headerBackgroundColor: '#0000ff' } }, // Tier 2
			{ headerBackgroundColor: '#00ff00' }, // Tier 1
			{ headerBackgroundColor: '#cccccc' }, // Tier 0
			null // attribute config
		);
		expect(result).toBe('#ff0000');
	});
});

describe('computeEffectiveValues', () => {
	const mockConfig = {
		headerBackgroundColor: {
			type: 'string',
			defaultValue: null,
			section: 'colors',
		},
		headerTextColor: {
			type: 'string',
			defaultValue: '#000000',
			section: 'colors',
		},
		borderWidth: {
			type: 'number',
			defaultValue: 1,
			section: 'border',
		},
		useCustomFormatting: {
			type: 'boolean',
			defaultValue: false,
			section: 'title',
		},
	};

	const mockDefaultTheme = {
		headerBackgroundColor: null,
		headerTextColor: '#000000',
		borderWidth: 1,
		useCustomFormatting: false,
	};

	test('computes effective values for all attributes with 4-tier cascade', () => {
		const blockAttrs = {
			headerBackgroundColor: '#ff0000', // Tier 3: block override
		};

		const pageStyle = {
			overrides: {
				borderWidth: 3, // Tier 2: page style override
			},
		};

		const theme = {
			headerBackgroundColor: '#00ff00',
			borderWidth: 2,
			headerTextColor: '#ffffff', // Tier 1: theme value
		};

		const result = computeEffectiveValues(
			blockAttrs,
			pageStyle,
			theme,
			mockDefaultTheme,
			mockConfig
		);

		expect(result).toEqual({
			headerBackgroundColor: '#ff0000', // Tier 3: Block override
			headerTextColor: '#ffffff', // Tier 1: Theme value
			borderWidth: 3, // Tier 2: Page style override
			useCustomFormatting: false, // Tier 0: Default value
		});
	});

	test('handles empty block attributes', () => {
		const theme = {
			headerBackgroundColor: '#00ff00',
		};

		const result = computeEffectiveValues(
			{}, // empty block attributes
			null, // no page style
			theme, // selected theme
			mockDefaultTheme, // default theme
			mockConfig
		);

		expect(result.headerBackgroundColor).toBe('#00ff00'); // From theme
		expect(result.headerTextColor).toBe('#000000'); // From default
		expect(result.borderWidth).toBe(1); // From default
	});

	test('handles null theme - falls back to default', () => {
		const blockAttrs = {
			headerBackgroundColor: '#ff0000',
		};

		const result = computeEffectiveValues(
			blockAttrs,
			null, // no page style
			null, // no selected theme
			mockDefaultTheme, // default theme
			mockConfig
		);

		expect(result.headerBackgroundColor).toBe('#ff0000'); // From block
		expect(result.headerTextColor).toBe('#000000'); // From default
		expect(result.borderWidth).toBe(1); // From default
	});

	test('returns object with all attributes from config', () => {
		const result = computeEffectiveValues(
			{}, // empty block
			null, // no page style
			{}, // empty theme
			mockDefaultTheme, // default theme
			mockConfig
		);

		expect(Object.keys(result)).toEqual(Object.keys(mockConfig));
		expect(result).toHaveProperty('headerBackgroundColor');
		expect(result).toHaveProperty('headerTextColor');
		expect(result).toHaveProperty('borderWidth');
		expect(result).toHaveProperty('useCustomFormatting');
	});

	test('page style overrides selected theme but not block', () => {
		const blockAttrs = {
			headerBackgroundColor: '#ff0000', // Block wins
		};

		const pageStyle = {
			overrides: {
				headerBackgroundColor: '#0000ff', // Page style loses to block
				borderWidth: 5, // Page style wins (no block value)
			},
		};

		const theme = {
			headerBackgroundColor: '#00ff00',
			borderWidth: 2, // Theme loses to page style
		};

		const result = computeEffectiveValues(
			blockAttrs,
			pageStyle,
			theme,
			mockDefaultTheme,
			mockConfig
		);

		expect(result.headerBackgroundColor).toBe('#ff0000'); // Block wins
		expect(result.borderWidth).toBe(5); // Page style wins
	});
});
