/**
 * CSS generation and style utilities
 * Block-agnostic helpers for generating inline styles and CSS
 *
 * @module style-helpers
 */

/**
 * Gets border radius CSS value from individual corner values
 * Returns shorthand if all corners are equal, full notation otherwise
 *
 * @param {number} topLeft - Top left corner radius in pixels
 * @param {number} topRight - Top right corner radius in pixels
 * @param {number} bottomRight - Bottom right corner radius in pixels
 * @param {number} bottomLeft - Bottom left corner radius in pixels
 * @returns {string} CSS border-radius value
 *
 * @example
 * getBorderRadiusValue(10, 10, 10, 10)
 * // Returns: '10px'
 *
 * @example
 * getBorderRadiusValue(10, 5, 10, 5)
 * // Returns: '10px 5px 10px 5px'
 */
export function getBorderRadiusValue(topLeft, topRight, bottomRight, bottomLeft) {
	// All equal - use shorthand
	if (topLeft === topRight && topLeft === bottomRight && topLeft === bottomLeft) {
		return `${topLeft}px`;
	}

	// Full notation
	return `${topLeft}px ${topRight}px ${bottomRight}px ${bottomLeft}px`;
}

/**
 * Gets CSS margin values for horizontal alignment
 * Returns margin-left and margin-right for centering or alignment
 *
 * @param {string} horizontalAlign - Alignment value ('left', 'center', 'right')
 * @returns {{marginLeft: string, marginRight: string}} Margin CSS properties
 *
 * @example
 * getAlignmentMargins('center')
 * // Returns: { marginLeft: 'auto', marginRight: 'auto' }
 *
 * @example
 * getAlignmentMargins('right')
 * // Returns: { marginLeft: 'auto', marginRight: '0' }
 */
export function getAlignmentMargins(horizontalAlign) {
	const alignMap = {
		left: { marginLeft: '0', marginRight: 'auto' },
		center: { marginLeft: 'auto', marginRight: 'auto' },
		right: { marginLeft: 'auto', marginRight: '0' },
	};

	return alignMap[horizontalAlign] || alignMap.left;
}

/**
 * Checks if a border radius object has any non-zero values
 *
 * @param {Object} borderRadius - Border radius object with corner properties
 * @param {number} borderRadius.topLeft - Top left corner
 * @param {number} borderRadius.topRight - Top right corner
 * @param {number} borderRadius.bottomRight - Bottom right corner
 * @param {number} borderRadius.bottomLeft - Bottom left corner
 * @returns {boolean} True if any corner has radius > 0
 *
 * @example
 * hasBorderRadius({ topLeft: 10, topRight: 0, bottomRight: 0, bottomLeft: 0 })
 * // Returns: true
 */
export function hasBorderRadius(borderRadius) {
	if (!borderRadius) return false;

	return (
		borderRadius.topLeft > 0 ||
		borderRadius.topRight > 0 ||
		borderRadius.bottomRight > 0 ||
		borderRadius.bottomLeft > 0
	);
}

/**
 * Builds inline styles object from effective values
 * Generates CSS variables for all color, border, and spacing attributes
 *
 * @param {Object} effectiveValues - Resolved effective values for all attributes
 * @returns {Object} Inline styles object suitable for React style prop
 *
 * @example
 * const styles = buildInlineStyles({
 *   headerBackgroundColor: '#ff0000',
 *   headerTextColor: '#ffffff',
 *   borderWidth: 2
 * });
 * // Returns: {
 * //   '--header-bg-color': '#ff0000',
 * //   '--header-text-color': '#ffffff',
 * //   '--border-width': '2px'
 * // }
 */
export function buildInlineStyles(effectiveValues) {
	const styles = {};

	// Color mappings
	if (effectiveValues.headerBackgroundColor) {
		styles['--header-bg-color'] = effectiveValues.headerBackgroundColor;
	}
	if (effectiveValues.headerTextColor) {
		styles['--header-text-color'] = effectiveValues.headerTextColor;
	}
	if (effectiveValues.headerHoverColor) {
		styles['--header-hover-color'] = effectiveValues.headerHoverColor;
	}
	if (effectiveValues.contentBackgroundColor && !effectiveValues.contentBackgroundTransparent) {
		styles['--content-bg-color'] = effectiveValues.contentBackgroundColor;
	}

	// Border
	if (effectiveValues.borderColor) {
		styles['--border-color'] = effectiveValues.borderColor;
	}
	if (effectiveValues.borderWidth !== null && effectiveValues.borderWidth !== undefined) {
		styles['--border-width'] = `${effectiveValues.borderWidth}px`;
	}
	if (effectiveValues.borderStyle) {
		styles['--border-style'] = effectiveValues.borderStyle;
	}

	// Divider border
	if (effectiveValues.dividerBorderColor) {
		styles['--divider-border-color'] = effectiveValues.dividerBorderColor;
	}
	if (effectiveValues.dividerBorderWidth !== null && effectiveValues.dividerBorderWidth !== undefined) {
		styles['--divider-border-width'] = `${effectiveValues.dividerBorderWidth}px`;
	}
	if (effectiveValues.dividerBorderStyle) {
		styles['--divider-border-style'] = effectiveValues.dividerBorderStyle;
	}

	// Border radius - only add if not null/undefined
	if (effectiveValues.borderRadiusTopLeft !== null && effectiveValues.borderRadiusTopLeft !== undefined) {
		styles['--border-radius-tl'] = `${effectiveValues.borderRadiusTopLeft}px`;
	}
	if (effectiveValues.borderRadiusTopRight !== null && effectiveValues.borderRadiusTopRight !== undefined) {
		styles['--border-radius-tr'] = `${effectiveValues.borderRadiusTopRight}px`;
	}
	if (effectiveValues.borderRadiusBottomRight !== null && effectiveValues.borderRadiusBottomRight !== undefined) {
		styles['--border-radius-br'] = `${effectiveValues.borderRadiusBottomRight}px`;
	}
	if (effectiveValues.borderRadiusBottomLeft !== null && effectiveValues.borderRadiusBottomLeft !== undefined) {
		styles['--border-radius-bl'] = `${effectiveValues.borderRadiusBottomLeft}px`;
	}

	// Padding
	if (effectiveValues.headerPadding !== null && effectiveValues.headerPadding !== undefined) {
		styles['--header-padding'] = `${effectiveValues.headerPadding}px`;
	}
	if (effectiveValues.contentPadding !== null && effectiveValues.contentPadding !== undefined) {
		styles['--content-padding'] = `${effectiveValues.contentPadding}px`;
	}

	// Icon
	if (effectiveValues.iconSize) {
		styles['--icon-size'] = `${effectiveValues.iconSize}px`;
	}
	if (effectiveValues.iconColor) {
		styles['--icon-color'] = effectiveValues.iconColor;
	}

	// Animation
	if (effectiveValues.animationSpeed) {
		const speedMap = {
			fast: '0.2s',
			normal: '0.3s',
			slow: '0.5s',
			none: '0s',
		};
		styles['--animation-speed'] = speedMap[effectiveValues.animationSpeed] || '0.3s';
	}

	// Title formatting
	if (effectiveValues.useCustomTitleFormatting) {
		if (effectiveValues.titleFontSize) {
			styles['--title-font-size'] = `${effectiveValues.titleFontSize}px`;
		}
		if (effectiveValues.titleFontWeight) {
			styles['--title-font-weight'] = effectiveValues.titleFontWeight;
		}
		if (effectiveValues.titleLineHeight) {
			styles['--title-line-height'] = effectiveValues.titleLineHeight;
		}
		if (effectiveValues.titleLetterSpacing) {
			styles['--title-letter-spacing'] = `${effectiveValues.titleLetterSpacing}px`;
		}
		if (effectiveValues.titleTextTransform) {
			styles['--title-text-transform'] = effectiveValues.titleTextTransform;
		}
	}

	return styles;
}
