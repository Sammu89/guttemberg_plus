/**
 * Generic AJAX adapter for WordPress theme operations
 * Block-agnostic wrapper for WordPress AJAX requests
 *
 * @module ajax-adapter
 */

/**
 * Gets the AJAX configuration from WordPress global settings
 * Falls back to default values if not available
 *
 * @param {string} blockType - Block type identifier (e.g., 'accordion', 'tabs')
 * @returns {Object} Configuration object
 * @returns {string} return.ajaxurl - WordPress AJAX URL
 * @returns {string} return.nonce - Security nonce for theme operations
 *
 * @example
 * const config = getAjaxConfig('accordion');
 * // Returns: { ajaxurl: '/wp-admin/admin-ajax.php', nonce: '...' }
 */
export function getAjaxConfig(blockType) {
	// Try block-specific settings first
	const settingsKey = `${blockType}GlobalSettings`;
	const blockSettings = window[settingsKey];

	return {
		ajaxurl: blockSettings?.ajaxurl || window.ajaxurl || '/wp-admin/admin-ajax.php',
		nonce: blockSettings?.themesNonce || '',
	};
}

/**
 * Sends a generic AJAX request with robust error handling
 * Handles timeout, network errors, HTTP status codes, and WordPress response validation
 *
 * @param {string} action - WordPress AJAX action name
 * @param {Object} data - Additional data to send as key-value pairs
 * @param {Object} options - Optional configuration
 * @param {number} options.timeout - Request timeout in milliseconds (default: 30000)
 * @returns {Promise<Object>} Response data from server
 * @throws {Error} If request fails (timeout, network, HTTP, validation)
 *
 * @example
 * const result = await sendAjaxRequest(
 *   'get_accordion_themes',
 *   {},
 *   { timeout: 30000 }
 * );
 */
export async function sendAjaxRequest(action, data = {}, options = {}) {
	const { timeout = 30000, blockType = 'accordion' } = options;
	const config = getAjaxConfig(blockType);

	try {
		const formData = new FormData();
		formData.append('action', action);
		formData.append('nonce', config.nonce);

		// Add all data entries to formData
		Object.entries(data).forEach(([key, value]) => {
			if (value !== null && value !== undefined) {
				// Serialize objects/arrays as JSON
				if (typeof value === 'object') {
					formData.append(key, JSON.stringify(value));
				} else {
					formData.append(key, value);
				}
			}
		});

		// Create abort controller for timeout
		const controller = new AbortController();
		const timeoutId = setTimeout(() => controller.abort(), timeout);

		let response;
		try {
			response = await fetch(config.ajaxurl, {
				method: 'POST',
				body: formData,
				signal: controller.signal,
			});
		} catch (fetchError) {
			clearTimeout(timeoutId);

			// Handle network errors
			if (fetchError.name === 'AbortError') {
				throw new Error('Request timed out. Please check your connection and try again.');
			}

			if (!navigator.onLine) {
				throw new Error('No internet connection. Please check your network and try again.');
			}

			throw new Error('Network error. Please check your connection and try again.');
		}

		clearTimeout(timeoutId);

		// Handle HTTP errors
		if (!response.ok) {
			const statusMessages = {
				400: 'Invalid request. Please try again.',
				401: 'Authentication failed. Please refresh the page and try again.',
				403: 'Permission denied. You may not have access to perform this action.',
				404: 'Server endpoint not found. Please check your WordPress installation.',
				500: 'Server error. Please try again later.',
				502: 'Bad gateway. The server is temporarily unavailable.',
				503: 'Service unavailable. Please try again later.',
			};

			const message =
				statusMessages[response.status] ||
				`Server returned error ${response.status}. Please try again.`;
			throw new Error(message);
		}

		// Parse JSON response
		let result;
		try {
			result = await response.json();
		} catch (parseError) {
			console.error('JSON parse error:', parseError);
			throw new Error('Invalid server response. Please try again or contact support.');
		}

		// Handle WordPress AJAX error responses
		if (!result.success) {
			const errorMessage =
				result.data?.message || result.message || 'An unknown error occurred. Please try again.';
			throw new Error(errorMessage);
		}

		// Validate response data
		if (!result.data) {
			console.warn('AJAX response missing data field:', result);
			throw new Error('Invalid server response format. Please try again.');
		}

		return result.data;
	} catch (error) {
		// Log detailed error for debugging
		console.error(`AJAX Error (${action}):`, {
			error,
			message: error.message,
			stack: error.stack,
			action,
			data,
		});

		// Re-throw with user-friendly message
		throw error;
	}
}

/**
 * Loads all themes for a specific block type
 *
 * @param {string} blockType - Block type identifier (e.g., 'accordion', 'tabs')
 * @param {Object} options - Optional configuration
 * @returns {Promise<Object>} Response data containing themes
 * @returns {Object} return.themes - Object of themes keyed by theme ID
 *
 * @example
 * const data = await loadThemes('accordion');
 * console.log(data.themes); // { default: {...}, theme_123: {...} }
 */
export async function loadThemes(blockType, options = {}) {
	return await sendAjaxRequest(`get_${blockType}_themes`, {}, { ...options, blockType });
}

/**
 * Saves a theme for a specific block type
 * Creates new theme or updates existing theme
 *
 * @param {string} blockType - Block type identifier
 * @param {string} themeId - Theme ID
 * @param {Object} themeData - Theme data to save
 * @param {Object} options - Optional configuration
 * @returns {Promise<Object>} Response data containing updated themes
 *
 * @example
 * const result = await saveTheme('accordion', 'theme_123', {
 *   theme_name: 'Dark Mode',
 *   headerBackgroundColor: '#222'
 * });
 */
export async function saveTheme(blockType, themeId, themeData, options = {}) {
	// Flatten themeData to match PHP endpoint expectations
	// PHP expects all fields at top level: theme_id, theme_name, headerBackgroundColor, etc.
	return await sendAjaxRequest(
		`save_${blockType}_theme`,
		{
			theme_id: themeId,
			...themeData, // Spread theme data to flatten it
		},
		{ ...options, blockType }
	);
}

/**
 * Updates an existing theme for a specific block type
 *
 * @param {string} blockType - Block type identifier
 * @param {string} themeId - Theme ID to update
 * @param {Object} updates - Partial theme data to merge
 * @param {Object} options - Optional configuration
 * @returns {Promise<Object>} Response data containing updated themes
 *
 * @example
 * const result = await updateTheme('accordion', 'theme_123', {
 *   headerBackgroundColor: '#333'
 * });
 */
export async function updateTheme(blockType, themeId, updates, options = {}) {
	// Flatten updates to match PHP endpoint expectations
	// PHP expects all fields at top level: theme_id, theme_name, headerBackgroundColor, etc.
	// Note: Uses save_*_theme endpoint since update and create share the same endpoint
	return await sendAjaxRequest(
		`save_${blockType}_theme`,
		{
			theme_id: themeId,
			...updates, // Spread updates to flatten them
		},
		{ ...options, blockType }
	);
}

/**
 * Deletes a theme for a specific block type
 *
 * @param {string} blockType - Block type identifier
 * @param {string} themeId - Theme ID to delete
 * @param {Object} options - Optional configuration
 * @returns {Promise<Object>} Response data containing updated themes
 *
 * @example
 * const result = await deleteTheme('accordion', 'theme_123');
 */
export async function deleteTheme(blockType, themeId, options = {}) {
	return await sendAjaxRequest(
		`delete_${blockType}_theme`,
		{
			theme_id: themeId,
		},
		{ ...options, blockType }
	);
}
