/**
 * Safe Access Utilities
 *
 * Defensive utilities to prevent "Cannot read properties of null/undefined" errors
 * throughout the block editor.
 *
 * @package GutenNavPlugin
 */

/**
 * Safely access a nested property with optional chaining
 *
 * @param {Object}   obj          - The object to access
 * @param {string}   path         - The property path (e.g., 'user.profile.name')
 * @param {*}        defaultValue - Default value if property is null/undefined
 * @return {*} - The property value or default value
 *
 * @example
 * const name = safeGet(user, 'profile.name', 'Anonymous');
 * const count = safeGet(data, 'items.length', 0);
 */
export function safeGet( obj, path, defaultValue = null ) {
	if ( ! obj || typeof obj !== 'object' ) {
		return defaultValue;
	}

	const keys = path.split( '.' );
	let result = obj;

	for ( const key of keys ) {
		if ( result === null || result === undefined || ! Object.prototype.hasOwnProperty.call( result, key ) ) {
			return defaultValue;
		}
		result = result[ key ];
	}

	return result !== null && result !== undefined ? result : defaultValue;
}

/**
 * Safely access an array element
 *
 * @param {Array} arr          - The array to access
 * @param {number} index        - The index to access
 * @param {*}      defaultValue - Default value if index is out of bounds or array is invalid
 * @return {*} - The array element or default value
 *
 * @example
 * const firstItem = safeArrayGet(items, 0, {});
 * const lastItem = safeArrayGet(items, -1, null);
 */
export function safeArrayGet( arr, index, defaultValue = null ) {
	if ( ! Array.isArray( arr ) || arr.length === 0 ) {
		return defaultValue;
	}

	// Handle negative indices
	const actualIndex = index < 0 ? arr.length + index : index;

	if ( actualIndex < 0 || actualIndex >= arr.length ) {
		return defaultValue;
	}

	const value = arr[ actualIndex ];
	return value !== null && value !== undefined ? value : defaultValue;
}

/**
 * Safely call a function if it exists
 *
 * @param {Function} fn   - The function to call
 * @param {...*}     args - Arguments to pass to the function
 * @return {*} - The function result or null if function doesn't exist
 *
 * @example
 * safeCall(onSave, data);
 * safeCall(theme?.getColor, 'primary');
 */
export function safeCall( fn, ...args ) {
	if ( typeof fn === 'function' ) {
		try {
			return fn( ...args );
		} catch ( error ) {
			// eslint-disable-next-line no-console -- Intentional error logging
			console.error( 'Error calling function:', error );
			return null;
		}
	}
	return null;
}

/**
 * Ensure a value is a string
 *
 * @param {*}      value        - The value to convert
 * @param {string} defaultValue - Default value if conversion fails
 * @return {string} - The string value
 *
 * @example
 * const title = ensureString(attributes.title, 'Untitled');
 * const id = ensureString(props.id, '');
 */
export function ensureString( value, defaultValue = '' ) {
	if ( value === null || value === undefined ) {
		return defaultValue;
	}
	return String( value );
}

/**
 * Ensure a value is a number
 *
 * @param {*}      value        - The value to convert
 * @param {number} defaultValue - Default value if conversion fails
 * @return {number} - The number value
 *
 * @example
 * const width = ensureNumber(attributes.width, 100);
 * const count = ensureNumber(props.count, 0);
 */
export function ensureNumber( value, defaultValue = 0 ) {
	if ( value === null || value === undefined ) {
		return defaultValue;
	}

	const num = Number( value );
	return ! isNaN( num ) ? num : defaultValue;
}

/**
 * Ensure a value is an array
 *
 * @param {*}     value        - The value to convert
 * @param {Array} defaultValue - Default value if conversion fails
 * @return {Array} - The array value
 *
 * @example
 * const items = ensureArray(attributes.items, []);
 * const options = ensureArray(props.options, []);
 */
export function ensureArray( value, defaultValue = [] ) {
	if ( Array.isArray( value ) ) {
		return value;
	}
	return defaultValue;
}

/**
 * Ensure a value is an object
 *
 * @param {*}      value        - The value to convert
 * @param {Object} defaultValue - Default value if conversion fails
 * @return {Object} - The object value
 *
 * @example
 * const settings = ensureObject(attributes.settings, {});
 * const theme = ensureObject(props.theme, {});
 */
export function ensureObject( value, defaultValue = {} ) {
	if ( value !== null && typeof value === 'object' && ! Array.isArray( value ) ) {
		return value;
	}
	return defaultValue;
}

/**
 * Safely merge objects with null/undefined checks
 *
 * @param {...Object} objects - Objects to merge
 * @return {Object} - Merged object
 *
 * @example
 * const merged = safeMerge(defaultSettings, userSettings, overrides);
 */
export function safeMerge( ...objects ) {
	return objects.reduce( ( result, obj ) => {
		if ( obj !== null && typeof obj === 'object' && ! Array.isArray( obj ) ) {
			return { ...result, ...obj };
		}
		return result;
	}, {} );
}

/**
 * Check if a value is empty (null, undefined, empty string, empty array, empty object)
 *
 * @param {*} value - The value to check
 * @return {boolean} - True if empty
 *
 * @example
 * if (isEmpty(attributes.title)) {
 *   setAttributes({ title: 'Default Title' });
 * }
 */
export function isEmpty( value ) {
	if ( value === null || value === undefined ) {
		return true;
	}

	if ( typeof value === 'string' ) {
		return value.trim().length === 0;
	}

	if ( Array.isArray( value ) ) {
		return value.length === 0;
	}

	if ( typeof value === 'object' ) {
		return Object.keys( value ).length === 0;
	}

	return false;
}

/**
 * Get a value with fallback chain
 *
 * @param {...*} values - Values to try in order
 * @return {*} - First non-null/undefined value or last value
 *
 * @example
 * const color = fallback(customColor, themeColor, defaultColor, '#000000');
 */
export function fallback( ...values ) {
	for ( const value of values ) {
		if ( value !== null && value !== undefined ) {
			return value;
		}
	}
	return values[ values.length - 1 ];
}
