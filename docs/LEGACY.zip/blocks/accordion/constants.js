/**
 * Constants and Options for Accordion Block
 *
 * This file contains all shared constants, options, and magic numbers
 * used throughout the accordion block to eliminate duplication.
 *
 * @module constants
 */

/**
 * Border style options for select controls
 * Used for both main border and divider border
 */
export const BORDER_STYLE_OPTIONS = [
	{ label: 'Hidden', value: 'none' },
	{ label: 'Solid', value: 'solid' },
	{ label: 'Dashed', value: 'dashed' },
	{ label: 'Dotted', value: 'dotted' },
	{ label: 'Double', value: 'double' },
	{ label: 'Groove', value: 'groove' },
	{ label: 'Ridge', value: 'ridge' },
	{ label: 'Inset', value: 'inset' },
	{ label: 'Outset', value: 'outset' },
];

/**
 * Horizontal alignment options for accordion positioning
 */
export const HORIZONTAL_ALIGN_OPTIONS = [
	{ label: 'Left', value: 'left' },
	{ label: 'Center', value: 'center' },
	{ label: 'Right', value: 'right' },
];

/**
 * Heading level options for semantic HTML
 */
export const HEADING_LEVEL_OPTIONS = [
	{ label: 'H1', value: 'h1' },
	{ label: 'H2', value: 'h2' },
	{ label: 'H3', value: 'h3' },
	{ label: 'H4', value: 'h4' },
	{ label: 'H5', value: 'h5' },
	{ label: 'H6', value: 'h6' },
];

/**
 * Animation speed options for accordion open/close
 */
export const ANIMATION_SPEED_OPTIONS = [
	{ label: 'Inherit from theme', value: '' },
	{ label: 'Fast', value: 'fast' },
	{ label: 'Normal', value: 'normal' },
	{ label: 'Slow', value: 'slow' },
	{ label: 'No Animation', value: 'none' },
];

/**
 * UI-related constants (magic numbers extracted for maintainability)
 */
export const UI_CONSTANTS = {
	// ColorPicker scaling and positioning
	COLOR_PICKER_SCALE: 0.8,
	COLOR_PICKER_MARGIN_OFFSET: '-40px',

	// Notification timing
	NOTIFICATION_TIMEOUT: 3000,

	// Animation speeds (CSS values)
	ANIMATION_SPEEDS: {
		FAST: '0.2s',
		NORMAL: '0.3s',
		SLOW: '0.5s',
	},
};

/**
 * Attribute metadata configuration - THE SINGLE SOURCE OF TRUTH
 *
 * This is the ONLY place you need to define customization attributes.
 * Everything else is auto-generated from this configuration.
 *
 * Structure:
 * - type: 'boolean' | 'string' | 'number' - Data type
 * - defaultValue: Default value when clearing/resetting
 * - section: 'colors' | 'border' | 'icon' | 'title' - Grouping category
 * - isToggle: (optional) If true, this boolean controls child attributes
 * - childAttributes: (optional) Array of attribute names this toggle controls
 * - treatFalseAsCustomization: (optional) For booleans - can false be a customization?
 *
 * HOW TO ADD A NEW CUSTOMIZATION:
 * 1. Add ONE entry here with its metadata
 * 2. That's it! The system auto-generates:
 *    - CUSTOMIZATION_SECTIONS (grouped by section)
 *    - CUSTOMIZATION_ATTRIBUTES (flat list)
 *    - Clearing logic (uses defaultValue)
 *    - Comparison logic (uses type + treatFalseAsCustomization)
 *    - Save/load to themes
 */
export const ATTRIBUTE_CONFIG = {
	// === COLORS ===
	headerBackgroundColor: {
		type: 'string',
		defaultValue: null,
		section: 'colors',
	},
	headerTextColor: {
		type: 'string',
		defaultValue: null,
		section: 'colors',
	},
	headerHoverColor: {
		type: 'string',
		defaultValue: null,
		section: 'colors',
	},
	contentBackgroundColor: {
		type: 'string',
		defaultValue: null,
		section: 'colors',
	},
	contentBackgroundTransparent: {
		type: 'boolean',
		defaultValue: false,
		section: 'colors',
		treatFalseAsCustomization: false, // false is the default, not a customization
	},

	// === MAIN BORDER ===
	borderColor: {
		type: 'string',
		defaultValue: null,
		section: 'mainBorder',
	},
	borderWidth: {
		type: 'number',
		defaultValue: null,
		section: 'mainBorder',
	},
	borderStyle: {
		type: 'string',
		defaultValue: null,
		section: 'mainBorder',
	},

	// === DIVIDER BORDER ===
	dividerBorderColor: {
		type: 'string',
		defaultValue: null,
		section: 'dividerBorder',
	},
	dividerBorderWidth: {
		type: 'number',
		defaultValue: null,
		section: 'dividerBorder',
	},
	dividerBorderStyle: {
		type: 'string',
		defaultValue: null,
		section: 'dividerBorder',
	},

	// === BORDER RADIUS ===
	borderRadiusTopLeft: {
		type: 'number',
		defaultValue: null,
		section: 'borderRadius',
	},
	borderRadiusTopRight: {
		type: 'number',
		defaultValue: null,
		section: 'borderRadius',
	},
	borderRadiusBottomLeft: {
		type: 'number',
		defaultValue: null,
		section: 'borderRadius',
	},
	borderRadiusBottomRight: {
		type: 'number',
		defaultValue: null,
		section: 'borderRadius',
	},

	// === ANIMATION ===
	animationSpeed: {
		type: 'string',
		defaultValue: null,
		section: 'animation',
	},

	// === ICON ===
	showIcon: {
		type: 'boolean',
		defaultValue: null,
		section: 'icon',
		isToggle: true,
		childAttributes: [ 'icon', 'iconType', 'iconPosition', 'animateIcon' ],
	},
	icon: {
		type: 'string',
		defaultValue: null,
		section: 'icon',
	},
	iconType: {
		type: 'string',
		defaultValue: null,
		section: 'icon',
	},
	iconPosition: {
		type: 'string',
		defaultValue: null,
		section: 'icon',
	},
	animateIcon: {
		type: 'boolean',
		defaultValue: null,
		section: 'icon',
	},

	// === TITLE FORMATTING ===
	useHeading: {
		type: 'boolean',
		defaultValue: false,
		section: 'titleFormatting',
		treatFalseAsCustomization: true, // Both true and false can be customizations
	},
	headingLevel: {
		type: 'string',
		defaultValue: 'h2',
		section: 'titleFormatting',
	},
	useHeadingStyles: {
		type: 'boolean',
		defaultValue: false,
		section: 'titleFormatting',
		treatFalseAsCustomization: true, // Both true and false can be customizations
	},
	useCustomTitleFormatting: {
		type: 'boolean',
		defaultValue: false,
		section: 'titleFormatting',
		isToggle: true,
		treatFalseAsCustomization: true, // false CAN differ from theme's true
		childAttributes: [
			'titleTextAlign',
			'titleFontSize',
			'titleFontWeight',
			'titleFontStyle',
			'titleTextTransform',
			'titleLetterSpacing',
			'titleWordSpacing',
			'titleTextDecoration',
			'titleFontFamily',
		],
	},
	titleTextAlign: {
		type: 'string',
		defaultValue: null,
		section: 'titleFormatting',
	},
	titleFontSize: {
		type: 'string',
		defaultValue: null,
		section: 'titleFormatting',
	},
	titleFontWeight: {
		type: 'string',
		defaultValue: null,
		section: 'titleFormatting',
	},
	titleFontStyle: {
		type: 'string',
		defaultValue: null,
		section: 'titleFormatting',
	},
	titleTextTransform: {
		type: 'string',
		defaultValue: null,
		section: 'titleFormatting',
	},
	titleLetterSpacing: {
		type: 'string',
		defaultValue: null,
		section: 'titleFormatting',
	},
	titleWordSpacing: {
		type: 'string',
		defaultValue: null,
		section: 'titleFormatting',
	},
	titleTextDecoration: {
		type: 'string',
		defaultValue: null,
		section: 'titleFormatting',
	},
	titleFontFamily: {
		type: 'string',
		defaultValue: null,
		section: 'titleFormatting',
	},
};

/**
 * Auto-generated: Customization sections grouped by category
 * DO NOT EDIT - Generated from ATTRIBUTE_CONFIG.section
 */
export const CUSTOMIZATION_SECTIONS = Object.entries( ATTRIBUTE_CONFIG ).reduce(
	( sections, [ attrName, config ] ) => {
		const section = config.section;
		if ( ! sections[ section ] ) {
			sections[ section ] = [];
		}
		sections[ section ].push( attrName );
		return sections;
	},
	{}
);

/**
 * Auto-generated: Flattened list of all customization attributes
 * DO NOT EDIT - Generated from ATTRIBUTE_CONFIG keys
 */
export const CUSTOMIZATION_ATTRIBUTES = Object.keys( ATTRIBUTE_CONFIG );

/**
 * Helper function: Get default value for an attribute when clearing
 * Uses ATTRIBUTE_CONFIG to determine the correct default value
 *
 * @param {string} attributeName - Name of the attribute
 * @return {*} - Default value (null, false, etc.)
 */
export const getAttributeDefaultValue = ( attributeName ) => {
	const config = ATTRIBUTE_CONFIG[ attributeName ];
	return config ? config.defaultValue : null;
};

/**
 * Helper function: Check if attribute value should be treated as a customization
 * Handles special cases for booleans with treatFalseAsCustomization flag
 *
 * @param {string} attributeName - Name of the attribute
 * @param {*} attributeValue - Current value of the attribute
 * @param {*} themeValue - Value from the theme
 * @return {boolean} - True if this represents a customization
 */
export const isAttributeCustomization = ( attributeName, attributeValue, themeValue ) => {
	const config = ATTRIBUTE_CONFIG[ attributeName ];

	// If no config, treat as normal comparison
	if ( ! config ) {
		return attributeValue !== themeValue;
	}

	// Skip null/undefined values (not set = not customized)
	if ( attributeValue === null || attributeValue === undefined ) {
		return false;
	}

	// Handle boolean attributes with special rules
	if ( config.type === 'boolean' ) {
		// If false is NOT a customization and value is false, skip it
		if ( config.treatFalseAsCustomization === false && attributeValue === false ) {
			return false;
		}
		// Otherwise, check if it differs from theme
		return attributeValue !== themeValue;
	}

	// For all other types, simple comparison
	return attributeValue !== themeValue;
};

/**
 * Title formatting options
 */
export const TITLE_TEXT_ALIGN_OPTIONS = [
	{ label: 'Inherit from theme', value: '' },
	{ label: 'Left', value: 'left' },
	{ label: 'Center', value: 'center' },
	{ label: 'Right', value: 'right' },
	{ label: 'Justify', value: 'justify' },
];

export const TITLE_FONT_WEIGHT_OPTIONS = [
	{ label: 'Inherit from theme', value: '' },
	{ label: 'Thin (100)', value: '100' },
	{ label: 'Extra Light (200)', value: '200' },
	{ label: 'Light (300)', value: '300' },
	{ label: 'Normal (400)', value: '400' },
	{ label: 'Medium (500)', value: '500' },
	{ label: 'Semi Bold (600)', value: '600' },
	{ label: 'Bold (700)', value: '700' },
	{ label: 'Extra Bold (800)', value: '800' },
	{ label: 'Black (900)', value: '900' },
];

export const TITLE_FONT_STYLE_OPTIONS = [
	{ label: 'Inherit from theme', value: '' },
	{ label: 'Normal', value: 'normal' },
	{ label: 'Italic', value: 'italic' },
	{ label: 'Oblique', value: 'oblique' },
];

export const TITLE_TEXT_TRANSFORM_OPTIONS = [
	{ label: 'Inherit from theme', value: '' },
	{ label: 'None', value: 'none' },
	{ label: 'Capitalize', value: 'capitalize' },
	{ label: 'Uppercase', value: 'uppercase' },
	{ label: 'Lowercase', value: 'lowercase' },
];

export const TITLE_TEXT_DECORATION_OPTIONS = [
	{ label: 'Inherit from theme', value: '' },
	{ label: 'None', value: 'none' },
	{ label: 'Underline', value: 'underline' },
	{ label: 'Overline', value: 'overline' },
	{ label: 'Line Through', value: 'line-through' },
];

/**
 * Fallback colors for ColorPicker display
 */
export const FALLBACK_COLORS = {
	BORDER: '#666666',
	HEADER_TEXT: '#333333',
	HEADER_BG: 'transparent',
	CONTENT_BG: 'transparent',
	HEADER_HOVER: '#f0f0f0',
};
