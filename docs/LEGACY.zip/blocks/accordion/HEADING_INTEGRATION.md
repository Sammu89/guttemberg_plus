# Heading Attributes - Full Automation Tree Integration

## Overview

**All heading-related attributes are now fully integrated into the automation tree.**

Previously, `useHeading` and `useHeadingStyles` were per-accordion settings. Now they are **theme customizations** that save to themes and propagate globally.

---

## Updated ATTRIBUTE_CONFIG

```javascript
export const ATTRIBUTE_CONFIG = {
    // === TITLE FORMATTING (Now 12 attributes total) ===

    // NEW: Use semantic HTML heading
    useHeading: {
        type: 'boolean',
        defaultValue: false,
        section: 'titleFormatting',
        treatFalseAsCustomization: true, // Both true/false can differ from theme
    },

    // NEW: Heading level (H1-H6)
    headingLevel: {
        type: 'string',
        defaultValue: 'h2',
        section: 'titleFormatting',
    },

    // NEW: Apply WordPress theme heading styles
    useHeadingStyles: {
        type: 'boolean',
        defaultValue: false,
        section: 'titleFormatting',
        treatFalseAsCustomization: true, // Both true/false can differ from theme
    },

    // EXISTING: Custom title formatting toggle
    useCustomTitleFormatting: {
        type: 'boolean',
        defaultValue: false,
        section: 'titleFormatting',
        isToggle: true,
        treatFalseAsCustomization: true,
        childAttributes: [
            'titleTextAlign',
            'titleFontSize',
            'titleFontWeight',
            'titleFontStyle',
            'titleTextTransform',
            'titleLetterSpacing',
            'titleWordSpacing',
            'titleTextDecoration',
            'titleFontFamily',
        ],
    },

    // EXISTING: 9 formatting attributes
    titleTextAlign: { ... },
    titleFontSize: { ... },
    // ... etc
};
```

**Total Customization Attributes:** 33 (was 31)

---

## Complete Flow Scenarios

### Scenario 1: Enable "Use heading for title"

```
User Action: Toggle ON "Use heading for title"
                    ↓
┌─────────────────────────────────────────────────┐
│ TitlePanel.js:73-76                             │
├─────────────────────────────────────────────────┤
│ setAttributes({ useHeading: true });            │
│ markAsCustomized(); ← Checks if differs        │
└─────────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────────┐
│ markAsCustomized() checks:                      │
│ isAttributeCustomization(                       │
│   'useHeading',                                 │
│   true,  ← User just enabled                    │
│   false  ← Theme default                        │
│ )                                               │
│ → Returns true (differs from theme)             │
│ → Sets isCustomized: true                       │
└─────────────────────────────────────────────────┘
                    ↓
         Result: Accordion shows "(custom)"
         Heading level selector appears
         Title renders as <h2> in editor
                    ↓
┌─────────────────────────────────────────────────┐
│ When saving to theme:                           │
│ collectEffectiveSettings() →                    │
│ {                                               │
│   useHeading: true,        ✅ SAVED             │
│   headingLevel: 'h2',      ✅ SAVED             │
│   // ... other attributes                       │
│ }                                               │
└─────────────────────────────────────────────────┘
                    ↓
         All accordions using theme get headings!
```

---

### Scenario 2: Change Heading Level

```
User Action: Select "H3" from dropdown
                    ↓
┌─────────────────────────────────────────────────┐
│ TitlePanel.js:89-92                             │
├─────────────────────────────────────────────────┤
│ setAttributes({ headingLevel: 'h3' });          │
│ markAsCustomized(); ← Checks if differs        │
└─────────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────────┐
│ markAsCustomized() checks:                      │
│ isAttributeCustomization(                       │
│   'headingLevel',                               │
│   'h3',  ← User selected                        │
│   'h2'   ← Theme default                        │
│ )                                               │
│ → Returns true (differs from theme)             │
│ → Sets isCustomized: true                       │
└─────────────────────────────────────────────────┘
                    ↓
         Result: Accordion shows "(custom)"
         Title renders as <h3>
                    ↓
┌─────────────────────────────────────────────────┐
│ When saving to theme:                           │
│ collectEffectiveSettings() →                    │
│ {                                               │
│   useHeading: true,                             │
│   headingLevel: 'h3',      ✅ SAVED             │
│   // ... other attributes                       │
│ }                                               │
└─────────────────────────────────────────────────┘
                    ↓
         All accordions using theme get H3!
```

---

### Scenario 3: Enable "Use WordPress heading styles"

```
User Action: Toggle ON "Use WordPress heading styles"
                    ↓
┌─────────────────────────────────────────────────┐
│ TitlePanel.js:106-114                           │
├─────────────────────────────────────────────────┤
│ setAttributes({                                 │
│   useHeadingStyles: true,                       │
│   useCustomTitleFormatting: false ← Disable     │
│ });                                             │
│ markAsCustomized(); ← Checks both               │
└─────────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────────┐
│ markAsCustomized() checks BOTH:                 │
│                                                 │
│ 1. isAttributeCustomization(                    │
│      'useHeadingStyles',                        │
│      true,  ← User enabled                      │
│      false  ← Theme default                     │
│    ) → TRUE                                     │
│                                                 │
│ 2. isAttributeCustomization(                    │
│      'useCustomTitleFormatting',                │
│      false, ← Just disabled                     │
│      true   ← Theme has it enabled              │
│    ) → TRUE (if theme differs)                  │
│                                                 │
│ → Sets isCustomized: true                       │
└─────────────────────────────────────────────────┘
                    ↓
         Result: Accordion shows "(custom)"
         Title gets WordPress theme styles (large, bold)
         Custom formatting controls hidden
                    ↓
┌─────────────────────────────────────────────────┐
│ When saving to theme:                           │
│ collectEffectiveSettings() →                    │
│ {                                               │
│   useHeading: true,                             │
│   headingLevel: 'h2',                           │
│   useHeadingStyles: true,  ✅ SAVED             │
│   useCustomTitleFormatting: false, ✅ SAVED     │
│   // Custom formatting attrs NOT included       │
│ }                                               │
└─────────────────────────────────────────────────┘
                    ↓
         All accordions using theme get WP styles!
```

---

### Scenario 4: Enable Custom Title Formatting

```
User Action: Toggle ON "Use custom title formatting"
                    ↓
┌─────────────────────────────────────────────────┐
│ TitlePanel.js:146-152                           │
├─────────────────────────────────────────────────┤
│ setAttributes({                                 │
│   useCustomTitleFormatting: true,               │
│   useHeadingStyles: false ← Disable             │
│ });                                             │
│ markAsCustomized();                             │
└─────────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────────┐
│ markAsCustomized() checks BOTH:                 │
│                                                 │
│ 1. isAttributeCustomization(                    │
│      'useCustomTitleFormatting',                │
│      true,  ← User enabled                      │
│      false  ← Theme default                     │
│    ) → TRUE                                     │
│                                                 │
│ 2. isAttributeCustomization(                    │
│      'useHeadingStyles',                        │
│      false, ← Just disabled                     │
│      true   ← Theme has it enabled (maybe)      │
│    ) → TRUE (if theme differs)                  │
│                                                 │
│ → Sets isCustomized: true                       │
└─────────────────────────────────────────────────┘
                    ↓
         Result: Accordion shows "(custom)"
         Custom formatting controls appear
         User can set titleTextAlign, fontSize, etc.
                    ↓
┌─────────────────────────────────────────────────┐
│ When saving to theme:                           │
│ collectEffectiveSettings() →                    │
│ {                                               │
│   useHeading: true,                             │
│   headingLevel: 'h2',                           │
│   useHeadingStyles: false, ✅ SAVED             │
│   useCustomTitleFormatting: true, ✅ SAVED      │
│   titleTextAlign: 'center',   ✅ SAVED          │
│   titleFontSize: '20px',      ✅ SAVED          │
│   // ... all child attributes                   │
│ }                                               │
└─────────────────────────────────────────────────┘
                    ↓
         All accordions using theme get custom formatting!
```

---

## Mutual Exclusivity Logic

```javascript
// useHeadingStyles and useCustomTitleFormatting are mutually exclusive

// When enabling useHeadingStyles:
setAttributes({
    useHeadingStyles: true,
    useCustomTitleFormatting: false, // ← Auto-disable
});

// When enabling useCustomTitleFormatting:
setAttributes({
    useCustomTitleFormatting: true,
    useHeadingStyles: false, // ← Auto-disable
});
```

**Why both are saved to theme:**
- Even though they're mutually exclusive, both states need to be saved
- A theme might have `useHeadingStyles: false` (explicit choice)
- Another accordion might customize it to `true` → shows "(custom)"
- Saving to theme propagates the choice globally

---

## Complete Automation Tree

```
ATTRIBUTE_CONFIG (33 attributes)
    ├── colors (5)
    ├── mainBorder (3)
    ├── dividerBorder (3)
    ├── borderRadius (4)
    ├── animation (1)
    ├── icon (5)
    └── titleFormatting (12) ← UPDATED!
        ├── useHeading ✅ NEW
        ├── headingLevel ✅ NEW
        ├── useHeadingStyles ✅ NEW
        ├── useCustomTitleFormatting
        └── [9 formatting attributes]
            ├── titleTextAlign
            ├── titleFontSize
            ├── titleFontWeight
            ├── titleFontStyle
            ├── titleTextTransform
            ├── titleLetterSpacing
            ├── titleWordSpacing
            ├── titleTextDecoration
            └── titleFontFamily
```

---

## What's Auto-Generated

All of these now work automatically for heading attributes:

1. ✅ **Clearing** - Uses `defaultValue` from config
   ```javascript
   useHeading → false
   headingLevel → 'h2'
   useHeadingStyles → false
   ```

2. ✅ **Comparison** - Uses `treatFalseAsCustomization` rule
   ```javascript
   // Both true and false can be customizations
   isAttributeCustomization('useHeading', false, true) → true
   isAttributeCustomization('useHeading', true, false) → true
   ```

3. ✅ **Saving to Themes** - Auto-collected by `collectEffectiveSettings()`
   ```javascript
   CUSTOMIZATION_ATTRIBUTES.forEach(attr => {
       // Includes: useHeading, headingLevel, useHeadingStyles
       settings[attr] = getEffectiveValue(attr, attr);
   });
   ```

4. ✅ **Loading from Themes** - Auto-applied by `getEffectiveValue()`
   ```javascript
   getEffectiveValue('useHeading', 'useHeading')
   // Checks: inline → theme → default
   ```

5. ✅ **Customization Detection** - Auto-checked by `markAsCustomized()`
   ```javascript
   for (const attr of CUSTOMIZATION_ATTRIBUTES) {
       // Includes: useHeading, headingLevel, useHeadingStyles
       if (isAttributeCustomization(attr, value, themeValue)) {
           markAsCustomized();
       }
   }
   ```

6. ✅ **Cache Management** - Auto-saved/restored when switching themes
   ```javascript
   customizationCache[themeId] = {
       useHeading: true,
       headingLevel: 'h3',
       useHeadingStyles: true,
       // ... all other customizations
   };
   ```

---

## Benefits of This Integration

### 1. Complete Consistency
**Before:** Some attributes saved to themes, others didn't
**After:** ALL 33 attributes follow the same logic

### 2. Theme Reusability
**Before:** Each accordion had to manually set heading preferences
**After:** Create a theme with heading settings, apply to all accordions

### 3. Global Updates
**Before:** Changing heading approach required editing each accordion
**After:** Update theme → all accordions using it change instantly

### 4. Proper Customization Detection
**Before:** Changing heading settings didn't mark as customized
**After:** Any change from theme shows "(custom)" correctly

### 5. Zero Maintenance
**Before:** Had to manually update multiple code locations
**After:** Single source of truth in `ATTRIBUTE_CONFIG`

---

## Example Use Cases

### Use Case 1: SEO-Focused Blog Theme
```javascript
// Create theme: "Blog Post Accordion"
{
    useHeading: true,
    headingLevel: 'h3',
    useHeadingStyles: false,
    useCustomTitleFormatting: true,
    titleFontSize: '18px',
    titleFontWeight: '600',
    // ... proper semantic headings with custom styling
}
```
Apply to all blog post accordions → Consistent SEO + styling

---

### Use Case 2: FAQ Page Theme
```javascript
// Create theme: "FAQ Accordion"
{
    useHeading: true,
    headingLevel: 'h2',
    useHeadingStyles: true,
    useCustomTitleFormatting: false,
    // ... WordPress theme styles for questions
}
```
Apply to FAQ page → Large, bold questions using theme typography

---

### Use Case 3: Sidebar Widget Theme
```javascript
// Create theme: "Sidebar Widget"
{
    useHeading: false, // Not semantic headings
    headingLevel: 'h2', // Unused since useHeading is false
    useHeadingStyles: false,
    useCustomTitleFormatting: true,
    titleFontSize: '14px',
    titleFontWeight: 'normal',
    // ... small, compact styling
}
```
Apply to sidebar widgets → Consistent compact appearance

---

## Testing Checklist

For each new heading attribute:

- [ ] ✅ Change in sidebar → preview updates
- [ ] ✅ Save post → reload → persists
- [ ] ✅ Shows "(custom)" when differs from theme
- [ ] ✅ Save as new theme → attribute saved
- [ ] ✅ Update theme → propagates to all accordions
- [ ] ✅ Switch theme → cache restores value
- [ ] ✅ Clear customizations → uses `defaultValue`
- [ ] ✅ Mutually exclusive toggles work correctly

---

## Summary

**Added to Automation Tree:**
- `useHeading` (boolean, treatFalseAsCustomization: true)
- `headingLevel` (string, default: 'h2')
- `useHeadingStyles` (boolean, treatFalseAsCustomization: true)

**Total Customization Attributes:** 33 (was 31)

**All heading attributes now:**
- ✅ Save to themes
- ✅ Load from themes
- ✅ Mark as customized when changed
- ✅ Clear with correct defaults
- ✅ Propagate globally on theme update
- ✅ Cache when switching themes
- ✅ Follow same logic as all other customizations

**Zero special cases. Complete consistency. Single source of truth.**
