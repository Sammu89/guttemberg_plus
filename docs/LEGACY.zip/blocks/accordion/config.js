/**
 * Accordion Block - Attribute Configuration
 * Defines all customization attributes with metadata
 *
 * This configuration is consumed by the centralized customization core
 * to provide theme management, value resolution, and customization detection.
 *
 * @module accordion-config
 */

/**
 * Accordion attribute configuration - Single source of truth
 * Defines all 33 customization attributes with type, default value, and section
 *
 * @constant {Object}
 */
export const ACCORDION_ATTRIBUTE_CONFIG = {
	// === COLORS ===
	headerBackgroundColor: {
		type: 'string',
		defaultValue: null,
		section: 'colors',
	},
	headerTextColor: {
		type: 'string',
		defaultValue: null,
		section: 'colors',
	},
	headerHoverColor: {
		type: 'string',
		defaultValue: null,
		section: 'colors',
	},
	contentBackgroundColor: {
		type: 'string',
		defaultValue: null,
		section: 'colors',
	},

	// === MAIN BORDER ===
	borderColor: {
		type: 'string',
		defaultValue: null,
		section: 'mainBorder',
	},
	borderWidth: {
		type: 'number',
		defaultValue: null,
		section: 'mainBorder',
	},
	borderStyle: {
		type: 'string',
		defaultValue: null,
		section: 'mainBorder',
	},

	// === DIVIDER BORDER ===
	dividerBorderColor: {
		type: 'string',
		defaultValue: null,
		section: 'dividerBorder',
	},
	dividerBorderWidth: {
		type: 'number',
		defaultValue: null,
		section: 'dividerBorder',
	},
	dividerBorderStyle: {
		type: 'string',
		defaultValue: null,
		section: 'dividerBorder',
	},

	// === BORDER RADIUS ===
	borderRadiusTopLeft: {
		type: 'number',
		defaultValue: null,
		section: 'borderRadius',
	},
	borderRadiusTopRight: {
		type: 'number',
		defaultValue: null,
		section: 'borderRadius',
	},
	borderRadiusBottomLeft: {
		type: 'number',
		defaultValue: null,
		section: 'borderRadius',
	},
	borderRadiusBottomRight: {
		type: 'number',
		defaultValue: null,
		section: 'borderRadius',
	},

	// === ANIMATION ===
	animationSpeed: {
		type: 'string',
		defaultValue: null,
		section: 'animation',
	},

	// === ICON ===
	showIcon: {
		type: 'boolean',
		defaultValue: null,
		section: 'icon',
		isToggle: true,
		childAttributes: ['icon', 'iconType', 'iconPosition', 'animateIcon'],
	},
	icon: {
		type: 'string',
		defaultValue: null,
		section: 'icon',
	},
	iconType: {
		type: 'string',
		defaultValue: null,
		section: 'icon',
	},
	iconPosition: {
		type: 'string',
		defaultValue: null,
		section: 'icon',
	},
	animateIcon: {
		type: 'boolean',
		defaultValue: null,
		section: 'icon',
	},

	// === TITLE FORMATTING ===
	useHeading: {
		type: 'boolean',
		defaultValue: false,
		section: 'titleFormatting',
	},
	headingLevel: {
		type: 'string',
		defaultValue: 'h2',
		section: 'titleFormatting',
	},
	useHeadingStyles: {
		type: 'boolean',
		defaultValue: false,
		section: 'titleFormatting',
	},
	useCustomTitleFormatting: {
		type: 'boolean',
		defaultValue: false,
		section: 'titleFormatting',
		isToggle: true,
		childAttributes: [
			'titleTextAlign',
			'titleFontSize',
			'titleFontWeight',
			'titleFontStyle',
			'titleTextTransform',
			'titleLetterSpacing',
			'titleWordSpacing',
			'titleTextDecoration',
			'titleFontFamily',
		],
	},
	titleTextAlign: {
		type: 'string',
		defaultValue: null,
		section: 'titleFormatting',
	},
	titleFontSize: {
		type: 'string',
		defaultValue: null,
		section: 'titleFormatting',
	},
	titleFontWeight: {
		type: 'string',
		defaultValue: null,
		section: 'titleFormatting',
	},
	titleFontStyle: {
		type: 'string',
		defaultValue: null,
		section: 'titleFormatting',
	},
	titleTextTransform: {
		type: 'string',
		defaultValue: null,
		section: 'titleFormatting',
	},
	titleLetterSpacing: {
		type: 'string',
		defaultValue: null,
		section: 'titleFormatting',
	},
	titleWordSpacing: {
		type: 'string',
		defaultValue: null,
		section: 'titleFormatting',
	},
	titleTextDecoration: {
		type: 'string',
		defaultValue: null,
		section: 'titleFormatting',
	},
	titleFontFamily: {
		type: 'string',
		defaultValue: null,
		section: 'titleFormatting',
	},
};

/**
 * Customization sections grouped by category
 * Auto-generated from ACCORDION_ATTRIBUTE_CONFIG
 *
 * @constant {Object}
 */
export const ACCORDION_CUSTOMIZATION_SECTIONS = Object.entries(ACCORDION_ATTRIBUTE_CONFIG).reduce(
	(sections, [attrName, config]) => {
		const section = config.section;
		if (!sections[section]) {
			sections[section] = [];
		}
		sections[section].push(attrName);
		return sections;
	},
	{}
);

/**
 * Flattened list of all customization attribute names
 * Auto-generated from ACCORDION_ATTRIBUTE_CONFIG keys
 *
 * @constant {Array<string>}
 */
export const ACCORDION_CUSTOMIZATION_ATTRIBUTES = Object.keys(ACCORDION_ATTRIBUTE_CONFIG);
