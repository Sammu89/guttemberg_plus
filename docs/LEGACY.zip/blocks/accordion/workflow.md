# Accordion Block Plugin - Complete Workflow Documentation

**Last Updated:** 2025-10-07
**Purpose:** Complete lifecycle documentation for Phase 1 refactoring (research-only)

This document maps the entire Accordion block plugin lifecycle from registration to theme management to rendering. Understanding this flow is critical before refactoring.

---

## Table of Contents

1. [Plugin Entry Points](#1-plugin-entry-points)
2. [Block Registration Flow](#2-block-registration-flow)
3. [Editor Flow (Gutenberg)](#3-editor-flow-gutenberg)
4. [Theme Management System](#4-theme-management-system)
5. [Customization System](#5-customization-system)
6. [Persistence & Serialization](#6-persistence--serialization)
7. [Frontend Rendering](#7-frontend-rendering)
8. [Key File Map](#8-key-file-map)
9. [Complete Lifecycle Flow](#9-complete-lifecycle-flow)

---

## 1. Plugin Entry Points

### 1.1 Main Plugin File (PHP)

**File:** `C:\Users\Sammu\Desktop\guttemberg-smpt\guten-nav-plugin.php`

**Purpose:** WordPress plugin bootstrap - initializes all blocks and assets

**Key Responsibilities:**
- Defines plugin constants (`GUTEN_NAV_PLUGIN_PATH`, `GUTEN_NAV_PLUGIN_URL`)
- Registers WordPress hooks
- Creates `GutenNavPlugin` class instance

**Hook Registration (lines 19-30):**
```php
add_action('init', array($this, 'register_blocks'));
add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
add_action('enqueue_block_editor_assets', array($this, 'enqueue_editor_assets'));

// Theme management AJAX endpoints
add_action('wp_ajax_get_accordion_themes', array($this, 'get_accordion_themes'));
add_action('wp_ajax_save_accordion_theme', array($this, 'save_accordion_theme'));
add_action('wp_ajax_delete_accordion_theme', array($this, 'delete_accordion_theme'));
```

### 1.2 Block Registration (PHP)

**Method:** `GutenNavPlugin::register_blocks()` (line 33-43)

**Block Registration:**
```php
register_block_type(GUTEN_NAV_PLUGIN_PATH . 'blocks/accordion');
```

This registers the accordion block using block.json metadata.

### 1.3 Asset Enqueueing

#### **Frontend Assets** (line 45-70)

**Conditional Loading Strategy:**
- Only loads assets if block is present in post content
- Uses `has_block('sammu/accordion', $content)` check
- Loads JavaScript: `assets/js/accordion.js`
- Loads CSS: `assets/css/accordion.css`
- **Special:** Injects theme CSS variables via `inject_accordion_theme_styles()` (line 68)

**Theme CSS Injection** (line 806-906):
- Retrieves themes from WordPress options: `get_option('accordion_themes', array())`
- Generates CSS classes for each theme (`.accordion-theme-{themeId}`)
- Injects CSS variables: `--header-bg-color`, `--border-width`, etc.
- Uses `wp_add_inline_style('guten-nav-accordion', $css)`

#### **Editor Assets** (line 72-79)

**AJAX Configuration:**
```php
wp_localize_script('wp-blocks', 'accordionGlobalSettings', array(
    'ajaxurl' => admin_url('admin-ajax.php'),
    'nonce' => wp_create_nonce('accordion_global_settings'),
    'themesNonce' => wp_create_nonce('accordion_themes')
));
```

This makes AJAX URL and nonces available to JavaScript via `window.accordionGlobalSettings`.

---

## 2. Block Registration Flow

### 2.1 block.json Configuration

**File:** `C:\Users\Sammu\Desktop\guttemberg-smpt\blocks\accordion\block.json`

**Key Settings:**
- **API Version:** 3
- **Block Name:** `sammu/accordion`
- **Category:** `widgets`
- **Editor Script:** `file:../../build/accordion/index.js`
- **Editor Style:** `file:../../assets/css/accordion-editor.css`

**Supports:**
```json
"supports": {
    "html": false,
    "anchor": true,
    "customClassName": true
}
```

**Critical Attributes (lines 18-194):**
- `title`: Accordion title text
- `accordionId`: Unique identifier
- `selectedTheme`: Currently selected theme ID
- `baseTheme`: Base theme when customized
- `isCustomized`: Flag indicating customization
- `isOpen`: Default open state on frontend
- `disabled`: Visibility toggle
- Color attributes: `headerBackgroundColor`, `headerTextColor`, etc.
- Border attributes: `borderColor`, `borderWidth`, `borderStyle`
- Border radius: `borderRadiusTopLeft`, `borderRadiusTopRight`, etc.
- Icon attributes: `showIcon`, `icon`, `iconType`, `iconPosition`, `animateIcon`
- Title formatting: `titleTextAlign`, `titleFontSize`, etc.

**Default Values:**
- Most customization attributes default to `null` (inherit from theme)
- Booleans like `contentBackgroundTransparent` default to `false`
- `selectedTheme` and `baseTheme` default to `"default"`

### 2.2 JavaScript Registration

**File:** `C:\Users\Sammu\Desktop\guttemberg-smpt\blocks\accordion\index.js`

**Registration Code:**
```javascript
import { registerBlockType } from '@wordpress/blocks';
import metadata from './block.json';
import Edit from './edit';
import Save from './save';

registerBlockType( metadata.name, {
    ...metadata,
    edit: Edit,
    save: Save,
} );
```

This connects the block metadata with Edit and Save components.

---

## 3. Editor Flow (Gutenberg)

### 3.1 Edit Component Lifecycle

**File:** `C:\Users\Sammu\Desktop\guttemberg-smpt\blocks\accordion\edit.js` (1260 lines)

#### **Component Initialization (lines 51-98)**

**Props Received:**
- `attributes`: All block attributes from block.json
- `setAttributes`: Function to update attributes
- `clientId`: Unique block instance ID

**Destructuring:** All 40+ attributes are destructured for easy access

#### **State Management (lines 92-135)**

**WordPress Hooks Used:**
1. `useDispatch(noticesStore)`: For showing warnings
2. `useSelect(editorStore)`: For detecting post save events
3. `useState`: For local UI state (save state tracking)

**Custom Hooks Imported (lines 34-38):**
```javascript
import useThemeManagement from './hooks/useThemeManagement';
import useAccordionState from './hooks/useAccordionState';
import useEffectiveValue from './hooks/useEffectiveValue';
import useEffectiveValues from './hooks/useEffectiveValues';
```

**Hook Initialization:**
```javascript
const {
    allThemes,
    defaultTheme,
    isLoadingThemes,
    isSavingTheme,
    isDeletingTheme,
    saveNotification,
    setSaveNotification,
    error: themeError,
    setError: setThemeError,
    handleSaveTheme,
    handleDeleteTheme,
    handleRenameTheme,
    handleCreateTheme,
    setAllThemes,
} = useThemeManagement();

const getEffectiveValue = useEffectiveValue(
    allThemes,
    selectedTheme,
    defaultTheme,
    attributes
);

const sidebarValues = useEffectiveValues( getEffectiveValue );

const {
    customizationCache,
    setCustomizationCache,
    enableDividerBorder,
    setEnableDividerBorder,
} = useAccordionState( attributes, allThemes, getEffectiveValue );
```

#### **React useEffect Hooks** (Major side effects)

**1. Theme Update Listener (lines 169-198):**
- Listens for `accordionThemeUpdated` custom events
- Syncs theme data across all accordion blocks on page
- Clears customizations when theme is updated elsewhere

**2. Accordion ID Generation (lines 200-207):**
- Generates unique 4-character ID if not set
- Format: `accordion-{4chars}`

**3. Auto-Cleanup of False Customizations (lines 209-286):**
- Detects and removes invalid customizations
- Runs when themes load or change
- Compares all customization attributes against theme
- Clears `isCustomized` flag if no real differences exist

**4. Save Notification Auto-Hide (lines 289-296):**
- Auto-hides notifications after 3 seconds
- Timeout: `UI_CONSTANTS.NOTIFICATION_TIMEOUT` (3000ms)

**5. Cached Customization Warning (lines 298-335):**
- Warns user when saving post with cached customizations
- Prevents data loss from switching themes before saving

**6. Theme Safety Check (lines 337-382):**
- Validates `selectedTheme` and `baseTheme` exist
- Falls back to `default` if theme was deleted
- Clears customizations when theme is missing

**7. Heading Styles Mutual Exclusivity (lines 384-394):**
- Enforces: `useHeadingStyles` and `useCustomTitleFormatting` cannot both be ON
- Priority: `useCustomTitleFormatting` wins

**8. Custom Title Formatting Cleanup (lines 396-416):**
- Clears title formatting attributes when toggle is OFF
- Prevents leakage of old values

#### **Event Handlers (Key Functions)**

**Theme Selection Handler** (lines 418-498):
```javascript
const handleThemeChange = useCallback((value) => {
    // Handles:
    // 1. Restoring customizations from cache ("{themeId}-customized")
    // 2. Caching current customizations before switching away
    // 3. Clearing customizations when selecting clean theme
    // 4. Announcing changes to screen readers
}, [dependencies]);
```

**Collect Effective Settings** (lines 500-518):
- Gathers all effective values (theme + customizations)
- Used when saving/creating themes
- Loops through `CUSTOMIZATION_ATTRIBUTES`

**Mark As Customized** (lines 524-580):
- Sets `isCustomized` flag when attribute changes
- Validates customization actually differs from theme
- Uses `isAttributeCustomization()` from constants.js

**Switch To Clean Theme** (lines 143-166):
- Shared logic for theme updates and new theme creation
- Clears all customizations and sets new theme
- Clears customization cache for theme

#### **Memoized Values** (lines 583-672)

**Effective Values Calculation:**
```javascript
const effectiveValues = useMemo(() => {
    // Computes effective values for rendering
    // Resolution order:
    // 1. Inline customization (attribute)
    // 2. Selected theme value
    // 3. Default theme value
    // 4. Hardcoded fallback

    return {
        headerBg: getEffectiveValue('headerBackgroundColor', 'headerBackgroundColor'),
        // ... 20+ more values
    };
}, [dependencies]);
```

**Editor Styles Object** (lines 675-724):
- Builds inline styles for editor preview
- Sets CSS variables: `--header-bg-color`, `--border-width`, etc.
- Applies border radius only if non-zero values exist

### 3.2 Inspector Sidebar Components

**File:** `C:\Users\Sammu\Desktop\guttemberg-smpt\blocks\accordion\edit.js` (lines 857-931)

**Component Tree:**
```
<InspectorControls>
├── <SettingsPanel>           → Theme selector, basic settings
├── <AppearancePanel>         → Colors, transparency
├── <TitlePanel>              → Title formatting options
├── <BorderPanel>             → Main and divider borders
├── <BorderRadiusPanel>       → Corner radius controls
├── <AnimationPanel>          → Animation speed
├── <IconPanel>               → Icon settings
└── <PanelBody> (Instructions) → Help text
```

#### **SettingsPanel** (Always visible, non-collapsible)

**File:** `C:\Users\Sammu\Desktop\guttemberg-smpt\blocks\accordion\components\inspector\SettingsPanel.js`

**Contents:**
- Theme selector dropdown (via `ThemeSelector` component)
- Theme management buttons:
  - "Update theme with these settings" (if customized)
  - "Save these settings as new theme" (if customized)
  - "Rename theme" (if not default)
  - "Delete theme" (if not default)
- Horizontal alignment selector
- Width text input
- "Appears open by default" toggle
- "Disable this accordion" toggle

**Theme Management Flow:**
1. User customizes colors/borders in other panels
2. `isCustomized` flag is set to `true`
3. Theme buttons appear in SettingsPanel
4. User clicks "Update theme" or "Save as new theme"
5. Calls `collectEffectiveSettings()` to gather all values
6. Calls `handleSaveTheme()` or `handleCreateTheme()`
7. AJAX request sent to PHP backend
8. Theme saved to WordPress options table
9. Custom event `accordionThemeUpdated` dispatched
10. All accordion blocks on page sync theme data

#### **ThemeSelector Component**

**File:** `C:\Users\Sammu\Desktop\guttemberg-smpt\blocks\accordion\components\ThemeSelector.js`

**Purpose:** Dropdown showing available themes with customization indicators

**Theme Options Format:**
- Clean themes: `"Default"`, `"Theme Name"`
- Customized themes: `"Theme Name (custom)"` with value `"{themeId}-customized"`

**Customization Detection:**
- Shows "(custom)" suffix if theme is in `customizationCache`
- OR if `isCustomized` and `baseTheme` matches theme

#### **Other Inspector Panels**

**Files:** `blocks/accordion/components/inspector/`
- `AppearancePanel.js` → Color pickers, transparency toggle
- `TitlePanel.js` → Title formatting (font, alignment, etc.)
- `BorderPanel.js` → Main border and divider border controls
- `BorderRadiusPanel.js` → Individual corner radius sliders
- `AnimationPanel.js` → Animation speed selector
- `IconPanel.js` → Icon settings (type, position, animation)

**Common Pattern:**
1. Each panel receives `getEffectiveValue` function
2. Displays current effective value (theme or inline)
3. User changes value → calls `setAttributes()`
4. Calls `markAsCustomized()` to set `isCustomized` flag

### 3.3 BlockControls (Toolbar)

**File:** `C:\Users\Sammu\Desktop\guttemberg-smpt\blocks\accordion\edit.js` (lines 738-855)

**Toolbar Buttons:**
1. **Visibility Toggle** (eye icon) → Sets `disabled` attribute
2. **Open by Default** (page icon) → Sets `isOpen` attribute
3. **Quick Settings Dropdown** → Contains:
   - Accordion Title text input
   - Theme selector
   - Horizontal alignment selector

### 3.4 Block Editor Preview

**Rendering** (lines 1051-1254):
- Shows disabled badge if `disabled` is true
- Renders accordion toggle button with:
  - Icon (positioned left/right/extreme-right)
  - RichText for title editing
  - Custom title formatting styles (if enabled)
- Renders accordion content area with:
  - InnerBlocks for nested content
  - Always open in editor (for easy editing)
  - Live style preview (borders, colors, radius)

---

## 4. Theme Management System

### 4.1 Database Storage

**WordPress Options Table:**
- **Option Key:** `accordion_themes`
- **Data Type:** Serialized PHP array
- **Structure:**
```php
array(
    'default' => array(
        'theme_id' => 'default',
        'theme_name' => 'Default',
        'headerBackgroundColor' => '#f8f9fa',
        'headerTextColor' => '#495057',
        // ... all customization attributes
    ),
    'theme-A7' => array(
        'theme_id' => 'theme-A7',
        'theme_name' => 'My Custom Theme',
        'headerBackgroundColor' => '#007cba',
        // ...
    )
)
```

**Theme ID Format:**
- Default theme: `"default"` (hardcoded, read-only)
- Custom themes: `"theme-{2chars}"` where chars are A-Z0-9
- Example: `theme-A7`, `theme-K3`, `theme-Z9`

**Default Theme** (PHP lines 543-564):
- Always included in responses
- Cannot be edited or deleted
- Provides fallback values for all attributes

### 4.2 AJAX Endpoints

**Base Configuration:**
- **AJAX URL:** `window.accordionGlobalSettings.ajaxurl` (`/wp-admin/admin-ajax.php`)
- **Nonce:** `window.accordionGlobalSettings.themesNonce`
- **Security:** WordPress nonce verification on all requests

#### **Get Themes Endpoint**

**Action:** `wp_ajax_get_accordion_themes`
**PHP Method:** `GutenNavPlugin::get_accordion_themes()` (lines 331-354)
**JS Wrapper:** `loadThemes()` in `utils/ajax.js` (lines 175-177)

**Request:**
```javascript
POST /wp-admin/admin-ajax.php
action: 'get_accordion_themes'
nonce: '{themesNonce}'
```

**Response:**
```javascript
{
    success: true,
    data: {
        message: 'Themes retrieved successfully',
        themes: {
            default: { theme_id: 'default', theme_name: 'Default', ... },
            'theme-A7': { theme_id: 'theme-A7', theme_name: 'Custom', ... }
        }
    }
}
```

#### **Save Theme Endpoint**

**Action:** `wp_ajax_save_accordion_theme`
**PHP Method:** `GutenNavPlugin::save_accordion_theme()` (lines 359-481)
**JS Wrapper:** `saveTheme(themeId, settings)` in `utils/ajax.js` (lines 198-203)

**Request:**
```javascript
POST /wp-admin/admin-ajax.php
action: 'save_accordion_theme'
nonce: '{themesNonce}'
theme_id: 'theme-A7'
theme_name: 'My Theme'
headerBackgroundColor: '#007cba'
borderWidth: 2
// ... all other attributes
```

**Security & Validation (PHP):**
1. Nonce verification: `check_ajax_referer('accordion_themes', 'nonce', false)`
2. Capability check: `current_user_can('edit_posts')`
3. Cannot edit default theme check (line 433-441)
4. Two-layer sanitization:
   - **Layer 1:** Basic sanitization on POST values (lines 386-431)
   - **Layer 2:** Deep sanitization via `sanitize_theme_settings()` (lines 443-452)

**Sanitization Rules** (lines 569-693):
- Colors: `sanitize_color()` supports hex, rgba, hsla, rgb, hsl, transparent
- Border width: 0-10 pixels
- Border radius: 0-100 pixels
- Border style: Whitelist of valid CSS border styles
- Boolean values: `filter_var($value, FILTER_VALIDATE_BOOLEAN)`
- Enums: Whitelist validation (animation speeds, icon positions, etc.)

**Response:**
```javascript
{
    success: true,
    data: {
        message: 'Theme saved successfully',
        themes: {
            // Updated themes array with new/modified theme
        }
    }
}
```

#### **Delete Theme Endpoint**

**Action:** `wp_ajax_delete_accordion_theme`
**PHP Method:** `GutenNavPlugin::delete_accordion_theme()` (lines 486-538)
**JS Wrapper:** `deleteTheme(themeId)` in `utils/ajax.js` (lines 218-222)

**Request:**
```javascript
POST /wp-admin/admin-ajax.php
action: 'delete_accordion_theme'
nonce: '{themesNonce}'
theme_id: 'theme-A7'
```

**Security:**
- Nonce verification
- Capability check: `current_user_can('edit_posts')`
- Cannot delete default theme (lines 507-511)

**Response:**
```javascript
{
    success: true,
    data: {
        message: 'Theme "My Theme" deleted successfully!',
        themes: {
            // Updated themes array without deleted theme
        }
    }
}
```

### 4.3 Theme Loading (Hook)

**File:** `C:\Users\Sammu\Desktop\guttemberg-smpt\blocks\accordion\hooks\useThemeManagement.js`

**Purpose:** React hook encapsulating all theme CRUD operations

**Hook Return Values:**
```javascript
const {
    // State
    allThemes,              // Object: all themes keyed by ID
    defaultTheme,           // Object: default theme data
    isLoadingThemes,        // Boolean: loading state
    isSavingTheme,          // Boolean: saving state
    isDeletingTheme,        // Boolean: deleting state
    saveNotification,       // Object: { message, panel }
    error,                  // String: error message or null

    // Functions
    handleSaveTheme,        // (themeId, settings) => Promise
    handleDeleteTheme,      // (themeId, selectedTheme, callback) => Promise
    handleRenameTheme,      // (themeId) => Promise
    handleCreateTheme,      // (settings) => Promise
    reloadThemes,           // () => Promise
    setAllThemes,           // (themes) => void
    setSaveNotification,    // (notification) => void
    setError,               // (error) => void
} = useThemeManagement();
```

**Load Themes on Mount** (lines 116-118):
```javascript
useEffect(() => {
    reloadThemes();
}, [reloadThemes]);
```

**Theme Loading Flow:**
1. Component mounts
2. `useThemeManagement()` hook initializes
3. `reloadThemes()` called automatically
4. Calls `loadThemes()` from `utils/ajax.js`
5. AJAX request sent to `get_accordion_themes`
6. Response sets `allThemes` and `defaultTheme` state
7. Sets `isLoadingThemes` to false
8. Editor UI renders with theme data

**Error Handling:**
- Network errors: Timeout, offline detection
- Fallback: Sets hardcoded default theme object (lines 97-109)

### 4.4 Theme Update Synchronization

**Custom Event System:**

**Dispatching (lines 156-160, 414-417):**
```javascript
const themeUpdateEvent = new CustomEvent('accordionThemeUpdated', {
    detail: { themeId, themes: data.themes, action: 'updated' }
});
window.dispatchEvent(themeUpdateEvent);
```

**Listening (edit.js lines 169-198):**
```javascript
useEffect(() => {
    const handleThemeUpdate = (event) => {
        const { themeId, themes } = event.detail;
        setAllThemes(themes); // Sync theme data

        // If this accordion uses updated theme, clear customizations
        if (selectedTheme === themeId || baseTheme === themeId) {
            switchToCleanTheme(themeId);
        }
    };

    window.addEventListener('accordionThemeUpdated', handleThemeUpdate);
    return () => window.removeEventListener('accordionThemeUpdated', handleThemeUpdate);
}, [dependencies]);
```

**Flow:**
1. User updates theme in Accordion A
2. Theme saved via AJAX
3. `accordionThemeUpdated` event dispatched
4. All accordion blocks on page (B, C, D) receive event
5. Each accordion syncs theme data
6. If using updated theme, clears customizations to show new theme

---

## 5. Customization System

### 5.1 ATTRIBUTE_CONFIG (Single Source of Truth)

**File:** `C:\Users\Sammu\Desktop\guttemberg-smpt\blocks\accordion\constants.js` (lines 100-302)

**Purpose:** Configuration-driven system for managing customization attributes

**Configuration Structure:**
```javascript
export const ATTRIBUTE_CONFIG = {
    headerBackgroundColor: {
        type: 'string',              // Data type
        defaultValue: null,          // Value when clearing
        section: 'colors',           // Grouping category
    },
    contentBackgroundTransparent: {
        type: 'boolean',
        defaultValue: false,
        section: 'colors',
        treatFalseAsCustomization: false, // Special handling
    },
    showIcon: {
        type: 'boolean',
        defaultValue: null,
        section: 'icon',
        isToggle: true,              // This controls child attributes
        childAttributes: ['icon', 'iconType', 'iconPosition', 'animateIcon'],
    },
    // ... 30+ more attributes
};
```

**Sections:**
- `colors`: Color attributes (header, content, hover)
- `mainBorder`: Main border (color, width, style)
- `dividerBorder`: Divider border between header and content
- `borderRadius`: Corner radius (4 corners individually)
- `animation`: Animation speed
- `icon`: Icon settings
- `titleFormatting`: Title formatting (font, alignment, etc.)

**Auto-Generated from Config:**

**1. CUSTOMIZATION_SECTIONS** (lines 308-318):
```javascript
export const CUSTOMIZATION_SECTIONS = {
    colors: ['headerBackgroundColor', 'headerTextColor', ...],
    mainBorder: ['borderColor', 'borderWidth', 'borderStyle'],
    // ... grouped by section
};
```

**2. CUSTOMIZATION_ATTRIBUTES** (line 324):
```javascript
export const CUSTOMIZATION_ATTRIBUTES = [
    'headerBackgroundColor',
    'headerTextColor',
    // ... flat array of all 30+ attributes
];
```

### 5.2 Customization Detection

**Helper Function:** `isAttributeCustomization()` (lines 347-372)

**Logic:**
```javascript
export const isAttributeCustomization = (attributeName, attributeValue, themeValue) => {
    const config = ATTRIBUTE_CONFIG[attributeName];

    // Skip null/undefined (not set = not customized)
    if (attributeValue === null || attributeValue === undefined) {
        return false;
    }

    // Special handling for booleans
    if (config.type === 'boolean') {
        // If false is NOT a customization and value is false, skip it
        if (config.treatFalseAsCustomization === false && attributeValue === false) {
            return false;
        }
    }

    // Compare with theme value
    return attributeValue !== themeValue;
};
```

**Examples:**
- `headerBackgroundColor: '#007cba'` (attribute) vs `'#f8f9fa'` (theme) → TRUE (customization)
- `headerBackgroundColor: '#007cba'` vs `'#007cba'` → FALSE (matches theme)
- `headerBackgroundColor: null` → FALSE (not set)
- `contentBackgroundTransparent: false` → FALSE (false is default, not customization)
- `useCustomTitleFormatting: false` vs `true` (theme) → TRUE (false can differ from theme)

### 5.3 Effective Value Resolution

**Hook:** `useEffectiveValue(allThemes, selectedTheme, defaultTheme, attributes)`

**File:** `C:\Users\Sammu\Desktop\guttemberg-smpt\blocks\accordion\hooks\useEffectiveValue.js`

**Resolution Order (Priority):**
1. **Inline customization** (attribute value) - HIGHEST
2. **Selected theme** value
3. **Default theme** value
4. **Hardcoded fallback** (null) - LOWEST

**Function Signature:**
```javascript
const getEffectiveValue = useCallback((attribute, themeAttribute) => {
    // 1. Check inline override
    if (attributes[attribute] !== null && attributes[attribute] !== undefined) {
        return attributes[attribute];
    }

    // 2. Check selected theme
    const selectedThemeSettings = allThemes[selectedTheme];
    if (selectedThemeSettings && selectedThemeSettings[themeAttribute] !== null) {
        return selectedThemeSettings[themeAttribute];
    }

    // 3. Fall back to default theme
    if (defaultTheme && defaultTheme[themeAttribute] !== null) {
        return defaultTheme[themeAttribute];
    }

    // 4. Return hardcoded fallback
    return null;
}, [allThemes, selectedTheme, defaultTheme, attributes]);
```

**Usage:**
```javascript
const effectiveColor = getEffectiveValue('headerBackgroundColor', 'headerBackgroundColor');
```

**Hook for All Values:** `useEffectiveValues(getEffectiveValue)`

**File:** `C:\Users\Sammu\Desktop\guttemberg-smpt\blocks\accordion\hooks\useEffectiveValues.js`

**Purpose:** Computes effective values for ALL customization attributes at once

**Returns:**
```javascript
{
    headerBackgroundColor: '#007cba',
    headerTextColor: '#ffffff',
    borderWidth: 2,
    // ... all 30+ attributes with effective values
}
```

**Used by:** Inspector sidebar controls to show current effective value

### 5.4 Customization Cache

**Hook:** `useAccordionState(attributes, allThemes, getEffectiveValue)`

**File:** `C:\Users\Sammu\Desktop\guttemberg-smpt\blocks\accordion\hooks\useAccordionState.js`

**Purpose:** Manages session-only transient state

**Return Values:**
```javascript
const {
    customizationCache,      // Object: { themeId: { ...customizations } }
    setCustomizationCache,   // Function to update cache
    enableDividerBorder,     // Boolean: UI toggle state
    setEnableDividerBorder,  // Function to toggle
} = useAccordionState(attributes, allThemes, getEffectiveValue);
```

**Customization Cache Structure:**
```javascript
{
    'theme-A7': {
        headerBackgroundColor: '#007cba',
        borderWidth: 2,
        isCustomized: true,
        baseTheme: 'theme-A7'
    },
    'theme-K3': {
        // ... other customizations for theme-K3
    }
}
```

**Cache Behavior:**
- **Not saved to database** (session-only)
- When user switches away from customized theme → customizations saved to cache
- When user switches back to "{theme}-customized" → customizations restored from cache
- If user saves post with base theme selected → cache is lost forever
- Cache cleared when theme is updated globally

### 5.5 Clearing Customizations

**Helper Function:** `getAttributeDefaultValue(attributeName)` (lines 333-336)

**Usage:**
```javascript
// Clear all customizations
const clearAttributes = { isCustomized: false, baseTheme: 'default' };
CUSTOMIZATION_ATTRIBUTES.forEach((attr) => {
    clearAttributes[attr] = getAttributeDefaultValue(attr);
});
setAttributes(clearAttributes);
```

**Default Values:**
- Most attributes: `null` (inherit from theme)
- Booleans: `false` or `null` depending on `treatFalseAsCustomization`
- `headingLevel`: `'h2'`

---

## 6. Persistence & Serialization

### 6.1 Post Content Serialization

**WordPress saves blocks as HTML comments + content in `wp_posts.post_content`**

**Example Serialized Accordion:**
```html
<!-- wp:sammu/accordion {
    "title":"My Accordion",
    "accordionId":"accordion-a7k3",
    "selectedTheme":"theme-A7",
    "isCustomized":true,
    "baseTheme":"theme-A7",
    "headerBackgroundColor":"#007cba",
    "borderWidth":2,
    "isOpen":false
} -->
<div class="wp-block-sammu-accordion accordion-block accordion-theme-theme-A7 animation-normal" data-theme="theme-A7" style="--header-bg-color:#007cba;--border-width:2px;width:100%;margin-left:0;margin-right:auto">
    <button id="accordion-a7k3" class="accordion-toggle icon-left" aria-expanded="false" aria-controls="accordion-a7k3-content">
        <span class="accordion-icon" data-animate="true">▼</span>
        <span class="accordion-title">My Accordion</span>
    </button>
    <div id="accordion-a7k3-content" class="accordion-content" role="region" aria-labelledby="accordion-a7k3" hidden>
        <!-- Inner blocks content -->
    </div>
</div>
<!-- /wp:sammu/accordion -->
```

**JSON Attributes Block:**
- All non-default attributes are serialized
- Customization attributes included if set
- Theme ID stored in `selectedTheme`

**HTML Output:**
- Generated by save.js
- Contains inline styles for customizations
- Theme class applied for theme-based styles

### 6.2 Save Component

**File:** `C:\Users\Sammu\Desktop\guttemberg-smpt\blocks\accordion\save.js`

**Key Functions:**

**1. getEffectiveIconValues** (lines 13-27):
- Simplified effective value calculation for save context
- No theme system access in save (uses raw attributes)
- Provides defaults for icon attributes

**2. getTitleStyles** (lines 35-86):
- Builds custom title formatting styles object
- Only applies if `useCustomTitleFormatting` is enabled
- Returns empty object if disabled

**3. Save Component** (lines 101-373):

**Disabled Check (lines 147-149):**
```javascript
if (disabled) {
    return null; // Don't render if disabled
}
```

**Inline Styles Building (lines 153-265):**
```javascript
const inlineStyles = {};

// Colors (only if customized)
if (headerBackgroundColor) {
    inlineStyles['--header-bg-color'] = headerBackgroundColor;
}

// Border radius (only if non-zero)
if (borderRadiusTopLeft !== null || ...) {
    const tl = borderRadiusTopLeft ?? 0;
    const tr = borderRadiusTopRight ?? 0;
    const bl = borderRadiusBottomLeft ?? 0;
    const br = borderRadiusBottomRight ?? 0;

    if (tl !== 0 || tr !== 0 || bl !== 0 || br !== 0) {
        inlineStyles['--border-radius'] = `${tl}px ${tr}px ${br}px ${bl}px`;
    }
}

// Width and alignment
if (width) {
    inlineStyles.width = width;
}
if (horizontalAlign === 'center') {
    inlineStyles.marginLeft = 'auto';
    inlineStyles.marginRight = 'auto';
}

// Title formatting CSS variables
if (useCustomTitleFormatting && !useHeadingStyles) {
    if (titleTextAlign) {
        inlineStyles['--title-text-align'] = titleTextAlign;
    }
    // ... more title formatting
}
```

**Class Names Building (lines 268-287):**
```javascript
const classNames = ['accordion-block'];

// Add theme class (not 'default' as that's base CSS)
if (selectedTheme && selectedTheme !== 'default') {
    classNames.push(`accordion-theme-${selectedTheme}`);
}

if (animationSpeed) {
    classNames.push(`animation-${animationSpeed}`);
}
if (isOpen) {
    classNames.push('is-open');
}
if (animateIcon !== null && animateIcon) {
    classNames.push('animate-icon');
}
if (useHeading && useHeadingStyles) {
    classNames.push('use-heading-styles');
}
```

**Toggle Element (lines 335-357):**
```javascript
const toggleElement = useHeading ? (
    createElement(
        headingLevel || 'h2',
        null,
        <button id={accordionId} className={`accordion-toggle icon-${iconPosition}`} aria-expanded={isOpen} aria-controls={contentId}>
            {buttonContent}
        </button>
    )
) : (
    <button id={accordionId} className={`accordion-toggle icon-${iconPosition}`} aria-expanded={isOpen} aria-controls={contentId}>
        {buttonContent}
    </button>
);
```

**Return JSX (lines 359-372):**
```javascript
return (
    <div {...blockProps}>
        {toggleElement}
        <div id={contentId} className={`accordion-content ${isOpen ? 'open' : ''}`} role="region" aria-labelledby={accordionId} hidden={!isOpen}>
            <InnerBlocks.Content />
        </div>
    </div>
);
```

### 6.3 Attribute Validation

**File:** `C:\Users\Sammu\Desktop\guttemberg-smpt\blocks\accordion\utils\validation.js` (not read but referenced)

**PHP Validation (Server-Side):**

**Color Sanitization** (lines 698-786):
- Supports: hex (#RGB, #RRGGBB, #RRGGBBAA), rgba(), rgb(), hsla(), hsl(), transparent
- Regex validation for each format
- Range validation (R/G/B: 0-255, H: 0-360, S/L: 0-100, A: 0-1)

**Border Styles** (lines 791-793):
```php
private function get_allowed_border_styles() {
    return array('none', 'hidden', 'solid', 'dashed', 'dotted', 'double', 'groove', 'ridge', 'inset', 'outset');
}
```

**Border Radius** (lines 798-801):
```php
private function sanitize_radius($value) {
    $radius = intval($value);
    return ($radius >= 0 && $radius <= 100) ? $radius : 6;
}
```

---

## 7. Frontend Rendering

### 7.1 HTML Structure

**Rendered by save.js → Saved to database → Rendered on frontend**

**Accordion Structure:**
```html
<div class="accordion-block accordion-theme-{themeId} animation-{speed} is-open animate-icon" data-theme="{themeId}" style="--header-bg-color:#007cba;...">
    <button id="accordion-a7k3" class="accordion-toggle icon-left" aria-expanded="false" aria-controls="accordion-a7k3-content">
        <span class="accordion-icon" data-animate="true">▼</span>
        <span class="accordion-title">My Accordion</span>
    </button>
    <div id="accordion-a7k3-content" class="accordion-content" role="region" aria-labelledby="accordion-a7k3" hidden>
        <!-- Inner blocks content -->
    </div>
</div>
```

**With Heading Wrapper:**
```html
<div class="accordion-block use-heading-styles ...">
    <h2>
        <button id="accordion-a7k3" class="accordion-toggle icon-left" aria-expanded="false" aria-controls="accordion-a7k3-content">
            <span class="accordion-icon" data-animate="true">▼</span>
            <span class="accordion-title">My Accordion</span>
        </button>
    </h2>
    <div id="accordion-a7k3-content" class="accordion-content" role="region" aria-labelledby="accordion-a7k3" hidden>
        <!-- Inner blocks content -->
    </div>
</div>
```

### 7.2 Frontend JavaScript

**File:** `C:\Users\Sammu\Desktop\guttemberg-smpt\assets\js\accordion.js`

**Initialization (lines 2-7):**
```javascript
document.addEventListener('DOMContentLoaded', function() {
    const accordionBlocks = document.querySelectorAll('.accordion-block');
    accordionBlocks.forEach(function(accordion) {
        initializeAccordion(accordion);
    });
});
```

**initializeAccordion Function (lines 9-51):**
1. Find toggle button and content div
2. Prevent duplicate initialization (check `data-accordion-initialized`)
3. Set initial state based on `.open` class
4. Set ARIA attributes (`aria-expanded`, `hidden`)
5. Add click event listener
6. Add keyboard support (Space key)

**toggleAccordion Function (lines 53-125):**

**Opening Animation:**
1. Remove `hidden` attribute (accessibility)
2. Add `.open` class (applies padding)
3. Measure `scrollHeight` (including padding)
4. Set `max-height` to measured height
5. After transition: Remove `max-height` restriction (set to `none`)

**Closing Animation:**
1. Remove `.open` class (removes padding)
2. Get height without padding
3. Set explicit `max-height` temporarily
4. Force reflow
5. Set `max-height` to `0`
6. After transition: Add `hidden` attribute

**ARIA Updates:**
- Toggle `aria-expanded` attribute
- Toggle `hidden` attribute
- Add/remove `.is-open` class on wrapper

### 7.3 Frontend CSS

**File:** `C:\Users\Sammu\Desktop\guttemberg-smpt\assets\css\accordion.css`

**CSS Variables (lines 10-18):**
```css
.accordion-block {
    --header-bg-color: #f8f9fa;
    --header-text-color: #495057;
    --header-hover-color: #e9ecef;
    --border-color: #e0e0e0;
    --border-width: 1px;
    --border-style: solid;
    --border-radius: 6px;
    --content-bg-color: #ffffff;
}
```

**Theme Override:**
```css
.accordion-theme-theme-A7 {
    --header-bg-color: #007cba;
    --border-width: 2px;
    /* ... injected by PHP */
}
```

**Inline Styles Override:**
```html
<div style="--header-bg-color:#ff0000;">
```

**Priority:** Inline styles > Theme class > Default variables

**Animation Classes (lines 134-148):**
```css
.animation-fast .accordion-content {
    transition: max-height 0.15s ease, padding 0.15s ease, ...;
}
.animation-normal .accordion-content {
    transition: max-height 0.3s ease, padding 0.3s ease, ...;
}
.animation-slow .accordion-content {
    transition: max-height 0.6s ease, padding 0.6s ease, ...;
}
.animation-none .accordion-content {
    transition: none;
}
```

**Icon Positioning (lines 150-308):**
```css
.accordion-toggle {
    display: flex;
    align-items: center;
}

.accordion-toggle.icon-left .accordion-icon {
    margin-right: 5px;
}

.accordion-toggle.icon-right .accordion-icon {
    margin-left: 10px;
}

.accordion-toggle.icon-extreme-right {
    justify-content: space-between;
}

.accordion-block.is-open .accordion-icon[data-animate="true"] {
    transform: rotate(180deg);
}
```

**Title Formatting (lines 157-169):**
```css
.accordion-title {
    text-align: var(--title-text-align, inherit);
    font-size: var(--title-font-size, inherit);
    font-weight: var(--title-font-weight, inherit);
    font-style: var(--title-font-style, inherit);
    text-transform: var(--title-text-transform, inherit);
    letter-spacing: var(--title-letter-spacing, inherit);
    word-spacing: var(--title-word-spacing, inherit);
    text-decoration: var(--title-text-decoration, inherit);
    font-family: var(--title-font-family, inherit);
}
```

**Heading Styles (lines 196-286):**
- When `.use-heading-styles` class present, apply WordPress theme heading styles
- Target: `.accordion-block.use-heading-styles h2 > .accordion-toggle .accordion-title`
- Different font sizes for h1-h6 levels

---

## 8. Key File Map

```
guten-nav-plugin.php                           → Plugin entry point, registers blocks, AJAX handlers
├── Class: GutenNavPlugin
├── register_blocks()                          → Registers accordion block via block.json
├── enqueue_frontend_assets()                  → Conditionally loads CSS/JS if block present
├── inject_accordion_theme_styles()            → Injects theme CSS variables
├── enqueue_editor_assets()                    → Localizes AJAX config for editor
├── get_accordion_themes()                     → AJAX: Fetch all themes
├── save_accordion_theme()                     → AJAX: Create/update theme
├── delete_accordion_theme()                   → AJAX: Delete theme
├── sanitize_theme_settings()                  → Theme validation/sanitization
└── sanitize_color()                           → Color validation (hex, rgba, hsla, etc.)

blocks/accordion/
├── block.json                                 → Block metadata, attributes schema
├── index.js                                   → Block registration (connects Edit/Save)
├── edit.js                                    → Editor component (Gutenberg)
│   ├── Component structure
│   ├── React hooks (useState, useEffect, useMemo, useCallback)
│   ├── Custom hooks (useThemeManagement, useAccordionState, etc.)
│   ├── Event handlers (handleThemeChange, markAsCustomized, etc.)
│   ├── Theme update synchronization (custom events)
│   ├── Auto-cleanup logic (false customization detection)
│   ├── BlockControls (toolbar)
│   ├── InspectorControls (sidebar)
│   └── Block preview rendering
│
├── save.js                                    → Frontend HTML generator
│   ├── getEffectiveIconValues()               → Simplified effective value calc
│   ├── getTitleStyles()                       → Custom title formatting
│   ├── Inline styles building (CSS variables)
│   ├── Class names building (theme classes)
│   ├── Toggle element (with optional heading wrapper)
│   └── JSX output (serialized to HTML)
│
├── constants.js                               → Configuration & constants
│   ├── ATTRIBUTE_CONFIG                       → Single source of truth for attributes
│   ├── CUSTOMIZATION_SECTIONS                 → Auto-generated grouped attributes
│   ├── CUSTOMIZATION_ATTRIBUTES               → Auto-generated flat attribute list
│   ├── getAttributeDefaultValue()             → Get default value for clearing
│   ├── isAttributeCustomization()             → Detect if value is customization
│   ├── BORDER_STYLE_OPTIONS                   → UI options arrays
│   ├── ANIMATION_SPEED_OPTIONS
│   ├── TITLE_TEXT_ALIGN_OPTIONS
│   └── UI_CONSTANTS                           → Magic numbers (timeouts, scales, etc.)
│
├── hooks/
│   ├── useThemeManagement.js                  → Theme CRUD operations hook
│   │   ├── State: allThemes, defaultTheme, loading/saving/deleting states
│   │   ├── reloadThemes()                     → Load themes from server
│   │   ├── handleSaveTheme()                  → Save/update theme
│   │   ├── handleDeleteTheme()                → Delete theme with callback
│   │   ├── handleRenameTheme()                → Rename theme (preserves settings)
│   │   ├── handleCreateTheme()                → Create new theme with unique ID
│   │   └── Event dispatching (accordionThemeUpdated)
│   │
│   ├── useAccordionState.js                   → Local UI state hook
│   │   ├── customizationCache                 → Session-only customization storage
│   │   ├── enableDividerBorder                → UI toggle state
│   │   └── hasDividerBorderValues             → Computed property
│   │
│   ├── useEffectiveValue.js                   → Single attribute effective value hook
│   │   ├── Resolution order: attribute → selectedTheme → defaultTheme → null
│   │   ├── Memoized with useCallback
│   │   └── Returns: getEffectiveValue(attribute, themeAttribute)
│   │
│   └── useEffectiveValues.js                  → All attributes effective values hook
│       ├── Loops through CUSTOMIZATION_SECTIONS
│       ├── Calls getEffectiveValue for each attribute
│       └── Returns: Object with all effective values
│
├── utils/
│   ├── ajax.js                                → AJAX utilities
│   │   ├── getAjaxConfig()                    → Get AJAX URL and nonce
│   │   ├── sendAccordionAjax()                → Centralized AJAX handler
│   │   │   ├── Timeout protection (30s default)
│   │   │   ├── Network error detection
│   │   │   ├── HTTP status handling
│   │   │   └── WordPress response validation
│   │   ├── loadThemes()                       → GET themes wrapper
│   │   ├── saveTheme()                        → SAVE theme wrapper
│   │   └── deleteTheme()                      → DELETE theme wrapper
│   │
│   ├── styleHelpers.js                        → Style utility functions
│   └── validation.js                          → Client-side validation helpers
│
├── components/
│   ├── ThemeSelector.js                       → Theme dropdown component
│   │   ├── Loading state display
│   │   ├── Theme options building (with "(custom)" indicators)
│   │   └── Current value determination
│   │
│   ├── AccordionIcon.js                       → Icon component (character/emoji/image)
│   ├── ErrorBoundary.js                       → React error boundary
│   ├── ColorPickerControl.js                  → Custom color picker wrapper
│   └── ThemeListItem.js                       → Theme list item component
│
└── components/inspector/                      → Inspector sidebar panels
    ├── SettingsPanel.js                       → Main settings (always visible)
    │   ├── Theme selector
    │   ├── Theme management buttons (update/create/rename/delete)
    │   ├── Horizontal alignment selector
    │   ├── Width input
    │   ├── "Appears open by default" toggle
    │   └── "Disable this accordion" toggle
    │
    ├── AppearancePanel.js                     → Colors, transparency
    │   ├── Header background color picker
    │   ├── Header text color picker
    │   ├── Header hover color picker
    │   ├── Content background color picker
    │   └── "Make content background transparent" toggle
    │
    ├── TitlePanel.js                          → Title formatting
    │   ├── "Use heading element" toggle
    │   ├── Heading level selector
    │   ├── "Use WordPress heading styles" toggle
    │   ├── "Use custom title formatting" toggle
    │   └── Custom formatting controls (font, alignment, etc.)
    │
    ├── BorderPanel.js                         → Main & divider borders
    │   ├── Main border color picker
    │   ├── Main border width slider
    │   ├── Main border style selector
    │   ├── "Enable divider border" toggle
    │   ├── Divider border color picker
    │   ├── Divider border width slider
    │   └── Divider border style selector
    │
    ├── BorderRadiusPanel.js                   → Corner radius
    │   ├── Top-left radius slider
    │   ├── Top-right radius slider
    │   ├── Bottom-left radius slider
    │   └── Bottom-right radius slider
    │
    ├── AnimationPanel.js                      → Animation settings
    │   └── Animation speed selector
    │
    └── IconPanel.js                           → Icon settings
        ├── "Show icon" toggle
        ├── Icon input (character/emoji)
        ├── Icon type selector (character/emoji/image)
        ├── Icon position selector (left/right/extreme-right)
        └── "Animate icon" toggle

assets/
├── css/
│   ├── accordion.css                          → Frontend styles
│   │   ├── CSS variables (theme defaults)
│   │   ├── Accordion block structure
│   │   ├── Toggle button styles
│   │   ├── Content area styles
│   │   ├── Animation classes
│   │   ├── Icon positioning
│   │   ├── Title formatting
│   │   ├── Heading styles integration
│   │   └── Responsive design
│   │
│   └── accordion-editor.css                   → Editor-specific styles
│
└── js/
    └── accordion.js                           → Frontend interactivity
        ├── DOMContentLoaded event listener
        ├── initializeAccordion()              → Setup accordion instance
        │   ├── Find toggle/content elements
        │   ├── Prevent duplicate initialization
        │   ├── Set initial state
        │   ├── Add click listener
        │   └── Add keyboard support
        └── toggleAccordion()                  → Open/close animation
            ├── Opening: Remove hidden → Add .open → Measure height → Animate
            ├── Closing: Remove .open → Set explicit height → Animate to 0
            └── ARIA updates (aria-expanded, hidden)
```

---

## 9. Complete Lifecycle Flow

### 9.1 User Opens Editor (First Load)

**Flow:**
1. WordPress loads Gutenberg editor
2. PHP: `enqueue_editor_assets()` called
3. Localizes `accordionGlobalSettings` with AJAX URL and nonces
4. Editor script loaded: `build/accordion/index.js`
5. Block registered via `registerBlockType()`
6. User inserts accordion block
7. Edit component mounts

**Edit Component Mount:**
1. `useThemeManagement()` hook initializes
2. `reloadThemes()` called automatically
3. AJAX request: `get_accordion_themes`
4. PHP: `GutenNavPlugin::get_accordion_themes()` executes
5. Retrieves `accordion_themes` from `wp_options`
6. Injects default theme
7. Response: `{ success: true, data: { themes: {...} } }`
8. State updated: `allThemes` and `defaultTheme` set
9. `isLoadingThemes` set to `false`
10. UI renders with theme dropdown

### 9.2 User Selects Theme

**Flow:**
1. User clicks theme dropdown in SettingsPanel
2. `ThemeSelector` component displays options
3. User selects "My Custom Theme"
4. `handleThemeChange('theme-A7')` called
5. Clears all customization attributes:
   ```javascript
   const clearAttributes = {
       selectedTheme: 'theme-A7',
       baseTheme: 'theme-A7',
       isCustomized: false
   };
   CUSTOMIZATION_ATTRIBUTES.forEach((attr) => {
       clearAttributes[attr] = null; // or config default
   });
   setAttributes(clearAttributes);
   ```
6. Block attributes updated
7. `useEffectiveValue` recalculates effective values
8. Theme values now used (no inline overrides)
9. Editor preview updates with theme styles

### 9.3 User Customizes Attribute

**Flow:**
1. User opens AppearancePanel
2. Changes header background color to `#007cba`
3. `setAttributes({ headerBackgroundColor: '#007cba' })` called
4. `markAsCustomized()` called in useEffect
5. Compares attribute value with theme value:
   ```javascript
   isAttributeCustomization('headerBackgroundColor', '#007cba', '#f8f9fa')
   // Returns: true (different from theme)
   ```
6. Sets `isCustomized: true` and `baseTheme: 'theme-A7'`
7. Theme dropdown shows "My Custom Theme (custom)"
8. `getEffectiveValue('headerBackgroundColor')` now returns `#007cba` (inline override)
9. Editor preview updates with new color

### 9.4 User Switches Themes (With Customizations)

**Scenario:** User has customized "Theme A", now wants to try "Theme B"

**Flow:**
1. User clicks theme dropdown
2. Sees options:
   - "Theme A (custom)" ← Currently selected
   - "Theme A" ← Clean version
   - "Theme B" ← Different theme
3. User selects "Theme B"
4. `handleThemeChange('theme-B')` called
5. **Before switching:** Cache current customizations
   ```javascript
   if (isCustomized && selectedTheme === baseTheme) {
       const currentCustomizations = {};
       CUSTOMIZATION_ATTRIBUTES.forEach((attr) => {
           currentCustomizations[attr] = attributes[attr];
       });
       setCustomizationCache((prev) => ({
           ...prev,
           ['theme-A']: {
               ...currentCustomizations,
               isCustomized: true,
               baseTheme: 'theme-A'
           }
       }));
   }
   ```
6. **After caching:** Clear customizations and apply Theme B
7. Accordion now shows Theme B styles (clean)
8. Theme A customizations preserved in cache (session-only)

### 9.5 User Restores Cached Customizations

**Flow:**
1. User realizes they want Theme A customizations back
2. Opens theme dropdown
3. Sees "Theme A (custom)" option (because cache exists)
4. Selects "Theme A (custom)"
5. `handleThemeChange('theme-A-customized')` called
6. Detects `-customized` suffix
7. Retrieves from cache:
   ```javascript
   const cachedCustomizations = customizationCache['theme-A'];
   if (cachedCustomizations) {
       setAttributes({
           selectedTheme: 'theme-A',
           ...cachedCustomizations // Restores all customizations
       });
   }
   ```
8. Accordion shows Theme A with customizations restored

### 9.6 User Creates New Theme

**Flow:**
1. User has customized accordion
2. Clicks "Save these settings as new theme" button
3. Prompted for theme name: "My Amazing Theme"
4. `handleCreateTheme()` called:
   ```javascript
   const effectiveSettings = collectEffectiveSettings();
   // effectiveSettings = all visible values (theme + customizations)

   const result = await handleCreateTheme({
       theme_name: 'My Amazing Theme',
       ...effectiveSettings
   });
   ```
5. **Generate unique ID:**
   ```javascript
   let themeId;
   do {
       themeId = `theme-${generateShortId()}`; // e.g., "theme-K3"
   } while (allThemes[themeId]); // Ensure unique
   ```
6. **AJAX request:**
   ```
   POST /wp-admin/admin-ajax.php
   action: 'save_accordion_theme'
   nonce: '{themesNonce}'
   theme_id: 'theme-K3'
   theme_name: 'My Amazing Theme'
   headerBackgroundColor: '#007cba'
   borderWidth: 2
   // ... all effective values
   ```
7. **PHP processes:**
   - Validates nonce and capabilities
   - Sanitizes all values
   - Saves to `wp_options` as `accordion_themes`
   - Returns updated themes array
8. **Frontend receives response:**
   - Updates `allThemes` state
   - Dispatches `accordionThemeUpdated` event
   - All accordions on page sync theme data
9. **Switches to clean theme:**
   ```javascript
   switchToCleanTheme('theme-K3');
   ```
10. Accordion now uses new theme (no customizations)
11. User can apply this theme to other accordions

### 9.7 User Updates Existing Theme

**Flow:**
1. User customizes accordion using Theme A
2. Clicks "Update theme with these settings"
3. Confirms: "This will affect all accordions using this theme"
4. `handleSaveTheme('theme-A', effectiveSettings)` called
5. **AJAX request with all effective values**
6. **PHP processes:**
   - Merges with existing theme settings
   - Saves to database
7. **Frontend receives response**
8. **Custom event dispatched:** `accordionThemeUpdated`
9. **All accordion blocks listening:**
   ```javascript
   useEffect(() => {
       const handleThemeUpdate = (event) => {
           const { themeId, themes } = event.detail;
           setAllThemes(themes); // Sync theme data

           // If this accordion uses updated theme, clear customizations
           if (selectedTheme === themeId || baseTheme === themeId) {
               switchToCleanTheme(themeId);
           }
       };
       window.addEventListener('accordionThemeUpdated', handleThemeUpdate);
   }, [dependencies]);
   ```
10. All accordions using Theme A immediately show updated theme
11. Customizations cleared to prevent conflicts

### 9.8 User Saves Post

**Flow:**
1. User clicks "Update" or "Publish" in WordPress editor
2. WordPress serializes all blocks to HTML
3. For each accordion block:
   - **Save component called** with current attributes
   - **Inline styles built** from customization attributes
   - **Theme class added** from `selectedTheme`
   - **HTML generated** with all styles and attributes
4. **Block comment generated:**
   ```html
   <!-- wp:sammu/accordion {
       "title":"My Accordion",
       "selectedTheme":"theme-A7",
       "isCustomized":true,
       "baseTheme":"theme-A7",
       "headerBackgroundColor":"#007cba",
       "borderWidth":2,
       ...
   } -->
   ```
5. **HTML content generated:**
   ```html
   <div class="accordion-block accordion-theme-theme-A7 ..." style="--header-bg-color:#007cba;...">
       <button>...</button>
       <div class="accordion-content">...</div>
   </div>
   ```
6. **Full block serialization saved to `wp_posts.post_content`**
7. Customizations now persisted with post
8. Customization cache cleared (data is in DB now)

### 9.9 Frontend Page Load

**Flow:**
1. User visits page with accordion
2. WordPress renders post content
3. PHP: `has_block('sammu/accordion', $content)` returns true
4. PHP: `enqueue_frontend_assets()` called
5. **Load assets:**
   - `assets/css/accordion.css`
   - `assets/js/accordion.js`
6. **Inject theme styles:**
   ```php
   inject_accordion_theme_styles();
   // Retrieves accordion_themes from wp_options
   // Generates CSS: .accordion-theme-{id} { --header-bg-color: ...; }
   // Injects via wp_add_inline_style()
   ```
7. **HTML rendered with:**
   - Theme class: `accordion-theme-theme-A7`
   - Inline styles: `style="--header-bg-color:#007cba;"`
   - Initial state: `hidden` if `isOpen` is false
8. **JavaScript initialization:**
   ```javascript
   document.addEventListener('DOMContentLoaded', () => {
       const accordions = document.querySelectorAll('.accordion-block');
       accordions.forEach(initializeAccordion);
   });
   ```
9. **Each accordion:**
   - Finds toggle button and content div
   - Sets initial state (open/closed)
   - Adds event listeners (click, keyboard)
   - Sets ARIA attributes

### 9.10 User Clicks Accordion (Frontend)

**Flow:**
1. User clicks accordion toggle button
2. **Click event handler:**
   ```javascript
   toggle.addEventListener('click', (e) => {
       e.preventDefault();
       toggleAccordion(accordion, content, toggle);
   });
   ```
3. **Check current state:**
   ```javascript
   const isOpen = content.classList.contains('open');
   ```
4. **If closing:**
   - Remove `.open` class (removes padding)
   - Remove `.is-open` class from wrapper
   - Set `aria-expanded="false"`
   - Animate `max-height` from `{height}px` to `0`
   - After transition: Add `hidden` attribute
5. **If opening:**
   - Remove `hidden` attribute
   - Add `.open` class (adds padding)
   - Add `.is-open` class to wrapper
   - Set `aria-expanded="true"`
   - Measure `scrollHeight` (including padding)
   - Animate `max-height` from `0` to `{height}px`
   - After transition: Set `max-height: none`
6. **Icon rotation (if enabled):**
   ```css
   .accordion-block.is-open .accordion-icon[data-animate="true"] {
       transform: rotate(180deg);
   }
   ```
7. **Animation controlled by CSS:**
   ```css
   .animation-normal .accordion-content {
       transition: max-height 0.3s ease, padding 0.3s ease;
   }
   ```

### 9.11 User Deletes Theme

**Flow:**
1. User selects theme in dropdown
2. Clicks "Delete theme" button
3. Confirms deletion
4. `handleDeleteTheme('theme-A7', selectedTheme, callback)` called
5. **AJAX request:**
   ```
   POST /wp-admin/admin-ajax.php
   action: 'delete_accordion_theme'
   nonce: '{themesNonce}'
   theme_id: 'theme-A7'
   ```
6. **PHP processes:**
   - Validates nonce and capabilities
   - Cannot delete default theme
   - Removes theme from `accordion_themes` array
   - Saves to database
   - Returns updated themes
7. **Frontend receives response:**
   - Updates `allThemes` state (theme removed)
   - If this accordion was using deleted theme:
     ```javascript
     if (selectedTheme === themeId && onThemeDeleted) {
         onThemeDeleted(themeId);
     }
     ```
   - Callback resets accordion to default theme
8. **Safety check in all accordions:**
   ```javascript
   useEffect(() => {
       if (selectedTheme && !allThemes[selectedTheme]) {
           // Theme no longer exists, fallback to default
           setAttributes({
               selectedTheme: 'default',
               baseTheme: 'default',
               isCustomized: false
           });
           // Clear all customizations
       }
   }, [allThemes, selectedTheme]);
   ```

---

## Summary: Critical System Behaviors

### Customization vs. Theme

**Customization:**
- Per-accordion attribute overrides
- Stored in post content (block attributes)
- Inline styles in HTML
- Perfect for one-off tweaks

**Theme:**
- Site-wide reusable preset
- Stored in `wp_options` table
- CSS classes + variables
- Perfect for consistent styling

### Effective Value Resolution Priority

1. **Inline customization** (attribute value) ← HIGHEST
2. **Selected theme** value
3. **Default theme** value
4. **Hardcoded fallback** (null) ← LOWEST

### Customization Cache

- **Session-only** storage (not saved to DB)
- Preserves customizations when switching themes
- Lost if user saves post with base theme selected
- Cleared when theme is updated globally

### Theme Update Synchronization

- Custom event: `accordionThemeUpdated`
- Dispatched when theme is saved/created
- All accordion blocks listen and sync
- Automatically clears customizations on affected accordions

### Persistence Locations

**WordPress Options Table:**
- `accordion_themes` → Site-wide themes

**Post Content:**
- Block attributes → Per-accordion settings
- HTML output → Rendered accordion structure

**Session Memory:**
- Customization cache → Temporary overrides

---

**End of Workflow Documentation**

This document provides a complete understanding of the Accordion block lifecycle from plugin initialization to frontend rendering. Use this as a reference before making any refactoring decisions.
