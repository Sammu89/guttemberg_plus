import { useBlockProps, InnerBlocks } from '@wordpress/block-editor';
import { createElement } from '@wordpress/element';
import AccordionIcon from './components/AccordionIcon';
import {
	buildInlineStyles,
	getBorderRadiusValue,
	getAlignmentMargins,
} from '../shared/utils/style-helpers';

/**
 * Calculate effective icon values for save component
 * This is a simplified version of the effective value calculation from the editor
 * Since we don't have access to the theme system in save, we use the raw attributes
 * 
 * @param {Object} attributes - Block attributes
 * @return {Object} - Effective icon values
 */
const getEffectiveIconValues = ( attributes ) => {
	const { showIcon, icon, iconType, iconPosition, animateIcon } = attributes;

	// Since block.json now has proper defaults, we can use the attributes directly
	// with minimal fallback handling
	const effectiveValues = {
		showIcon: showIcon !== false, // ensure boolean, default to true
		icon: icon || '▼', // fallback to default arrow
		iconType: iconType || 'character',
		iconPosition: iconPosition || 'left',
		animateIcon: animateIcon !== false, // ensure boolean, default to true
	};

	return effectiveValues;
};

/**
 * Build custom title styles object
 *
 * @param {Object} attributes - Block attributes
 * @return {Object} - Title styles object
 */
const getTitleStyles = ( attributes ) => {
	const {
		useCustomTitleFormatting,
		useHeadingStyles,
		titleTextAlign,
		titleFontSize,
		titleFontWeight,
		titleFontStyle,
		titleTextTransform,
		titleLetterSpacing,
		titleWordSpacing,
		titleTextDecoration,
		titleFontFamily,
	} = attributes;

	// Only apply custom formatting if enabled and not using heading styles
	if ( ! useCustomTitleFormatting || useHeadingStyles ) {
		return {};
	}

	const styles = {};

	if ( titleTextAlign ) {
		styles.textAlign = titleTextAlign;
	}
	if ( titleFontSize ) {
		styles.fontSize = titleFontSize;
	}
	if ( titleFontWeight ) {
		styles.fontWeight = titleFontWeight;
	}
	if ( titleFontStyle ) {
		styles.fontStyle = titleFontStyle;
	}
	if ( titleTextTransform ) {
		styles.textTransform = titleTextTransform;
	}
	if ( titleLetterSpacing ) {
		styles.letterSpacing = titleLetterSpacing;
	}
	if ( titleWordSpacing ) {
		styles.wordSpacing = titleWordSpacing;
	}
	if ( titleTextDecoration ) {
		styles.textDecoration = titleTextDecoration;
	}
	if ( titleFontFamily ) {
		styles.fontFamily = titleFontFamily;
	}

	return styles;
};

/**
 * Save component for Accordion block
 *
 * Renders the frontend HTML structure with:
 * - Inline styles for per-accordion customizations
 * - Theme classes for theme-based styling
 * - Proper ARIA attributes for accessibility
 * - Conditional rendering based on disabled state
 *
 * @param {Object} props            - Component props
 * @param {Object} props.attributes - Block attributes
 * @return {JSX.Element|null} - Rendered accordion HTML or null if disabled
 */
const Save = ( { attributes } ) => {
	const {
		title,
		isOpen,
		selectedTheme,
		_pageStyleRef,
		headerBackgroundColor,
		headerTextColor,
		headerHoverColor,
		borderColor,
		borderWidth,
		borderStyle,
		dividerBorderColor,
		dividerBorderWidth,
		dividerBorderStyle,
		borderRadiusTopLeft,
		borderRadiusTopRight,
		borderRadiusBottomLeft,
		borderRadiusBottomRight,
		contentBackgroundColor,
		contentBackgroundTransparent,
		width,
		horizontalAlign,
		disabled,
		animationSpeed,
		showIcon,
		icon,
		iconType,
		iconPosition,
		animateIcon,
		accordionId,
		useHeading,
		headingLevel,
		useHeadingStyles,
		useCustomTitleFormatting,
		titleTextAlign,
		titleFontSize,
		titleFontWeight,
		titleFontStyle,
		titleTextTransform,
		titleLetterSpacing,
		titleWordSpacing,
		titleTextDecoration,
		titleFontFamily,
	} = attributes;

	// Don't render if disabled
	if ( disabled ) {
		return null;
	}

	// Build inline styles using shared utility
	// In save context, we don't need to resolve cascade because:
	// 1. Editor already resolved effective values during editing
	// 2. Block attributes contain the final effective values when saved
	// 3. We just need to render those values as inline styles
	// Therefore, we pass attributes directly - no cascade resolution needed
	const inlineStyles = buildInlineStyles( attributes );

	// Add width and alignment (per-accordion settings, not theme properties)
	if ( width ) {
		inlineStyles.width = width;
	}

	// Add horizontal alignment margins using shared utility
	const alignmentMargins = getAlignmentMargins( horizontalAlign );
	Object.assign( inlineStyles, alignmentMargins );

	// Title Formatting (CSS variables for use in .accordion-title styles)
	// Only apply if custom formatting is enabled and not using heading styles
	if ( useCustomTitleFormatting && ! useHeadingStyles ) {
		if ( titleTextAlign ) {
			inlineStyles[ '--title-text-align' ] = titleTextAlign;
			// Set justify-content value for icon-right/icon-extreme-right layouts
			const justifyValue = titleTextAlign === 'left' ? 'flex-start' :
								  titleTextAlign === 'center' ? 'center' :
								  titleTextAlign === 'right' ? 'flex-end' : 'flex-start';
			inlineStyles[ '--title-justify-content' ] = justifyValue;
		}
		if ( titleFontSize ) {
			inlineStyles[ '--title-font-size' ] = titleFontSize;
		}
		if ( titleFontWeight ) {
			inlineStyles[ '--title-font-weight' ] = titleFontWeight;
		}
		if ( titleFontStyle ) {
			inlineStyles[ '--title-font-style' ] = titleFontStyle;
		}
		if ( titleTextTransform ) {
			inlineStyles[ '--title-text-transform' ] = titleTextTransform;
		}
		if ( titleLetterSpacing ) {
			inlineStyles[ '--title-letter-spacing' ] = titleLetterSpacing;
		}
		if ( titleWordSpacing ) {
			inlineStyles[ '--title-word-spacing' ] = titleWordSpacing;
		}
		if ( titleTextDecoration ) {
			inlineStyles[ '--title-text-decoration' ] = titleTextDecoration;
		}
		if ( titleFontFamily ) {
			inlineStyles[ '--title-font-family' ] = titleFontFamily;
		}
	}

	// Build class names
	const classNames = [ 'accordion-block' ];

	// Add theme class (not 'default' as that's the base CSS)
	if ( selectedTheme && selectedTheme !== 'default' ) {
		classNames.push( `accordion-theme-${ selectedTheme }` );
	}

	// Add page style class if using page style (Phase 3 - Section 8.2)
	if ( _pageStyleRef ) {
		classNames.push( `accordion-page-style-${ _pageStyleRef }` );
	}

	// Use attribute values for classes (they already contain effective values)
	if ( animationSpeed ) {
		classNames.push( `animation-${ animationSpeed }` );
	}
	if ( isOpen ) {
		classNames.push( 'is-open' );
	}
	// Use attribute value for animateIcon - default is true (null should be treated as true)
	if ( animateIcon !== false ) {
		classNames.push( 'animate-icon' );
	}
	if ( useHeading && useHeadingStyles ) {
		classNames.push( 'use-heading-styles' );
	}

	const blockProps = useBlockProps.save( {
		className: classNames.join( ' ' ),
		style:
			Object.keys( inlineStyles ).length > 0 ? inlineStyles : undefined,
		'data-theme': selectedTheme,
	} );

	const contentId = accordionId ? `${ accordionId }-content` : undefined;

	// Calculate effective icon values
	const effectiveIconValues = getEffectiveIconValues( attributes );
	const { showIcon: effectiveShowIcon, icon: effectiveIcon, iconType: effectiveIconType, iconPosition: effectiveIconPosition, animateIcon: effectiveAnimateIcon } = effectiveIconValues;

	// Get custom title styles
	const titleStyles = getTitleStyles( attributes );

	// Build the button content
	const buttonContent = (
		<>
			{ effectiveIconPosition !== 'right' &&
				effectiveIconPosition !== 'extreme-right' && (
					<AccordionIcon
						showIcon={ effectiveShowIcon }
						iconType={ effectiveIconType }
						icon={ effectiveIcon }
						animateIcon={ effectiveAnimateIcon }
					/>
				) }
			 <span
				className="accordion-title"
				style={ Object.keys( titleStyles ).length > 0 ? titleStyles : undefined }
			>
				{ title }
			</span>
			{ ( effectiveIconPosition === 'right' ||
				effectiveIconPosition === 'extreme-right' ) && (
				<AccordionIcon
					showIcon={ effectiveShowIcon }
					iconType={ effectiveIconType }
					icon={ effectiveIcon }
					animateIcon={ effectiveAnimateIcon }
				/>
			) }
		</>
	);

	// Build the toggle element (either wrapped in heading or standalone)
	const toggleElement = useHeading ? (
		createElement(
			headingLevel || 'h2',
			null,
			<button
				id={ accordionId }
				className={ `accordion-toggle icon-${ effectiveIconPosition }` }
				aria-expanded={ isOpen }
				aria-controls={ contentId }
			>
				{ buttonContent }
			</button>
		)
	) : (
		<button
			id={ accordionId }
			className={ `accordion-toggle icon-${ effectiveIconPosition }` }
			aria-expanded={ isOpen }
			aria-controls={ contentId }
		>
			{ buttonContent }
		</button>
	);

	return (
		<div { ...blockProps }>
			{ toggleElement }
			<div
				id={ contentId }
				className={ `accordion-content ${ isOpen ? 'open' : '' }` }
				role="region"
				aria-labelledby={ accordionId }
				hidden={ ! isOpen }
			>
				<InnerBlocks.Content />
			</div>
		</div>
	);
};

export default Save;
