# Accordion Customization System

This document explains the block-based customization architecture used in the Accordion block. This system is designed to be easily extensible and maintainable.

## Architecture Overview

The customization system is built around **configuration-driven logic** where all attribute behavior is defined in one place (`constants.js`), and the rest of the codebase uses helper functions to handle them automatically.

## How to Add a New Customization

### Step 1: Define the Attribute in `ATTRIBUTE_CONFIG`

In `blocks/accordion/constants.js`, add your attribute to the `ATTRIBUTE_CONFIG` object:

```javascript
export const ATTRIBUTE_CONFIG = {
	// ... existing attributes ...

	// Your new attribute
	myNewAttribute: {
		type: 'string', // or 'boolean', 'number'
		defaultValue: null, // or false for booleans, 0 for numbers, etc.
		// Optional fields:
		isToggle: false, // Set to true if this boolean controls child attributes
		childAttributes: [], // Array of attribute names this toggle controls
		treatFalseAsCustomization: true, // For booleans: can false be a customization?
	},
};
```

### Step 2: Add to `CUSTOMIZATION_SECTIONS`

Add your attribute to the appropriate section (or create a new section):

```javascript
export const CUSTOMIZATION_SECTIONS = {
	// ... existing sections ...

	mySection: [
		'myNewAttribute',
		'anotherRelatedAttribute',
	],
};
```

### Step 3: That's It!

The system will **automatically** handle:
- ✅ Clearing with correct default value when switching themes
- ✅ Comparison logic for detecting customizations
- ✅ Saving to themes
- ✅ Loading from themes
- ✅ Cache management
- ✅ Validation

## Attribute Configuration Fields

### Required Fields

| Field | Type | Description |
|-------|------|-------------|
| `type` | `'string' \| 'boolean' \| 'number'` | Data type of the attribute |
| `defaultValue` | any | Default value when clearing/resetting |

### Optional Fields

| Field | Type | Description |
|-------|------|-------------|
| `isToggle` | boolean | If true, this boolean controls visibility of child attributes |
| `childAttributes` | string[] | Array of attribute names that depend on this toggle |
| `treatFalseAsCustomization` | boolean | For booleans: Should `false` be treated as a customization? |

## Boolean Attribute Behavior

Booleans have special handling based on `treatFalseAsCustomization`:

### Example 1: `contentBackgroundTransparent`
```javascript
contentBackgroundTransparent: {
	type: 'boolean',
	defaultValue: false,
	treatFalseAsCustomization: false, // false is the DEFAULT, not a customization
}
```

**Behavior:**
- If accordion has `false` and theme has `false` → NOT customized ✓
- If accordion has `false` and theme has `true` → NOT customized (false is default)
- If accordion has `true` and theme has `false` → IS customized ✓

### Example 2: `useCustomTitleFormatting`
```javascript
useCustomTitleFormatting: {
	type: 'boolean',
	defaultValue: false,
	treatFalseAsCustomization: true, // false CAN differ from theme
}
```

**Behavior:**
- If accordion has `false` and theme has `false` → NOT customized ✓
- If accordion has `false` and theme has `true` → IS customized ✓
- If accordion has `true` and theme has `false` → IS customized ✓

## Helper Functions

### `getAttributeDefaultValue(attributeName)`

Returns the correct default value for clearing an attribute.

```javascript
import { getAttributeDefaultValue } from './constants';

// Clear all customizations
CUSTOMIZATION_ATTRIBUTES.forEach((attr) => {
	clearAttributes[attr] = getAttributeDefaultValue(attr);
});
```

### `isAttributeCustomization(attributeName, attributeValue, themeValue)`

Checks if an attribute value represents a customization compared to the theme.

```javascript
import { isAttributeCustomization } from './constants';

// Check if any customizations exist
for (const attr of CUSTOMIZATION_ATTRIBUTES) {
	if (isAttributeCustomization(attr, attributes[attr], themeData[attr])) {
		hasCustomizations = true;
		break;
	}
}
```

## Toggle Attributes with Children

Some attributes are toggles that control groups of child attributes:

### Example: Icon Customizations
```javascript
showIcon: {
	type: 'boolean',
	defaultValue: null,
	isToggle: true,
	childAttributes: ['icon', 'iconType', 'iconPosition', 'animateIcon'],
}
```

**Pattern:**
1. `showIcon` is the master toggle
2. When `showIcon` is enabled → child attributes are visible in UI
3. When `showIcon` is disabled → child attributes are hidden (but still saved)
4. `showIcon` itself is a customization that gets saved to themes

## Complete Example: Adding Border Shadow

Let's walk through adding a complete new feature with multiple attributes.

### Step 1: Add to `ATTRIBUTE_CONFIG`

```javascript
export const ATTRIBUTE_CONFIG = {
	// ... existing attributes ...

	// Border Shadow toggle and attributes
	useBorderShadow: {
		type: 'boolean',
		defaultValue: false,
		isToggle: true,
		treatFalseAsCustomization: true,
		childAttributes: ['shadowOffsetX', 'shadowOffsetY', 'shadowBlur', 'shadowColor'],
	},
	shadowOffsetX: { type: 'number', defaultValue: null },
	shadowOffsetY: { type: 'number', defaultValue: null },
	shadowBlur: { type: 'number', defaultValue: null },
	shadowColor: { type: 'string', defaultValue: null },
};
```

### Step 2: Add to `CUSTOMIZATION_SECTIONS`

```javascript
export const CUSTOMIZATION_SECTIONS = {
	// ... existing sections ...

	borderShadow: [
		'useBorderShadow',
		'shadowOffsetX',
		'shadowOffsetY',
		'shadowBlur',
		'shadowColor',
	],
};
```

### Step 3: Add to `block.json` attributes

```json
{
	"attributes": {
		"useBorderShadow": {
			"type": "boolean",
			"default": false
		},
		"shadowOffsetX": {
			"type": "number"
		},
		"shadowOffsetY": {
			"type": "number"
		},
		"shadowBlur": {
			"type": "number"
		},
		"shadowColor": {
			"type": "string"
		}
	}
}
```

### Step 4: Create UI Panel (Optional)

Create `blocks/accordion/components/inspector/BorderShadowPanel.js` with controls for the new attributes.

The panel should:
- Use `markAsCustomized()` when attributes change
- Use `sidebarValues` from `useEffectiveValues()` to show current values
- Follow existing panel patterns

## Testing Your Customization

After adding a new customization, verify:

1. ✅ **Attribute saves correctly** - Change value, save post, reload - value persists
2. ✅ **Theme creation works** - Customize, click "Save as new theme" - new theme has your attribute
3. ✅ **Theme update works** - Customize existing theme, click "Update theme" - theme updates globally
4. ✅ **Customization detection** - Change from theme value shows "(custom)" in dropdown
5. ✅ **Clearing works** - Switch to base theme clears your customization
6. ✅ **Cache works** - Switch back to "(custom)" version restores your changes
7. ✅ **Frontend rendering** - Attribute applies correctly on frontend

## Common Pitfalls

### ❌ Forgetting to add attribute to `block.json`
Without this, WordPress won't save the attribute to the database.

### ❌ Using `null` default for booleans
Booleans should default to `false`, not `null`, unless you specifically need a tri-state.

### ❌ Not calling `markAsCustomized()` in UI controls
When user changes a customization, you must call `markAsCustomized()` to trigger the "(custom)" state.

### ❌ Hardcoding clearing or comparison logic
Always use `getAttributeDefaultValue()` and `isAttributeCustomization()` instead of hardcoded conditions.

## Benefits of This Architecture

✅ **Single source of truth** - All attribute behavior defined in `ATTRIBUTE_CONFIG`
✅ **Self-documenting** - Configuration clearly shows how each attribute behaves
✅ **Easy to extend** - Add new customizations in 2 steps
✅ **No duplication** - Logic is centralized in helper functions
✅ **Type-safe** - Configuration enforces consistent handling
✅ **Future-proof** - Can add new attribute types without touching core logic

## File Organization

```
blocks/accordion/
├── constants.js              # ATTRIBUTE_CONFIG, CUSTOMIZATION_SECTIONS, helpers
├── edit.js                   # Uses helpers for clearing/comparison
├── components/inspector/     # UI panels that call markAsCustomized()
│   ├── TitlePanel.js
│   ├── IconPanel.js
│   └── ...
├── hooks/
│   └── useEffectiveValues.js # Calculates effective values from theme + inline
└── CUSTOMIZATION_SYSTEM.md   # This file
```

## Questions?

If you need to add a customization that doesn't fit this pattern, **update this document first** to explain the new pattern, then implement it. This keeps the system documented and maintainable.
