# Accordion Attribute Verification Checklist

This checklist verifies that every customization attribute works correctly through the entire lifecycle.

## Testing Methodology

For EACH attribute, verify all 6 steps:

1. ✅ **Change in Sidebar** - Change the value in sidebar, verify it shows in editor preview
2. ✅ **Save Post** - Save post, reload page, verify value persists
3. ✅ **Mark as Customized** - Verify accordion shows "(custom)" in theme dropdown
4. ✅ **Save as New Theme** - Create new theme, verify attribute is in new theme
5. ✅ **Update Theme** - Update existing theme, verify attribute updates globally
6. ✅ **Theme Switch** - Switch to clean theme, switch back to customized, verify cache works

---

## Boolean Attributes (9 total)

### 1. contentBackgroundTransparent
- **Type:** Boolean (false is NOT a customization)
- **Location:** Appearance Panel
- **Test Values:** `false` (default), `true`
- **Special Case:** Only `true` should mark as customized (false is default)

**Test Steps:**
- [ ] Set to `true` → background becomes transparent
- [ ] Save post → reload → still transparent
- [ ] Shows "(custom)" when `true`
- [ ] Save as theme → new theme has `contentBackgroundTransparent: true`
- [ ] Update theme → all accordions using theme become transparent
- [ ] Switch theme → switch back → transparency restored from cache

---

### 2. useCustomTitleFormatting
- **Type:** Boolean (false CAN be a customization)
- **Location:** Title Panel
- **Test Values:** `false` (default), `true`
- **Child Attributes:** All title formatting attributes
- **Special Case:** Both `true` and `false` can be customizations (differs from theme)

**Test Steps:**
- [ ] Enable toggle → title formatting controls appear
- [ ] Set title formatting values → title changes in editor
- [ ] Save post → reload → toggle still enabled, values persist
- [ ] Shows "(custom)" when enabled
- [ ] Save as theme → new theme has `useCustomTitleFormatting: true` + all title values
- [ ] Update theme → all accordions get title formatting
- [ ] Disable toggle (if theme has `true`) → shows "(custom)" with `false`
- [ ] Save as theme with toggle disabled → new theme has `useCustomTitleFormatting: false`

---

### 3. showIcon
- **Type:** Boolean
- **Location:** Icon Panel
- **Test Values:** `null` (inherit), `false`, `true`
- **Child Attributes:** icon, iconType, iconPosition, animateIcon

**Test Steps:**
- [ ] Set to `false` → icon disappears from editor
- [ ] Set to `true` → icon appears in editor
- [ ] Save post → reload → icon visibility persists
- [ ] Shows "(custom)" when changed from theme
- [ ] Save as theme with `showIcon: false` → new theme has no icons
- [ ] Update theme → all accordions hide/show icons
- [ ] Switch theme → switch back → icon state restored

---

### 4. animateIcon
- **Type:** Boolean
- **Location:** Icon Panel
- **Test Values:** `null` (inherit), `false`, `true`

**Test Steps:**
- [ ] Set to `false` → icon doesn't rotate on open/close
- [ ] Set to `true` → icon rotates
- [ ] Save post → reload → animation behavior persists
- [ ] Shows "(custom)" when changed
- [ ] Save as theme → new theme has animateIcon value
- [ ] Update theme → all accordions animate/don't animate
- [ ] Switch theme → switch back → animation restored

---

### 5. useHeading
- **Type:** Boolean (NOT a customization - per-accordion only)
- **Location:** Title Panel
- **Test Values:** `false` (default), `true`
- **Note:** This is NOT in CUSTOMIZATION_ATTRIBUTES - it's per-accordion

**Test Steps:**
- [ ] Enable → heading level selector appears
- [ ] Save post → reload → still enabled
- [ ] Should NOT show "(custom)" (not a theme customization)
- [ ] Should NOT save to themes
- [ ] Update theme → this value unchanged (per-accordion setting)

---

### 6. useHeadingStyles
- **Type:** Boolean (NOT a customization - per-accordion only)
- **Location:** Title Panel
- **Test Values:** `false` (default), `true`
- **Note:** This is NOT in CUSTOMIZATION_ATTRIBUTES

**Test Steps:**
- [ ] Enable → title gets WordPress heading styles (larger, bold)
- [ ] Save post → reload → styles persist
- [ ] Should NOT show "(custom)"
- [ ] Should NOT save to themes

---

### 7. disabled
- **Type:** Boolean (NOT a customization - per-accordion only)
- **Location:** Block Toolbar
- **Test Values:** `false` (default), `true`
- **Note:** Controls visibility on frontend

**Test Steps:**
- [ ] Enable → accordion hidden on frontend
- [ ] Save post → reload → still disabled
- [ ] Should NOT show "(custom)"
- [ ] Should NOT save to themes

---

### 8. isOpen
- **Type:** Boolean (NOT a customization - per-accordion only)
- **Location:** Block Toolbar
- **Test Values:** `false` (default), `true`
- **Note:** Controls default open state on frontend

**Test Steps:**
- [ ] Enable → accordion opens by default on frontend
- [ ] Save post → reload → still set to open
- [ ] Should NOT show "(custom)"
- [ ] Should NOT save to themes

---

### 9. isOpenInEditor
- **Type:** Boolean (NOT saved - editor UI state only)
- **Location:** N/A (internal state)
- **Note:** Controls editor preview state only

**Test Steps:**
- [ ] Not tested (internal editor state)

---

## String Attributes (18 total)

### 10. headerBackgroundColor
- **Type:** String (color)
- **Location:** Appearance Panel
- **Test Values:** `null` (inherit), `'#ff0000'`, `'#0000ff'`

**Test Steps:**
- [ ] Set to red → header becomes red in editor
- [ ] Save post → reload → still red
- [ ] Shows "(custom)"
- [ ] Save as theme → new theme has `headerBackgroundColor: '#ff0000'`
- [ ] Update theme → all accordions become red
- [ ] Switch theme → switch back → red restored

---

### 11. headerTextColor
- **Type:** String (color)
- **Location:** Appearance Panel
- **Test Values:** `null` (inherit), `'#ffffff'`, `'#000000'`

**Test Steps:**
- [ ] Set to white → header text becomes white
- [ ] Save post → reload → still white
- [ ] Shows "(custom)"
- [ ] Save as theme → saved
- [ ] Update theme → propagates
- [ ] Cache works

---

### 12. headerHoverColor
- **Type:** String (color)
- **Location:** Appearance Panel
- **Test Values:** `null` (inherit), `'#cccccc'`

**Test Steps:**
- [ ] Set color → CSS variable updates
- [ ] Save post → reload → persists
- [ ] Shows "(custom)"
- [ ] Save as theme → saved
- [ ] Update theme → propagates
- [ ] Cache works

---

### 13. contentBackgroundColor
- **Type:** String (color)
- **Location:** Appearance Panel
- **Test Values:** `null` (inherit), `'#f0f0f0'`

**Test Steps:**
- [ ] Set color → content area background changes
- [ ] Save post → reload → persists
- [ ] Shows "(custom)"
- [ ] Save as theme → saved
- [ ] Update theme → propagates
- [ ] Cache works

---

### 14. borderColor
- **Type:** String (color)
- **Location:** Border Panel
- **Test Values:** `null` (inherit), `'#00ff00'`

**Test Steps:**
- [ ] Set color → border becomes green
- [ ] Save post → reload → persists
- [ ] Shows "(custom)"
- [ ] Save as theme → saved
- [ ] Update theme → propagates
- [ ] Cache works

---

### 15. borderStyle
- **Type:** String (CSS border-style)
- **Location:** Border Panel
- **Test Values:** `null` (inherit), `'solid'`, `'dashed'`, `'dotted'`

**Test Steps:**
- [ ] Change style → border changes
- [ ] Save post → reload → persists
- [ ] Shows "(custom)"
- [ ] Save as theme → saved
- [ ] Update theme → propagates
- [ ] Cache works

---

### 16. dividerBorderColor
- **Type:** String (color)
- **Location:** Border Panel
- **Test Values:** `null` (inherit), `'#ff00ff'`

**Test Steps:**
- [ ] Set color → divider between header/content changes
- [ ] Save post → reload → persists
- [ ] Shows "(custom)"
- [ ] Save as theme → saved
- [ ] Update theme → propagates
- [ ] Cache works

---

### 17. dividerBorderStyle
- **Type:** String (CSS border-style)
- **Location:** Border Panel
- **Test Values:** `null` (inherit), `'solid'`, `'dashed'`

**Test Steps:**
- [ ] Change style → divider changes
- [ ] Save post → reload → persists
- [ ] Shows "(custom)"
- [ ] Save as theme → saved
- [ ] Update theme → propagates
- [ ] Cache works

---

### 18. animationSpeed
- **Type:** String (enum)
- **Location:** Animation Panel
- **Test Values:** `null` (inherit), `'fast'`, `'normal'`, `'slow'`, `'none'`

**Test Steps:**
- [ ] Change speed → animation speed changes
- [ ] Save post → reload → persists
- [ ] Shows "(custom)"
- [ ] Save as theme → saved
- [ ] Update theme → propagates
- [ ] Cache works

---

### 19. icon
- **Type:** String (character or URL)
- **Location:** Icon Panel
- **Test Values:** `null` (inherit), `'▼'`, `'►'`, custom URL

**Test Steps:**
- [ ] Change icon → icon changes in editor
- [ ] Save post → reload → persists
- [ ] Shows "(custom)"
- [ ] Save as theme → saved
- [ ] Update theme → propagates
- [ ] Cache works

---

### 20. iconType
- **Type:** String (enum)
- **Location:** Icon Panel
- **Test Values:** `null` (inherit), `'character'`, `'image'`

**Test Steps:**
- [ ] Change type → icon rendering changes
- [ ] Save post → reload → persists
- [ ] Shows "(custom)"
- [ ] Save as theme → saved
- [ ] Update theme → propagates
- [ ] Cache works

---

### 21. iconPosition
- **Type:** String (enum)
- **Location:** Icon Panel
- **Test Values:** `null` (inherit), `'left'`, `'right'`, `'extreme-right'`

**Test Steps:**
- [ ] Change position → icon moves in editor
- [ ] Save post → reload → persists
- [ ] Shows "(custom)"
- [ ] Save as theme → saved
- [ ] Update theme → propagates
- [ ] Cache works

---

### 22-30. Title Formatting Attributes
- titleTextAlign (string: 'left', 'center', 'right', 'justify')
- titleFontSize (string: '16px', '1.5em', etc.)
- titleFontWeight (string: '100'-'900', 'normal', 'bold')
- titleFontStyle (string: 'normal', 'italic', 'oblique')
- titleTextTransform (string: 'none', 'uppercase', 'lowercase', 'capitalize')
- titleLetterSpacing (string: '1px', '0.5em', etc.)
- titleWordSpacing (string: '2px', etc.)
- titleTextDecoration (string: 'none', 'underline', 'line-through')
- titleFontFamily (string: 'Arial', 'serif', etc.)

**Test Steps for Each:**
- [ ] Enable `useCustomTitleFormatting` first
- [ ] Change value → title appearance changes
- [ ] Save post → reload → persists
- [ ] Shows "(custom)"
- [ ] Save as theme → saved
- [ ] Update theme → propagates
- [ ] Disable `useCustomTitleFormatting` → values cleared but theme saved with toggle disabled
- [ ] Cache works

---

## Number Attributes (6 total)

### 31. borderWidth
- **Type:** Number (pixels)
- **Location:** Border Panel
- **Test Values:** `null` (inherit), `0`, `1`, `5`, `10`

**Test Steps:**
- [ ] Change width → border thickness changes
- [ ] Save post → reload → persists
- [ ] Shows "(custom)"
- [ ] Save as theme → saved
- [ ] Update theme → propagates
- [ ] Cache works

---

### 32. dividerBorderWidth
- **Type:** Number (pixels)
- **Location:** Border Panel
- **Test Values:** `null` (inherit), `0`, `1`, `3`

**Test Steps:**
- [ ] Change width → divider thickness changes
- [ ] Save post → reload → persists
- [ ] Shows "(custom)"
- [ ] Save as theme → saved
- [ ] Update theme → propagates
- [ ] Cache works

---

### 33-36. Border Radius Attributes
- borderRadiusTopLeft (number: pixels)
- borderRadiusTopRight (number: pixels)
- borderRadiusBottomLeft (number: pixels)
- borderRadiusBottomRight (number: pixels)

**Test Steps for Each:**
- [ ] Change value → border radius changes
- [ ] Save post → reload → persists
- [ ] Shows "(custom)"
- [ ] Save as theme → saved
- [ ] Update theme → propagates
- [ ] Cache works

---

## Special Attributes (Not Customizations)

### width
- **Type:** String (NOT a customization - per-accordion)
- **Location:** Quick Settings
- **Test Values:** `'auto'`, `'50%'`, `'600px'`
- **Note:** Per-accordion setting, not saved to themes

---

### horizontalAlign
- **Type:** String (NOT a customization - per-accordion)
- **Location:** Quick Settings
- **Test Values:** `'left'`, `'center'`, `'right'`
- **Note:** Per-accordion setting, not saved to themes

---

### title
- **Type:** String (NOT a customization - content)
- **Location:** Editor / Quick Settings
- **Test Values:** Any text
- **Note:** Content, not a customization

---

### accordionId
- **Type:** String (NOT a customization - generated)
- **Location:** Auto-generated
- **Test Values:** `'accordion-xxxx'`
- **Note:** Auto-generated unique ID

---

### headingLevel
- **Type:** String (NOT a customization - per-accordion)
- **Location:** Title Panel
- **Test Values:** `'h1'`, `'h2'`, `'h3'`, `'h4'`, `'h5'`, `'h6'`
- **Note:** Per-accordion SEO setting

---

## Summary of Customization Attributes

**Total Customization Attributes:** 31

- **Booleans (2):** contentBackgroundTransparent, useCustomTitleFormatting, showIcon, animateIcon
- **Strings (18):** Colors (4), borders (4), animation (1), icon (3), title formatting (9)
- **Numbers (6):** Border widths (2), border radius (4)

**Non-Customizations (10):** useHeading, useHeadingStyles, disabled, isOpen, width, horizontalAlign, title, accordionId, headingLevel, isOpenInEditor

---

## Testing Priority

### High Priority (Core Functionality)
1. useCustomTitleFormatting (toggle + children)
2. showIcon (toggle + children)
3. headerBackgroundColor
4. borderColor
5. animationSpeed

### Medium Priority (Visual)
6. All color attributes
7. Border attributes
8. Border radius attributes

### Low Priority (Edge Cases)
9. contentBackgroundTransparent (special boolean logic)
10. Individual title formatting attributes
