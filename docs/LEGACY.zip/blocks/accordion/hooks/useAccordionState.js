import { useState, useEffect, useMemo } from '@wordpress/element';

/**
 * Custom hook for managing accordion-specific local state
 *
 * This hook manages transient UI state that is NOT saved to the database:
 * - customizationCache: Stores temporary customizations per theme (persists only during editing session)
 * - enableDividerBorder: UI toggle for divider border controls visibility
 *
 * It also provides computed values with memoization for performance.
 *
 * Important: The customization cache is session-only storage. When user saves the post:
 * - If using a customized theme: customizations are saved to post_meta
 * - If switched to base theme: cached customizations are LOST unless restored before saving
 *
 * @param {Object}   attributes                    - Block attributes
 * @param {string}   attributes.dividerBorderColor - Divider border color override
 * @param {number}   attributes.dividerBorderWidth - Divider border width override
 * @param {string}   attributes.dividerBorderStyle - Divider border style override
 * @param {string}   attributes.selectedTheme      - Currently selected theme ID
 * @param {Object}   allThemes                     - All available themes keyed by theme ID
 * @param {Function} getEffectiveValue             - Function to get effective values with theme inheritance
 * @return {Object} - State and helper functions
 * @return {Object} return.customizationCache - Cache of customizations keyed by theme ID
 * @return {Function} return.setCustomizationCache - Function to update customization cache
 * @return {boolean} return.enableDividerBorder - Whether divider border controls are visible
 * @return {Function} return.setEnableDividerBorder - Function to toggle divider border controls
 * @return {boolean} return.hasDividerBorderValues - Whether any divider border values exist
 *
 * @example
 * const {
 *   customizationCache,
 *   setCustomizationCache,
 *   enableDividerBorder,
 *   setEnableDividerBorder,
 *   hasDividerBorderValues
 * } = useAccordionState(attributes, allThemes, getEffectiveValue);
 */
const useAccordionState = ( attributes, allThemes, getEffectiveValue ) => {
	const {
		dividerBorderColor,
		dividerBorderWidth,
		dividerBorderStyle,
		selectedTheme,
	} = attributes;

	// Transient storage for customizations per theme (only persists during editing session)
	const [ customizationCache, setCustomizationCache ] = useState( {} );

	// Local UI state for divider border toggle (not saved to DB)
	const [ enableDividerBorder, setEnableDividerBorder ] = useState( false );

	// Auto-detect if divider border should be shown (based on actual values)
	useEffect( () => {
		// Check if ANY divider border customization exists (from attributes or theme)
		const hasDividerBorderValues =
			dividerBorderColor !== null ||
			dividerBorderWidth !== null ||
			dividerBorderStyle !== null ||
			// Also check theme values
			getEffectiveValue( 'dividerBorderColor', 'dividerBorderColor' ) !==
				null ||
			getEffectiveValue( 'dividerBorderWidth', 'dividerBorderWidth' ) !==
				null ||
			getEffectiveValue( 'dividerBorderStyle', 'dividerBorderStyle' ) !==
				null;

		if ( hasDividerBorderValues ) {
			setEnableDividerBorder( true );
		}
	}, [
		dividerBorderColor,
		dividerBorderWidth,
		dividerBorderStyle,
		selectedTheme,
		allThemes,
		getEffectiveValue,
	] );

	// Memoized computed value: check if any divider border values exist
	const hasDividerBorderValues = useMemo( () => {
		return (
			dividerBorderColor !== null ||
			dividerBorderWidth !== null ||
			dividerBorderStyle !== null ||
			getEffectiveValue( 'dividerBorderColor', 'dividerBorderColor' ) !==
				null ||
			getEffectiveValue( 'dividerBorderWidth', 'dividerBorderWidth' ) !==
				null ||
			getEffectiveValue( 'dividerBorderStyle', 'dividerBorderStyle' ) !==
				null
		);
	}, [
		dividerBorderColor,
		dividerBorderWidth,
		dividerBorderStyle,
		getEffectiveValue,
	] );

	return {
		customizationCache,
		setCustomizationCache,
		enableDividerBorder,
		setEnableDividerBorder,
		hasDividerBorderValues,
	};
};

export default useAccordionState;
