/**
 * ColorPickerControl Component
 *
 * Reusable color picker with consistent styling and fallback logic
 * Replaces 7+ duplicate ColorPicker instances in index.js
 */

import { BaseControl, ColorPicker } from '@wordpress/components';
import { useRef, useEffect } from '@wordpress/element';
import { UI_CONSTANTS } from '../constants';

/**
 * ColorPickerControl component
 *
 * @param {Object}   props                  - Component props
 * @param {string}   props.label            - Label for the color picker
 * @param {string}   props.color            - Current color value (can be null/undefined)
 * @param {string}   props.effectiveColor   - Effective color from theme/fallback
 * @param {string}   props.fallbackColor    - Fallback color to use if no value
 * @param {Function} props.onChange         - Callback when color changes
 * @param {Function} props.markAsCustomized - Callback to mark accordion as customized
 * @param {string}   props.help             - Optional help text
 * @return {JSX.Element} - Rendered color picker
 */
const ColorPickerControl = ( {
	label,
	color,
	effectiveColor,
	fallbackColor,
	onChange,
	markAsCustomized,
	help,
} ) => {
	// Track when color changes from defined to undefined (customization clearing)
	const previousColorRef = useRef(color);
	const justClearedRef = useRef(false);

	useEffect(() => {
		// Detect when color goes from defined to undefined (clearing customization)
		if (previousColorRef.current !== undefined && color === undefined) {
			console.log('[COLOR PICKER] Customization cleared, blocking spurious onChange for 100ms');
			justClearedRef.current = true;

			// Clear the flag after a short delay (next event loop tick)
			// This allows the spurious onChange to be blocked but allows user changes afterward
			const timer = setTimeout(() => {
				console.log('[COLOR PICKER] Blocking period ended, user changes allowed');
				justClearedRef.current = false;
			}, 100);

			return () => clearTimeout(timer);
		}

		previousColorRef.current = color;
	}, [color]);

	// Determine the color to display in the picker
	const displayColor = color || effectiveColor || fallbackColor;

	/**
	 * Handles color change events
	 * Marks accordion as customized if callback is provided, then calls onChange
	 *
	 * @param {string} newColor - The new color value selected by user
	 */
	const handleChange = ( newColor ) => {
		console.log('[COLOR PICKER] onChange fired:', {
			label,
			newColor,
			currentColor: color,
			effectiveColor,
			fallbackColor,
			displayColor,
			justCleared: justClearedRef.current,
		});

		// CRITICAL: Prevent spurious onChange events when clearing customizations
		// WordPress ColorPicker fires onChange immediately after we clear (color becomes undefined)
		// We block onChange events for 100ms after clearing to prevent re-customization
		// but allow user changes after that grace period
		if (justClearedRef.current && color === undefined && newColor !== effectiveColor) {
			console.log('[COLOR PICKER] BLOCKED: Ignoring spurious onChange during 100ms grace period after clearing');
			console.log('[COLOR PICKER] This prevents automatic re-customization');
			return;
		}

		console.trace('[COLOR PICKER] onChange call stack');

		// Mark as customized if callback provided
		if ( markAsCustomized ) {
			markAsCustomized();
		}
		onChange( newColor );
	};

	return (
		<BaseControl label={ label } help={ help }>
			<div
				style={ {
					transform: `scale(${ UI_CONSTANTS.COLOR_PICKER_SCALE })`,
					transformOrigin: 'top center',
					width: '100%',
					marginBottom: UI_CONSTANTS.COLOR_PICKER_MARGIN_OFFSET,
					display: 'flex',
					justifyContent: 'center',
				} }
			>
				<ColorPicker
					color={ displayColor }
					onChange={ handleChange }
					enableAlpha
				/>
			</div>
		</BaseControl>
	);
};

export default ColorPickerControl;
