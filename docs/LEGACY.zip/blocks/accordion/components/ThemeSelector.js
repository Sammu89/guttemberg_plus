/**
 * ThemeSelector Component
 *
 * Consolidated theme dropdown selector
 * Handles loading state and customization indicators
 */

import { SelectControl } from '@wordpress/components';
import { __ } from '@wordpress/i18n';

/**
 * ThemeSelector component
 *
 * @param {Object}   props                    - Component props
 * @param {Object}   props.allThemes          - All available themes
 * @param {Object}   props.customizationCache - Cache of customized themes
 * @param {string}   props.selectedTheme      - Currently selected theme ID
 * @param {string}   props.baseTheme          - Base theme ID (when customized)
 * @param {boolean}  props.isCustomized       - Whether current accordion is customized
 * @param {boolean}  props.isLoading          - Whether themes are loading
 * @param {Function} props.onChange           - Callback when theme changes
 * @param {string}   props.label              - Optional label override
 * @return {JSX.Element} - Rendered theme selector
 */
const ThemeSelector = ( {
	allThemes,
	customizationCache,
	selectedTheme,
	baseTheme,
	isCustomized,
	isLoading,
	onChange,
	label,
} ) => {
	// Show loading state
	if ( isLoading ) {
		return (
			<div
				style={ {
					padding: '12px',
					textAlign: 'center',
					color: '#666',
				} }
			>
				{ __( 'Loading themes…', 'guten-nav-plugin' ) }
			</div>
		);
	}

	// Build theme options with customization indicators
	const themeOptions = [];
	Object.keys( allThemes ).forEach( ( themeId ) => {
		const theme = allThemes[ themeId ];
		if ( ! theme ) {
			return;
		} // Skip if theme data is missing

		const themeName = theme.theme_name || themeId;
		const hasCustomizationInCache =
			customizationCache[ themeId ] !== undefined;
		const isCurrentlyCustomized = isCustomized && baseTheme === themeId;

		// Show customized option if in cache OR currently customized
		if ( hasCustomizationInCache || isCurrentlyCustomized ) {
			themeOptions.push( {
				label: `${ themeName } (custom)`,
				value: `${ themeId }-customized`,
			} );
		}

		// Always show the clean theme
		themeOptions.push( {
			label: themeName,
			value: themeId,
		} );
	} );

	// Determine current value
	const currentValue =
		isCustomized && selectedTheme === baseTheme
			? `${ selectedTheme }-customized`
			: selectedTheme;

	return (
		<SelectControl
			label={ label || __( 'Theme', 'guten-nav-plugin' ) }
			value={ currentValue }
			options={ themeOptions }
			onChange={ onChange }
			aria-label={
				label || __( 'Select accordion theme', 'guten-nav-plugin' )
			}
			help={
				isCustomized
					? __(
							'Currently using customized theme',
							'guten-nav-plugin'
					  )
					: null
			}
		/>
	);
};

export default ThemeSelector;
