/**
 * AccordionIcon Component
 *
 * Renders the accordion icon (character/emoji or image)
 * Consolidates icon rendering logic used in both editor and save modes
 */

/**
 * AccordionIcon component
 *
 * @param {Object}  props             - Component props
 * @param {boolean} props.showIcon    - Whether to show the icon
 * @param {string}  props.iconType    - Type of icon ('character' or 'image')
 * @param {string}  props.icon        - Icon value (emoji/character or image URL)
 * @param {boolean} props.animateIcon - Whether to animate the icon
 * @return {JSX.Element|null} - Rendered icon or null
 */
const AccordionIcon = ( { showIcon, iconType, icon, animateIcon } ) => {
	// Don't render if icons are disabled
	if ( showIcon === false ) {
		return null;
	}

	const effectiveAnimateIcon = animateIcon !== null ? animateIcon : true;

	// Render image icon
	if ( iconType === 'image' && icon ) {
		return (
			<img
				src={ icon }
				className="accordion-icon accordion-icon-image"
				data-animate={ effectiveAnimateIcon }
				alt=""
			/>
		);
	}

	// Render character/emoji icon (simple validation: non-empty string)
	if ( icon && typeof icon === 'string' && icon.trim().length > 0 ) {
		return (
			<span
				className="accordion-icon"
				data-animate={ effectiveAnimateIcon }
			>
				{ icon.trim() }
			</span>
		);
	}

	// Render default arrow icon
	return (
		<span className="accordion-icon" data-animate={ effectiveAnimateIcon }>
			▼
		</span>
	);
};

export default AccordionIcon;
