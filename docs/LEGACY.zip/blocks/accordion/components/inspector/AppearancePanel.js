/**
 * AppearancePanel Component
 *
 * Color controls panel for accordion appearance
 * Uses ColorPickerControl component for all color settings
 */

import { PanelBody } from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import { FALLBACK_COLORS } from '../../constants';
import ColorPickerControl from '../ColorPickerControl';

/**
 * AppearancePanel component
 *
 * @param {Object}   props                   - Component props
 * @param {Object}   props.attributes        - Block attributes
 * @param {Function} props.setAttributes     - Function to set attributes
 * @param {Function} props.getEffectiveValue - Function to get effective value from theme (legacy)
 * @param {Function} props.markAsCustomized  - Function to mark accordion as customized
 * @param {Object}   props.currentTheme      - Current theme object with all theme values
 * @param {Object}   props.defaultTheme      - Default theme object (fallback)
 * @return {JSX.Element} - Rendered appearance panel
 */
const AppearancePanel = ( {
	attributes,
	setAttributes,
	getEffectiveValue, // Legacy prop, kept for compatibility
	markAsCustomized,
	currentTheme,
	defaultTheme,
} ) => {
	const {
		headerBackgroundColor,
		headerTextColor,
		headerHoverColor,
		contentBackgroundColor,
	} = attributes;

	// Get theme values directly from currentTheme (no manual lookups needed)
	const getThemeValue = ( themeAttr ) => {
		// First check currentTheme
		if ( currentTheme && currentTheme[ themeAttr ] !== null && currentTheme[ themeAttr ] !== undefined ) {
			return currentTheme[ themeAttr ];
		}

		// Fall back to default theme
		if ( defaultTheme && defaultTheme[ themeAttr ] !== null && defaultTheme[ themeAttr ] !== undefined ) {
			return defaultTheme[ themeAttr ];
		}

		return null;
	};

	const themeHeaderBg = getThemeValue( 'headerBackgroundColor' );
	const themeHeaderText = getThemeValue( 'headerTextColor' );
	const themeHeaderHover = getThemeValue( 'headerHoverColor' );
	const themeContentBg = getThemeValue( 'contentBackgroundColor' );

	return (
		<PanelBody
			title={ __( 'Appearance', 'guten-nav-plugin' ) }
			initialOpen={ false }
		>
			<div
				style={ {
					fontSize: '11px',
					fontWeight: '600',
					color: '#757575',
					textTransform: 'uppercase',
					marginBottom: '12px',
					marginTop: '0',
					letterSpacing: '0.5px',
					paddingBottom: '8px',
					borderBottom: '1px solid #e0e0e0',
				} }
			>
				{ __( 'Header', 'guten-nav-plugin' ) }
			</div>

			<ColorPickerControl
				label={ __( 'Background Color', 'guten-nav-plugin' ) }
				color={ headerBackgroundColor }
				effectiveColor={ themeHeaderBg }
				fallbackColor={ FALLBACK_COLORS.HEADER_BG }
				onChange={ ( color ) =>
					setAttributes( { headerBackgroundColor: color } )
				}
				markAsCustomized={ markAsCustomized }
			/>

			<ColorPickerControl
				label={ __( 'Text Color', 'guten-nav-plugin' ) }
				color={ headerTextColor }
				effectiveColor={ themeHeaderText }
				fallbackColor={ FALLBACK_COLORS.HEADER_TEXT }
				onChange={ ( color ) =>
					setAttributes( { headerTextColor: color } )
				}
				markAsCustomized={ markAsCustomized }
			/>

			<ColorPickerControl
				label={ __( 'Hover Color', 'guten-nav-plugin' ) }
				color={ headerHoverColor }
				effectiveColor={ themeHeaderHover }
				fallbackColor={ FALLBACK_COLORS.HEADER_HOVER }
				onChange={ ( color ) =>
					setAttributes( { headerHoverColor: color } )
				}
				markAsCustomized={ markAsCustomized }
			/>

			<div
				style={ {
					fontSize: '11px',
					fontWeight: '600',
					color: '#757575',
					textTransform: 'uppercase',
					marginTop: '20px',
					marginBottom: '12px',
					letterSpacing: '0.5px',
					paddingTop: '16px',
					paddingBottom: '8px',
					borderTop: '1px solid #e0e0e0',
					borderBottom: '1px solid #e0e0e0',
				} }
			>
				{ __( 'Content', 'guten-nav-plugin' ) }
			</div>

			<ColorPickerControl
				label={ __( 'Background Color', 'guten-nav-plugin' ) }
				color={ contentBackgroundColor }
				effectiveColor={ themeContentBg }
				fallbackColor={ FALLBACK_COLORS.CONTENT_BG }
				onChange={ ( color ) =>
					setAttributes( { contentBackgroundColor: color } )
				}
				markAsCustomized={ markAsCustomized }
			/>
		</PanelBody>
	);
};

export default AppearancePanel;
