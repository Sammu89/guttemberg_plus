/**
 * BorderRadiusPanel Component
 *
 * Border radius controls panel for all four corners
 * Groups corner controls logically
 */

import { PanelBody, RangeControl } from '@wordpress/components';
import { __ } from '@wordpress/i18n';

/**
 * BorderRadiusPanel component
 *
 * @param {Object}   props                   - Component props
 * @param {Object}   props.attributes        - Block attributes
 * @param {Function} props.setAttributes     - Function to set attributes
 * @param {Function} props.getEffectiveValue - Function to get effective value from theme (legacy)
 * @param {Function} props.markAsCustomized  - Function to mark accordion as customized
 * @param {Object}   props.currentTheme      - Current theme object with all theme values
 * @param {Object}   props.defaultTheme      - Default theme object (fallback)
 * @return {JSX.Element} - Rendered border radius panel
 */
const BorderRadiusPanel = ( {
	attributes,
	setAttributes,
	getEffectiveValue, // Legacy prop, kept for compatibility
	markAsCustomized,
	currentTheme,
	defaultTheme,
} ) => {
	const {
		borderRadiusTopLeft,
		borderRadiusTopRight,
		borderRadiusBottomLeft,
		borderRadiusBottomRight,
	} = attributes;

	// Get theme values directly from currentTheme (no manual lookups needed)
	const getThemeValue = ( themeAttr, defaultValue = null ) => {
		// First check currentTheme
		if ( currentTheme && currentTheme[ themeAttr ] !== null && currentTheme[ themeAttr ] !== undefined ) {
			return currentTheme[ themeAttr ];
		}

		// Fall back to default theme
		if ( defaultTheme && defaultTheme[ themeAttr ] !== null && defaultTheme[ themeAttr ] !== undefined ) {
			return defaultTheme[ themeAttr ];
		}

		return defaultValue;
	};

	const themeBorderRadiusTL = getThemeValue( 'borderRadiusTopLeft', 0 );
	const themeBorderRadiusTR = getThemeValue( 'borderRadiusTopRight', 0 );
	const themeBorderRadiusBL = getThemeValue( 'borderRadiusBottomLeft', 0 );
	const themeBorderRadiusBR = getThemeValue( 'borderRadiusBottomRight', 0 );

	return (
		<PanelBody
			title={ __( 'Border Radius', 'guten-nav-plugin' ) }
			initialOpen={ false }
		>
			<RangeControl
				label={ __( 'Top Left (px)', 'guten-nav-plugin' ) }
				value={
					borderRadiusTopLeft !== null
						? borderRadiusTopLeft
						: themeBorderRadiusTL
				}
				onChange={ ( value ) => {
					markAsCustomized();
					setAttributes( { borderRadiusTopLeft: value } );
				} }
				min={ 0 }
				max={ 40 }
				step={ 1 }
				aria-label={ __(
					'Top left border radius in pixels',
					'guten-nav-plugin'
				) }
			/>

			<RangeControl
				label={ __( 'Top Right (px)', 'guten-nav-plugin' ) }
				value={
					borderRadiusTopRight !== null
						? borderRadiusTopRight
						: themeBorderRadiusTR
				}
				onChange={ ( value ) => {
					markAsCustomized();
					setAttributes( { borderRadiusTopRight: value } );
				} }
				min={ 0 }
				max={ 40 }
				step={ 1 }
				aria-label={ __(
					'Top right border radius in pixels',
					'guten-nav-plugin'
				) }
			/>

			<RangeControl
				label={ __( 'Bottom Left (px)', 'guten-nav-plugin' ) }
				value={
					borderRadiusBottomLeft !== null
						? borderRadiusBottomLeft
						: themeBorderRadiusBL
				}
				onChange={ ( value ) => {
					markAsCustomized();
					setAttributes( { borderRadiusBottomLeft: value } );
				} }
				min={ 0 }
				max={ 40 }
				step={ 1 }
				aria-label={ __(
					'Bottom left border radius in pixels',
					'guten-nav-plugin'
				) }
			/>

			<RangeControl
				label={ __( 'Bottom Right (px)', 'guten-nav-plugin' ) }
				value={
					borderRadiusBottomRight !== null
						? borderRadiusBottomRight
						: themeBorderRadiusBR
				}
				onChange={ ( value ) => {
					markAsCustomized();
					setAttributes( { borderRadiusBottomRight: value } );
				} }
				min={ 0 }
				max={ 40 }
				step={ 1 }
				aria-label={ __(
					'Bottom right border radius in pixels',
					'guten-nav-plugin'
				) }
			/>
		</PanelBody>
	);
};

export default BorderRadiusPanel;
