/**
 * BorderPanel Component
 *
 * Border controls panel including main border and divider border
 * Uses BORDER_STYLE_OPTIONS constant and ColorPickerControl component
 */

import {
	PanelBody,
	RangeControl,
	SelectControl,
	ToggleControl,
} from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import { BORDER_STYLE_OPTIONS, FALLBACK_COLORS } from '../../constants';
import ColorPickerControl from '../ColorPickerControl';

/**
 * BorderPanel component
 *
 * @param {Object}   props                        - Component props
 * @param {Object}   props.attributes             - Block attributes
 * @param {Function} props.setAttributes          - Function to set attributes
 * @param {Function} props.getEffectiveValue      - Function to get effective value from theme (legacy)
 * @param {Function} props.markAsCustomized       - Function to mark accordion as customized
 * @param {boolean}  props.enableDividerBorder    - Whether divider border controls are shown
 * @param {Function} props.setEnableDividerBorder - Function to toggle divider border controls
 * @param {Object}   props.currentTheme           - Current theme object with all theme values
 * @param {Object}   props.defaultTheme           - Default theme object (fallback)
 * @return {JSX.Element} - Rendered border panel
 */
const BorderPanel = ( {
	attributes,
	setAttributes,
	getEffectiveValue, // Legacy prop, kept for compatibility
	markAsCustomized,
	enableDividerBorder,
	setEnableDividerBorder,
	currentTheme,
	defaultTheme,
} ) => {
	/* eslint-disable no-unused-vars -- Used in getEffectiveValue calls below */
	const {
		borderColor,
		borderWidth,
		borderStyle,
		dividerBorderColor,
		dividerBorderWidth,
		dividerBorderStyle,
	} = attributes;
	/* eslint-enable no-unused-vars */

	// Get theme values directly from currentTheme (no manual lookups needed)
	const getThemeValue = ( themeAttr, defaultValue = null ) => {
		// First check currentTheme
		if ( currentTheme && currentTheme[ themeAttr ] !== null && currentTheme[ themeAttr ] !== undefined ) {
			return currentTheme[ themeAttr ];
		}

		// Fall back to default theme
		if ( defaultTheme && defaultTheme[ themeAttr ] !== null && defaultTheme[ themeAttr ] !== undefined ) {
			return defaultTheme[ themeAttr ];
		}

		return defaultValue;
	};

	const themeBorderColor = getThemeValue( 'borderColor' );
	const themeBorderWidth = getThemeValue( 'borderWidth' );
	const themeBorderStyle = getThemeValue( 'borderStyle', 'solid' );
	const themeDividerBorderColor = getThemeValue( 'dividerBorderColor' );
	const themeDividerBorderWidth = getThemeValue( 'dividerBorderWidth' );
	const themeDividerBorderStyle = getThemeValue( 'dividerBorderStyle', 'solid' );

	return (
		<PanelBody
			title={ __( 'Border', 'guten-nav-plugin' ) }
			initialOpen={ false }
		>
			<ColorPickerControl
				label={ __( 'Color', 'guten-nav-plugin' ) }
				color={ borderColor }
				effectiveColor={ themeBorderColor }
				fallbackColor={ FALLBACK_COLORS.BORDER }
				onChange={ ( color ) =>
					setAttributes( { borderColor: color } )
				}
				markAsCustomized={ markAsCustomized }
			/>

			<RangeControl
				label={ __( 'Thickness (px)', 'guten-nav-plugin' ) }
				value={
					borderWidth !== null
						? borderWidth
						: themeBorderWidth ?? 1
				}
				onChange={ ( value ) => {
					markAsCustomized();
					setAttributes( { borderWidth: value } );
				} }
				min={ 0 }
				max={ 10 }
				step={ 1 }
				help={ __(
					'Set border thickness in pixels',
					'guten-nav-plugin'
				) }
				aria-describedby="accordion-border-thickness-help"
			/>

			<SelectControl
				label={ __( 'Style', 'guten-nav-plugin' ) }
				value={ borderStyle || themeBorderStyle }
				options={ BORDER_STYLE_OPTIONS.map( ( opt ) => ( {
					label: __( opt.label, 'guten-nav-plugin' ),
					value: opt.value,
				} ) ) }
				onChange={ ( value ) => {
					markAsCustomized();
					setAttributes( { borderStyle: value } );
				} }
			/>

			<hr className="accordion-section-divider" />

			<div
				style={ {
					fontSize: '12px',
					fontWeight: '600',
					color: '#1e1e1e',
					marginTop: '16px',
					marginBottom: '12px',
					padding: '8px 12px',
					backgroundColor: '#f0f0f1',
					borderRadius: '4px',
					borderLeft: '3px solid #2271b1',
				} }
			>
				{ __( 'Header / Content Divider', 'guten-nav-plugin' ) }
			</div>

			<ToggleControl
				label={ __( 'Custom Divider Border', 'guten-nav-plugin' ) }
				help={ __(
					'Show controls for the border between header and content',
					'guten-nav-plugin'
				) }
				checked={ enableDividerBorder }
				onChange={ ( value ) => setEnableDividerBorder( value ) }
				aria-describedby="accordion-divider-border-help"
			/>

			{ enableDividerBorder && (
				<>
					<ColorPickerControl
						label={ __( 'Color', 'guten-nav-plugin' ) }
						color={ dividerBorderColor }
						effectiveColor={
							themeDividerBorderColor || themeBorderColor
						}
						fallbackColor="#e0e0e0"
						onChange={ ( color ) =>
							setAttributes( { dividerBorderColor: color } )
						}
						markAsCustomized={ markAsCustomized }
					/>

					<RangeControl
						label={ __( 'Thickness (px)', 'guten-nav-plugin' ) }
						value={
							dividerBorderWidth !== null &&
							dividerBorderWidth !== undefined
								? dividerBorderWidth
								: themeDividerBorderWidth !== null &&
								  themeDividerBorderWidth !== undefined
								? themeDividerBorderWidth
								: 0
						}
						onChange={ ( value ) => {
							markAsCustomized();
							setAttributes( { dividerBorderWidth: value } );
						} }
						min={ 0 }
						max={ 10 }
						step={ 1 }
						help={ __(
							'Set divider border thickness in pixels (0 = hidden)',
							'guten-nav-plugin'
						) }
						aria-describedby="accordion-divider-thickness-help"
					/>

					<SelectControl
						label={ __( 'Style', 'guten-nav-plugin' ) }
						value={
							themeDividerBorderStyle ||
							themeBorderStyle ||
							'solid'
						}
						options={ BORDER_STYLE_OPTIONS.map( ( opt ) => ( {
							label: __( opt.label, 'guten-nav-plugin' ),
							value: opt.value,
						} ) ) }
						onChange={ ( value ) => {
							markAsCustomized();
							setAttributes( { dividerBorderStyle: value } );
						} }
					/>
				</>
			) }
		</PanelBody>
	);
};

export default BorderPanel;
