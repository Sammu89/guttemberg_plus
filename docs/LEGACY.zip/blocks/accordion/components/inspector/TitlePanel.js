/**
 * TitlePanel Component
 *
 * Title formatting and heading controls panel for accordion
 * Includes heading settings and custom title formatting options
 */

import {
	PanelBody,
	ToggleControl,
	SelectControl,
	TextControl,
} from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import { useEffect } from '@wordpress/element';
import {
	HEADING_LEVEL_OPTIONS,
	TITLE_TEXT_ALIGN_OPTIONS,
	TITLE_FONT_WEIGHT_OPTIONS,
	TITLE_FONT_STYLE_OPTIONS,
	TITLE_TEXT_TRANSFORM_OPTIONS,
	TITLE_TEXT_DECORATION_OPTIONS,
} from '../../constants';
import {
	ACCORDION_ATTRIBUTE_CONFIG,
} from '../../config';

/**
 * TitlePanel component
 *
 * @param {Object}   props                   - Component props
 * @param {Object}   props.attributes        - Block attributes
 * @param {Function} props.setAttributes     - Function to set attributes
 * @param {Object}   props.sidebarValues     - Effective values from theme/inline for sidebar display
 * @param {Function} props.markAsCustomized  - Function to mark accordion as customized
 * @return {JSX.Element} - Rendered title panel
 */
const TitlePanel = ( {
	attributes,
	setAttributes,
	sidebarValues,
	markAsCustomized,
} ) => {
	const {
		headingLevel,
	} = attributes;

	// Use sidebar values for display (auto-populated from theme/inline)
	// Boolean toggles MUST read from sidebarValues (effective values) just like colors and borders
	const {
		useHeading,
		useHeadingStyles,
		useCustomTitleFormatting,
		titleTextAlign,
		titleFontSize,
		titleFontWeight,
		titleFontStyle,
		titleTextTransform,
		titleLetterSpacing,
		titleWordSpacing,
		titleTextDecoration,
		titleFontFamily,
	} = sidebarValues;

	// DEBUG: Monitor attribute changes in TitlePanel
	useEffect(() => {
		console.log('[TITLE PANEL useEffect] Component rendered/updated');
		console.log('[TITLE PANEL useEffect] useHeading from sidebarValues (EFFECTIVE):', useHeading);
		console.log('[TITLE PANEL useEffect] useHeading from raw attributes:', attributes.useHeading);
		console.log('[TITLE PANEL useEffect] Type:', typeof useHeading);
		console.log('[TITLE PANEL useEffect] Full attributes:', attributes);
		console.log('[TITLE PANEL useEffect] Full sidebarValues:', sidebarValues);
	}, [useHeading, attributes, sidebarValues]);

	return (
		<PanelBody
			title={ __( 'Title', 'guten-nav-plugin' ) }
			initialOpen={ false }
		>
			<ToggleControl
				label={ __( 'Use heading for title', 'guten-nav-plugin' ) }
				help={ __(
					'Render title as HTML heading (H1-H6) for SEO',
					'guten-nav-plugin'
				) }
				checked={ useHeading }
				onChange={ ( value ) => {
					console.log('[TITLE PANEL] useHeading toggle clicked');
					console.log('[TITLE PANEL] Previous EFFECTIVE value (from sidebarValues):', useHeading);
					console.log('[TITLE PANEL] Previous RAW value (from attributes):', attributes.useHeading);
					console.log('[TITLE PANEL] New value:', value);
					console.log('[TITLE PANEL] Setting attribute to:', value);
					setAttributes( { useHeading: value } );
					markAsCustomized();
					console.log('[TITLE PANEL] After setAttributes call');
				} }
				aria-describedby="accordion-use-heading-help"
			/>

			{ useHeading && (
				<>
					<SelectControl
						label={ __( 'Heading Level', 'guten-nav-plugin' ) }
						value={ headingLevel }
						options={ HEADING_LEVEL_OPTIONS.map( ( opt ) => ( {
							label: __( opt.label, 'guten-nav-plugin' ),
							value: opt.value,
						} ) ) }
						onChange={ ( value ) => {
							setAttributes( { headingLevel: value } );
							markAsCustomized();
						} }
						help={ __(
							'Select the appropriate heading level for your content hierarchy',
							'guten-nav-plugin'
						) }
						aria-describedby="accordion-heading-level-help"
					/>

					<ToggleControl
						label={ __(
							'Use WordPress heading styles',
							'guten-nav-plugin'
						) }
						help={ __(
							'Enable to use theme heading styles (larger, bold). Disable to keep accordion button formatting.',
							'guten-nav-plugin'
						) }
						checked={ useHeadingStyles }
						onChange={ ( value ) => {
							setAttributes( {
								useHeadingStyles: value,
								useCustomTitleFormatting: value ? false : useCustomTitleFormatting,
							} );
							// Mark as customized if we're disabling useCustomTitleFormatting
							// and it differs from the theme
							markAsCustomized();
						} }
						aria-describedby="accordion-use-heading-styles-help"
					/>
				</>
			) }

			<div
				style={ {
					fontSize: '11px',
					fontWeight: '600',
					color: '#757575',
					textTransform: 'uppercase',
					marginBottom: '12px',
					marginTop: '16px',
					letterSpacing: '0.5px',
					paddingBottom: '8px',
					paddingTop: '8px',
					borderTop: '1px solid #e0e0e0',
					borderBottom: '1px solid #e0e0e0',
				} }
			>
				{ __( 'Custom Title Formatting', 'guten-nav-plugin' ) }
			</div>

			<ToggleControl
				label={ __(
					'Use custom title formatting',
					'guten-nav-plugin'
				) }
				help={ __(
					'Enable custom formatting options for the accordion title',
					'guten-nav-plugin'
				) }
				checked={ useCustomTitleFormatting }
				onChange={ ( value ) => {
					if ( value ) {
						// Enabling: untoggle WordPress heading styles
						setAttributes( {
							useCustomTitleFormatting: true,
							useHeadingStyles: false,
						} );
						markAsCustomized();
					} else {
						// Disabling: clear all title formatting customizations
						const clearedAttributes = {
							useCustomTitleFormatting: false,
						};

						// Get child attributes from config and clear them
						const childAttrs = ACCORDION_ATTRIBUTE_CONFIG.useCustomTitleFormatting.childAttributes || [];
						childAttrs.forEach( ( attr ) => {
							clearedAttributes[ attr ] = null;
						} );

						setAttributes( clearedAttributes );
						markAsCustomized();
					}
				} }
			/>

			{ useCustomTitleFormatting && ! useHeadingStyles && (
						<>
							<SelectControl
								label={ __( 'Text Align', 'guten-nav-plugin' ) }
								value={ titleTextAlign || '' }
								options={ TITLE_TEXT_ALIGN_OPTIONS.map(
									( opt ) => ( {
										label: __(
											opt.label,
											'guten-nav-plugin'
										),
										value: opt.value,
									} )
								) }
								onChange={ ( value ) => {
									setAttributes( {
										titleTextAlign: value || null,
									} );
									markAsCustomized();
								} }
							/>

							<TextControl
								label={ __( 'Font Size', 'guten-nav-plugin' ) }
								value={ titleFontSize || '' }
								onChange={ ( value ) => {
									setAttributes( {
										titleFontSize: value || null,
									} );
									markAsCustomized();
								} }
								help={ __(
									'e.g., 16px, 1.2em, 1.5rem',
									'guten-nav-plugin'
								) }
								placeholder="16px"
							/>

							<SelectControl
								label={ __(
									'Font Weight',
									'guten-nav-plugin'
								) }
								value={ titleFontWeight || '' }
								options={ TITLE_FONT_WEIGHT_OPTIONS.map(
									( opt ) => ( {
										label: __(
											opt.label,
											'guten-nav-plugin'
										),
										value: opt.value,
									} )
								) }
								onChange={ ( value ) => {
									setAttributes( {
										titleFontWeight: value || null,
									} );
									markAsCustomized();
								} }
							/>

							<SelectControl
								label={ __( 'Font Style', 'guten-nav-plugin' ) }
								value={ titleFontStyle || '' }
								options={ TITLE_FONT_STYLE_OPTIONS.map(
									( opt ) => ( {
										label: __(
											opt.label,
											'guten-nav-plugin'
										),
										value: opt.value,
									} )
								) }
								onChange={ ( value ) => {
									setAttributes( {
										titleFontStyle: value || null,
									} );
									markAsCustomized();
								} }
							/>

							<SelectControl
								label={ __(
									'Text Transform',
									'guten-nav-plugin'
								) }
								value={ titleTextTransform || '' }
								options={ TITLE_TEXT_TRANSFORM_OPTIONS.map(
									( opt ) => ( {
										label: __(
											opt.label,
											'guten-nav-plugin'
										),
										value: opt.value,
									} )
								) }
								onChange={ ( value ) => {
									setAttributes( {
										titleTextTransform: value || null,
									} );
									markAsCustomized();
								} }
							/>

							<TextControl
								label={ __(
									'Letter Spacing',
									'guten-nav-plugin'
								) }
								value={ titleLetterSpacing || '' }
								onChange={ ( value ) => {
									setAttributes( {
										titleLetterSpacing: value || null,
									} );
									markAsCustomized();
								} }
								help={ __(
									'e.g., 1px, 0.5em, normal',
									'guten-nav-plugin'
								) }
								placeholder="normal"
							/>

							<TextControl
								label={ __(
									'Word Spacing',
									'guten-nav-plugin'
								) }
								value={ titleWordSpacing || '' }
								onChange={ ( value ) => {
									setAttributes( {
										titleWordSpacing: value || null,
									} );
									markAsCustomized();
								} }
								help={ __(
									'e.g., 2px, 0.5em, normal',
									'guten-nav-plugin'
								) }
								placeholder="normal"
							/>

							<SelectControl
								label={ __(
									'Text Decoration',
									'guten-nav-plugin'
								) }
								value={ titleTextDecoration || '' }
								options={ TITLE_TEXT_DECORATION_OPTIONS.map(
									( opt ) => ( {
										label: __(
											opt.label,
											'guten-nav-plugin'
										),
										value: opt.value,
									} )
								) }
								onChange={ ( value ) => {
									setAttributes( {
										titleTextDecoration: value || null,
									} );
									markAsCustomized();
								} }
							/>

							<TextControl
								label={ __(
									'Font Family',
									'guten-nav-plugin'
								) }
								value={ titleFontFamily || '' }
								onChange={ ( value ) => {
									setAttributes( {
										titleFontFamily: value || null,
									} );
									markAsCustomized();
								} }
								help={ __(
									'e.g., Arial, "Times New Roman", sans-serif',
									'guten-nav-plugin'
								) }
								placeholder="inherit"
							/>
						</>
					) }
		</PanelBody>
	);
};

export default TitlePanel;
