/**
 * SettingsPanel Component
 *
 * Main settings panel - always visible (non-collapsible)
 * Contains theme selector, alignment, width, and toggle controls
 */

import {
	TextControl,
	ToggleControl,
	SelectControl,
	Button,
} from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import { update, plus } from '@wordpress/icons';
import { speak } from '@wordpress/a11y';
import {
	HORIZONTAL_ALIGN_OPTIONS,
} from '../../constants';
import ThemeSelector from '../ThemeSelector';

/**
 * SettingsPanel component
 *
 * @param {Object}   props                       - Component props
 * @param {Object}   props.attributes            - Block attributes
 * @param {Function} props.setAttributes         - Function to set attributes
 * @param {Object}   props.allThemes             - All available themes
 * @param {Object}   props.customizationCache    - Cache of customized themes
 * @param {boolean}  props.isLoadingThemes       - Whether themes are loading
 * @param {Function} props.handleThemeChange     - Callback for theme changes
 * @param {boolean}  props.isCustomized          - Whether theme is customized
 * @param {string}   props.selectedTheme         - Currently selected theme
 * @param {boolean}  props.isSavingTheme         - Whether theme is saving
 * @param {boolean}  props.isDeletingTheme       - Whether theme is deleting
 * @param {Function} props.collectEffectiveSettings - Collects effective settings
 * @param {Function} props.handleSaveTheme       - Handles theme saving
 * @param {Function} props.handleCreateTheme     - Handles theme creation
 * @param {Function} props.handleRenameTheme     - Handles theme renaming
 * @param {Function} props.handleDeleteTheme     - Handles theme deletion
 * @param {Function} props.setSaveNotification   - Sets save notification
 * @param {Function} props.switchToCleanTheme    - Switches to clean theme
 * @return {JSX.Element} - Rendered settings panel
 */
const SettingsPanel = ( {
	attributes,
	setAttributes,
	allThemes,
	customizationCache,
	isLoadingThemes,
	handleThemeChange,
	isCustomized,
	selectedTheme,
	isSavingTheme,
	isDeletingTheme,
	collectEffectiveSettings,
	handleSaveTheme,
	handleCreateTheme,
	handleRenameTheme,
	handleDeleteTheme,
	setSaveNotification,
	switchToCleanTheme,
} ) => {
	const {
		baseTheme,
		horizontalAlign,
		width,
		isOpen,
		disabled,
	} = attributes;

	return (
		<div style={ { padding: '16px', borderBottom: '1px solid #ddd' } }>
			<ThemeSelector
				allThemes={ allThemes }
				customizationCache={ customizationCache }
				selectedTheme={ selectedTheme }
				baseTheme={ baseTheme }
				isCustomized={ isCustomized }
				isLoading={ isLoadingThemes }
				onChange={ handleThemeChange }
			/>

			{/* Theme Management Buttons */}
			<div
				className="accordion-theme-buttons"
				style={ { marginTop: '16px', marginBottom: '16px' } }
			>
				{ isCustomized && selectedTheme !== 'default' && (
					<Button
						isPrimary
						icon={ update }
						onClick={ async () => {
							const themeName =
								allThemes[ selectedTheme ]?.theme_name || selectedTheme;
							if (
								! confirm(
									__(
										`Update theme "${ themeName }" with these settings? This will affect all accordions using this theme.`,
										'guten-nav-plugin'
									)
								)
							) {
								return;
							}

							const allSettings = collectEffectiveSettings();
							const data = await handleSaveTheme(
								selectedTheme,
								allSettings
							);

							if ( data ) {
								setSaveNotification( {
									message: __(
										`Theme "${ themeName }" updated successfully!`,
										'guten-nav-plugin'
									),
									panel: 'themes',
								} );

								speak(
									__(
										`Theme "${ themeName }" updated successfully`,
										'guten-nav-plugin'
									),
									'polite'
								);
							}
						} }
						disabled={ isSavingTheme || isDeletingTheme }
						style={ {
							marginBottom: '8px',
							display: 'block',
							width: '100%',
						} }
					>
						{ isSavingTheme
							? __( 'Updating…', 'guten-nav-plugin' )
							: __( 'Update theme with these settings', 'guten-nav-plugin' ) }
					</Button>
				) }

				{ isCustomized && (
					<Button
						isSecondary
						icon={ plus }
						onClick={ async () => {
							const themeName = prompt(
								__( 'Enter a name for the new theme:', 'guten-nav-plugin' )
							);
							if ( ! themeName ) {
								return;
							}

							const effectiveSettings = collectEffectiveSettings();
							const result = await handleCreateTheme( themeName, effectiveSettings );

							if ( result ) {
								speak(
									__(
										`New theme "${ themeName }" created and applied`,
										'guten-nav-plugin'
									),
									'polite'
								);
							}
						} }
						disabled={ isSavingTheme || isDeletingTheme }
						style={ {
							marginBottom: '8px',
							display: 'block',
							width: '100%',
						} }
					>
						{ __( 'Save these settings as new theme', 'guten-nav-plugin' ) }
					</Button>
				) }

				{ selectedTheme && selectedTheme !== 'default' && (
					<>
						<Button
							isSecondary
							onClick={ async () => {
								const currentThemeName =
									allThemes[ selectedTheme ]?.theme_name || selectedTheme;
								const newName = prompt(
									__( 'Enter new theme name:', 'guten-nav-plugin' ),
									currentThemeName
								);

								if ( ! newName || newName === currentThemeName ) {
									return;
								}

								await handleRenameTheme( selectedTheme, newName );
							} }
							disabled={ isSavingTheme || isDeletingTheme }
							style={ {
								marginBottom: '8px',
								display: 'block',
								width: '100%',
							} }
						>
							{ __( 'Rename theme', 'guten-nav-plugin' ) }
						</Button>

						<Button
							isDestructive
							onClick={ async () => {
								const themeName =
									allThemes[ selectedTheme ]?.theme_name || selectedTheme;

								if (
									! confirm(
										__(
											`Are you sure you want to delete theme "${ themeName }"? This cannot be undone.`,
											'guten-nav-plugin'
										)
									)
								) {
									return;
								}

								await handleDeleteTheme(
									selectedTheme,
									selectedTheme,
									( deletedThemeId ) => {
										if ( selectedTheme === deletedThemeId ) {
											setAttributes( {
												selectedTheme: 'default',
											} );
										}
									}
								);
							} }
							disabled={ isSavingTheme || isDeletingTheme }
							style={ {
								display: 'block',
								width: '100%',
							} }
						>
							{ isDeletingTheme
								? __( 'Deleting…', 'guten-nav-plugin' )
								: __( 'Delete theme', 'guten-nav-plugin' ) }
						</Button>
					</>
				) }
			</div>

			<SelectControl
				label={ __( 'Horizontal Alignment', 'guten-nav-plugin' ) }
				value={ horizontalAlign }
				options={ HORIZONTAL_ALIGN_OPTIONS.map( ( opt ) => ( {
					label: __( opt.label, 'guten-nav-plugin' ),
					value: opt.value,
				} ) ) }
				onChange={ ( value ) =>
					setAttributes( { horizontalAlign: value } )
				}
			/>

			<TextControl
				label={ __( 'Width', 'guten-nav-plugin' ) }
				value={ width || '' }
				onChange={ ( value ) =>
					setAttributes( { width: value || null } )
				}
				help={ __(
					'(in px, em, %, etc)',
					'guten-nav-plugin'
				) }
				placeholder="100%"
				aria-describedby="accordion-width-help"
			/>

			<ToggleControl
				label={ __( 'Appears open by default', 'guten-nav-plugin' ) }
				help={ __(
					'Controls default state on the page. In editor, accordions are always expanded.',
					'guten-nav-plugin'
				) }
				checked={ isOpen }
				onChange={ ( value ) => setAttributes( { isOpen: value } ) }
			/>

			<ToggleControl
				label={ __( 'Disable this accordion', 'guten-nav-plugin' ) }
				help={ __(
					'Hide accordion on the frontend',
					'guten-nav-plugin'
				) }
				checked={ disabled }
				onChange={ ( value ) => setAttributes( { disabled: value } ) }
				aria-describedby="accordion-disable-help"
			/>
		</div>
	);
};

export default SettingsPanel;
