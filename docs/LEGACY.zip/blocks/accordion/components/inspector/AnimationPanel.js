/**
 * AnimationPanel Component
 *
 * Animation controls panel for accordion open/close speed
 * Uses ANIMATION_SPEED_OPTIONS constant
 */

import { PanelBody, SelectControl } from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import { ANIMATION_SPEED_OPTIONS } from '../../constants';

/**
 * AnimationPanel component
 *
 * @param {Object}   props                   - Component props
 * @param {Object}   props.attributes        - Block attributes
 * @param {Function} props.setAttributes     - Function to set attributes
 * @param {Object}   props.sidebarValues     - Effective values from theme/inline for sidebar display
 * @param {Function} props.markAsCustomized  - Function to mark accordion as customized
 * @return {JSX.Element} - Rendered animation panel
 */
const AnimationPanel = ( {
	attributes,
	setAttributes,
	sidebarValues,
	markAsCustomized,
} ) => {
	// Read animationSpeed from sidebarValues (effective value) just like colors and borders
	const { animationSpeed } = sidebarValues;

	return (
		<PanelBody
			title={ __( 'Animation', 'guten-nav-plugin' ) }
			initialOpen={ false }
		>
			<SelectControl
				label={ __( 'Animation Speed', 'guten-nav-plugin' ) }
				value={ animationSpeed || 'normal' }
				options={ ANIMATION_SPEED_OPTIONS.map( ( opt ) => ( {
					label: __( opt.label, 'guten-nav-plugin' ),
					value: opt.value,
				} ) ) }
				onChange={ ( value ) => {
					markAsCustomized();
					setAttributes( { animationSpeed: value || null } );
				} }
			/>
		</PanelBody>
	);
};

export default AnimationPanel;
