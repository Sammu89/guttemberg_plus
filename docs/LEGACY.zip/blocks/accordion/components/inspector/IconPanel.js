/**
 * IconPanel Component
 *
 * Icon configuration panel with AccordionIcon preview
 * Controls icon visibility, type, position, and animation
 */

import {
	PanelBody,
	ToggleControl,
	SelectControl,
	TextControl,
} from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import AccordionIcon from '../AccordionIcon';

/**
 * Validates icon string (max 10 characters)
 * @param {string} icon - Icon string to validate
 * @return {boolean} - True if valid
 */
const validateIcon = ( icon ) => {
	return typeof icon === 'string' && icon.length <= 10;
};

/**
 * IconPanel component
 *
 * @param {Object}   props                   - Component props
 * @param {Object}   props.attributes        - Block attributes
 * @param {Function} props.setAttributes     - Function to set attributes
 * @param {Object}   props.sidebarValues     - Effective values from theme/inline for sidebar display
 * @param {Function} props.markAsCustomized  - Function to mark accordion as customized
 * @return {JSX.Element} - Rendered icon panel
 */
const IconPanel = ( {
	attributes,
	setAttributes,
	sidebarValues,
	markAsCustomized,
} ) => {
	const { icon } = attributes;

	// Read ALL values from sidebarValues (effective values) just like colors and borders
	const {
		showIcon,
		iconType,
		iconPosition,
		animateIcon,
	} = sidebarValues;

	// Icon value needs special handling for validation
	const displayIcon = icon || sidebarValues.icon || '';

	return (
		<PanelBody
			title={ __( 'Icon', 'guten-nav-plugin' ) }
			initialOpen={ false }
		>
			<ToggleControl
				label={ __( 'Show Icon', 'guten-nav-plugin' ) }
				checked={ showIcon }
				onChange={ ( value ) => {
					markAsCustomized();
					setAttributes( { showIcon: value } );
				} }
			/>

			{ showIcon && (
				<>
					<SelectControl
						label={ __( 'Icon Type', 'guten-nav-plugin' ) }
						value={ iconType }
						options={ [
							{
								label: __(
									'Character/Emoji',
									'guten-nav-plugin'
								),
								value: 'character',
							},
							{
								label: __( 'Image URL', 'guten-nav-plugin' ),
								value: 'image',
							},
						] }
						onChange={ ( value ) => {
							markAsCustomized();
							setAttributes( { iconType: value } );
						} }
					/>

					{ iconType === 'image' ? (
						<TextControl
							label={ __( 'Image URL', 'guten-nav-plugin' ) }
							value={ displayIcon }
							onChange={ ( value ) => {
								markAsCustomized();
								setAttributes( { icon: value } );
							} }
							help={ __(
								'Enter the URL of the icon image',
								'guten-nav-plugin'
							) }
							placeholder="https://example.com/icon.png"
							aria-describedby="accordion-icon-image-url-help"
						/>
					) : (
						<TextControl
							label={ __(
								'Icon Character/Emoji',
								'guten-nav-plugin'
							) }
							value={ displayIcon }
							onChange={ ( value ) => {
								if ( validateIcon( value ) || value === '' ) {
									markAsCustomized();
									setAttributes( { icon: value } );
								}
							} }
							help={
								icon && ! validateIcon( icon )
									? __(
											'Invalid icon (max 10 characters)',
											'guten-nav-plugin'
									  )
									: __(
											'Enter custom icon (emoji or symbol, max 10 chars)',
											'guten-nav-plugin'
									  )
							}
							placeholder="▼"
							aria-describedby="accordion-icon-character-help"
						/>
					) }

					<SelectControl
						label={ __( 'Icon Position', 'guten-nav-plugin' ) }
						value={ iconPosition }
						options={ [
							{
								label: __( 'Left', 'guten-nav-plugin' ),
								value: 'left',
							},
							{
								label: __( 'Right', 'guten-nav-plugin' ),
								value: 'right',
							},
							{
								label: __(
									'Extreme Right',
									'guten-nav-plugin'
								),
								value: 'extreme-right',
							},
						] }
						onChange={ ( value ) => {
							markAsCustomized();
							setAttributes( { iconPosition: value } );
						} }
					/>

					<ToggleControl
						label={ __( 'Animate Icon', 'guten-nav-plugin' ) }
						checked={ animateIcon }
						onChange={ ( value ) => {
							markAsCustomized();
							setAttributes( { animateIcon: value } );
						} }
						help={ __(
							'Rotate icon when accordion opens/closes',
							'guten-nav-plugin'
						) }
						aria-describedby="accordion-animate-icon-help"
					/>

					<div
						style={ {
							marginTop: '16px',
							padding: '12px',
							backgroundColor: '#f0f0f1',
							borderRadius: '4px',
							borderLeft: '3px solid #2271b1',
						} }
					>
						<div
							style={ {
								fontSize: '11px',
								fontWeight: '600',
								color: '#1e1e1e',
								marginBottom: '8px',
							} }
						>
							{ __( 'Icon Preview', 'guten-nav-plugin' ) }
						</div>
						<div
							style={ {
								fontSize: '24px',
								textAlign: 'center',
								padding: '8px',
							} }
						>
							<AccordionIcon
								showIcon={ showIcon }
								iconType={ iconType }
								icon={ displayIcon }
								animateIcon={ animateIcon }
							/>
						</div>
					</div>
				</>
			) }
		</PanelBody>
	);
};

export default IconPanel;
