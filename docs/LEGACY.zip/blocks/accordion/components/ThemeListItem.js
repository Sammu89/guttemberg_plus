/**
 * ThemeListItem Component
 *
 * Renders a single theme in the theme management list
 * Supports rename, delete, select actions with default theme restrictions
 */

import { Button } from '@wordpress/components';
import { __ } from '@wordpress/i18n';

/**
 * ThemeListItem component
 *
 * @param {Object}   props                 - Component props
 * @param {string}   props.themeId         - Theme ID
 * @param {Object}   props.theme           - Theme object with settings
 * @param {string}   props.selectedTheme   - Currently selected theme ID
 * @param {boolean}  props.isCustomized    - Whether accordion is customized
 * @param {boolean}  props.isSavingTheme   - Whether a theme is being saved
 * @param {boolean}  props.isDeletingTheme - Whether a theme is being deleted
 * @param {Function} props.onSelect        - Callback when theme is selected
 * @param {Function} props.onRename        - Callback when theme is renamed
 * @param {Function} props.onDelete        - Callback when theme is deleted
 * @return {JSX.Element} - Rendered theme list item
 */
const ThemeListItem = ( {
	themeId,
	theme,
	selectedTheme,
	isCustomized,
	isSavingTheme,
	isDeletingTheme,
	onSelect,
	onRename,
	onDelete,
} ) => {
	const themeName = theme.theme_name || themeId;
	const isDefault = themeId === 'default';
	const isSelected = selectedTheme === themeId;

	return (
		<div
			className={ `accordion-theme-list-item ${
				isSelected ? 'selected' : ''
			}` }
		>
			<span
				style={ {
					fontWeight: isSelected ? '600' : '400',
					fontSize: '13px',
				} }
			>
				{ themeName }
				{ isSelected && isCustomized && (
					<span
						style={ {
							marginLeft: '6px',
							color: '#d63638',
							fontSize: '11px',
						} }
					>
						({ __( 'customized', 'guten-nav-plugin' ) })
					</span>
				) }
				{ isSelected && ! isCustomized && (
					<span
						style={ {
							marginLeft: '6px',
							color: '#0073aa',
							fontSize: '11px',
						} }
					>
						({ __( 'Active', 'guten-nav-plugin' ) })
					</span>
				) }
			</span>
			<div
				className="accordion-theme-item-actions"
				style={ {
					display: 'flex',
					gap: '4px',
				} }
			>
				{ ! isSelected && (
					<Button
						isSmall
						isPrimary
						onClick={ () => onSelect( themeId ) }
						disabled={ isSavingTheme || isDeletingTheme }
						aria-label={ __(
							`Select theme ${ themeName }`,
							'guten-nav-plugin'
						) }
					>
						{ __( 'Select', 'guten-nav-plugin' ) }
					</Button>
				) }
				{ ! isDefault && (
					<>
						<Button
							isSmall
							onClick={ () => onRename( themeId ) }
							disabled={ isSavingTheme || isDeletingTheme }
							aria-label={ __(
								`Rename theme ${ themeName }`,
								'guten-nav-plugin'
							) }
						>
							{ __( 'Rename', 'guten-nav-plugin' ) }
						</Button>
						<Button
							isSmall
							isDestructive
							onClick={ () => onDelete( themeId ) }
							disabled={ isSavingTheme || isDeletingTheme }
							aria-label={ __(
								`Delete theme ${ themeName }`,
								'guten-nav-plugin'
							) }
						>
							{ __( 'Delete', 'guten-nav-plugin' ) }
						</Button>
					</>
				) }
			</div>
		</div>
	);
};

export default ThemeListItem;
