import {
	useBlockProps,
	InnerBlocks,
	InspectorControls,
	BlockControls,
	RichText,
} from '@wordpress/block-editor';
import {
	PanelBody,
	TextControl,
	SelectControl,
	ToolbarGroup,
	ToolbarButton,
	Dropdown,
	__experimentalVStack as VStack,
} from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import { settings, page } from '@wordpress/icons';
import { useState, useEffect, useMemo, useCallback } from '@wordpress/element';
import { useSelect, useDispatch } from '@wordpress/data';
import { store as editorStore } from '@wordpress/editor';
import { store as noticesStore } from '@wordpress/notices';
import { speak } from '@wordpress/a11y';
import { HORIZONTAL_ALIGN_OPTIONS, UI_CONSTANTS } from './constants';
import {
	ACCORDION_ATTRIBUTE_CONFIG,
	ACCORDION_CUSTOMIZATION_ATTRIBUTES,
} from './config';
import { hasBorderRadius, getAlignmentMargins } from '../shared/utils/style-helpers';

// Import shared hooks
import {
	useThemeManagement,
	useEffectiveValues,
	useCustomizationState,
	useThemeHandlers,
} from '../shared/hooks';

// Import shared core utilities
import {
	getAttributeDefaultValue,
	isAttributeCustomized,
} from '../shared/customization-core';

// Import block-specific hooks
import useAccordionState from './hooks/useAccordionState';

// Import components
import AccordionIcon from './components/AccordionIcon';
import ErrorBoundary from '../shared/components/ErrorBoundary';
import ThemeSelector from './components/ThemeSelector';
import SettingsPanel from './components/inspector/SettingsPanel';
import AppearancePanel from './components/inspector/AppearancePanel';
import TitlePanel from './components/inspector/TitlePanel';
import BorderPanel from './components/inspector/BorderPanel';
import BorderRadiusPanel from './components/inspector/BorderRadiusPanel';
import IconPanel from './components/inspector/IconPanel';
import AnimationPanel from './components/inspector/AnimationPanel';

const Edit = ( { attributes, setAttributes: originalSetAttributes, clientId } ) => {
	// Wrap setAttributes with debug logging to track ALL attribute changes
	const setAttributes = useCallback((updates) => {
		console.log('[EDIT.JS] setAttributes called with:', updates);
		console.log('[EDIT.JS] headerBackgroundColor in updates:', updates?.headerBackgroundColor);
		console.log('[EDIT.JS] useHeading in updates:', updates?.useHeading);
		console.log('[EDIT.JS] Current attributes before update:', {
			themeId: attributes.themeId,
			selectedTheme: attributes.selectedTheme,
			baseTheme: attributes.baseTheme,
			headerBackgroundColor: attributes.headerBackgroundColor,
			useHeading: attributes.useHeading,
		});
		console.trace('[EDIT.JS] setAttributes call stack');
		originalSetAttributes(updates);

		// Log after update to verify if it was applied
		setTimeout(() => {
			console.log('[EDIT.JS] Attributes AFTER update (via setTimeout):', {
				useHeading: attributes.useHeading,
				...updates
			});
		}, 0);
	}, [originalSetAttributes, attributes]);

	/* eslint-disable no-unused-vars -- These are destructured for passing to child components */
	const {
		title,
		isOpen,
		isOpenInEditor,
		selectedTheme,
		baseTheme,
		isCustomized,
		headerBackgroundColor,
		headerTextColor,
		headerHoverColor,
		borderColor,
		borderWidth,
		borderStyle,
		dividerBorderColor,
		dividerBorderWidth,
		dividerBorderStyle,
		borderRadiusTopLeft,
		borderRadiusTopRight,
		borderRadiusBottomLeft,
		borderRadiusBottomRight,
		contentBackgroundColor,
		contentBackgroundTransparent,
		width,
		horizontalAlign,
		disabled,
		animationSpeed,
		showIcon,
		icon,
		iconType,
		iconPosition,
		animateIcon,
		accordionId,
		useHeading,
		headingLevel,
		useHeadingStyles,
		useCustomTitleFormatting,
	} = attributes;
	/* eslint-enable no-unused-vars */

	// Get editor data for save detection
	const { createWarningNotice } = useDispatch( noticesStore );
	const isSavingPost = useSelect(
		( select ) => select( editorStore ).isSavingPost(),
		[]
	);
	const [ lastSaveState, setLastSaveState ] = useState( false );

	// Load page styles from post meta (section 7.1 - Editor Store Access)
	const [ pageStyles, setPageStyles ] = useState( {} );

	useEffect( () => {
		const loadPageStyles = () => {
			// Direct access from Gutenberg store (instant, no HTTP overhead)
			const meta = wp.data.select( 'core/editor' )?.getEditedPostAttribute( 'meta' );
			const styles = meta?._accordion_page_styles || {};

			console.log( '[PAGE STYLES] Loaded from editor store:', styles );
			setPageStyles( styles );
		};

		// Initial load
		loadPageStyles();

		// Subscribe to meta changes for reactivity
		const unsubscribe = wp.data.subscribe( () => {
			const currentMeta = wp.data.select( 'core/editor' )?.getEditedPostAttribute( 'meta' );
			const currentStyles = currentMeta?._accordion_page_styles || {};

			// Only update if actually changed (prevent infinite loops)
			if ( JSON.stringify( currentStyles ) !== JSON.stringify( pageStyles ) ) {
				console.log( '[PAGE STYLES] Meta changed, reloading...' );
				setPageStyles( currentStyles );
			}
		} );

		return unsubscribe; // Cleanup subscription on unmount
	}, [] ); // Empty deps - run once on mount

	// Use custom hooks for state management
	const {
		themes: allThemes,
		currentTheme,
		isLoading: isLoadingThemes,
		isSaving: isSavingTheme,
		isDeleting: isDeletingTheme,
		error: themeError,
		setError: setThemeError,
		loadThemes,
		createTheme,
		updateTheme,
		deleteTheme,
	} = useThemeManagement( 'accordion', {
		attributeConfig: ACCORDION_ATTRIBUTE_CONFIG,
		currentThemeId: attributes.themeId || attributes.selectedTheme,
		onThemeChange: ( themeId ) => {
			setAttributes( {
				themeId,
				selectedTheme: themeId,
				baseTheme: themeId,
			} );
		},
	} );

	// Use customization state hook for detection and clearing
	const {
		hasCustomizations,
		customizedAttributes,
		clearCustomizations,
		clearSection,
		clearAttributes,
	} = useCustomizationState(
		attributes,
		currentTheme,
		ACCORDION_ATTRIBUTE_CONFIG,
		setAttributes
	);

	// Get all effective values using shared hook with 4-tier cascade
	// Per section 3.2 of spec
	const effectiveValuesFromHook = useEffectiveValues(
		attributes,
		allThemes,
		pageStyles,
		ACCORDION_ATTRIBUTE_CONFIG
	);

	// Map to legacy naming for backward compatibility during refactor
	const defaultTheme = allThemes?.default || null;
	const getEffectiveValue = ( attrName ) => effectiveValuesFromHook[ attrName ];

	// Wrapper functions for legacy inspector panel compatibility
	const [ saveNotification, setSaveNotification ] = useState( null );

	const handleDeleteTheme = useCallback(
		async ( themeId ) => {
			try {
				await deleteTheme( themeId );
				setSaveNotification( { type: 'success', message: 'Theme deleted successfully' } );
				return true;
			} catch ( error ) {
				setSaveNotification( { type: 'error', message: error.message } );
				return false;
			}
		},
		[ deleteTheme ]
	);

	// Use accordion state hook
	const {
		customizationCache,
		setCustomizationCache,
		enableDividerBorder,
		setEnableDividerBorder,
	} = useAccordionState( attributes, allThemes, getEffectiveValue );

	// Use centralized theme handlers hook
	const {
		handleSaveTheme,
		handleRenameTheme,
		handleCreateTheme,
		switchToCleanTheme,
		handleThemeChange,
	} = useThemeHandlers( 'accordion', {
		attributes,
		setAttributes,
		allThemes,
		customizationCache,
		setCustomizationCache,
		customizationAttributes: ACCORDION_CUSTOMIZATION_ATTRIBUTES,
		attributeConfig: ACCORDION_ATTRIBUTE_CONFIG,
		clearCustomizations,
		createTheme,
		updateTheme,
		setSaveNotification,
		clientId,
	} );

	// Listen for theme updates from other accordion blocks
	// NOTE: The shared useThemeManagement hook handles theme syncing internally,
	// but we keep this for additional customization clearing logic
	useEffect( () => {
		const handleThemeUpdate = ( event ) => {
			console.log('[EVENT LISTENER] accordionThemeUpdated event received:', event.detail);
			const { themeId, themes, operation, sourceBlockId } = event.detail;
			console.log('[EVENT LISTENER] Event details:', {
				themeId,
				operation,
				sourceBlockId,
				currentClientId: clientId,
				currentSelectedTheme: selectedTheme,
				currentBaseTheme: baseTheme,
				currentHeaderBg: attributes.headerBackgroundColor,
			});

			if ( themes ) {
				// IMPORTANT: Only clear customizations for "update" operations
				// For "create" operations, handleCreateTheme already handles the full state transition
				// Calling switchToCleanTheme here would cause a race condition where we clear customizations
				// using the wrong theme context (old theme instead of new theme)
				if ( operation === 'create' ) {
					console.log('[EVENT LISTENER] Skipping switchToCleanTheme for CREATE operation');
					return; // Skip - handleCreateTheme handles everything for create
				}

				// CRITICAL FIX: Don't clear customizations for the block that triggered the update
				// The handleSaveTheme function already cleared them. Doing it again causes a race condition
				// where the server has saved the correct values but we clear them before the UI updates
				if ( sourceBlockId === clientId ) {
					console.log('[EVENT LISTENER] Skipping switchToCleanTheme - this block triggered the update');
					return;
				}

				// When a theme is UPDATED (not created), ALL OTHER accordions using that theme should
				// immediately switch to the clean theme (clear customizations)
				// This applies whether the accordion is in customized mode or not,
				// because the theme in the database has been updated with new settings

				// Check if this accordion is using the updated theme
				const isUsingThisTheme =
					selectedTheme === themeId || baseTheme === themeId;
				console.log('[EVENT LISTENER] Is using this theme?', isUsingThisTheme);

				if ( isUsingThisTheme ) {
					// Clear customizations and switch to clean theme
					// This ensures the accordion immediately reflects the updated theme
					console.log('[EVENT LISTENER] Calling switchToCleanTheme for UPDATE operation');
					switchToCleanTheme( themeId );
				}
			}
		};

		window.addEventListener( 'accordionThemeUpdated', handleThemeUpdate );

		return () => {
			window.removeEventListener( 'accordionThemeUpdated', handleThemeUpdate );
		};
	}, [ selectedTheme, baseTheme, switchToCleanTheme, attributes.headerBackgroundColor, clientId ] );

	// Generate unique ID if not already set
	useEffect( () => {
		if ( ! accordionId ) {
			// Generate 4-character random slug
			const randomSlug = Math.random().toString( 36 ).substring( 2, 6 );
			setAttributes( { accordionId: `accordion-${ randomSlug }` } );
		}
	}, [ accordionId, clientId, setAttributes ] );

	// Auto-detect customizations: Update isCustomized flag based on actual differences
	// Uses centralized detection logic from shared hooks
	useEffect( () => {
		// Skip if themes are still loading
		if ( isLoadingThemes || ! allThemes || Object.keys( allThemes ).length === 0 ) {
			return;
		}

		const themeToCompare = baseTheme || selectedTheme || 'default';
		const themeData = allThemes[ themeToCompare ];

		// If theme doesn't exist, don't run detection - let safety check handle it
		if ( ! themeData ) {
			return;
		}

		// Use centralized detection from shared hooks to check if ANY attribute is customized
		const actuallyHasCustomizations = hasCustomizations;

		// Sync isCustomized attribute with actual customization state
		if ( actuallyHasCustomizations && ! isCustomized ) {
			// Has customizations but not marked - mark it
			setAttributes( {
				isCustomized: true,
				baseTheme: themeToCompare,
			} );
		} else if ( ! actuallyHasCustomizations && isCustomized ) {
			// No customizations but marked as customized - clear the flag
			setAttributes( {
				isCustomized: false,
				baseTheme: themeToCompare,
			} );
		}
	}, [ allThemes, isLoadingThemes, isCustomized, selectedTheme, baseTheme, hasCustomizations, setAttributes ] );

	// Show notification with auto-hide
	useEffect( () => {
		if ( saveNotification?.message ) {
			const timer = setTimeout( () => {
				setSaveNotification( { message: null, panel: null } );
			}, UI_CONSTANTS.NOTIFICATION_TIMEOUT );
			return () => clearTimeout( timer );
		}
	}, [ saveNotification ] );

	// Warning when saving post with cached customizations
	useEffect( () => {
		// Detect transition from not-saving to saving
		if ( isSavingPost && ! lastSaveState ) {
			// Check if we have cached customizations
			const hasCachedCustomizations =
				Object.keys( customizationCache ).length > 0;

			if ( hasCachedCustomizations && ! isCustomized ) {
				// User is saving with base theme selected while cache has customizations
				const cachedThemes = Object.keys( customizationCache )
					.map(
						( themeId ) =>
							allThemes[ themeId ]?.theme_name || themeId
					)
					.join( ', ' );

				createWarningNotice(
					__(
						`⚠️ You have unsaved accordion customizations in cache for: ${ cachedThemes }. These will be lost when you save. Switch back to customized themes to preserve them.`,
						'guten-nav-plugin'
					),
					{
						isDismissible: true,
						type: 'warning',
					}
				);
			}
		}
		setLastSaveState( isSavingPost );
	}, [
		isSavingPost,
		customizationCache,
		isCustomized,
		allThemes,
		createWarningNotice,
		lastSaveState,
	] );

	// Safety check: if selected theme or base theme doesn't exist, fallback to default
	useEffect( () => {
		// Skip safety check while saving/creating themes to avoid race condition
		// (theme gets created but allThemes hasn't updated yet)
		if ( ! isLoadingThemes && ! isSavingTheme && Object.keys( allThemes ).length > 0 ) {
			let needsUpdate = false;
			const updates = {};

			// Check if selected theme exists
			if ( selectedTheme && ! allThemes[ selectedTheme ] ) {
				console.warn(
					`Accordion: Selected theme "${ selectedTheme }" not found. Falling back to default.`
				);
				updates.selectedTheme = 'default';
				updates.baseTheme = 'default';
				updates.isCustomized = false;

				// Clear all customization attributes when theme is deleted
				ACCORDION_CUSTOMIZATION_ATTRIBUTES.forEach( ( attr ) => {
					updates[ attr ] = getAttributeDefaultValue( attr, ACCORDION_ATTRIBUTE_CONFIG );
				} );

				needsUpdate = true;
			}

			// Check if base theme exists (when customized)
			if ( isCustomized && baseTheme && ! allThemes[ baseTheme ] ) {
				console.warn(
					`Accordion: Base theme "${ baseTheme }" not found. Falling back to selected or default theme.`
				);
				const fallbackTheme = allThemes[ selectedTheme ] ? selectedTheme : 'default';
				updates.selectedTheme = fallbackTheme;
				updates.baseTheme = fallbackTheme;
				updates.isCustomized = false;

				// Clear all customization attributes when base theme is deleted
				ACCORDION_CUSTOMIZATION_ATTRIBUTES.forEach( ( attr ) => {
					updates[ attr ] = getAttributeDefaultValue( attr, ACCORDION_ATTRIBUTE_CONFIG );
				} );

				needsUpdate = true;
			}

			if ( needsUpdate ) {
				setAttributes( updates );
			}
		}
	}, [ allThemes, selectedTheme, baseTheme, isCustomized, isLoadingThemes, isSavingTheme ] );

	// DEBUG: Monitor useHeading attribute changes
	useEffect(() => {
		console.log('[EDIT.JS useEffect] useHeading value changed to:', useHeading);
		console.log('[EDIT.JS useEffect] Type of useHeading:', typeof useHeading);
		console.log('[EDIT.JS useEffect] Full attributes object:', attributes);
	}, [useHeading]);

	// Enforce mutual exclusivity: useHeadingStyles and useCustomTitleFormatting cannot both be ON
	useEffect( () => {
		if ( useHeadingStyles && useCustomTitleFormatting ) {
			// Both are ON - this is invalid state
			// Priority: useCustomTitleFormatting wins (disable WordPress heading styles)
			console.warn(
				'Accordion: Both useHeadingStyles and useCustomTitleFormatting are enabled. Disabling useHeadingStyles to enforce mutual exclusivity.'
			);
			setAttributes( { useHeadingStyles: false } );
		}
	}, [ useHeadingStyles, useCustomTitleFormatting, setAttributes ] );

	// Clear custom title formatting attributes when toggle is OFF
	// This ensures old values don't leak through if user disables the toggle
	useEffect( () => {
		if ( ! useCustomTitleFormatting ) {
			const childAttrs = ACCORDION_ATTRIBUTE_CONFIG.useCustomTitleFormatting.childAttributes || [];
			const updates = {};
			let needsClearing = false;

			// Check if any child attributes are still set (non-null)
			childAttrs.forEach( ( attr ) => {
				if ( attributes[ attr ] !== null && attributes[ attr ] !== undefined ) {
					updates[ attr ] = null;
					needsClearing = true;
				}
			} );

			if ( needsClearing ) {
				setAttributes( updates );
			}
		}
	}, [ useCustomTitleFormatting, attributes, setAttributes ] );

	// Collect all effective values (customizations + theme values) for saving to theme
	// Per section 5.1 of ACCORDION-THEME-SYSTEM-V2-SPEC.md
	const collectEffectiveSettings = useCallback( () => {
		console.log('[COLLECT] Gathering effective settings for theme save...');

		const settings = {};

		// Loop through all customization attributes
		// Use effectiveValuesFromHook which already includes 4-tier cascade resolution
		ACCORDION_CUSTOMIZATION_ATTRIBUTES.forEach( ( attr ) => {
			const effectiveValue = effectiveValuesFromHook[ attr ];

			// Include ALL values (themes are complete snapshots)
			if ( effectiveValue !== null && effectiveValue !== undefined ) {
				settings[ attr ] = effectiveValue;
			}
		} );

		console.log(`[COLLECT] Collected ${Object.keys(settings).length} attributes:`, settings);
		return settings;
	}, [ effectiveValuesFromHook ] );

	/**
	 * DEPRECATED: markAsCustomized function is no longer needed
	 * Customization detection now happens automatically via useEffect + useCustomizationState hook
	 * Kept as no-op for backward compatibility with inspector panels
	 */
	const markAsCustomized = useCallback( () => {
		// No-op: Detection happens automatically in useEffect
	}, [] );

	// Get effective values using shared hook (replaces 82-line useMemo)
	const effectiveValues = useMemo( () => {
		const values = {
			headerBg: effectiveValuesFromHook.headerBackgroundColor,
			headerText: effectiveValuesFromHook.headerTextColor,
			headerHover: effectiveValuesFromHook.headerHoverColor,
			contentBg: contentBackgroundTransparent
				? 'transparent'
				: effectiveValuesFromHook.contentBackgroundColor,
			borderColor: effectiveValuesFromHook.borderColor,
			borderWidth: effectiveValuesFromHook.borderWidth,
			borderStyle: effectiveValuesFromHook.borderStyle || 'solid',
			animationSpeed: effectiveValuesFromHook.animationSpeed || 'normal',
			showIcon: effectiveValuesFromHook.showIcon !== false,
			icon: effectiveValuesFromHook.icon,
			iconType: effectiveValuesFromHook.iconType || 'character',
			iconPosition: effectiveValuesFromHook.iconPosition || 'left',
			animateIcon: effectiveValuesFromHook.animateIcon !== false,
			borderRadiusTL: effectiveValuesFromHook.borderRadiusTopLeft || 0,
			borderRadiusTR: effectiveValuesFromHook.borderRadiusTopRight || 0,
			borderRadiusBL: effectiveValuesFromHook.borderRadiusBottomLeft || 0,
			borderRadiusBR: effectiveValuesFromHook.borderRadiusBottomRight || 0,
			dividerBorderColor: effectiveValuesFromHook.dividerBorderColor,
			dividerBorderWidth: effectiveValuesFromHook.dividerBorderWidth,
			dividerBorderStyle: effectiveValuesFromHook.dividerBorderStyle,
		};
		return values;
	}, [ effectiveValuesFromHook, contentBackgroundTransparent ] );

	// Check if any border radius values are non-zero
	const hasBorderRadiusValue = hasBorderRadius(
		effectiveValues.borderRadiusTL,
		effectiveValues.borderRadiusTR,
		effectiveValues.borderRadiusBL,
		effectiveValues.borderRadiusBR
	);

	// Memoize editor styles for performance
	const editorStyles = useMemo( () => {
		const styles = {};

		if ( effectiveValues.headerBg ) {
			styles[ '--header-bg-color' ] = effectiveValues.headerBg;
		}
		if ( effectiveValues.headerText ) {
			styles[ '--header-text-color' ] = effectiveValues.headerText;
		}
		if ( effectiveValues.headerHover ) {
			styles[ '--header-hover-color' ] = effectiveValues.headerHover;
		}
		if ( effectiveValues.contentBg ) {
			styles[ '--content-bg-color' ] = effectiveValues.contentBg;
		}
		if ( effectiveValues.borderColor ) {
			styles[ '--border-color' ] = effectiveValues.borderColor;
		}
		if (
			effectiveValues.borderWidth !== null &&
			effectiveValues.borderWidth !== undefined
		) {
			styles.borderWidth = `${ effectiveValues.borderWidth }px`;
		}

		// Divider border - apply CSS variables if values exist
		if ( effectiveValues.dividerBorderColor ) {
			styles[ '--divider-border-color' ] =
				effectiveValues.dividerBorderColor;
		}
		if (
			effectiveValues.dividerBorderWidth !== null &&
			effectiveValues.dividerBorderWidth !== undefined
		) {
			styles[
				'--divider-border-width'
			] = `${ effectiveValues.dividerBorderWidth }px`;
		}
		if ( effectiveValues.dividerBorderStyle ) {
			styles[ '--divider-border-style' ] =
				effectiveValues.dividerBorderStyle;
		}

		// Border radius - apply CSS variables (same as frontend)
		if ( effectiveValues.borderRadiusTL !== null && effectiveValues.borderRadiusTL !== undefined ) {
			styles[ '--border-radius-top-left' ] = `${ effectiveValues.borderRadiusTL }px`;
		}
		if ( effectiveValues.borderRadiusTR !== null && effectiveValues.borderRadiusTR !== undefined ) {
			styles[ '--border-radius-top-right' ] = `${ effectiveValues.borderRadiusTR }px`;
		}
		if ( effectiveValues.borderRadiusBR !== null && effectiveValues.borderRadiusBR !== undefined ) {
			styles[ '--border-radius-bottom-right' ] = `${ effectiveValues.borderRadiusBR }px`;
		}
		if ( effectiveValues.borderRadiusBL !== null && effectiveValues.borderRadiusBL !== undefined ) {
			styles[ '--border-radius-bottom-left' ] = `${ effectiveValues.borderRadiusBL }px`;
		}

		return styles;
	}, [ effectiveValues, hasBorderRadiusValue ] );

	// Merge editor styles with alignment and width
	const combinedStyles = useMemo( () => {
		const styles = { ...editorStyles };

		// Add width
		if ( width ) {
			styles.width = width;
		}

		// Add horizontal alignment margins using shared utility
		const alignmentMargins = getAlignmentMargins( horizontalAlign );
		Object.assign( styles, alignmentMargins );

		return Object.keys( styles ).length > 0 ? styles : undefined;
	}, [ editorStyles, width, horizontalAlign ] );

	const blockProps = useBlockProps( {
		className: `accordion-block-editor animation-${
			effectiveValues.animationSpeed
		} is-open${
			effectiveValues.animateIcon ? ' animate-icon' : ''
		}`,
		style: combinedStyles,
	} );

	// CRITICAL: Don't render UI until themes are loaded
	// Without this, effectiveValues resolves to undefined because allThemes is empty
	if ( isLoadingThemes || ! allThemes || Object.keys( allThemes ).length === 0 ) {
		return (
			<div { ...blockProps }>
				<div style={ { padding: '20px', textAlign: 'center', color: '#666' } }>
					{ __( 'Loading accordion themes...', 'guten-nav-plugin' ) }
				</div>
			</div>
		);
	}

	return (
		<ErrorBoundary blockName="Accordion">
			<BlockControls>
				<ToolbarGroup>
					<ToolbarButton
						icon={ disabled ? 'hidden' : 'visibility' }
						label={ __( 'Toggle Visibility', 'guten-nav-plugin' ) }
						isPressed={ disabled }
						onClick={ () =>
							setAttributes( { disabled: ! disabled } )
						}
						aria-label={
							disabled
								? __(
										'Enable accordion visibility',
										'guten-nav-plugin'
								  )
								: __(
										'Disable accordion visibility',
										'guten-nav-plugin'
								  )
						}
					/>
					<ToolbarButton
						icon={ page }
						label={ __(
							'Open by Default (Frontend)',
							'guten-nav-plugin'
						) }
						isPressed={ isOpen }
						onClick={ () => setAttributes( { isOpen: ! isOpen } ) }
						aria-label={
							isOpen
								? __(
										'Set accordion to closed by default on frontend',
										'guten-nav-plugin'
								  )
								: __(
										'Set accordion to open by default on frontend',
										'guten-nav-plugin'
								  )
						}
					/>
					<Dropdown
						className="guten-nav-toolbar-accordion"
						contentClassName="guten-nav-toolbar-popover"
						position="bottom center"
						renderToggle={ ( {
							isOpen: isAccordionOpen,
							onToggle,
						} ) => (
							<ToolbarButton
								icon={ settings }
								label={ __(
									'Quick Settings',
									'guten-nav-plugin'
								) }
								onClick={ onToggle }
								aria-expanded={ isAccordionOpen }
								aria-label={ __(
									'Open quick settings panel',
									'guten-nav-plugin'
								) }
								aria-controls="accordion-quick-settings-panel"
							/>
						) }
						renderContent={ () => (
							<div
								id="accordion-quick-settings-panel"
								style={ { padding: '16px', minWidth: '260px' } }
							>
								<VStack spacing={ 3 }>
									<TextControl
										label={ __(
											'Accordion Title',
											'guten-nav-plugin'
										) }
										value={ title }
										onChange={ ( value ) =>
											setAttributes( { title: value } )
										}
									/>
									<ThemeSelector
										allThemes={ allThemes }
										customizationCache={
											customizationCache
										}
										selectedTheme={ selectedTheme }
										baseTheme={ baseTheme }
										isCustomized={ isCustomized }
										isLoading={ isLoadingThemes }
										onChange={ handleThemeChange }
									/>
									<SelectControl
										label={ __(
											'Horizontal Alignment',
											'guten-nav-plugin'
										) }
										value={ horizontalAlign }
										options={ HORIZONTAL_ALIGN_OPTIONS.map(
											( opt ) => ( {
												label: __(
													opt.label,
													'guten-nav-plugin'
												),
												value: opt.value,
											} )
										) }
										onChange={ ( value ) =>
											setAttributes( {
												horizontalAlign: value,
											} )
										}
									/>
								</VStack>
							</div>
						) }
					/>
				</ToolbarGroup>
			</BlockControls>

			<InspectorControls>
				<SettingsPanel
					attributes={ attributes }
					setAttributes={ setAttributes }
					allThemes={ allThemes }
					customizationCache={ customizationCache }
					isLoadingThemes={ isLoadingThemes }
					handleThemeChange={ handleThemeChange }
					isCustomized={ isCustomized }
					selectedTheme={ selectedTheme }
					isSavingTheme={ isSavingTheme }
					isDeletingTheme={ isDeletingTheme }
					collectEffectiveSettings={ collectEffectiveSettings }
					handleSaveTheme={ handleSaveTheme }
					handleCreateTheme={ handleCreateTheme }
					handleRenameTheme={ handleRenameTheme }
					handleDeleteTheme={ handleDeleteTheme }
					setSaveNotification={ setSaveNotification }
					switchToCleanTheme={ switchToCleanTheme }
				/>

				<AppearancePanel
					attributes={ attributes }
					setAttributes={ setAttributes }
					getEffectiveValue={ getEffectiveValue }
					markAsCustomized={ markAsCustomized }
					currentTheme={ currentTheme }
					defaultTheme={ defaultTheme }
				/>

				<TitlePanel
					attributes={ attributes }
					setAttributes={ setAttributes }
					sidebarValues={ effectiveValuesFromHook }
					markAsCustomized={ markAsCustomized }
				/>

				<BorderPanel
					attributes={ attributes }
					setAttributes={ setAttributes }
					getEffectiveValue={ getEffectiveValue }
					markAsCustomized={ markAsCustomized }
					enableDividerBorder={ enableDividerBorder }
					setEnableDividerBorder={ setEnableDividerBorder }
					currentTheme={ currentTheme }
					defaultTheme={ defaultTheme }
				/>

				<BorderRadiusPanel
					attributes={ attributes }
					setAttributes={ setAttributes }
					getEffectiveValue={ getEffectiveValue }
					markAsCustomized={ markAsCustomized }
					currentTheme={ currentTheme }
					defaultTheme={ defaultTheme }
				/>

				<AnimationPanel
					attributes={ attributes }
					setAttributes={ setAttributes }
					sidebarValues={ effectiveValuesFromHook }
					markAsCustomized={ markAsCustomized }
				/>

				<IconPanel
					attributes={ attributes }
					setAttributes={ setAttributes }
					sidebarValues={ effectiveValuesFromHook }
					markAsCustomized={ markAsCustomized }
				/>

				<PanelBody
					title={ __( '📖 Instructions', 'guten-nav-plugin' ) }
					initialOpen={ false }
				>
					{ isLoadingThemes ? (
						<div
							style={ {
								padding: '12px',
								textAlign: 'center',
								color: '#666',
							} }
						>
							{ __( 'Loading…', 'guten-nav-plugin' ) }
						</div>
					) : (
						<div className="accordion-help-box">
							<strong>
								{ __(
									'Understanding Customizations vs. Themes:',
									'guten-nav-plugin'
								) }
							</strong>
							<ul>
								<li>
									<strong>
										{ __(
											'Per-Accordion Customizations:',
											'guten-nav-plugin'
										) }
									</strong>{ ' ' }
									{ __(
										'Ideal for small tweaks to individual accordions (e.g., highlight one accordion with a different color)',
										'guten-nav-plugin'
									) }
								</li>
								<li>
									<strong>
										{ __(
											'Themes:',
											'guten-nav-plugin'
										) }
									</strong>{ ' ' }
									{ __(
										'Best for major modifications you want to apply across multiple accordions site-wide',
										'guten-nav-plugin'
									) }
								</li>
							</ul>
							<strong>
								{ __(
									'How Per-Accordion Customization Works:',
									'guten-nav-plugin'
								) }
							</strong>
							<ul>
								<li>
									{ __(
										'When you customize a theme, it becomes "[Theme Name] (custom)" in the dropdown',
										'guten-nav-plugin'
									) }
								</li>
								<li>
									{ __(
										'You can click the base theme to compare - your customizations are kept in memory',
										'guten-nav-plugin'
									) }
								</li>
								<li>
									{ __(
										'Click back to "[Theme Name] (custom)" to restore your changes',
										'guten-nav-plugin'
									) }
								</li>
								<li>
									{ __(
										'Customizations are saved with this specific accordion when you save/update the post',
										'guten-nav-plugin'
									) }
								</li>
								<li>
									<strong style={ { color: '#d63638' } }>
										{ __(
											'⚠️ Warning: Saving the post with base theme selected will discard cached customizations!',
											'guten-nav-plugin'
										) }
									</strong>
								</li>
							</ul>
							<strong>
								{ __(
									'When to Create/Update Themes:',
									'guten-nav-plugin'
								) }
							</strong>
							<ul style={ { marginBottom: '0' } }>
								<li>
									{ __(
										'Use "Update theme" when you want to apply changes globally to all accordions using this theme',
										'guten-nav-plugin'
									) }
								</li>
								<li>
									{ __(
										'Use "Save as new theme" to create a reusable theme for future accordions across your site',
										'guten-nav-plugin'
									) }
								</li>
								<li>
									{ __(
										'Themes are ideal for consistent styling across multiple pages and posts',
										'guten-nav-plugin'
									) }
								</li>
							</ul>
						</div>
					) }
				</PanelBody>
			</InspectorControls>

			<div { ...blockProps }>
				{ disabled && (
					<div
						style={ {
							padding: '8px 12px',
							backgroundColor: '#f0f0f0',
							border: '2px dashed #999',
							borderRadius: '4px',
							marginBottom: '8px',
							textAlign: 'center',
							color: '#666',
							fontSize: '12px',
							fontWeight: 'bold',
						} }
					>
						{ __(
							'This accordion is DISABLED and will not be visible on the frontend',
							'guten-nav-plugin'
						) }
					</div>
				) }
				{ /* In editor, we don't wrap with heading tag to allow easy editing */ }
				{ /* The heading wrapper is only applied in save.js for proper frontend semantics */ }
				<div
					className={ `accordion-toggle accordion-toggle-editor icon-${ effectiveValues.iconPosition }${ useHeading ? ' has-heading' : '' }` }
					role="button"
					tabIndex={ 0 }
					aria-expanded={ true }
					aria-controls={
						accordionId ? `${ accordionId }-content` : undefined
					}
					aria-label={
						title || __( 'Accordion toggle', 'guten-nav-plugin' )
					}
					style={ {
						backgroundColor: effectiveValues.headerBg,
						color: effectiveValues.headerText,
						borderTopColor: effectiveValues.borderColor,
						borderTopWidth: `${ effectiveValues.borderWidth }px`,
						borderTopStyle: effectiveValues.borderStyle,
						borderRightColor: effectiveValues.borderColor,
						borderRightWidth: `${ effectiveValues.borderWidth }px`,
						borderRightStyle: effectiveValues.borderStyle,
						borderBottomWidth: '0',
						borderBottomStyle: 'none',
						borderLeftColor: effectiveValues.borderColor,
						borderLeftWidth: `${ effectiveValues.borderWidth }px`,
						borderLeftStyle: effectiveValues.borderStyle,
						borderTopLeftRadius: `var(--border-radius-top-left, 0)`,
						borderTopRightRadius: `var(--border-radius-top-right, 0)`,
						borderBottomLeftRadius: '0',
						borderBottomRightRadius: '0',
						padding: '12px 16px',
						display: 'flex',
						alignItems: 'center',
						gap: '8px',
						// Apply text-align if custom formatting is enabled
						...( useCustomTitleFormatting && ! useHeadingStyles && getEffectiveValue( 'titleTextAlign', 'titleTextAlign' ) ? {
							justifyContent: getEffectiveValue( 'titleTextAlign', 'titleTextAlign' ) === 'left' ? 'flex-start' :
											getEffectiveValue( 'titleTextAlign', 'titleTextAlign' ) === 'center' ? 'center' :
											getEffectiveValue( 'titleTextAlign', 'titleTextAlign' ) === 'right' ? 'flex-end' : 'flex-start',
						} : {} ),
					} }
				>
					{ effectiveValues.iconPosition !== 'right' &&
						effectiveValues.iconPosition !== 'extreme-right' && (
							<AccordionIcon
								showIcon={ effectiveValues.showIcon }
								iconType={ effectiveValues.iconType }
								icon={ effectiveValues.icon }
								animateIcon={ effectiveValues.animateIcon }
							/>
						) }
					<RichText
						tagName="span"
						className="accordion-title"
						value={ title }
						onChange={ ( value ) =>
							setAttributes( { title: value } )
						}
						onFocus={ () => {
							if ( title === 'Accordion title' ) {
								setAttributes( { title: '' } );
							}
						} }
						placeholder={ __(
							'Click here to edit title…',
							'guten-nav-plugin'
						) }
						allowedFormats={ [] }
						style={ {
							flex:
								effectiveValues.iconPosition === 'extreme-right'
									? '1'
									: 'initial',
							// Apply custom title formatting if enabled and not using heading styles
							...( useCustomTitleFormatting && ! useHeadingStyles ? {
								textAlign: getEffectiveValue( 'titleTextAlign', 'titleTextAlign' ) || undefined,
								fontSize: getEffectiveValue( 'titleFontSize', 'titleFontSize' ) || undefined,
								fontWeight: getEffectiveValue( 'titleFontWeight', 'titleFontWeight' ) || undefined,
								fontStyle: getEffectiveValue( 'titleFontStyle', 'titleFontStyle' ) || undefined,
								textTransform: getEffectiveValue( 'titleTextTransform', 'titleTextTransform' ) || undefined,
								letterSpacing: getEffectiveValue( 'titleLetterSpacing', 'titleLetterSpacing' ) || undefined,
								wordSpacing: getEffectiveValue( 'titleWordSpacing', 'titleWordSpacing' ) || undefined,
								textDecoration: getEffectiveValue( 'titleTextDecoration', 'titleTextDecoration' ) || undefined,
								fontFamily: getEffectiveValue( 'titleFontFamily', 'titleFontFamily' ) || undefined,
							} : {} ),
						} }
					/>
					{ ( effectiveValues.iconPosition === 'right' ||
						effectiveValues.iconPosition === 'extreme-right' ) && (
						<AccordionIcon
							showIcon={ effectiveValues.showIcon }
							iconType={ effectiveValues.iconType }
							icon={ effectiveValues.icon }
							animateIcon={ effectiveValues.animateIcon }
						/>
					) }
				</div>
				<div
					id={ accordionId ? `${ accordionId }-content` : undefined }
					className="accordion-content open"
					role="region"
					aria-labelledby={ accordionId }
					style={ ( () => {
						const calculatedTopWidth =
							effectiveValues.dividerBorderWidth !== null &&
							effectiveValues.dividerBorderWidth !== undefined
								? `${ effectiveValues.dividerBorderWidth }px`
								: effectiveValues.borderWidth
								? `${ Math.max(
										1,
										Math.floor(
											effectiveValues.borderWidth / 2
										)
								  ) }px`
								: '1px';
						const calculatedTopStyle =
							effectiveValues.dividerBorderStyle ||
							effectiveValues.borderStyle ||
							'solid';
						const calculatedTopColor =
							effectiveValues.dividerBorderColor ||
							effectiveValues.borderColor ||
							'#e0e0e0';

						return {
							display: 'block',
							backgroundColor: contentBackgroundTransparent
								? 'transparent'
								: effectiveValues.contentBg,
							// Use individual border properties instead of shorthand to avoid override issues
							borderTopWidth: calculatedTopWidth,
							borderTopStyle: calculatedTopStyle,
							borderTopColor: calculatedTopColor,
							borderRightWidth: `${ effectiveValues.borderWidth }px`,
							borderRightStyle: effectiveValues.borderStyle,
							borderRightColor: effectiveValues.borderColor,
							borderBottomWidth: `${ effectiveValues.borderWidth }px`,
							borderBottomStyle: effectiveValues.borderStyle,
							borderBottomColor: effectiveValues.borderColor,
							borderLeftWidth: `${ effectiveValues.borderWidth }px`,
							borderLeftStyle: effectiveValues.borderStyle,
							borderLeftColor: effectiveValues.borderColor,
							borderBottomLeftRadius: `var(--border-radius-bottom-left, 0)`,
							borderBottomRightRadius: `var(--border-radius-bottom-right, 0)`,
							padding: '16px',
						};
					} )() }
				>
					<InnerBlocks
						templateLock={ false }
						placeholder={ __(
							'Add content to this accordion section…',
							'guten-nav-plugin'
						) }
					/>
				</div>
			</div>
		</ErrorBoundary>
	);
};

export default Edit;
