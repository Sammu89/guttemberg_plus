const defaultConfig = require( '@wordpress/scripts/config/webpack.config' );
const path = require( 'path' );

module.exports = {
	...defaultConfig,
	entry: {
		'tabs/index': './blocks/tabs/index.js',
		'tab-panel/index': './blocks/tab-panel/index.js',
		'auto-menu/index': './blocks/auto-menu/index.js',
		'accordion/index': './blocks/accordion/index.js',
	},
	output: {
		...defaultConfig.output,
		path: path.resolve( __dirname, 'build' ),
		filename: '[name].js',
	},
};
