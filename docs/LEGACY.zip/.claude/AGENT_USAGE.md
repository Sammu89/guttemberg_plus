# Quick Agent Reference

## Documentation Agent

### Quick Invoke (Copy-Paste Template)

```
@documentation-agent

Files changed:
-
-
-

Structural changes: [yes/no]
Change description:
```

### Example 1: Simple File Updates
```
@documentation-agent

Files changed:
- blocks/accordion/index.js
- blocks/accordion/block.json

Structural changes: no
Change description: Added width control (10-100%) and disable functionality
```

### Example 2: New Feature with Structural Changes
```
@documentation-agent

Files changed:
- blocks/accordion/index.js
- blocks/accordion/block.json
- assets/css/accordion.css

Structural changes: yes
Change description: Complete rename from dropdown to accordion, updated all references
```

### Example 3: Multiple Files
```
@documentation-agent

Files changed:
- blocks/accordion/index.js
- blocks/accordion/block.json
- guten-nav-plugin.php
- webpack.config.js
- README.md

Structural changes: yes
Change description: Renamed dropdown block to accordion throughout entire project
```

## Common Scenarios

### After Feature Implementation
1. Complete your code changes
2. Copy the Quick Invoke template above
3. Fill in the changed files
4. Mark if architecture changed
5. Send to agent

### Before Committing
```
@documentation-agent verify-complete

Check these files have updated docs:
- blocks/accordion/index.js
- blocks/accordion/block.json
```

### Manual Documentation Update
If you prefer to do it manually, follow CLAUDE.md workflow:
1. `./scripts/check_docs.sh`
2. Update `.txt` files for changed source files
3. Update `architecture.md` Recent Changes section
4. Commit docs with code

## Agent vs Manual

| Aspect | Agent | Manual |
|--------|-------|--------|
| Speed | Fast | Slower |
| Accuracy | Good, review needed | High (you control) |
| Format | Consistent | Varies |
| Effort | Low | Higher |
| Best for | Routine updates | Complex changes |

**Recommendation:** Use agent for routine updates, manually review and adjust as needed.
