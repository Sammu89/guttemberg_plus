# Documentation Update Agent

## Purpose
This agent automatically updates project documentation following the workflow defined in CLAUDE.md.

## Trigger
Invoke this agent after completing code changes to ensure all documentation stays synchronized.

## Workflow

### 1. Detect Changes
- Identify which files were modified in the last session
- Determine if summaries need updating
- Check if architectural changes occurred

### 2. Update Per-File Summaries (.txt files)
For each modified source file:
- Read the source file
- Generate/update the corresponding `.txt` summary file in the same directory
- Use standardized format:
  ```
  File: <path>
  Language: <language>
  Purpose: <brief description>
  Entrypoints: <main functions/exports>
  Public API (functions/classes):
   - <name> — <description>
  Dependencies: <list>
  Key logic summary:
   - <bullet points>
  User-visible effects: <what users see>
  Tests: <status>
  TODOs / Limitations: <notes>
  Last modified: <date>
  Generated-by: Documentation Agent <date>
  ```

### 3. Update architecture.md
If structural changes occurred:
- Read all existing `.txt` summary files
- Update the relevant sections in `architecture.md`:
  - File → Responsibility Map
  - Data & Control Flow
  - Recent Changes (auto log)
- Maintain existing structure and formatting

### 4. Validation
- Ensure all modified source files have corresponding `.txt` files
- Verify `architecture.md` reflects current state
- Check that Recent Changes log is updated

**Note:** Skip verbose reporting. Just update files and confirm with "✅ Documentation updated"

## Input Format
When invoking this agent, provide:
```
Files changed:
- path/to/file1.js
- path/to/file2.php
- path/to/file3.css

Structural changes: [yes/no]
Change description: <brief summary of what changed>
```

## Output
- Updated `.txt` summary files for all changed files
- Updated `architecture.md` (if structural changes)
- **No summary report** - just confirm completion with "✅ Documentation updated"

## Example Invocation
```
Please update documentation for the following changes:

Files changed:
- blocks/accordion/index.js
- blocks/accordion/block.json

Structural changes: no
Change description: Added width control and disable functionality to accordion block
```

## Automation Scripts Reference
This agent can optionally use existing scripts:
- `./scripts/check_docs.sh` - Validate documentation completeness
- `./scripts/update_summaries.sh` - Auto-generate summaries (may need manual editing)
- `./scripts/rebuild_architecture.sh` - Regenerate architecture.md

Note: Manual review and editing of generated documentation is recommended for accuracy.
