# PHP Security Agent

## Role
Handle PHP security improvements, validation, and critical fixes for theme management and color handling (Phase 0 & Phase 1.3).

## Responsibilities

### Phase 0: Critical Fixes
- **Theme Update Fix**: Make "Update theme with these settings" button update the current theme site-wide WITHOUT requiring POST save
  - Investigate current theme update mechanism
  - Implement immediate theme update via AJAX
  - Ensure changes apply globally across all accordion instances
  - Test theme updates without page refresh

- **Color Transparency Fix**: Ensure PHP color sanitization properly handles colors with transparency
  - Review current color sanitization logic
  - Add support for rgba() and hsla() color formats
  - Add support for 8-digit hex colors (#RRGGBBAA)
  - Validate alpha channel values (0-1 or 0-255)
  - Test with various transparent color formats

### Phase 1.3: PHP Security & Validation
- Add immediate sanitization in `save_accordion_theme()` (lines 405-409)
- Extract `get_allowed_border_styles()` method (duplicated at lines 593-595, 607-609)
- Wrap error logging in `WP_DEBUG` checks
- Add nonce verification before processing POST data
- Test theme save/update operations
- Ensure all user input is sanitized before database storage
- Add input validation for all theme properties

## Files to Modify
- `guten-nav-plugin.php` (primary file)
- Any related PHP files for theme management

## Security Checklist
- [ ] All POST data has nonce verification
- [ ] All user input is sanitized before DB storage
- [ ] All database queries use prepared statements
- [ ] Error messages don't expose sensitive information
- [ ] Debug logs only show when WP_DEBUG is enabled
- [ ] Border style validation uses whitelist approach
- [ ] Color validation handles all modern CSS formats

## Testing Requirements
- Test theme save/update operations
- Test with various color formats (hex, rgb, rgba, hsl, hsla)
- Test with transparent colors (alpha < 1)
- Test theme updates without saving POST
- Verify nonce validation prevents unauthorized access
- Test error scenarios (invalid input, failed DB operations)

## Dependencies
- None (can start immediately)

## Deliverables
- Immediate theme update functionality working
- Robust color transparency support
- Secure PHP code with proper validation
- All Phase 0 and Phase 1.3 TODO.md checkboxes completed

## Estimated Time
4-5 hours
