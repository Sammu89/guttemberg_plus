# Accordion Block Agent

## Purpose
This agent handles all improvements and maintenance for the Accordion block (sammu/accordion).

## Scope
- blocks/accordion/index.js (JavaScript/React)
- blocks/accordion/block.json (Block configuration)
- assets/css/accordion.css (Frontend styling)
- assets/js/accordion.js (Frontend functionality)
- guten-nav-plugin.php (PHP backend, only accordion-related code)

## Current Task List

### 1. Icon Validation & Enhancement
- Add icon validation when user inputs custom icon
- Add "Show Icon" toggle control (show/hide icon option)
- Implement 180-degree rotation animation when accordion opens (check if already coded)
- Add icon position control (left/right of header text)
- Default: left side, before header text (coded in accordion.css)
- Fix inconsistency: Editor and save use different icon logic

### 2. Color System Refinement
- Goal: Let global CSS control colors by default
- Logic should only apply inline styles when user explicitly changes a color
- This applies to both global settings and per-accordion settings
- Ensure null values = CSS controls the color
- Verify fallback colors match actual CSS defaults

### 3. Code Cleanup
- Remove @wordpress/api-fetch import (unused, using fetch API instead)
- Replace with native fetch API calls (already implemented)

### 4. Loading States for AJAX
- Add loading state to "Save Global Settings" button
- Add loading state to "Reset Global Settings" button
- Show spinner or disable button during request
- Provide clear feedback during async operations

### 5. Error Handling
- Add validation for malformed block data in PHP processing
- Add try/catch error handling in block rendering
- Graceful degradation when data is invalid

### 6. Load Existing Global Settings
- Add useEffect hook to component mount
- Call get_accordion_global_settings() AJAX endpoint on load
- Populate globalSettings state with existing saved settings
- This ensures UI shows current saved values on page load

## Workflow
1. Work on tasks sequentially (1 → 2 → 3 → 4 → 5 → 6)
2. Test each task before moving to next
3. Update code comments where needed
4. After ALL tasks complete, invoke @documentation-agent to update docs

## Files to Update
- blocks/accordion/index.js - Main JavaScript file
- blocks/accordion/block.json - Add new attributes (showIcon, iconPosition)
- assets/css/accordion.css - Icon positioning and rotation
- assets/js/accordion.js - Frontend icon rotation (if needed)
- guten-nav-plugin.php - Error handling in block processing

## Documentation Policy
- Do NOT update documentation files during task work
- After completing ALL tasks, invoke documentation-agent with:
  ```
  Files changed:
  - blocks/accordion/index.js
  - blocks/accordion/block.json
  - assets/css/accordion.css
  - assets/js/accordion.js
  - guten-nav-plugin.php

  Structural changes: no
  Change description: [summary of all changes made]
  ```

## Notes
- Global settings managed via Gutenberg sidebar (no dedicated admin page needed)
- CSS-as-source-of-truth pattern must be maintained
- All styling defaults to null, CSS provides actual values
- Inline styles only when user explicitly sets values
