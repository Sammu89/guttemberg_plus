# Constants & Utilities Agent

## Role
Extract constants, options, and utility functions from the accordion block to eliminate duplication and improve maintainability (Phase 1.1 & 1.2).

## Responsibilities

### Phase 1.1: Extract Constants and Options
- Create `blocks/accordion/constants.js`
- Extract and consolidate duplicated options:
  - `BORDER_STYLE_OPTIONS` (duplicated at lines 960-971, 1023-1034)
  - `HORIZONTAL_ALIGN_OPTIONS` (duplicated at lines 772-776, 804-808)
  - `HEADING_LEVEL_OPTIONS` (line 845-852)
  - `ANIMATION_SPEED_OPTIONS` (lines 1083-1089)
- Extract magic numbers to `UI_CONSTANTS`:
  - `COLOR_PICKER_SCALE: 0.8`
  - `COLOR_PICKER_MARGIN_OFFSET: '-40px'`
  - `NOTIFICATION_TIMEOUT: 3000`
  - `ANIMATION_SPEEDS: { FAST: '0.2s', NORMAL: '0.3s', SLOW: '0.5s' }`
- Update all references in `index.js` to use imported constants
- Test accordion functionality after changes

### Phase 1.2: Create Utilities Module

#### 1.2.1 Validation Utilities
- Create `blocks/accordion/utils/validation.js`
- Move `validateIcon()` function (duplicated at lines 681-684, 1598-1601)
- Create `isDefined()` helper for null/undefined checks
- Export all validation functions

#### 1.2.2 AJAX Utilities
- Create `blocks/accordion/utils/ajax.js`
- Create `sendAccordionAjax()` function to replace 6 duplicated patterns:
  - Lines 140-161 (load themes)
  - Lines 359-395 (save theme)
  - Lines 409-442 (delete theme)
  - Lines 459-489 (rename theme)
  - Lines 499-589 (update theme)
  - Lines 1243-1299 (create theme)
- Create `getAjaxConfig()` helper for URL/nonce access
- Add error handling to AJAX utility
- Update all AJAX calls in `index.js` to use new utility

#### 1.2.3 Style Utilities
- Create `blocks/accordion/utils/styleHelpers.js`
- Move `hasBorderRadius()` check (duplicated at lines 607-614, 1545-1555)
- Create `getBorderRadiusValue()` helper
- Export style utilities

## Files to Modify
- `blocks/accordion/index.js` (read and update)

## Files to Create
- `blocks/accordion/constants.js`
- `blocks/accordion/utils/validation.js`
- `blocks/accordion/utils/ajax.js`
- `blocks/accordion/utils/styleHelpers.js`

## Testing Requirements
- Test accordion functionality after each extraction
- Verify all imports resolve correctly
- Ensure no functionality is broken
- Test theme operations (load, save, delete, rename, update)

## Dependencies
- None (can start immediately)

## Deliverables
- `constants.js` with all shared constants
- Three utility files with comprehensive helpers
- Updated `index.js` with all references using imports
- All Phase 1.1 and 1.2 TODO.md checkboxes completed

## Estimated Time
5-7 hours
