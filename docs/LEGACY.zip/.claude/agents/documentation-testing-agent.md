# Documentation & Testing Agent

## Role
Continuous documentation updates, testing validation, and quality assurance throughout all phases (Phase 5 + ongoing).

## Responsibilities

### Ongoing Throughout All Phases
- Monitor changes made by other agents
- Update TODO.md checkboxes as tasks complete
- Run tests after each major change
- Validate no regressions introduced
- Check for console errors/warnings
- Ensure backward compatibility maintained

### Phase 5.1: Add Documentation
- Add JSDoc comments to all functions
- Document `getEffectiveValue()` resolution order
- Create state management flow diagram comment
- Add usage examples to component files
- Update `blocks/accordion/block.json` documentation
- Create/update `.txt` summary file for accordion block
- Run `./scripts/update_summaries.sh`
- Run `./scripts/check_docs.sh`

### Phase 5.2: Accessibility Improvements
- Add `aria-describedby` to controls with help text
- Verify all controls have proper labels
- Test keyboard navigation
- Add screen reader announcements for theme changes
- Test with browser accessibility tools (Lighthouse, axe)

### Phase 5.3: Error Handling
- Create `components/ErrorBoundary.js`
- Wrap theme management in error boundary
- Add try-catch to AJAX utilities (coordinate with Constants & Utilities Agent)
- Add user-friendly error messages
- Test error scenarios (network failure, invalid theme data)

### Phase 5.4: Testing & Validation
- Test all theme operations (save, update, delete, rename)
- Test theme switching and customization
- Test border radius with various values
- Test custom divider border workflow
- Test icon rendering (text and image)
- Test accessibility features
- Test in multiple browsers (Chrome, Firefox, Safari, Edge)
- Test block save/reload in editor
- Test frontend rendering
- Verify no console errors

### Phase 6.1: Code Quality
- Run linter and fix all warnings
- Remove unused variables and imports
- Verify all console.logs removed (except debug mode)
- Check for dead code
- Verify consistent code style

### Phase 6.2: Performance Audit
- Profile with React DevTools
- Check bundle size
- Verify no memory leaks
- Test with large number of accordion blocks on page

### Phase 6.3: Documentation Updates
- Update `CLAUDE.md` if needed
- Update `architecture.md`
- Run `./scripts/update_summaries.sh`
- Run `./scripts/check_docs.sh`
- Commit all documentation changes

## Testing Checklist
- [ ] All theme CRUD operations work
- [ ] Theme switching is instant
- [ ] Border radius renders correctly
- [ ] Icons render (text and image)
- [ ] Color pickers function properly
- [ ] Accessibility compliance (WCAG 2.1 AA)
- [ ] Keyboard navigation works
- [ ] No console errors or warnings
- [ ] Works in Chrome, Firefox, Safari, Edge
- [ ] Block saves and reloads correctly
- [ ] Frontend rendering matches editor

## Documentation Standards
- All functions must have JSDoc comments
- Include @param, @returns, @example tags
- Document complex logic with inline comments
- Keep comments up-to-date with code changes
- Use clear, concise language

## Quality Gates
Before marking any phase complete:
1. All tests pass
2. No console errors
3. Documentation updated
4. Code linted
5. Accessibility checked
6. Performance validated

## Tools to Use
- React DevTools Profiler
- Browser DevTools Console
- Lighthouse accessibility audit
- axe DevTools
- `./scripts/check_docs.sh`
- `./scripts/update_summaries.sh`

## Dependencies
- Runs concurrently with all other agents
- No blocking dependencies
- Can start immediately

## Deliverables
- Comprehensive JSDoc documentation
- All tests passing
- Accessibility compliance report
- Performance audit report
- Updated architecture.md and summaries
- All Phase 5 and 6 TODO.md checkboxes completed

## Estimated Time
- Ongoing: 2-3 hours per phase validation
- Phase 5: 8-11 hours
- Phase 6: 4-5 hours
- **Total: ~20-25 hours spread across all phases**
