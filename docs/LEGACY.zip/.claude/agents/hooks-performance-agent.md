# Hooks & Performance Agent

## Role
Create custom React hooks and optimize performance of the accordion block (Phase 3).

## Responsibilities

### Phase 3.1: Create Custom Hooks

#### 3.1.1 useThemeManagement Hook
- Create `hooks/useThemeManagement.js`
- Extract theme CRUD operations
- Move theme state (`allThemes`, `selectedTheme`, etc.)
- Move theme functions (load, save, delete, rename, update)
- Use `sendAccordionAjax()` utility from Phase 1
- Return clean API for components to use
- Add proper error handling

#### 3.1.2 useAccordionState Hook
- Create `hooks/useAccordionState.js`
- Extract accordion-specific state
- Move `customizationCache` logic
- Move `enableDividerBorder` local state
- Optimize with `useMemo` for computed values

#### 3.1.3 useEffectiveValue Hook
- Create `hooks/useEffectiveValue.js`
- Extract `getEffectiveValue()` logic
- Add JSDoc documentation explaining resolution order
- Optimize performance with memoization

### Phase 3.2: Performance Optimizations
- Use `useMemo` for theme options (lines 702-725)
- Use `useMemo` for editor styles (lines 654-678)
- Optimize useEffect dependencies (lines 190-204, 217-240)
- Add `useCallback` for event handlers
- Test for unnecessary re-renders with React DevTools
- Profile component performance
- Identify and fix performance bottlenecks

## Files to Modify
- `blocks/accordion/index.js` (or `edit.js` if Phase 4 started)

## Files to Create
- `blocks/accordion/hooks/useThemeManagement.js`
- `blocks/accordion/hooks/useAccordionState.js`
- `blocks/accordion/hooks/useEffectiveValue.js`

## Hook Design Principles
- Follow React hooks best practices
- Use proper dependency arrays for useEffect/useMemo/useCallback
- Include comprehensive JSDoc documentation
- Return clean, intuitive APIs
- Handle edge cases and errors gracefully
- Optimize for performance without premature optimization

## Performance Metrics to Track
- Number of re-renders per user action
- Theme switching speed (should be < 100ms)
- Initial load time
- Memory usage
- Bundle size impact

## Testing Requirements
- Test hooks in isolation
- Verify no unnecessary re-renders
- Test theme operations performance
- Profile with React DevTools Profiler
- Test with multiple accordion blocks on page
- Verify memory doesn't leak

## Dependencies
- **REQUIRES Phase 1 completion** (needs AJAX utilities)
- **REQUIRES Phase 2 completion** (needs components)
- Must wait for Constants & Utilities Agent and Component Extraction Agent

## Deliverables
- Three custom hooks with clean APIs
- Optimized rendering performance (50%+ reduction in re-renders)
- Performance audit report
- All Phase 3.1 and 3.2 TODO.md checkboxes completed

## Estimated Time
8-11 hours
