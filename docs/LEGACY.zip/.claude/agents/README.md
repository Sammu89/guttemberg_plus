# Claude Code Agents

This directory contains specialized agent configurations for common tasks in this project.

## Available Agents

### Documentation Agent (`documentation-agent.md`)
**Purpose:** Automatically updates all documentation files after code changes

**When to use:**
- After implementing new features
- After modifying existing functionality
- After refactoring code
- Before committing changes

**How to invoke:**
1. Complete your code changes
2. Trigger the Documentation Agent with context:
   ```
   @documentation-agent

   Files changed:
   - blocks/accordion/index.js
   - blocks/accordion/block.json

   Structural changes: no
   Change description: Added width and disable controls
   ```

3. Agent will:
   - Update `.txt` summary files for changed files
   - Update `architecture.md` if needed
   - Add entries to Recent Changes log
   - Validate documentation completeness

**Output:**
- All `.txt` files updated
- `architecture.md` updated (if applicable)
- Summary report

## Creating New Agents

To add a new specialized agent:

1. Create `<agent-name>.md` in this directory
2. Follow this template:
   ```markdown
   # Agent Name

   ## Purpose
   Brief description

   ## Trigger
   When to use this agent

   ## Workflow
   Step-by-step process

   ## Input Format
   What information the agent needs

   ## Output
   What the agent produces
   ```

3. Update this README with the new agent

## Best Practices

- **Invoke agents explicitly** - Don't automate unless specifically requested
- **Provide context** - Include file paths and change descriptions
- **Review output** - Always check agent-generated documentation
- **Keep agents focused** - One agent = one clear task
- **Follow CLAUDE.md** - All agents must respect project guidelines

## Integration with Workflow

These agents complement the manual workflow defined in `CLAUDE.md`:

```
Code Change → Documentation Agent → Review → Commit
```

The agent handles the tedious parts (file updates, formatting) while you focus on accuracy and completeness.
