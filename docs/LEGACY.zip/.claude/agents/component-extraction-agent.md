# Component Extraction Agent

## Role
Extract and create reusable React components from the monolithic accordion index.js file (Phase 2).

## Responsibilities

### Phase 2.1: Create Shared Components

#### 2.1.1 AccordionIcon Component
- Create `blocks/accordion/components/AccordionIcon.js`
- Consolidate icon rendering logic (lines 686-699, 1604-1622)
- Handle both editor and save modes
- Support image and text icons
- Test icon rendering in editor and frontend

#### 2.1.2 ColorPickerControl Component
- Create `blocks/accordion/components/ColorPickerControl.js`
- Enhance existing `renderColorPicker()` function
- Add fallback logic and `markAsCustomized()` integration
- Apply consistent styling (scale 0.8, centered)
- Replace all 7+ ColorPicker calls in `index.js`

#### 2.1.3 ThemeSelector Component
- Create `blocks/accordion/components/ThemeSelector.js`
- Consolidate theme dropdown (lines 764-768, 793-798)
- Add loading state handling
- Support both toolbar and inspector placements
- Update references in `index.js`

#### 2.1.4 ThemeListItem Component
- Create `blocks/accordion/components/ThemeListItem.js`
- Extract 66-line theme list rendering (lines 1316-1382)
- Support rename, delete, select actions
- Handle default theme restrictions
- Test theme management modal

### Phase 2.2: Extract Inspector Controls Panels

#### 2.2.1 Settings Panel
- Create `components/inspector/SettingsPanel.js`
- Extract theme selector, alignment, width, toggles
- Make always-visible (non-collapsible)

#### 2.2.2 Appearance Panel
- Create `components/inspector/AppearancePanel.js`
- Extract all color controls
- Use `ColorPickerControl` component

#### 2.2.3 Border Panel
- Create `components/inspector/BorderPanel.js`
- Extract main border controls
- Extract divider border controls
- Use `BORDER_STYLE_OPTIONS` constant

#### 2.2.4 Border Radius Panel
- Create `components/inspector/BorderRadiusPanel.js`
- Extract radius controls
- Group corner controls logically

#### 2.2.5 Icon Panel
- Create `components/inspector/IconPanel.js`
- Extract icon configuration controls
- Use `AccordionIcon` component for preview

#### 2.2.6 Animation Panel
- Create `components/inspector/AnimationPanel.js`
- Extract animation controls
- Use `ANIMATION_SPEED_OPTIONS` constant

## Files to Modify
- `blocks/accordion/index.js` (read and update)

## Files to Create
- `blocks/accordion/components/AccordionIcon.js`
- `blocks/accordion/components/ColorPickerControl.js`
- `blocks/accordion/components/ThemeSelector.js`
- `blocks/accordion/components/ThemeListItem.js`
- `blocks/accordion/components/inspector/SettingsPanel.js`
- `blocks/accordion/components/inspector/AppearancePanel.js`
- `blocks/accordion/components/inspector/BorderPanel.js`
- `blocks/accordion/components/inspector/BorderRadiusPanel.js`
- `blocks/accordion/components/inspector/IconPanel.js`
- `blocks/accordion/components/inspector/AnimationPanel.js`

## Component Design Principles
- Each component should be self-contained
- Use PropTypes or TypeScript for type safety
- Include proper JSDoc documentation
- Follow React best practices (hooks, functional components)
- Ensure accessibility (ARIA labels, keyboard navigation)
- Make components reusable and testable

## Testing Requirements
- Test each component in isolation
- Verify all components render correctly in editor
- Test theme management functionality
- Test color picker interactions
- Ensure inspector panels are collapsible/expandable
- Test with various accordion configurations

## Dependencies
- **REQUIRES Phase 1 completion** (constants and utilities must exist)
- Must wait for Constants & Utilities Agent to finish

## Deliverables
- Four reusable React components (Phase 2.1)
- Six inspector panel components (Phase 2.2)
- Updated `index.js` using all new components
- All Phase 2.1 and 2.2 TODO.md checkboxes completed

## Estimated Time
10-14 hours
