# Accordion Block - Variable Transformation Flow Diagram

## Data Flow Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                     SINGLE SOURCE OF TRUTH                          │
│                                                                     │
│  ┌───────────────────────────────────────────────────────────┐    │
│  │              ATTRIBUTE_CONFIG (constants.js)              │    │
│  │  - type, defaultValue, section, isToggle, childAttributes │    │
│  └───────────────┬─────────────────────────────────────┬─────┘    │
│                  │                                     │            │
│         Object.entries + reduce            Object.keys              │
│                  │                                     │            │
│                  ▼                                     ▼            │
│    ┌─────────────────────────┐         ┌──────────────────────┐   │
│    │  CUSTOMIZATION_SECTIONS │         │ CUSTOMIZATION_       │   │
│    │  Grouped by section     │         │ ATTRIBUTES           │   │
│    └──────────┬──────────────┘         └─────┬────────────────┘   │
└───────────────┼─────────────────────────────┼─────────────────────┘
                │                             │
                │                             │
                ▼                             ▼
        ┌───────────────┐          ┌──────────────────┐
        │ UI Panels     │          │ Iteration Logic  │
        │ - Appearance  │          │ - Clearing attrs │
        │ - Border      │          │ - Collecting     │
        │ - Title       │          │ - Validation     │
        └───────────────┘          └──────────────────┘
```

---

## Theme Resolution Flow

```
┌──────────────────────────────────────────────────────────────────┐
│                    VALUE RESOLUTION CASCADE                      │
└──────────────────────────────────────────────────────────────────┘

User Input (Attribute)
    │
    ▼
┌────────────────────┐
│ Block Attributes   │ ◄──── Direct user customization
│ (edit.js:53-89)    │       (ColorPicker, RangeControl, etc.)
└─────────┬──────────┘
          │
          │ Priority 1: Check if attribute is set
          ▼
    ┌──────────┐
    │ Not null?│────── NO ──────┐
    └──────────┘                │
          │ YES                 │
          ▼                     ▼
   Return attribute    ┌────────────────────┐
          value        │ Selected Theme     │ ◄──── Theme chosen in dropdown
                       │ (allThemes[id])    │       (useThemeManagement)
                       └─────────┬──────────┘
                                 │
                                 │ Priority 2: Check theme value
                                 ▼
                           ┌──────────┐
                           │ Not null?│────── NO ──────┐
                           └──────────┘                │
                                 │ YES                 │
                                 ▼                     ▼
                          Return theme        ┌────────────────┐
                               value          │ Default Theme  │ ◄──── System default
                                              │ (default)      │       (Loaded from DB)
                                              └────────┬───────┘
                                                       │
                                                       │ Priority 3: Check default
                                                       ▼
                                                 ┌──────────┐
                                                 │ Not null?│────── NO ──────┐
                                                 └──────────┘                │
                                                       │ YES                 │
                                                       ▼                     ▼
                                                Return default         Return null
                                                     value             (fallback)

┌────────────────────────────────────────────────────────────────────┐
│ Implementation: useEffectiveValue.js:47-78                         │
│ Used in: edit.js:119-124                                          │
│ Called for EVERY attribute in rendering pipeline                   │
└────────────────────────────────────────────────────────────────────┘
```

---

## Rendering Pipeline

```
┌─────────────────────────────────────────────────────────────────────┐
│                         EDITOR (edit.js)                            │
└─────────────────────────────────────────────────────────────────────┘

Attributes + Themes
      │
      ▼
┌───────────────────────────┐
│ useEffectiveValue hook    │ ◄──── Returns getEffectiveValue function
│ (lines 119-124)           │       Memoized with [allThemes, selectedTheme,
└──────────┬────────────────┘       defaultTheme, attributes]
           │
           ├────────────────────────────────┐
           │                                │
           ▼                                ▼
┌─────────────────────────┐    ┌──────────────────────────┐
│ effectiveValues useMemo │    │ sidebarValues hook       │
│ (lines 583-664)         │    │ (line 127)               │
│                         │    │ useEffectiveValues       │
│ - headerBg              │    └──────────────────────────┘
│ - headerText            │              │
│ - borderWidth           │              │ DUPLICATION WARNING
│ - iconPosition          │              │ Both compute effective
│ - [30+ values]          │              │ values differently!
└──────────┬──────────────┘              │
           │                              ▼
           │                    ┌──────────────────────┐
           │                    │ Used in Inspector    │
           │                    │ Panels for display   │
           │                    └──────────────────────┘
           │
           ▼
┌─────────────────────────┐
│ editorStyles useMemo    │ ◄──── CSS variable mapping
│ (lines 675-724)         │       --header-bg-color: value
│                         │       --border-width: Npx
│ CSS Custom Properties   │
└──────────┬──────────────┘
           │
           ├─────────────────────────────┐
           │                             │
           ▼                             ▼
┌─────────────────────┐      ┌──────────────────────┐
│ blockProps          │      │ Inline styles        │
│ className           │      │ - Header (1103-1134) │
│ style object        │      │ - Content (1196-1244)│
└─────────────────────┘      └──────────────────────┘
           │                             │
           └──────────┬──────────────────┘
                      ▼
             ┌────────────────┐
             │ Rendered HTML  │
             │ <div> blocks   │
             └────────────────┘


┌─────────────────────────────────────────────────────────────────────┐
│                       FRONTEND (save.js)                            │
└─────────────────────────────────────────────────────────────────────┘

Attributes (saved to post_meta)
      │
      ├────────────────────────────────────┐
      │                                    │
      ▼                                    ▼
┌──────────────────────┐       ┌──────────────────────────┐
│ getEffectiveIconValues│       │ getTitleStyles           │
│ (lines 13-27)         │       │ (lines 35-86)            │
│                       │       │                          │
│ Computes icon values  │       │ Builds custom title CSS  │
│ with defaults         │       │ if enabled               │
└──────────┬────────────┘       └──────────┬───────────────┘
           │                               │
           └───────────┬───────────────────┘
                       │
                       ▼
              ┌────────────────┐
              │ inlineStyles   │ ◄──── CSS variable mapping
              │ (lines 151-229)│       (DUPLICATES styleHelpers.js!)
              │                │
              │ - Colors       │
              │ - Borders      │
              │ - Border radius│
              │ - Alignment    │
              └────────┬───────┘
                       │
                       ▼
              ┌────────────────┐
              │ classNames     │ ◄──── CSS class array
              │ (lines 268-287)│       - theme class
              │                │       - animation class
              │ array building │       - state classes
              └────────┬───────┘
                       │
                       ▼
              ┌────────────────┐
              │ blockProps     │ ◄──── useBlockProps.save
              │ className      │       Combines classes + styles
              │ style          │
              │ data-theme     │
              └────────┬───────┘
                       │
                       ▼
              ┌────────────────┐
              │ Rendered HTML  │ ◄──── Final frontend output
              │ with inline    │       Saved to post_content
              │ styles + CSS   │
              └────────────────┘
```

---

## Customization State Machine

```
┌──────────────────────────────────────────────────────────────────┐
│              CUSTOMIZATION STATE FLOW                            │
└──────────────────────────────────────────────────────────────────┘

      START: Clean Theme
      │
      │ selectedTheme: "theme-X"
      │ baseTheme: "theme-X"
      │ isCustomized: false
      │ attributes: all null
      │
      ▼
┌─────────────────────┐
│ User changes color  │
│ or other attribute  │
└──────────┬──────────┘
           │
           │ setAttributes({ headerBg: "#007cba" })
           │ markAsCustomized() called
           ▼
    ┌──────────────┐
    │ Compare with │
    │ theme values │
    └──────┬───────┘
           │
           ▼
     ┌─────────┐
     │Different?│─── NO ──► Don't mark as customized
     └─────────┘           (false positive prevention)
           │ YES
           ▼
      isCustomized: true
      baseTheme: "theme-X"
      selectedTheme: "theme-X"
      │
      │ Dropdown now shows: "Theme X (custom)"
      │
      ▼
┌─────────────────────┐
│ User switches theme │
│ to "theme-Y"        │
└──────────┬──────────┘
           │
           │ Save to cache BEFORE switching:
           │ customizationCache["theme-X"] = {
           │   headerBg: "#007cba",
           │   isCustomized: true,
           │   baseTheme: "theme-X"
           │ }
           │
           ▼
      Clear attributes
      selectedTheme: "theme-Y"
      baseTheme: "theme-Y"
      isCustomized: false
      │
      │ Dropdown shows: "Theme Y" (clean)
      │               + "Theme X (custom)" (cached)
      │
      ▼
┌──────────────────────────┐
│ User switches back to    │
│ "theme-X-customized"     │
└──────────┬───────────────┘
           │
           │ Restore from cache:
           │ customizationCache["theme-X"]
           │
           ▼
      isCustomized: true
      baseTheme: "theme-X"
      selectedTheme: "theme-X"
      headerBg: "#007cba" (restored)
      │
      ▼
┌─────────────────────┐
│ User saves post     │
└──────────┬──────────┘
           │
           │ If isCustomized: Save attributes to post_meta
           │ If NOT customized: Cache is LOST (warning shown)
           │
           ▼
      Customizations persisted to database
```

---

## Theme Management Flow

```
┌──────────────────────────────────────────────────────────────────┐
│                    THEME CRUD OPERATIONS                         │
└──────────────────────────────────────────────────────────────────┘

┌─────────────────┐
│ Component Mount │
└────────┬────────┘
         │
         │ useEffect(() => reloadThemes(), [])
         ▼
┌────────────────────┐
│ loadThemes() AJAX  │ ◄──── GET /wp-admin/admin-ajax.php
└────────┬───────────┘       action: get_accordion_themes
         │
         │ Response: { themes: { default: {...}, theme-XX: {...} }}
         ▼
┌────────────────────┐
│ setAllThemes(data) │
│ setDefaultTheme()  │
└────────┬───────────┘
         │
         ├──────────────────────────────┐
         │                              │
         ▼                              ▼
┌─────────────────┐          ┌──────────────────────┐
│ SELECT THEME    │          │ CREATE NEW THEME     │
└────────┬────────┘          └──────────┬───────────┘
         │                              │
         │ handleThemeChange()          │ handleCreateTheme()
         │                              │
         ▼                              ▼
┌─────────────────┐          ┌──────────────────────┐
│ Switch theme    │          │ Generate short ID    │
│ Clear attributes│          │ "theme-X7"           │
└─────────────────┘          └──────────┬───────────┘
                                        │
                                        │ saveTheme(id, settings)
                                        ▼
                             ┌──────────────────────┐
                             │ POST to server       │
                             │ action: save_        │
                             │ accordion_theme      │
                             └──────────┬───────────┘
                                        │
                                        │ Response: { themes: {...} }
                                        ▼
                             ┌──────────────────────┐
                             │ setAllThemes(themes) │
                             │ Dispatch event:      │
                             │ accordionThemeUpdated│
                             └──────────┬───────────┘
                                        │
                                        │ Other blocks listen
                                        ▼
                             ┌──────────────────────┐
                             │ All accordions using │
                             │ this theme switch to │
                             │ clean version        │
                             └──────────────────────┘

┌─────────────────┐          ┌──────────────────────┐
│ UPDATE THEME    │          │ DELETE THEME         │
└────────┬────────┘          └──────────┬───────────┘
         │                              │
         │ handleSaveTheme()            │ handleDeleteTheme()
         │                              │
         ▼                              ▼
┌─────────────────┐          ┌──────────────────────┐
│ Collect         │          │ Confirm with user    │
│ effectiveValues │          │ if (confirm(...))    │
│ (current look)  │          └──────────┬───────────┘
└────────┬────────┘                     │
         │                              │ deleteTheme(id) AJAX
         │ saveTheme(id, settings)      ▼
         ▼                   ┌──────────────────────┐
┌─────────────────┐          │ Remove from database │
│ Merge with      │          │ Return updated themes│
│ existing theme  │          └──────────┬───────────┘
└────────┬────────┘                     │
         │                              ▼
         ▼                   ┌──────────────────────┐
┌─────────────────┐          │ setAllThemes(themes) │
│ POST to server  │          │ Reset to default     │
└────────┬────────┘          │ if was selected      │
         │                   └──────────────────────┘
         │ Response
         ▼
┌─────────────────┐
│ Dispatch event  │
│ Other accordions│
│ reload theme    │
└─────────────────┘
```

---

## Key Transformation Hotspots

### 1. ATTRIBUTE_CONFIG → Derived Constants (constants.js)
```javascript
ATTRIBUTE_CONFIG (object)
    │
    ├─ Object.entries + reduce ──► CUSTOMIZATION_SECTIONS (grouped)
    │                               { colors: [...], border: [...], ... }
    │
    └─ Object.keys ──────────────► CUSTOMIZATION_ATTRIBUTES (flat array)
                                    ['headerBackgroundColor', 'borderWidth', ...]
```

**Used by:**
- Edit panels (UI organization)
- Clearing logic (iteration)
- Comparison logic (validation)

---

### 2. Effective Value Resolution (useEffectiveValue.js)
```javascript
attribute + theme + default
    │
    └─ Priority cascade ──► effectiveValue
       1. attribute !== null → return attribute
       2. theme[attr] !== null → return theme[attr]
       3. default[attr] !== null → return default[attr]
       4. return null
```

**Used by:**
- Rendering (editor + frontend)
- Inspector panels (display values)
- Style generation (CSS variables)

---

### 3. CSS Variable Mapping (edit.js, save.js)
```javascript
effectiveValues / attributes
    │
    └─ Conditional mapping ──► inlineStyles object
       { '--header-bg-color': '#007cba',
         '--border-width': '2px',
         'marginLeft': 'auto' }
```

**Used by:**
- Editor block styles
- Frontend block styles
- Theme overrides

---

### 4. Customization Detection (edit.js)
```javascript
attributes + theme
    │
    └─ Compare each attribute ──► isCustomized boolean
       for (attr of CUSTOMIZATION_ATTRIBUTES) {
         if (isAttributeCustomization(attr, value, themeValue))
           return true
       }
```

**Used by:**
- Auto-cleanup effect
- markAsCustomized function
- Theme switch logic

---

## Optimization Targets

### Priority 1: Reduce Duplication
```
BEFORE:
  edit.js:152   ───┐
  edit.js:278   ───┤
  edit.js:353   ───┼─► CUSTOMIZATION_ATTRIBUTES.forEach(clear)
  edit.js:371   ───┤
  edit.js:450   ───┤
  edit.js:472   ───┘

AFTER:
  clearAllCustomizationAttributes(setAttributes)  ◄── Single utility
```

### Priority 2: Consolidate Effective Values
```
BEFORE:
  effectiveValues (rendering)   ─┐
  sidebarValues (UI controls)   ─┼─► 2 separate computations
                                  │
AFTER:
  Single effective values source ◄── Unified computation
```

### Priority 3: Use Existing Utilities
```
BEFORE:
  save.js: Manual CSS variable mapping (151-229)

AFTER:
  import { buildInlineStyles } from './utils/styleHelpers'
  const inlineStyles = buildInlineStyles(attributes)
```

---

## End-to-End Example: Changing Header Color

```
1. User clicks color picker
   └─► ColorPickerControl onChange

2. setAttributes({ headerBackgroundColor: "#FF0000" })
   └─► Triggers re-render

3. effectiveValues useMemo recalculates
   └─► getEffectiveValue('headerBackgroundColor')
       ├─ Check attribute: "#FF0000" ✓ (found)
       └─ Return "#FF0000"

4. editorStyles useMemo recalculates
   └─► { '--header-bg-color': '#FF0000' }

5. blockProps.style updated
   └─► React applies inline styles

6. Browser renders with new color
   └─► User sees change immediately

7. markAsCustomized() called
   └─► Compares "#FF0000" vs theme value
       ├─ Different? → isCustomized: true
       └─ Same? → Don't mark (false positive prevention)

8. Dropdown updates
   └─► "Theme X (custom)" appears

9. User saves post
   └─► headerBackgroundColor: "#FF0000" saved to post_meta

10. Frontend load (save.js)
    └─► inlineStyles['--header-bg-color'] = "#FF0000"
        └─► CSS variable applied
            └─► Color renders on frontend
```

---

## Summary

**Total transformation steps in typical render:** ~150-200
- **Hot path operations:** 30-50 per render
- **Duplication factor:** 20 transformations duplicated (27%)
- **Optimization potential:** High (utilities can reduce by 15-20%)

**Critical paths:**
1. Effective value resolution (used everywhere)
2. CSS variable mapping (rendering pipeline)
3. Customization detection (state management)
4. Theme CRUD operations (data persistence)

**Bottlenecks:**
1. effectiveValues useMemo (20+ dependencies)
2. Duplicate getThemeValue calls in panels
3. Manual inline styles building in save.js
4. Multiple attribute clearing patterns
