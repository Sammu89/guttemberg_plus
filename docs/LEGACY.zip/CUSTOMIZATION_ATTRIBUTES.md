# Accordion Block Customization Attributes

This document lists all customizable attributes in the accordion block, grouped by section.
Here's how things work: accordion.css gives the default values to the sidebar for css values. Other defaults are stored on database. The null values means that the fallback is always accordion.css and the customization is empty

**Total Customization Attributes: 33**

**Toggles: 2**
- `showIcon` (controls 4 children)
- `useCustomTitleFormatting` (controls 9 children)

---

## ANIMATION

### animationSpeed
- Type: `string`
- Default: `normal`
- Values: `'no animation'`,`'slow'`, `'normal'`, `'fast'`
- Notes: Controls how fast the accordion opens/closes, and no animation deletes the animation.

---

## COLORS

### headerBackgroundColor
- Type: `string`
- Default: `null` - reads from accordion.css for fallback value, this way if the plugin compares this to Default theme, the value is the same
- Notes: Background color of accordion header

### headerTextColor
- Type: `string`
- Default: `null`  - reads from accordion.css for fallback value, this way if the plugin compares this to Default theme, the value is the same
- Notes: Text color of accordion header

### headerHoverColor
- Type: `string`
- Default: `null` - reads from accordion.css for fallback value, this way if the plugin compares this to Default theme, the value is the same
- Notes: Hover color for accordion header

### contentBackgroundColor
- Type: `string`
- Default: transparent
- Notes: Background color of accordion content area

### contentBackgroundTransparent #lets delete all of this, as contentBackgroundColor will handle it
- Type: `boolean`
- Default: `true` 
- treatFalseAsCustomization: `false`
- Notes: Makes content background transparent

---

## MAIN BORDER

### borderColor
- Type: `string`
- Default: `null` - reads from accordion.css for fallback value, this way if the plugin compares this to Default theme, the value is the same
- Notes: Border color around accordion

### borderWidth
- Type: `number`
- Default: `null` - reads from accordion.css for fallback value, this way if the plugin compares this to Default theme, the value is the same
- Notes: Border width in pixels

### borderStyle
- Type: `string`
- Default: `solid` 
- Values: `'solid'`, `'dashed'`, `'dotted'`, etc.

---

## BORDER RADIUS

### borderRadiusTopLeft
- Type: `number`
- Default: `null`
- Notes: Top-left corner radius

### borderRadiusTopRight
- Type: `number`
- Default: `null`
- Notes: Top-right corner radius

### borderRadiusBottomLeft
- Type: `number`
- Default: `null`
- Notes: Bottom-left corner radius

### borderRadiusBottomRight
- Type: `number`
- Default: `null`
- Notes: Bottom-right corner radius

---

## DIVIDER BORDER

### dividerBorderColor
- Type: `string`
- Default: `null`
- Notes: Color of divider between accordions

### dividerBorderWidth
- Type: `number`
- Default: `null`
- Notes: Width of divider

### dividerBorderStyle
- Type: `string`
- Default: `null`
- Values: `'solid'`, `'dashed'`, `'dotted'`, etc.

---

## ICON

### 🔘 showIcon (TOGGLE)
- Type: `boolean`
- Default: `true`
- **IS TOGGLE** - Controls 4 child attributes
- **Children:** `icon`, `iconType`, `iconPosition`, `animateIcon`
- Notes: Master toggle for icon display, if its off, disables the children and their values are not passed as a customization. Any modification to the children when its enabled also are a customization

#### ↳ icon (child of showIcon)
- Type: `string`
- Default: `null`
- Notes: The icon character or class name

#### ↳ iconType (child of showIcon)
- Type: `string`
- Default: `character`
- Values: `'character'`, `'dashicon'`, `'custom'`

#### ↳ iconPosition (child of showIcon)
- Type: `string`
- Default: `left`
- Values: `'left'`, `'right'`

#### ↳ animateIcon (child of showIcon)
- Type: `boolean`
- Default: `true`
- Notes: Whether icon rotates when accordion opens

---

## TITLE FORMATTING

### useHeading ⚠️ SPECIAL BOOLEAN
- Type: `boolean`
- Default: `false`
- **treatFalseAsCustomization: `true`** <--- why is this for?
- Notes: Render title as semantic HTML heading (H1-H6)

### headingLevel
- Type: `string`
- Default: `'h2'`
- Values: `'h1'`, `'h2'`, `'h3'`, `'h4'`, `'h5'`, `'h6'`
- Notes: Which heading level to use (only if useHeading is true)

### useHeadingStyles ⚠️ SPECIAL BOOLEAN
- Type: `boolean`
- Default: `false`
- **treatFalseAsCustomization: `true`** <--- why is this for?
- **MUTUALLY EXCLUSIVE** with `useCustomTitleFormatting`
- Notes: Apply theme's heading styles

### 🔘 useCustomTitleFormatting (TOGGLE + SPECIAL)
- Type: `boolean`
- Default: `false`
- **treatFalseAsCustomization: `true`** <--- why is this for?
- **IS TOGGLE** - Controls 9 child attributes
- **MUTUALLY EXCLUSIVE** with `useHeadingStyles`
- **Children:** `titleTextAlign`, `titleFontSize`, `titleFontWeight`, `titleFontStyle`, `titleTextTransform`, `titleLetterSpacing`, `titleWordSpacing`, `titleTextDecoration`, `titleFontFamily` if its off, disables the children and their values are not passed as a customization

#### ↳ titleTextAlign (child of useCustomTitleFormatting)
- Type: `string`
- Default: `null`
- Values: `'left'`, `'center'`, `'right'`

#### ↳ titleFontSize (child of useCustomTitleFormatting)
- Type: `string`
- Default: `null`

#### ↳ titleFontWeight (child of useCustomTitleFormatting)
- Type: `string`
- Default: `null`
- Values: `'normal'`, `'bold'`, `'100'`-`'900'`

#### ↳ titleFontStyle (child of useCustomTitleFormatting)
- Type: `string`
- Default: `null`
- Values: `'normal'`, `'italic'`, `'oblique'`

#### ↳ titleTextTransform (child of useCustomTitleFormatting)
- Type: `string`
- Default: `null`
- Values: `'none'`, `'uppercase'`, `'lowercase'`, `'capitalize'`

#### ↳ titleLetterSpacing (child of useCustomTitleFormatting)
- Type: `string`
- Default: `null`

#### ↳ titleWordSpacing (child of useCustomTitleFormatting)
- Type: `string`
- Default: `null`

#### ↳ titleTextDecoration (child of useCustomTitleFormatting)
- Type: `string`
- Default: `null`
- Values: `'none'`, `'underline'`, `'overline'`, `'line-through'`

#### ↳ titleFontFamily (child of useCustomTitleFormatting)
- Type: `string`
- Default: `null`

---

## SPECIAL BEHAVIORS

### Toggle Attributes
Toggle attributes control whether their children are active:
- `showIcon` (controls 4 child attributes)
- `useCustomTitleFormatting` (controls 9 child attributes)

**Current behavior:** A toggle is only detected as customized if ANY of its children differ from the theme.

**Problem:** Turning on a toggle (e.g., `showIcon: false → true`) without changing children is NOT detected as customization but it should, because they trigger a action.



## NON-CUSTOMIZATION ATTRIBUTES

These are NOT included in customization detection:
- `title` - The accordion title text
- `accordionId` - Unique ID for the accordion
- `isOpen` - Whether accordion is open by default
- `disabled` - Whether accordion is disabled
- `width` - Accordion width setting
- `horizontalAlign` - Horizontal alignment
- `isOpenInEditor` - Editor-only state
- `selectedTheme` - Current theme ID
- `baseTheme` - Base theme for customizations
- `isCustomized` - Flag indicating customization state
